const fs = require('fs')

const generateSSRWebConfig = () => {
    const webConfig = `<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <system.web>
    <httpCookies httpOnlyCookies="true" requireSSL="true" lockItem="true" />
  </system.web>
  <system.webServer>
    <webSocket enabled="false" />
    <handlers>
      <add name="iisnode" path="server.js" verb="*" modules="iisnode"/>
    </handlers>
    <iisnode nodeProcessCommandLine="&quot;D:\\Program Files (x86)\\nodejs\\${process.env.NODEVERSION}\\node.exe&quot; --max-http-header-size 16384"/>
    <rewrite>
      <rules>
        <rule name="NodeInspector" patternSyntax="ECMAScript" stopProcessing="true">
          <match url="^server.js\\/debug[\\/]?" />
        </rule>

        <rule name="StaticContent">
          <action type="Rewrite" url="public{REQUEST_URI}"/>
        </rule>

        <rule name="DynamicContent">
          <conditions>
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true"/>
          </conditions>
          <action type="Rewrite" url="server.js"/>
        </rule>

        <rule name="HTTP to HTTPS redirect" stopProcessing="true">
          <match url="(.*)" />
          <conditions>
            <add input="{HTTPS}" pattern="off" ignoreCase="true" />
          </conditions>
          <action type="Redirect" url="https://{HTTP_HOST}/{R:1}" redirectType="Permanent" />
          </rule>
      </rules>

      <outboundRules>
        <rule name="Add Strict-Transport-Security when HTTPS" enabled="true">
          <match serverVariable="RESPONSE_Strict_Transport_Security" pattern=".*" />
          <conditions>
            <add input="{HTTPS}" pattern="on" ignoreCase="true" />
          </conditions>
          <action type="Rewrite" value="max-age=31536000" />
        </rule>
      </outboundRules>
    </rewrite>

    <security>
      <requestFiltering>
        <hiddenSegments>
          <remove segment="bin"/>
        </hiddenSegments>
      </requestFiltering>
    </security>

    <httpErrors errorMode="Detailed" existingResponse="PassThrough" />

  </system.webServer>
</configuration>`

    fs.writeFileSync(`web.config`, webConfig)
}

module.exports = generateSSRWebConfig
