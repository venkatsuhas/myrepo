const fs = require('fs')
const getPages  = require('../../src/adapters/contentful/queries/get-pages')

require('dotenv').config()

const getSitemapItemsXml = (pages, domain) => {
    const sitemapItemsXml = pages
        .map((page) => {
            const { canonicalUrl='' } = page.fields
            const pageUpdatedDate = page.sys.updatedAt

            const pageHref = `${domain}/${canonicalUrl}`

            return `<url>
            <loc>${pageHref}</loc>
            <lastmod>${pageUpdatedDate}</lastmod>
            <xhtml:link rel="alternate" hreflang="en-us" href="${pageHref}"/>
            </url>`
        })
        .reduce((string, curr) => string + curr)

    return sitemapItemsXml
}

const createSitemap = async () => {
    const pages = await getPages()
    // const pages = []

    const domain = process.env.DOMAIN || 'https://localhost:3000'

    return `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
        <url>
            <loc>${domain}/</loc>
        </url>
      ${pages?.length > 0 ? getSitemapItemsXml(pages, domain) : ''}
      </urlset>`
}

const generateSitemap = async () => {
    fs.writeFileSync('out/sitemap.xml', await createSitemap());
    console.info(":: :: :: :: sitemap.xml created  :: :: :: ::")

}

module.exports = generateSitemap
