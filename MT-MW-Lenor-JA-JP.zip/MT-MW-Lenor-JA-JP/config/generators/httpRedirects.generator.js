const fs = require("fs")
const generateHttpRedirects = () => {
    const httpRedirectionRules = `
    <httpRedirect enabled="true" exactDestination="true" httpResponseStatus="Permanent">
        <add wildcard="/" destination="/ja-jp" />
    </httpRedirect>
    `

    fs.writeFileSync(`out/httpRedirects.config`, httpRedirectionRules)
}

module.exports = generateHttpRedirects
