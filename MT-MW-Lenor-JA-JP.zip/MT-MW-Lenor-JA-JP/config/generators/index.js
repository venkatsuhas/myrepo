const generateSitemap = require('./sitemap.generator')
const generateRobots = require('./robots.generator')
const generateSSGWebConfig = require('./ssg-web.config.generator')
const generateSSRWebConfig = require('./ssr-web.config.generator')
const generateHttpRedirects = require('./httpRedirects.generator')
const generateRedirectionRules = require('./redirectionRules.generator')

module.exports = {
  generateSSGConfigs: () => {
    generateRobots()
    generateSitemap()
    generateSSGWebConfig()
    generateHttpRedirects()
    generateRedirectionRules()
  },
  generateSSRConfigs: () => {
    generateSSRWebConfig()
  },
}
