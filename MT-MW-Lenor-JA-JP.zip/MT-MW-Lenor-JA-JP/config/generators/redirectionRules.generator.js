const siteUrl = process.env.DOMAIN || 'https://www.lenorjapan.jp'
const fs = require('fs')

const generateRedirectionRules = () => {
    const redirectionRules = `<rules>
    <rule name="Remove trailing slash" stopProcessing="true">
        <match url="(.*)/$" />
        <conditions>
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="false" />
        </conditions>
        <action type="Redirect" redirectType="Permanent" url="${siteUrl}/{R:1}" />	   
    </rule>
    <rule name="HTTP to HTTPS redirect" stopProcessing="true">
        <match url="(.*)" />
        <conditions>
            <add input="{HTTPS}" pattern="off" ignoreCase="true" />
        </conditions>
        <action type="Redirect" redirectType="Permanent" url="https://{HTTP_HOST}/{R:1}" />
    </rule>
    <rule name="No slash root" enabled="true" stopProcessing="true">
      <match url="^(.*[^/])$" />
      <conditions>
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" />
      </conditions>
      <action type="Rewrite" url="{R:1}/index.html" />
    </rule>
</rules>`

    fs.writeFileSync(`out/redirectionRules.config`, redirectionRules)
}

module.exports = generateRedirectionRules

