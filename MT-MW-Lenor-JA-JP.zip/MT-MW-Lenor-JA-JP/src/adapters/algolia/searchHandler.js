import algoliaSearch from 'algoliasearch/lite'
import { productsPerPageSearch, articlesPerPageSearch } from '@constants'

const client = algoliaSearch(
    process.env.ALGOLIA_APP_ID,
    process.env.ALGOLIA_READ_KEY,
)

const searchHandler = ({ searchTerm, page, type, limit }) =>
    new Promise((resolve, reject) => {
        if (type === 'all') {
            const queries = [
                {
                    indexName: process.env.ALGOLIA_PRODUCT_INDEX_ID,
                    query: searchTerm,
                    params: {
                        hitsPerPage: limit || productsPerPageSearch,
                        page: page || 0,
                    },
                },
                {
                    indexName: process.env.ALGOLIA_ARTICLE_INDEX_ID,
                    query: searchTerm,
                    params: {
                        hitsPerPage: limit || articlesPerPageSearch,
                        page: page || 0,
                    },
                },
            ]
            client.multipleQueries(queries).then(resolve).catch(reject)
        } else if (type === 'product') {
            client
                .initIndex(process.env.ALGOLIA_PRODUCT_INDEX_ID)
                .search(searchTerm, {
                    hitsPerPage: limit || productsPerPageSearch,
                    page: page || 0,
                })
                .then(resolve)
                .catch(reject)
        } else if (type === 'article') {
            client
                .initIndex(process.env.ALGOLIA_ARTICLE_INDEX_ID)
                .search(searchTerm, {
                    hitsPerPage: limit || articlesPerPageSearch,
                    page: page || 0,
                })
                .then(resolve)
                .catch(reject)
        }
    })

export default searchHandler
