import dataFetcher from '@adapters/algolia/dataFetchHandler'
import algoliaSearch from 'algoliasearch'

const client = algoliaSearch(
    process.env.ALGOLIA_APP_ID,
    process.env.ALGOLIA_WRITE_KEY,
)

export const dataPushHandler = async () => {
    const data = await dataFetcher()

    const productIndex = client.initIndex(process.env.ALGOLIA_PRODUCT_INDEX_ID)
    productIndex
        .partialUpdateObjects(data.products, { createIfNotExists: true })
        .then(({ objectIDs }) => {
            console.info(`Successfully Pushed ${objectIDs.length} Product Records`)
        })
        .catch((err) => {
            console.error('Error Pushing Data')
            console.error(err)
        })
    const articleIndex = client.initIndex(process.env.ALGOLIA_ARTICLE_INDEX_ID)
    articleIndex
        .partialUpdateObjects([...data.articles, ...data.experiences], {
            createIfNotExists: true,
        })
    // .partialUpdateObjects(data.articles, {
    //     createIfNotExists: true,
    //   })
        .then(({ objectIDs }) => {
            console.info(`Successfully Pushed ${objectIDs.length} Article Records`)
        })
        .catch((err) => {
            console.error('Error Pushing Data')
            console.error(err)
        })
}
