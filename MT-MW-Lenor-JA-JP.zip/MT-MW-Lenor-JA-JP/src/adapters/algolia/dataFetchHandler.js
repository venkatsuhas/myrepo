import { locales } from '@constants'
import queryHandler from '@contentful/contentful.adapter'
import { getMappedSearchData } from '@contentful/dataMappers/Algolia.mapper'

const dataFetcher = () =>
    new Promise((resolve, reject) => {
        Promise.all([
            queryHandler({
                content_type: 'productContainer',
                limit: 500,
                depth: 10,
                locale: locales.japanese,
            }),
            queryHandler({
                content_type: 'articleContainer',
                limit: 500,
                depth: 10,
                locale: locales.japanese,
            }),
            queryHandler({
                content_type: 'experienceContainer',
                limit: 500,
                depth: 10,
                locale: locales.japanese,
            }),
        ])
            .then(
                ([
                    productCollectionJA,
                    articleCollectionJA,
                    experienceCollectionJA,
                ]) => {
                    const mappedData = getMappedSearchData(
                        [...productCollectionJA.items],
                        [...articleCollectionJA.items],
                        [...experienceCollectionJA.items],
                    )
                    resolve(mappedData)
                },
            )
            .catch(reject)
    })

export default dataFetcher
