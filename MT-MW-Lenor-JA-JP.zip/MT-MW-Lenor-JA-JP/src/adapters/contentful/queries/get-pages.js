const { getContentfulClient } = require('../index')

// This is an example for quering pages
// Can be deleted and replaced
const getPages = async () => {
    const client = getContentfulClient()

    const query = {
        locale: 'ja-JP',
        content_type: 'pageMetadata',
    }
    if (client !== null) {
        const { items } = await client.getEntries(query)
        return items
    }

    return []
}
module.exports = getPages
