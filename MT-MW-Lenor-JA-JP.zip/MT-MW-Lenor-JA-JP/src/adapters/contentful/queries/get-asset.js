const { getContentfulClient } = require('../index')

// This is an example for quering pages
// Can be deleted and replaced

const getAsset = async (title) => {
    const client = getContentfulClient()

    const query = {
        limit: 1,
        include: 10,
        'fields.title': title,
    }

    const {
        items: [asset],
    } = await client.getAssets(query)

    return asset
}
module.exports = getAsset
