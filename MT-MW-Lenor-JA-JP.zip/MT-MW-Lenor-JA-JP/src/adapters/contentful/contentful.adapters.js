import { locales } from 'src/constants'
const contentful = require('contentful')

export const client = contentful.createClient({
    space: process.env.CF_SPACE_ID,
    environment: process.env.CF_ENVIRONMENT,
    ...(process.env.CF_PREVIEW?.trim() == 'true'
        ? {
            accessToken: process.env.CF_PREVIEW_ACCESS_TOKEN,
            host: 'preview.contentful.com',
        }
        : {
            accessToken: process.env.CF_DELIVERY_ACCESS_TOKEN,
        }),
})

const queryHandler = ({ content_type, depth, locale, limit, ...fields }) =>
    client.getEntries({
        ...(content_type ? { content_type: content_type } : {}),
        ...(limit ? { limit } : {}),
        ...{ include: depth || 5, locale: locale || locales.japanese },
        ...(Object.keys(fields)
            ? Object.keys(fields).reduce(
                (prevState, field) => ({
                    ...prevState,
                    [`fields.${field}`]: fields[field],
                }),
                {},
            )
            : {}),
    })

export default queryHandler
