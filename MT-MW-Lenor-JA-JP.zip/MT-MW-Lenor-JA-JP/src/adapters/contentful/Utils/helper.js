const setTypeName = (type) => {
    switch (type) {
    case 'imageSet':
        return 'ImageSet'
    case 'product':
        return 'Product'
    case 'richText':
        return 'ContentTypeRichText'
    case 'article':
        return 'Article'
    case 'category':
        return 'Category'
    case 'image':
        return 'Image'
    case 'sectionContainer':
        return 'SectionContainer'
    case 'banner':
        return 'Banner'
    case 'linkButton':
        return 'LinkButton'
    case 'imageButton':
        return 'ImageButton'
    case 'imageText':
        return 'ImageText'
    case 'howItWorks':
        return 'HowItWorks'
    case 'articleLiner':
        return 'ArticleLiner'
    case 'video':
        return 'Video'
    case 'imageButtonCollection':
        return 'ImageButtonCollection'
    case 'iconImgBanner':
        return 'IconImgBanner'
    default:
        break
    }
}

const getCallToActionData = (data) => {
    let callToActionCollection = {
        items: [],
    }
    data?.forEach((callToActionData) => {
        callToActionCollection?.items?.push({ ...getLinkButton(callToActionData) })
    })
    return callToActionCollection
}

const getCard = (cardData) => {
    return {
        sys: { id: cardData.sys?.id, __typename: 'Sys' },
        __typename: 'Callout',
        name: cardData.fields?.name || null,
        text: cardData?.fields?.text || null,
        title: cardData.fields?.title || null,
        subTitle: cardData?.fields?.subTitle || null,
        supportingText: cardData?.fields?.supportingText || null,
        variant: cardData?.fields?.variant || null,
        isLazyLoad: cardData?.fields?.isLazyLoad || false,
        styles: cardData?.fields?.styles || null,
        link: cardData?.fields?.link || null,
        image: cardData?.fields?.image
            ? getImage(cardData?.fields?.image || {})
            : cardData?.fields?.imageSet
                ? getImageSet(cardData?.fields?.imageSet || {})
                : {},
        componentWidth:
      getComponentWidth(cardData?.fields?.componentWidth || {}) || {},
        callToActionsCollection: getCallToActionData(
            cardData?.fields?.callToActions,
        ),
    }
}

const iterateImageFields = (fieldData) => {
    if (fieldData) {
        return {
            sys: { id: fieldData.sys?.id, __typename: 'Sys' },
            url: fieldData.fields.file?.url || null,
            title: fieldData.fields?.title || null,
            fileName: fieldData.fields?.fileName || null,
        }
    }
    return null
}

const productImageVideoData = (data) => {
    let productImageVideoCollection = {
        items: [],
        __typename: 'ProductProductImageVideoCollection',
    }
    data.forEach((productImageItem) => {
        productImageVideoCollection.items.push({
            ...productImageItem.fields,
            sys: { id: productImageItem.sys.id, __typename: 'Sys' },
            altText: productImageItem.fields.altText || null,
            gaEventClass: productImageItem?.fields?.gaEventClass || null,
            gaEventLabel: productImageItem?.fields?.gaEventLabel || null,
            styles: productImageItem.fields.styles || null,
            toolTip: productImageItem.fields.toolTip || null,
            __typename: setTypeName(productImageItem.sys.contentType.sys.id),
            image: {
                title: productImageItem?.fields?.image?.fields?.title || null,
                url: productImageItem?.fields?.image?.fields?.file?.url || null,
            },
        })
    })
    return productImageVideoCollection
}

const imageSetFields = (fieldData) => {
    return {
        ...fieldData.fields,
        altText: fieldData.fields.altText || null,
        link: fieldData.fields.link || null,
        linkText: fieldData.fields.linkText || null,
        styles: fieldData.fields.styles || null,
        toolTip: fieldData.fields.toolTip || null,
        sys: { id: fieldData.sys.id, __typename: 'Sys' },
        desktopImage: iterateImageFields(fieldData.fields.desktopImage),
        smartphoneImage: iterateImageFields(fieldData.fields.smartphoneImage),
        tabletImage: iterateImageFields(fieldData.fields.tabletImage),
        __typename: setTypeName(fieldData.sys.contentType.sys.id),
    }
}

const pageMetaData = (metaData) => {
    const openGraphImage =
    {
        url: metaData?.fields?.openGraphImage?.fields?.file?.url || null,
        __typename: 'Asset',
    } || null

    return {
        sys: { id: metaData.sys.id, __typename: 'Sys' },
        ...metaData.fields,
        metaKeywords: metaData.fields.metaKeywords || null,
        openGraphDescription: metaData.fields.openGraphDescription || null,
        openGraphImage: metaData.fields.openGraphImage ? openGraphImage : null,
        openGraphPageTitle: metaData.fields.openGraphPageTitle || null,
    }
}

const richText = (data) => {
    return {
        sys: { id: data.sys.id, __typename: 'Sys' },
        __typename: setTypeName(data.sys.contentType.sys.id),
        ...data.fields,
    }
}

const getComponentWidth = (componentWidth) => {
    return {
        sys: { id: componentWidth?.sys?.id || '', __typename: 'Sys' },
        desktopComponentWidth:
      componentWidth?.fields?.desktopComponentWidth || null,
        smartphoneComponentWidth:
      componentWidth?.fields?.smartphoneComponentWidth || null,
        tabletComponentWidth: componentWidth?.fields?.tabletComponentWidth || null,
    }
}

const getImage = (data) => {
    return {
        sys: { id: data?.sys?.id || '', __typename: 'Sys' },
        __typename: setTypeName(data?.sys?.contentType?.sys?.id || 'Sys'),
        ...data?.fields,
        image: {
            url: data?.fields?.image?.fields?.file?.url || null,
            title: data?.fields?.image?.fields?.title || null,
        },
    }
}

const getLinkButton = (link) => {
    return {
        sys: { id: link?.sys?.id, __typename: 'Sys' },
        ...link?.fields,
        link: link?.fields?.link || null,
        linkText: link?.fields?.linkText || null,
        name: link?.fields?.name || null,
        toolTip: link?.fields?.toolTip || null,
        target: link?.fields?.target || null,
        variant: link?.fields?.variant || null,
        styles: link?.fields?.styles || null,
        gaEventClass: link?.fields?.gaEventClass || null,
        gaEventLabel: link?.fields?.gaEventLabel || null,
        __typename: setTypeName(link?.sys?.contentType?.sys?.id),
        componentWidth: getComponentWidth(link?.fields?.componentWidth || {}) || {},
    }
}

const getImageSet = (data) => {
    return {
        __typename:
      setTypeName(
          data &&
          data.sys &&
          data.sys.contentType &&
          data.sys.contentType.sys &&
          data.sys.contentType.sys.id,
      ) || null,
        name: (data && data.fields && data.fields.name) || null,
        sys: { id: (data && data.sys && data.sys.id) || null, __typename: 'Sys' },
        altText: (data && data.fields && data.fields.altText) || null,
        styles: (data && data.fields && data.fields.styles) || null,
        toolTip: (data && data.fields && data.fields.toolTip) || null,
        desktopImage:
      (data &&
        data.fields &&
        data.fields.desktopImage &&
        iterateImageFields(data.fields.desktopImage)) ||
      null,
        smartphoneImage:
      (data &&
        data.fields &&
        data.fields.smartphoneImage &&
        iterateImageFields(data.fields.smartphoneImage)) ||
      null,
        tabletImage:
      (data &&
        data.fields &&
        data.fields.tabletImage &&
        iterateImageFields(data.fields.tabletImage)) ||
      null,
        componentWidth: getComponentWidth(data?.fields?.componentWidth || {}),
    }
}

const getBreadCrumbData = (data) => {
    let breadCrumbCollection = []
    breadCrumbCollection.push(
        ...data.map((item) => {
            return {
                sys: item.sys.id || null,
                title: item.fields.title || null,
                link: {
                    title: item.fields.link.fields.title || null,
                    url: item.fields.link.fields.url || null,
                },
            }
        }),
    )
    return breadCrumbCollection
}

const setContentCollection = (data) => {
    let sectionContentFields = data.fields
    if (data?.sys?.contentType?.sys?.id === 'richText') {
        return {
            ...sectionContentFields,
            __typename: setTypeName(data.sys?.contentType?.sys?.id),
            componentWidth: getComponentWidth(data?.fields?.componentWidth || {}),
            sys: data?.sys || {},
        }
    }
    if (data?.sys?.contentType?.sys?.id === 'banner') {
        return {
            sys: { id: data?.sys.id, __typename: 'Sys' },
            ...sectionContentFields,
            callToAction: {
                ...sectionContentFields?.callToAction?.fields,
            },
            content: {
                ...sectionContentFields?.content?.fields,
            },
            image: getImageSet(sectionContentFields?.image),
            __typename: setTypeName(data.sys.contentType.sys.id),
        }
    }
    if (data?.sys?.contentType?.sys?.id === 'iconImgBanner') {
        return {
            ...data.fields,
            sys: data.sys,
            __typename: setTypeName(data.sys.contentType.sys.id),
            iconImages: [
                ...data.fields.iconImages.map((iconImage) => {
                    return {
                        ...iconImage.fields,
                        image: getImageSet(iconImage.fields.image),
                    }
                }),
            ],
        }
    }

    if (data?.sys?.contentType?.sys?.id === 'imageText') {
        return {
            ...sectionContentFields,
            image: getImage(sectionContentFields?.image),
            sys: data?.sys || { id: '' },
            imageType: 'image',
            styles: sectionContentFields?.styleVariant,
            __typename: setTypeName(data.sys.contentType.sys.id),
        }
    }
    if (data?.sys?.contentType?.sys?.id === 'image') {
        return {
            ...getImage(data),
        }
    }

    if (data?.sys?.contentType?.sys?.id === 'imageSet') {
        return {
            ...sectionContentFields,
            altText: sectionContentFields?.altText || null,
            link: sectionContentFields?.link || null,
            linkText: sectionContentFields?.linkText || null,
            styles: sectionContentFields?.styles || null,
            toolTip: sectionContentFields?.toolTip || null,
            sys: data?.sys,
            desktopImage: iterateImageFields(sectionContentFields?.desktopImage),
            smartphoneImage: iterateImageFields(
                sectionContentFields?.smartphoneImage,
            ),
            tabletImage: iterateImageFields(sectionContentFields?.tabletImage),
            __typename: setTypeName(data.sys.contentType.sys.id),
        }
    }

    if (data?.sys?.contentType?.sys?.id === 'sectionContainer') {
        let sectionContentCollection = {
            items: [],
        }
        sectionContentCollection.items =
      sectionContentFields?.sectionContent?.map((contentData) => {
          if (contentData?.sys?.contentType?.sys?.id === 'callout') {
              return getCard(contentData)
          } else if (contentData?.sys?.contentType?.sys?.id === 'headingTypes') {
              return {
                  heading: contentData?.fields?.heading || null,
                  headingName: contentData?.fields?.headingName || null,
                  sys: { id: contentData.sys?.id || null, __typename: 'Sys' },
                  __typename: 'HeadingTypes',
                  styles: contentData?.fields?.styles || null,
              }
          } else if (
              contentData?.sys?.contentType?.sys?.id === 'sectionContainer'
          ) {
              return setContentCollection(contentData)
          } else if (contentData?.sys?.contentType?.sys?.id === 'linkButton') {
              return getLinkButton(contentData)
          }
          return setContentCollection(contentData)
      }) || []
        return {
            name: sectionContentFields?.name || null,
            title: sectionContentFields?.title || null,
            styles: sectionContentFields?.styles || null,
            __typename: 'SectionContainer',
            sys: { id: data.sys?.id || null, __typename: 'Sys' },
            componentWidth: getComponentWidth(
                sectionContentFields?.componentWidth || {},
            ),
            sectionContentCollection: sectionContentCollection,
        }
    }

    if (data?.sys?.contentType?.sys?.id === 'imageButton') {
        let imgBtn = data
        return (
            {
                sys: { id: imgBtn.sys?.id, __typename: 'Sys' },
                altText: imgBtn?.fields?.altText || null,
                link: imgBtn?.fields?.link || null,
                linkText: imgBtn?.fields.linkText || null,
                name: imgBtn?.fields?.name || null,
                target: imgBtn?.fields?.target || null,
                styles: imgBtn?.fields?.styles || null,
                __typename: setTypeName(imgBtn.sys.contentType.sys.id),
                image: {
                    title: imgBtn?.fields?.image?.fields?.title || null,
                    url: imgBtn?.fields?.image?.fields?.file?.url || null,
                },
            } || {}
        )
    }

    if (data?.sys?.contentType?.sys?.id === 'imageButtonCollection') {
        let imageButtons = {
            imageButtonCollection: {
                items: [],
            },
        }
    ;(imageButtons.sys = data?.sys),
        (imageButtons.__typename = setTypeName(data.sys.contentType.sys.id))
        if (sectionContentFields?.imageButton) {
            imageButtons.imageButtonCollection.items?.push(
                ...sectionContentFields?.imageButton?.map((imgBtn) => {
                    return (
                        {
                            sys: { id: imgBtn.sys?.id, __typename: 'Sys' },
                            altText: imgBtn?.fields?.altText || null,
                            link: imgBtn?.fields?.link || null,
                            linkText: imgBtn?.fields.linkText || null,
                            name: imgBtn?.fields?.name || null,
                            target: imgBtn?.fields?.target || null,
                            styles: imgBtn?.fields?.styles || null,
                            image: {
                                title: imgBtn?.fields?.image?.fields?.title || null,
                                url: imgBtn?.fields?.image?.fields?.file?.url || null,
                            },
                        } || {}
                    )
                }),
            )
        }

        return imageButtons
    }
    return { ...sectionContentFields }
}

const productVariantCollection = (data) => {
    let dataFields = data.fields
    return {
        name: dataFields?.name || null,
        variantName: dataFields?.variantName || null,
        minPrice: dataFields?.minPrice || null,
        ratingAndReviewId: dataFields?.ratingAndReviewId || null,
        gtin: dataFields?.gtin || null,
        bvFeedGtin: dataFields?.bvFeedGtin || null,
        productImageVideoCollection: productImageVideoData(
            dataFields?.productImageVideo || [],
        ),
    }
}

const relatedProductsCollection = (data) => {
    let dataFields = data.fields
    let variantsCollection = []
    return {
        sys: { id: data.sys?.id, __typename: 'Sys' },
        name: dataFields?.name || null,
        title: dataFields?.title || null,
        slug: dataFields?.slug || null,
        shortDescription: dataFields?.shortDescription || null,
        minPrice: dataFields?.minPrice || null,
        gtin: dataFields?.gtin || null,
        maxPrice: dataFields?.maxPrice || null,
        ratingAndReviewId: dataFields?.ratingAndReviewId || null,
        heroImage: iterateImageFields(dataFields.heroImage || {}),
        url: dataFields?.url || null,
        variants: dataFields.variants.map((variant) => {
            variantsCollection.push({ ...productVariantCollection(variant) })
        }),
    }
}

const relatedArticlesMapping = (data) => {
    let dataFields = data.fields
    return {
        sys: { id: data?.sys?.id, __typename: 'Sys' },
        name: dataFields?.name || null,
        slug: dataFields?.slug || null,
        title: dataFields?.title || null,
        url: dataFields?.url || null,
    }
}

const getPromoImage = (fieldData) => {
    if (fieldData) {
        return {
            sys: { id: fieldData.sys?.id, __typename: 'Sys' },
            url: fieldData.fields?.image.fields?.file?.url || null,
            title: fieldData.fields?.image.fields?.title || null,
            fileName: fieldData.fields?.image.fields?.file?.fileName || null,
            altText: fieldData.fields?.altText || null,
        }
    }
    return null
}

const promosCollection = (data) => {
    let dataFields = data.fields
    return {
        sys: { id: data.sys?.id, __typename: 'Sys' },
        name: dataFields.name || null,
        styles: dataFields.styles || null,
        variant: dataFields.variant || null,
        image: getPromoImage(dataFields?.image),
        componentWidth: getComponentWidth(dataFields?.componentWidth || {}),
        callToActionsCollection: getCallToActionData(
            dataFields?.callToActions || {},
        ),
    }
}

module.exports = {
    setTypeName,
    iterateImageFields,
    pageMetaData,
    productImageVideoData,
    richText,
    getImage,
    getImageSet,
    imageSetFields,
    getBreadCrumbData,
    getComponentWidth,
    getLinkButton,
    setContentCollection,
    getCallToActionData,
    getCard,
    productVariantCollection,
    relatedProductsCollection,
    promosCollection,
    relatedArticlesMapping,
}
