require('dotenv').config()
const { createClient } = require('contentful')

const contentfulClient = process.env.CF_DELIVERY_ACCESS_TOKEN
    ? createClient({
        space: process.env.CF_SPACE_ID,
        environment: process.env.CF_ENVIRONMENT,
        accessToken: process.env.CF_DELIVERY_ACCESS_TOKEN,
    })
    : null

const contentfulPreviewClient = process.env.CF_PREVIEW_ACCESS_TOKEN
    ? createClient({
        space: process.env.CF_SPACE_ID,
        environment: process.env.CF_ENVIRONMENT,
        accessToken: process.env.CF_PREVIEW_ACCESS_TOKEN,
        host: 'preview.contentful.com',
    })
    : null

function getContentfulClient(preview = false) {
    return preview ? contentfulPreviewClient : contentfulClient
}
module.exports = {
    getContentfulClient,
    contentfulClient,
    contentfulPreviewClient,
}
