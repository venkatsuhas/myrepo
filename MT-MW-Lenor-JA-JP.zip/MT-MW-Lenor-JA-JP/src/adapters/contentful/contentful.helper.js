import getContent from '@contentful/contentful.adapter'

import {
    getMappedHeaderData,
    getMappedFooterData,
    getMappedHomepageData,
} from '@contentful/dataMappers'
import {
    getMappedArticleListingData,
    getMappedArticleListingSlug,
    getMappedArticleData,
    getMappedArticleSlug,
    getMappedProductListingData,
    getMappedProductListingSlug,
    getMappedExperienceListingData,
    getMappedExperienceListingSlug,
    getMappedExperienceData,
    getMappedExperienceSlug,
    getMappedSearchData,
    getMappedSitemapData,
} from '@contentful/dataMappers'
import { getMappedContactUsData } from '@contentful/dataMappers/ContactUs.mapper'
import { getMappedErrorPageData } from '@contentful/dataMappers/404.mapper'

import {
    getMappedProductData,
    getMappedProductSlug,
} from '@contentful/dataMappers'

const getPromise = (queryOptions, mapperFunction) =>
    new Promise((resolve, reject) => {
        getContent(queryOptions)
            .then((entries) => {
                const mappedData = mapperFunction(entries)
                resolve(mappedData)
            })
            .catch(reject)
    })
const getADPData = ({ slug, locale }) =>
    getPromise({ content_type: 'article', slug, locale }, getMappedArticleData)

const getFooterData = ({ locale }) =>
    getPromise({ content_type: 'footer', locale }, getMappedFooterData)

const getHeaderData = ({ locale }) =>
    getPromise({ content_type: 'header', locale }, getMappedHeaderData)

const getArticleListingSlug = ({ locale }) =>
    getPromise(
        { content_type: 'articleCategoryContainer', locale },
        getMappedArticleListingSlug,
    )
const getArticleListingData = ({ locale, slug, topics }) =>
    new Promise((resolve, reject) => {
        Promise.all([
            getContent({
                content_type: 'articleCategory',
                ...(topics ? { topics } : {}),
                slug,
                locale,
            }),
            getContent({ content_type: 'articleCategoryContainer', locale }),
            getContent({
                locale,
                content_type: 'articleContainer',
                limit: 500,
            }),
        ])
            .then(([content, container, articles]) => {
                const mappedData = getMappedArticleListingData(
                    content,
                    container,
                    articles,
                )
                resolve(mappedData)
            })
            .catch(reject)
    })

const getADPSlug = ({ locale }) =>
    getPromise(
        { content_type: 'articleContainer', locale, limit: 500 },
        getMappedArticleSlug,
    )
const getExperienceListingData = ({ locale, slug, topics }) =>
    new Promise((resolve, reject) => {
        Promise.all([
            getContent({
                content_type: 'experienceCategory',
                ...(topics ? { topics } : {}),
                slug,
                locale,
                limit: 100,
            }),
            getContent({ content_type: 'experienceCategoryContainer', locale }),
            getContent({
                locale,
                content_type: 'experienceContainer',
                limit: 500,
            }),
        ])
            .then(([content, container, experiences]) => {
                const mappedData = getMappedExperienceListingData(
                    content,
                    container,
                    experiences,
                )
                resolve(mappedData)
            })
            .catch(reject)
    })
const getExperienceListingSlug = ({ locale }) =>
    getPromise(
        { content_type: 'experienceCategoryContainer', locale, limit: 100 },
        getMappedExperienceListingSlug,
    )
const getExperienceData = ({ slug, locale }) =>
    getPromise(
        {
            content_type: 'experience',
            slug,
            locale,
            limit: 100,
        },
        getMappedExperienceData,
    )
const getExperienceSlug = ({ locale }) =>
    getPromise(
        { content_type: 'experience', locale, limit: 500 },
        getMappedExperienceSlug,
    )
const getContactUsData = ({ locale }) =>
    getPromise(
        { content_type: 'generalPage', locale, pageType: 'Contact' },
        getMappedContactUsData,
    )

const getHomePageData = ({ locale }) =>
    getPromise({ content_type: 'homepage', locale }, getMappedHomepageData)
const getProductListingData = ({ slug, locale, topic }) =>
    new Promise((resolve, reject) => {
        Promise.all([
            getContent({
                content_type: 'productCategory',
                ...(slug ? { slug } : {}),
                locale,
                ...(topic ? { topic } : {}),
            }),
            getContent({ content_type: 'productCategoryContainer', locale }),
            getContent({
                // locale,
                content_type: 'productContainer',
                limit: 500,
            }),
        ])
            .then(([content, container, products]) => {
                const mappedData = getMappedProductListingData(
                    content,
                    container,
                    products,
                )
                resolve(mappedData)
            })
            .catch(reject)
    })
const getProductListingSlug = ({ locale }) =>
    getPromise(
        { content_type: 'productCategoryContainer', locale },
        getMappedProductListingSlug,
    )
const getPDPSlug = ({ locale }) =>
    getPromise(
        { content_type: 'productContainer', locale, limit: 500 },
        getMappedProductSlug,
    )
const getPDPData = ({ slug, locale }) =>
    getPromise({ content_type: 'product', slug, locale }, getMappedProductData)

const getSitemapData = ({ locale }) =>
    getPromise({ content_type: 'sitemap', locale }, getMappedSitemapData)

const getSearchPageData = ({ locale }) =>
    getPromise(
        { content_type: 'generalPage', locale, pageType: 'Search' },
        getMappedSearchData,
    )

const getErrorPage = ({ locale }) =>
    getPromise(
        { content_type: 'generalPage', pageType: '404', locale },
        getMappedErrorPageData,
    )

module.exports = {
    getArticleListingSlug,
    getArticleListingData,
    getContactUsData,
    getADPSlug,
    getADPData,
    getHeaderData,
    getFooterData,
    getHomePageData,
    getProductListingData,
    getProductListingSlug,
    getExperienceListingData,
    getExperienceListingSlug,
    getExperienceData,
    getExperienceSlug,
    getPDPData,
    getPDPSlug,
    getSearchPageData,
    getErrorPage,
    getSitemapData,
}
