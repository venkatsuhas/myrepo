import {
    getMappedArticleListingData,
    getMappedArticleListingSlug,
} from '@contentful/dataMappers/ArticleListing.mapper'
import { getMappedContactUsData } from '@contentful/dataMappers/ContactUs.mapper'
import {
    getMappedHeaderData,
    getMappedFooterData,
} from '@contentful/dataMappers/Layout.mapper'
import {
    getMappedExperienceListingData,
    getMappedExperienceListingSlug,
} from '@contentful/dataMappers/ExperienceListing.mapper'
import {
    getMappedExperienceData,
    getMappedExperienceSlug,
} from '@contentful/dataMappers/Experience.mapper'
import {
    getMappedArticleSlug,
    getMappedArticleData,
} from '@contentful/dataMappers/Article.mapper'
import { getMappedHomepageData } from '@contentful/dataMappers/Homepage.mapper'
import {
    getMappedProductListingData,
    getMappedProductListingSlug,
} from '@contentful/dataMappers/ProductListing.mapper'
import { getMappedSearchData } from '@contentful/dataMappers/Search.mapper'

import {
    getMappedProductData,
    getMappedProductSlug,
} from '@contentful/dataMappers/Product.mapper'
import { getMappedSitemapData } from '@contentful/dataMappers/Sitemap.mapper'
module.exports = {
    getMappedArticleSlug,
    getMappedArticleData,
    getMappedArticleListingSlug,
    getMappedArticleListingData,
    getMappedContactUsData,
    getMappedHeaderData,
    getMappedFooterData,
    getMappedHomepageData,
    getMappedProductListingData,
    getMappedProductListingSlug,
    getMappedExperienceListingData,
    getMappedExperienceListingSlug,
    getMappedExperienceData,
    getMappedExperienceSlug,
    getMappedSearchData,
    getMappedProductData,
    getMappedProductSlug,
    getMappedSitemapData,
}
