import { locales, pageTypes } from '@constants'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'
import { getImageData } from '@dataMapperHelper/image.helper'

export const getMappedErrorPageData = (errorData) => {
    const errorPageData = {
        [locales.japanese]: {
            locale: locales.japanese,
            card: {},
        },
    }

    const errorFirstData = errorData?.items[0] && errorData?.items[0]?.fields

    if (errorFirstData) {
        errorPageData.locale = errorData?.items[0]?.sys?.locale || locales.japanese
        errorPageData.card = {
            title: errorFirstData?.card?.fields?.name || null,
            subTitle: errorFirstData?.card?.fields?.subTitle || null,
            image:
        (errorFirstData?.card?.fields?.image &&
          getImageData(errorFirstData?.card?.fields?.image[0])) ||
        null,
        }

        const pageMetadata =
      (errorFirstData?.pageMetadata &&
        getPageMetadata(errorFirstData?.pageMetadata)) ||
      {}
        return {
            pageData: errorPageData,
            pageType: pageTypes.errorPage,
            pageMetadata,
            locale: locales.japanese,
        }
    } else {
        return {
            pageData: {},
            pageType: pageTypes.errorPage,
            pageMetadata: {},
            locale: locales.japanese,
        }
    }
}
