import { pageTypes, locales } from 'src/constants/index'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getImageData } from '@dataMapperHelper/image.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'
import { getRelatedArticleData } from '@dataMapperHelper/RelatedArticleData.helper'
import { getRelatedProductData } from '@dataMapperHelper/relatedProduct.helper'
import urlHelper from '@helpers/url.helper'
export const getMappedArticleData = (entries) => {
    const articleData = {
        name: null,
        category: [],
        bannerImage: null,
        descriptionCard: {},
        cardsCollection: [],
        discoverMoreCard: {},
        relatedArticles: [],
        indentedCard: {},
        listingPageURL: null,
        videoCard: {},
        promCardTitle: '',
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        articleData.locale = entries?.items[0].sys.locale || null
        articleData.category = firstItem.articleCategory || null
        articleData.name = firstItem.articleName || null
        articleData.articleBody = firstItem.articleBody || null
        articleData.promCardTitle = firstItem.promCardTitle || null
        articleData.bannerImage =
      (firstItem.bannerImageSet && {
          desktopImage: getImageData(
              firstItem.bannerImageSet?.fields?.desktopImage,
          ),
          smartphoneImage: getImageData(
              firstItem.bannerImageSet?.fields?.smartphoneImage,
          ),
      }) ||
      null
        articleData.listingPageURL = urlHelper({
            locale: articleData.locale,
            pageType: pageTypes.alpPage,
            topicSlug: firstItem.topicSlug,
            listingSlug: firstItem.listingSlug,
        })
        articleData.articleURL = urlHelper({
            locale: articleData.locale,
            pageType: pageTypes.adpPage,
            topicSlug: firstItem.topicSlug,
            listingSlug: firstItem.listingSlug,
            slug: firstItem.slug,
        })

        articleData.descriptionCard = {
            sys: firstItem?.descriptionCard?.sys?.id || null,
            title: firstItem?.descriptionCard?.fields?.title || null,
            description: firstItem?.descriptionCard?.fields?.description || null,
            image:
        (firstItem?.descriptionCard?.fields?.image &&
          getImageData(firstItem?.descriptionCard?.fields?.image[0])) ||
        null,
        }
        articleData.cardsCollection =
      firstItem?.horizontalCards?.map((horizontalCard) => {
          if (horizontalCard?.sys?.contentType?.sys?.id === 'videoCard') {
              return {
                  sys: horizontalCard?.sys?.id || null,
                  title: horizontalCard?.fields?.title || null,
                  url: horizontalCard?.fields?.url || null,
                  type: horizontalCard?.sys?.contentType?.sys?.id || null,
              }
          } else {
              return {
                  sys: horizontalCard?.sys?.id || null,
                  title: horizontalCard?.fields?.title || null,
                  type: horizontalCard?.sys?.contentType?.sys?.id || null,
                  description: horizontalCard?.fields?.description || null,
                  href:
              (horizontalCard?.fields?.callToActions &&
                horizontalCard?.fields?.callToActions[0]?.fields?.url) ||
              null,
                  linkText:
              (horizontalCard?.fields?.callToActions &&
                horizontalCard?.fields?.callToActions[0]?.fields?.title) ||
              null,
                  cardLink: horizontalCard?.fields?.cardLink || null,
                  image:
              (horizontalCard?.fields?.image &&
                getImageData(horizontalCard?.fields?.image[0])) ||
              null,
              }
          }
      }) || []
        articleData.indentedCard = {
            sys: firstItem.indentedCard?.sys?.id || null,
            description: firstItem.indentedCard?.fields?.description || null,
        }
        articleData.discoverMoreCard =
      (firstItem.discoverMoreCard && {
          sys: firstItem.discoverMoreCard?.sys?.id || null,
          href: urlHelper({
              locale: articleData.locale,
              pageType: pageTypes.adpPage,
              topicSlug: firstItem.discoverMoreCard?.fields?.topicSlug,
              listingSlug: firstItem.discoverMoreCard?.fields?.listingSlug,
              slug: firstItem.discoverMoreCard?.fields?.slug,
          }),
          description: firstItem.discoverMoreCard?.fields?.articleName || null,
          image:
          (firstItem?.discoverMoreCard?.fields?.bannerImageSet &&
            firstItem.discoverMoreCard?.fields?.bannerImageSet?.fields
                ?.smartphoneImage &&
            getImageData(
                firstItem.discoverMoreCard?.fields?.bannerImageSet?.fields
                    ?.smartphoneImage,
            )) ||
          null,
      }) ||
      null
        articleData.relatedArticles =
      firstItem?.relatedArticles
          ?.map((article) => getRelatedArticleData(article, articleData.locale))
          .filter((article) => article) || []
        articleData.videoCard =
      (firstItem?.videoCard && {
          sys: firstItem?.videoCard?.sys?.id || null,
          title: firstItem?.videoCard?.fields?.title || null,
          url: firstItem?.videoCard?.fields?.url || null,
      }) ||
      null
        articleData.relatedProducts =
      firstItem?.relatedProducts
          ?.map((product) => getRelatedProductData(product, articleData.locale))
          .filter((product) => product) || []

        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata =
      (firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata)) ||
      {}
        const schemaData = {
            name: articleData.name || '',
            banner: articleData.bannerImage?.desktopImage?.url
                ? `//images.ctfassets.net/${process.env.CF_SPACE_ID}/${articleData.bannerImage?.desktopImage?.url}`
                : '',
            description: pageMetadata?.metaDescription || '',
            created: entries?.items[0].sys?.createdAt || '01-01-2010',
            published: entries?.items[0].sys?.updatedAt || '01-01-2010',
            url: urlHelper({
                locale: articleData.locale,
                pageType: pageTypes.adpPage,
                topicSlug: firstItem.topicSlug,
                listingSlug: firstItem.listingSlug,
                slug: firstItem.slug,
            }),
        }

        return {
            props: {
                pageData: articleData,
                pageType: pageTypes.adpPage,
                breadcrumb,
                pageMetadata,
                schemaData,
                locale: articleData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.adpPage,
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}
export const getMappedArticleSlug = (entries) =>
    entries?.items
        ?.map(({ fields }) => fields?.content)
        ?.filter((entry) => entry?.fields?.slug)
        .map((entry) => ({
            params: {
                topics: entry?.fields?.topicSlug,
                listingSlug: entry?.fields?.listingSlug,
                detailSlug: entry?.fields?.slug,
            },
        })) || []
