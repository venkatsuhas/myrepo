import { locales, pageTypes } from '@constants'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'
import { getFeatureCard } from '@dataMapperHelper/featureCard.helper'
import { getBannerCard } from '@dataMapperHelper/banner.helper'
import { getImageData } from '@dataMapperHelper/image.helper'

export const getMappedHomepageData = (entries) => {
    const homeData = {
        banner: [],
        featureCards: {},
    }
    const firstItem = entries?.items[0]?.fields
    if (firstItem) {
        homeData.locale = entries?.items[0].sys.locale || null
        homeData.name = firstItem.name || null
        homeData.banner =
      firstItem?.banner?.map((details) => getBannerCard(details)) || []

        homeData.featureCards =
      firstItem?.featureCards?.map((info) => getFeatureCard(info)) || []

        const pageMetadata =
      (firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata)) ||
      {}

        homeData.mobileMenu =
      (firstItem?.mobileMenu &&
        firstItem?.mobileMenu.map((menu) => ({
            sys: menu?.sys?.id || null,
            url: menu?.fields?.url || null,
            title: menu?.fields?.title || null,
        }))) ||
      null

        homeData.bottomImage =
      (firstItem?.bottomImage && {
          desktopImage: getImageData(
              firstItem?.bottomImage?.fields?.desktopImage,
          ),
          smartphoneImage: getImageData(
              firstItem?.bottomImage?.fields?.smartphoneImage,
          ),
      }) ||
      null

        return {
            props: {
                pageData: homeData,
                pageType: pageTypes.homepage,
                pageMetadata,
                locale: homeData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.homepage,
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}
