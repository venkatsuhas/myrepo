import { locales, pageTypes } from 'src/constants'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'

export const getMappedContactUsData = (entries) => {
    const ContactUsData = {
        locale: locales.japanese,
        gcr: null,
    }

    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        ContactUsData.locale = entries?.items[0]?.sys?.locale
        ContactUsData.gcr = firstItem?.gcr || null
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata =
      (firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata)) ||
      {}

        return {
            props: {
                pageData: ContactUsData,
                pageType: pageTypes.contactUsPage,
                breadcrumb,
                pageMetadata,
                locale: ContactUsData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.contactUsPage,
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}
