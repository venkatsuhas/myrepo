import { locales, pageTypes } from '@constants'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getImageData } from '@dataMapperHelper/image.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'
import { getFeatureCard } from '@dataMapperHelper/featureCard.helper'
import { getRelatedProductData } from '@dataMapperHelper/relatedProduct.helper'
import urlHelper from '@helpers/url.helper'

const getCategory = (category, isBasePath = true) => ({
    sys: category?.sys?.id || null,
    title: category?.fields?.categoryTitle,
    url: urlHelper({
        locale: category?.sys?.locale || locales.japanese,
        pageType: pageTypes.plpPage,
        ...(isBasePath ? { slug: category?.fields?.slug } : {}),
        topicSlug: category?.fields?.topic,
        type: category?.fields?.type,
    }),
})

const getDiscoverCards = ({ sys, fields }) => ({
    sys: sys?.id || '',
    title: fields?.title || '',
    linkText: fields?.subTitle || '',
    imageset:
    (fields?.promoBannerImage[0] && {
        desktopImage:
        (fields?.promoBannerImage[0]?.fields?.desktopImage &&
          getImageData(fields?.promoBannerImage[0]?.fields?.desktopImage)) ||
        null,
        smartphoneImage:
        (fields?.promoBannerImage[0]?.fields?.smartphoneImage &&
          getImageData(fields?.promoBannerImage[0]?.fields?.smartphoneImage)) ||
        null,
    }) ||
    null,
    href: fields?.url || '',
})

export const getPromoCardDetails = ({ sys, fields }) => ({
    sys: sys?.id || '',
    titleLinkText: fields?.title || '',
    subTitleLinkText: fields?.subTitle || '',
    imageset:
    (fields?.promoCardImage && {
        desktopImage:
        (fields?.promoCardImage?.fields?.desktopImage &&
          getImageData(fields?.promoCardImage?.fields?.desktopImage)) ||
        null,
        smartphoneImage:
        (fields?.promoCardImage?.fields?.smartphoneImage &&
          getImageData(fields?.promoCardImage?.fields?.smartphoneImage)) ||
        null,
    }) ||
    null,
    titleHref: fields?.titleUrl || '',
    subTitleHref: fields?.subTitleUrl || '',
})

export const getMappedProductListingData = (content, container, products) => {
    const firstContentEntry = content.items[0] && content.items[0].fields
    const productListingData = {
        locale: locales.japanese,
        bannerImage: {},
        promoCardDetails: {},
        title: null,
        subTitle: null,
        topic: null,
        mainCategories: [],
        secondMainCategories: [],
        discoverCardsCollection: [],
        type: null,
        filters: [],
        products: [],
        bannerCollection: [],
        pageType: firstContentEntry?.isProductPage
            ? pageTypes.productsPage
            : pageTypes.plpPage,
    }

    const firstContainerEntry =
    container.items &&
    container.items.filter(
        (container) =>
            container?.fields &&
        container?.fields?.categories &&
        container?.fields?.categories[0] &&
        container?.fields?.categories[0].fields?.type ===
          firstContentEntry?.type,
    )[0]?.fields
    const secondContainerEntry =
    container.items &&
    container.items.filter(
        (container) =>
            container?.fields &&
        container?.fields?.categories &&
        container?.fields?.categories[0] &&
        container?.fields?.categories[0].fields?.type ===
          firstContentEntry?.type,
    )[1]?.fields

    if (firstContentEntry && firstContainerEntry) {
        productListingData.locale = container.items[0].sys.locale
        productListingData.title =
      firstContentEntry?.pageTitle || firstContentEntry?.title || null
        productListingData.subTitle = firstContentEntry?.subTitle || null
        productListingData.type = firstContentEntry?.type || null
        productListingData.topic = firstContentEntry?.topic || null
        productListingData.discoverCardsCollection =
      firstContentEntry?.discoverCardsCollection
          ? firstContentEntry?.discoverCardsCollection?.map(getDiscoverCards)
          : []
        productListingData.bannerCollection =
      firstContentEntry?.bannerCollection?.map((item) =>
          getFeatureCard(item),
      ) || []
        ;(productListingData.bannerImage =
      (firstContentEntry?.bannerImage && {
          desktopImage:
          (firstContentEntry?.bannerImage?.fields?.desktopImage &&
            getImageData(
                firstContentEntry?.bannerImage?.fields?.desktopImage,
            )) ||
          null,
          smartphoneImage:
          (firstContentEntry?.bannerImage?.fields?.smartphoneImage &&
            getImageData(
                firstContentEntry?.bannerImage?.fields?.smartphoneImage,
            )) ||
          null,
      }) ||
      null),
        (productListingData.promoCardDetails = firstContentEntry?.promoCard
            ? getPromoCardDetails(firstContentEntry?.promoCard)
            : {})
        productListingData.mainCategories = [
            ...firstContainerEntry.categories.map((category) =>
                getCategory(category),
            ),
        ]
        productListingData.secondMainCategories = [
            ...secondContainerEntry?.categories.map((category) =>
                getCategory(category),
            ),
        ]

        productListingData.filters =
      firstContainerEntry.filters?.fields?.filters?.map(({ fields }) => ({
          name: fields.name,
          options: fields.options,
      })) || []

        productListingData.products =
      products.items
          .map(({ fields }) => fields?.content)
          .filter((product) => {
              if (product) {
                  const productFacets = [
                      product?.fields?.productMainCategory,
                      product?.fields?.minPrice,
                      ...(product?.fields?.productFacets || []),
                  ]
                  return firstContentEntry?.facets.some((filter) =>
                      productFacets.includes(filter),
                  )
              } else {
                  return false
              }
          })
          .sort(
              (firstProduct, secondProduct) =>
                  (firstProduct?.fields?.featuredRating || 100) -
            (secondProduct?.fields?.featuredRating || 100),
          )
          .map((product) =>
              getRelatedProductData(product, productListingData?.locale, true),
          ) || []

        const breadcrumb = firstContentEntry?.breadcrumb?.map(getBreadcrumb) || []
        productListingData.breadcrumb = breadcrumb
        const pageMetadata =
      (firstContentEntry?.pageMetadata &&
        getPageMetadata(firstContentEntry?.pageMetadata)) ||
      {}

        return {
            props: {
                pageData: productListingData,
                pageType:
          firstContentEntry?.slug === 'products'
              ? pageTypes.productsPage
              : pageTypes.plpPage,
                breadcrumb,
                pageMetadata,
                locale: productListingData?.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType:
          firstContentEntry?.slug === 'products'
              ? pageTypes.productsPage
              : pageTypes.plpPage,
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}

export const getMappedProductListingSlug = (entries) =>
    entries?.items
        ?.map(({ fields }) => fields?.categories)
        .flat()
        ?.filter((entry) => entry?.fields?.slug)
        .map((entry) => ({
            params: {
                listingSlug: entry?.fields?.slug,
            },
        })) || []
