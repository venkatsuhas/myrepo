import { locales, pageTypes } from '@constants'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getImageData } from '@dataMapperHelper/image.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'
import { getRelatedProductData } from '@dataMapperHelper/relatedProduct.helper'
import { getRelatedArticleData } from '@dataMapperHelper/relatedArticle.helper'

const getGalleryImageData = ({ fields: { productImages, variant } }) => ({
    variant,
    productImages: productImages.map(getImageData).filter((image) => image),
})

const getSubVariantData = (
    {
        fields: {
            variantName,
            mainVariant: isMainVariant,
            productImages,
            smartLabelId,
            buyNowId,
        },
    },
    fallbackImages,
) => ({
    variantName: variantName || null,
    isMainVariant: !!isMainVariant,
    productImages:
    productImages?.map(getGalleryImageData).filter((image) => image) ||
    fallbackImages ||
    [],
    smartLabelId: smartLabelId || null,
    buyNowId: buyNowId || null,
})

const getMainVariantData = (
    {
        fields: {
            variantName,
            mainVariant: isMainVariant,
            subVariants,
            productImages,
            smartLabelId,
            buyNowId,
        },
    },
    fallbackImages,
) =>
    subVariants && subVariants.length > 0
        ? {
            variantName: variantName || null,
            isMainVariant: !!isMainVariant,
            subVariants: subVariants?.map((variant) =>
                getSubVariantData(variant, fallbackImages),
            ),
        }
        : getSubVariantData(
            {
                fields: {
                    variantName,
                    mainVariant: isMainVariant,
                    productImages,
                    smartLabelId,
                    buyNowId,
                },
            },
            fallbackImages,
        )

export const getMappedProductData = async (entries) => {
    const productData = {
        locale: locales.japanese,
        name: null,
        mainCategory: null,
        productVariants: [],
        hasMainVariant: false,
        hasSubVariant: false,
        bannerImage: {},
        breadcrumb: [],
        productImages: [],
        heroImage: null,
        description: null,
        minPrice: null,
        ourIngredients: null,
        smartLabelId: null,
        faq: null,
        videos: null,
        relatedArticlesListing: null,
        relatedProducts: [],
        usageDetailsCardsCollection: [],
        productDetailsCardsCollection: [],
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        productData.locale = entries?.items[0].sys.locale || null
        productData.name = firstItem?.productName || null
        productData.mainCategory = firstItem?.productMainCategory || null
        productData.breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb) || []
        productData.cardsCollection =
      firstItem?.horizontalCards?.map((horizontalCard) => {
          if (horizontalCard?.sys?.contentType?.sys?.id === 'videoCard') {
              return {
                  sys: horizontalCard?.sys?.id || null,
                  title: horizontalCard?.fields?.title || null,
                  url: horizontalCard?.fields?.url || null,
                  type: horizontalCard?.sys?.contentType?.sys?.id || null,
              }
          } else {
              return {
                  sys: horizontalCard?.sys?.id || null,
                  title: horizontalCard?.fields?.title || null,
                  type: horizontalCard?.sys?.contentType?.sys?.id || null,
                  description: horizontalCard?.fields?.description || null,
                  href:
              (horizontalCard?.fields?.callToActions &&
                horizontalCard?.fields?.callToActions[0]?.fields?.url) ||
              null,
                  linkText:
              (horizontalCard?.fields?.callToActions &&
                horizontalCard?.fields?.callToActions[0]?.fields?.title) ||
              null,
                  cardLink: horizontalCard?.fields?.cardLink || null,
                  image:
              (horizontalCard?.fields?.image &&
                getImageData(horizontalCard?.fields?.image[0])) ||
              null,
              }
          }
      }) || []
        productData.productImages =
      firstItem.productImages
          ?.map(getGalleryImageData)
          .filter((image) => image) || []
        productData.productVariants =
      firstItem.productVariants
          ?.map((variant) => {
              if (variant?.fields?.mainVariant && !productData.hasSubVariant) {
                  productData.hasMainVariant = true
                  return getMainVariantData(variant, productData.productImages)
              } else if (!productData.hasMainVariant) {
                  productData.hasSubVariant = true
                  return getSubVariantData(variant, productData.productImages)
              } else {
                  return null
              }
          })
          .filter((variant) => variant) || []
        productData.bannerImage =
      (firstItem?.bannerImage && {
          desktopImage:
          (firstItem?.bannerImage?.fields?.desktopImage &&
            getImageData(firstItem?.bannerImage?.fields?.desktopImage)) ||
          null,
          smartphoneImage:
          (firstItem?.bannerImage?.fields?.smartphoneImage &&
            getImageData(firstItem?.bannerImage?.fields?.smartphoneImage)) ||
          null,
      }) ||
      null
        //     productData.productImages =
        //   ((!firstItem.productVariants || firstItem.productVariants.length === 0) &&
        //     firstItem.productImages
        //         ?.map(getGalleryImageData)
        //         .filter((image) => image)) ||
        //   []
        ;(productData.heroImage =
      (firstItem.heroImage && getImageData(firstItem.heroImage)) || null),
        (productData.description = firstItem.description || null)
        productData.minPrice = firstItem.minPrice || null
        productData.smartLabelId = firstItem.smartLabelId || null
        productData.productDetails = firstItem.productDetails || null
        productData.faq = firstItem.faq || null
        productData.videos = firstItem.videos || null
        productData.bazaarVoiceId = `${firstItem.bazaarvoiceId}` || null
        productData.buyNowId = firstItem.priceSpiderId || null
        productData.productDetailsCardsCollection = getCardDetails(
            firstItem?.productDetailsCardsCollection,
        )
        productData.usageDetailsCardsCollection = getCardDetails(
            firstItem?.usageDetailsCardsCollection,
        )
        productData.cardData = getRelatedProductData(
            entries.items[0],
            productData.locale,
        )

        productData.relatedProducts =
      firstItem?.relatedProducts
          ?.map((product) => getRelatedProductData(product, productData.locale))
          .filter((product) => product) || []
        productData.relatedArticles =
      firstItem?.relatedArticles
          ?.map((article) => getRelatedArticleData(article, productData.locale))
          .filter((article) => article) || []
        productData.relatedArticlesListing =
      (productData.relatedArticles &&
        productData.relatedArticles.length > 0 &&
        productData?.relatedArticles[0]?.href
            ?.split('/')
            .slice(0, -1)
            .join('/')) ||
      null

        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata =
      (firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata)) ||
      {}
        const ratingData = {
            aggregateRating: {
                ratingValue: 0,
                reviewCount: 0,
            },
            review: {
                author: '',
                date: '',
                reviewBody: '',
                name: '',
                rating: 0,
            },
        }

        const schemaData = {
            name: firstItem.productName || '',
            description: firstItem.description || '',
            image:
        firstItem.heroImage && getImageData(firstItem.heroImage)?.url
            ? `//images.ctfassets.net/${process.env.CF_SPACE_ID}/${
              getImageData(firstItem.heroImage)?.url
            }`
            : '',
            sku: firstItem.smartLabelId?.padStart(14, '0') || '',
            ...ratingData,
        }

        return {
            props: {
                pageData: productData,
                pageType: pageTypes.pdpPage,
                breadcrumb,
                pageMetadata,
                schemaData,
                locale: productData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.pdpPage,
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}

export const getMappedProductSlug = (entries) =>
    entries?.items
        ?.map(({ fields }) => fields?.content)
        ?.filter((entry) => entry?.fields?.slug && entry?.fields?.listingSlug)
        .map((entry) => ({
            params: {
                listingSlug: entry?.fields?.listingSlug,
                detailSlug: entry?.fields?.slug,
            },
        })) || []
const getCardDetails = (cardDetails) =>
    cardDetails?.map((card) => {
        if (card?.sys?.contentType?.sys?.id === 'videoCard') {
            return {
                sys: card?.sys?.id || null,
                title: card?.fields?.title || null,
                url: card?.fields?.url || null,
                type: card?.sys?.contentType?.sys?.id || null,
            }
        } else {
            return {
                sys: card?.sys?.id || null,
                title: card?.fields?.title || null,
                type: card?.sys?.contentType?.sys?.id || null,
                description: card?.fields?.description || null,
                image:
          (card?.fields?.image && getImageData(card?.fields?.image[0])) || null,
            }
        }
    }) || []
