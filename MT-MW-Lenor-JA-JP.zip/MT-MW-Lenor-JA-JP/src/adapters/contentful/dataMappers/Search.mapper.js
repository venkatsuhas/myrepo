import { locales, pageTypes } from '@constants'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'

export const getMappedSearchData = (entries) => {
    const searchPageData = {
        locale: locales.japanese,
        breadcrumb: [],
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata =
      (firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata)) ||
      {}

        searchPageData.breadcrumb = breadcrumb

        return {
            props: {
                pageData: searchPageData,
                pageType: pageTypes.searchPage,
                pageMetadata,
                locale: searchPageData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.searchPage,
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}
