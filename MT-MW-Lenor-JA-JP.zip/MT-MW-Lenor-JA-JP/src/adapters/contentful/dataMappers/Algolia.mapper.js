import { pageTypes } from '@constants'
import { getImageData } from '@contentful/dataMappers/helper/image.helper'
import urlHelper from '@helpers/url.helper'

const getMappedArticle = (entry) => ({
    objectID: entry?.sys?.id,
    locale: entry?.sys?.locale,
    articleName: entry?.fields?.articleName,
    articleCategory: entry?.fields?.articleCategory,
    url: urlHelper({
        locale: entry?.sys?.locale,
        pageType: pageTypes.adpPage,
        topicSlug: entry?.fields?.topicSlug,
        listingSlug: entry?.fields?.listingSlug,
        slug: entry?.fields?.slug,
    }),
    heroImage:
    (entry?.fields?.heroImage && getImageData(entry?.fields?.heroImage)) ||
    null,
})

const getMappedExperience = (entry) => ({
    objectID: entry?.sys?.id,
    locale: entry?.sys?.locale,
    articleName: entry?.fields?.name,
    articleCategory: entry?.fields?.experienceCategory,
    url: urlHelper({
        locale: entry?.sys?.locale,
        pageType: pageTypes.edpPage,
        topicSlug: entry?.fields?.topicSlug,
        listingSlug: entry?.fields?.listingSlug,
        slug: entry?.fields?.slug,
    }),
    heroImage:
    (entry?.fields?.heroImage && getImageData(entry?.fields?.heroImage)) ||
    null,
})

const getMappedProduct = (entry) => ({
    objectID: entry?.sys?.id,
    locale: entry?.sys?.locale,
    productName: entry?.fields?.productName,
    category: entry?.fields?.productMainCategory,
    facets: entry?.fields?.productFacets,
    description: entry?.fields?.description,
    slug: entry?.fields?.slug,
    url: urlHelper({
        locale: entry?.sys?.locale,
        pageType: pageTypes.pdpPage,
        slug: entry?.fields?.slug,
        listingSlug: entry?.fields?.productMainCategory?.toLowerCase(),
    }),
    productHeroImageURL: entry?.fields?.heroImage?.fields?.file?.url,
    productHeroImage:
    (entry?.fields?.heroImage && getImageData(entry?.fields?.heroImage)) ||
    null,
    priceSpiderId: entry?.fields?.priceSpiderId,
})

export const getMappedSearchData = (
    productData,
    articleData,
    experienceData,
) => ({
    products: productData
        ?.filter(({ fields }) => fields?.content)
        .map(({ fields }) => fields?.content)
        .map(getMappedProduct),
    articles: articleData
        ?.filter(({ fields }) => fields?.content)
        .map(({ fields }) => fields?.content)
        .map(getMappedArticle),
    experiences: experienceData
        ?.filter(({ fields }) => fields?.content)
        .map(({ fields }) => fields?.content[0])
        .map(getMappedExperience),
})
