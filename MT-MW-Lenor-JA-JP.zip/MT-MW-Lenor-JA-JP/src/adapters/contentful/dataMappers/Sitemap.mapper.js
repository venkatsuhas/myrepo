import { locales, pageTypes } from '@constants'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'

export const getMappedSitemapData = (entries) => {
    const sitemapData = {
        title: null,
        products: {
            title: null,
            items: [],
        },
        aboutUs: {
            title: null,
            items: [],
        },
        tips: {
            title: null,
            items: [],
        },
        leftSection: {
            title: null,
            items: [],
        },
        rightSection: {
            title: null,
            items: [],
        },
        contactUs: {
            title: null,
            url: null,
        },
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        sitemapData.leftSection.items = firstItem?.leftSection?.map((ele) =>
            ele?.fields?.sitemapSubsection?.map((ele) => {
                return {
                    title: ele?.fields?.name,
                    subMenu: ele?.fields?.sectionItems?.map((ele) => ({
                        title: ele?.fields?.title || ele?.fields?.name,
                    })),
                }
            }),
        )
        sitemapData.rightSection.items = firstItem?.rightSection?.map(
            (ele) =>
                ele?.fields?.sitemapSubsection?.map((ele) => {
                    return {
                        title: ele?.fields?.name,
                        subMenu: ele?.fields?.sectionItems?.map(
                            (ele) =>
                                ({ title: ele?.fields?.title || ele?.fields?.name } || []),
                        ),
                    }
                }) || [],
        )
        //     sitemapData.title = firstItem?.title || null

        sitemapData.locale = entries?.items[0].sys.locale || null

        //     sitemapData.tips.title = firstItem?.tipsTitle || null
        //     sitemapData.aboutUs.title = firstItem?.aboutUsTitle || null
        //     sitemapData.products.title = firstItem?.productsTitle || null

        //     sitemapData.tips.items =
        //   (firstItem?.tips && getMenuData(firstItem?.tips)) || []
        //     sitemapData.aboutUs.items =
        //   (firstItem?.aboutUs?.[0]?.fields?.subMenu &&
        //     getMenuData(firstItem?.aboutUs?.[0]?.fields?.subMenu)) ||
        //   []
        //     sitemapData.products.items =
        //   (firstItem?.products && getMenuData(firstItem?.products)) || []

        //     sitemapData.contactUs.url = firstItem?.contactUs?.fields?.url || null
        //     sitemapData.contactUs.title = firstItem?.contactUs?.fields?.title || null

        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata =
      (firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata)) ||
      {}

        return {
            props: {
                breadcrumb,
                pageMetadata,
                pageData: sitemapData,
                locale: sitemapData.locale,
                pageType: pageTypes.sitemapPage,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.japanese,
                pageType: pageTypes.sitemapPage,
            },
        }
    }
}
