import { pageTypes, locales } from 'src/constants/index'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getImageData } from '@dataMapperHelper/image.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'
import urlHelper from '@helpers/url.helper'
import { getFeatureCard } from '@dataMapperHelper/featureCard.helper'
import { getRelatedArticleData } from '@dataMapperHelper/RelatedArticleData.helper'
import { getRelatedProductData } from '@dataMapperHelper/relatedProduct.helper'

export const getMappedExperienceData = (entries) => {
    const experienceData = {
        name: null,
        category: [],
        bannerImage: [],
        descriptionCard: {},
        cardsCollection: [],
        discoverMoreCard: {},
        relatedArticles: [],
        recommendedProducts: [],
        featureCards: {},
        indentedCard: {},
        instaCardsCollection: [],
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        experienceData.locale = entries?.items[0].sys.locale || null
        experienceData.category = firstItem.experienceCategory || null
        experienceData.name = firstItem.name || null

        experienceData.experienceURL = urlHelper({
            locale: experienceData.locale,
            pageType: pageTypes.edpPage,
            topicSlug: firstItem.topicSlug,
            listingSlug: firstItem.listingSlug,
            slug: firstItem.slug,
        })
        experienceData.descriptionCard = {
            sys: firstItem?.descriptionCard?.sys?.id || null,
            title: firstItem?.descriptionCard?.fields?.title || null,
            description: firstItem?.descriptionCard?.fields?.description || null,
            image:
        (firstItem?.descriptionCard?.fields?.image &&
          getImageData(firstItem?.descriptionCard?.fields?.image[0])) ||
        null,
        }
        experienceData.bannerImage =
      (firstItem.banner && {
          desktopImage: getImageData(firstItem.banner[0]?.fields?.desktopImage),
          smartphoneImage: getImageData(
              firstItem.banner[0]?.fields?.smartphoneImage,
          ),
      }) ||
      null
        experienceData.featureCards =
      firstItem?.featureCards?.map((info) => getFeatureCard(info)) || []

        experienceData.relatedArticles =
      firstItem?.relatedArticles
          ?.map((article) =>
              getRelatedArticleData(article, experienceData.locale),
          )
          .filter((article) => article) || []

        experienceData.relatedProducts =
      firstItem?.relatedProducts
          ?.map((product) =>
              getRelatedProductData(product, experienceData.locale),
          )
          .filter((product) => product) || []

        experienceData.recommendedProducts =
      firstItem?.recommendedProducts
          ?.map((product) =>
              getRelatedProductData(product, experienceData.locale, false),
          )
          .filter((product) => product) || []
        experienceData.cardsCollection =
      firstItem?.horizontalCards?.map((horizontalCard) => {
          if (horizontalCard?.sys?.contentType?.sys?.id === 'videoCard') {
              return {
                  sys: horizontalCard?.sys?.id || null,
                  title: horizontalCard?.fields?.title || null,
                  url: horizontalCard?.fields?.url || null,
                  type: horizontalCard?.sys?.contentType?.sys?.id || null,
              }
          } else {
              return {
                  sys: horizontalCard?.sys?.id || null,
                  title: horizontalCard?.fields?.title || null,
                  type: horizontalCard?.sys?.contentType?.sys?.id || null,
                  description: horizontalCard?.fields?.description || null,
                  cardType: horizontalCard?.fields?.cardType || null,
                  href:
              (horizontalCard?.fields?.callToActions &&
                horizontalCard?.fields?.callToActions[0]?.fields?.url) ||
              null,
                  linkText:
              (horizontalCard?.fields?.callToActions &&
                horizontalCard?.fields?.callToActions[0]?.fields?.title) ||
              null,
                  cardLink: horizontalCard?.fields?.cardLink || null,

                  image:
              (horizontalCard?.fields?.image &&
                getImageData(horizontalCard?.fields?.image[0])) ||
              null,
              }
          }
      }) || []

        experienceData.instaCardsCollection =
      firstItem?.instagramCard?.map((instaCard) => ({
          sys: instaCard?.sys?.id || null,
          title: instaCard?.fields?.title || null,
          type: instaCard?.sys?.contentType?.sys?.id || null,
          description: instaCard?.fields?.description || null,
          cardType: instaCard?.fields?.cardType || null,
          href:
          (instaCard?.fields?.callToActions &&
            instaCard?.fields?.callToActions[0]?.fields?.url) ||
          null,
          linkText:
          (instaCard?.fields?.callToActions &&
            instaCard?.fields?.callToActions[0]?.fields?.title) ||
          null,
          cardLink: instaCard?.fields?.cardLink || null,

          image:
          (instaCard?.fields?.image &&
            getImageData(instaCard?.fields?.image[0])) ||
          null,
      })) || []

        experienceData.indentedCard = {
            sys: firstItem.indentedCard?.sys?.id || null,
            description: firstItem.indentedCard?.fields?.description || null,
        }

        experienceData.discoverMoreCard =
      (firstItem.discoverMoreCard && {
          sys: firstItem.discoverMoreCard?.sys?.id || null,
          href: urlHelper({
              locale: experienceData.locale,
              pageType: pageTypes.edpPage,
              topicSlug: firstItem.discoverMoreCard?.fields?.topicSlug,
              listingSlug: firstItem.discoverMoreCard?.fields?.listingSlug,
              slug: firstItem.discoverMoreCard?.fields?.slug,
          }),
          description: firstItem.discoverMoreCard?.fields?.name || null,
          image:
          (firstItem?.discoverMoreCard?.fields?.bannerImageSet &&
            firstItem.discoverMoreCard?.fields?.bannerImageSet?.fields
                ?.smartphoneImage &&
            getImageData(
                firstItem.discoverMoreCard?.fields?.bannerImageSet?.fields
                    ?.smartphoneImage,
            )) ||
          null,
      }) ||
      null
        const breadcrumb = firstItem?.breadcrumbs?.map(getBreadcrumb) || []
        const pageMetadata =
      (firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata)) ||
      []
        const schemaData = {
            name: experienceData.name || '',
            bannerImage: experienceData.banner?.desktopImage?.url
                ? `//images.ctfassets.net/${process.env.CF_SPACE_ID}/${experienceData.bannerImage?.desktopImage?.url}`
                : '',
            description: pageMetadata?.metaDescription || '',
            created: entries?.items[0].sys?.createdAt || '01-01-2010',
            published: entries?.items[0].sys?.updatedAt || '01-01-2010',
            url: urlHelper({
                locale: experienceData.locale,
                pageType: pageTypes.edpPage,
                topicSlug: firstItem.topicSlug,
                listingSlug: firstItem.slug,
                slug: '',
            }),
        }
        return {
            props: {
                pageData: experienceData,
                pageType: pageTypes.edpPage,
                breadcrumb,
                pageMetadata,
                schemaData,
                locale: experienceData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.edpPage,
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}

export const getMappedExperienceSlug = (entries) =>
    entries?.items
        ?.filter((entry) => entry?.fields?.slug && entry?.fields?.listingSlug)
        .map((entry) => ({
            params: {
                topics: entry?.fields?.topicSlug,
                listingSlug: entry?.fields?.listingSlug,
                detailSlug: entry?.fields?.slug,
            },
        })) || []
