import { pageTypes } from 'src/constants'
import { getImageData } from './image.helper'
import urlHelper from 'src/helpers/url.helper'
export const getFeatureData = (experience, locale) =>
    experience.sys && experience.fields?.category
        ? {
            sys: experience.sys?.id || null,
            category: experience.fields?.category || null,
            name: experience.fields?.name || null,
            href: urlHelper({
                locale,
                pageType: pageTypes.edpPage,
                topicSlug: experience.fields?.topicSlug,
                listingSlug: experience.fields?.slug,
                slug: experience.fields?.slug,
            }),
            image:
          (experience?.fields?.heroImage &&
            getImageData(experience?.fields?.heroImage)) ||
          null,
        }
        : null
