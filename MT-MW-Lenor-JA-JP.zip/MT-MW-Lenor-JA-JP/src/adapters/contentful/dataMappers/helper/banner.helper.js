import { getImageData } from '@dataMapperHelper/image.helper'

export const getBannerCard = (card) => {
    const bannerFields = card?.fields
    return {
        title:
      (bannerFields?.image && bannerFields?.image[0]?.fields?.title) || null,
        subTitle: bannerFields?.entryTitle || null,
        href:
      (bannerFields?.callToActions &&
        bannerFields.callToActions[0]?.fields?.url) ||
      null,
        linkText:
      (bannerFields?.callToActions &&
        bannerFields.callToActions[0]?.fields?.title) ||
      null,
        background:
      (bannerFields?.callToActions &&
        bannerFields.callToActions[0]?.fields?.background) ||
      null,
        imageSet:
      (bannerFields?.imageSet && {
          desktopImage: getImageData(
              bannerFields?.imageSet?.fields?.desktopImage,
          ),
          smartphoneImage: getImageData(
              bannerFields?.imageSet?.fields?.smartphoneImage,
          ),
      }) ||
      null,
    }
}
