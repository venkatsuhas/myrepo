import { locales, pageTypes } from '@constants'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getImageData } from '@dataMapperHelper/image.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'
import { getRelatedArticleData } from '@dataMapperHelper/RelatedArticleData.helper'
import urlHelper from '@helpers/url.helper'

const getCategory = (category, isBasePath = true) => ({
    sys: category?.sys?.id || null,
    title: category?.fields?.title,
    url: urlHelper({
        locale: category?.sys?.locale || locales.japanese,
        pageType: pageTypes.alpPage,
        ...(isBasePath ? { slug: category?.fields?.slug } : {}),
        topicSlug: category?.fields?.topics,
        type: category?.fields?.type,
    }),
})
export const getMappedArticleListingData = (content, container, articles) => {
    const articleListingData = {}
    const firstContentEntry = content.items[0] && content.items[0].fields
    const firstContainerEntry = container.items[0] && container.items[0]?.fields

    if (firstContentEntry) {
        articleListingData.locale = container.items[0].sys.locale
        articleListingData.title =
      firstContentEntry?.pageTitle || firstContentEntry?.title || null
        articleListingData.subTitle = firstContentEntry?.subTitle || null
        articleListingData.type = firstContentEntry?.type || null
        articleListingData.bannerImage =
      (firstContentEntry?.banner && {
          desktopImage:
          (firstContentEntry?.banner?.fields?.desktopImage &&
            getImageData(firstContentEntry?.banner?.fields?.desktopImage)) ||
          null,
          smartphoneImage:
          (firstContentEntry?.banner?.fields?.smartphoneImage &&
            getImageData(firstContentEntry?.banner?.fields?.smartphoneImage)) ||
          null,
      }) ||
      null
        const breadcrumb = firstContentEntry?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata =
      (firstContentEntry?.pageMetadata &&
        getPageMetadata(firstContentEntry?.pageMetadata)) ||
      {}
        articleListingData.filters =
      firstContainerEntry.filters?.fields?.filters?.map(({ fields }) => ({
          name: fields.name,
          options: fields.options,
      })) || []
        articleListingData.mainCategories = [
            ...firstContainerEntry.conditions.map((category) =>
                getCategory(category),
            ),
            getCategory(firstContainerEntry.allCategories, false),
        ]
        articleListingData.articles =
      articles.items
          .map(({ fields }) => fields?.content)
          .filter(
              (article) =>
                  article &&
            article.fields &&
            article.fields.articleCategory &&
            firstContentEntry.articleCategory.indexOf(
                article.fields.articleCategory,
            ) !== -1,
          )
          .map((article) => {
              const data = getRelatedArticleData(article, articleListingData.locale)
              return data
          })
          .sort((a, b) => {
              if (b.categoryBasedFeatured && !a.categoryBasedFeatured) {
                  return 1
              } else if (a.categoryBasedFeatured && !b.categoryBasedFeatured) {
                  return -1
              } else {
                  return 0
              }
          }) || []
        return {
            props: {
                pageData: articleListingData,
                pageType: pageTypes.alpPage,
                locale: articleListingData.locale,
                breadcrumb,
                pageMetadata,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.alpPage,
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}

export const getMappedArticleListingSlug = (entries) => {
    const entry = entries?.items[0] && entries?.items[0].fields
    const array = [
        ...(entry?.conditions?.map((category) => ({
            params: {
                topics: category.fields.topics,
                listingSlug: category.fields.slug,
            },
        })) || []),
    ]
    return array
}
