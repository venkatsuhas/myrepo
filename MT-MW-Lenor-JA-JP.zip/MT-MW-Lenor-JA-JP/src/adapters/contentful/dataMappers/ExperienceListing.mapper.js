import { locales, pageTypes } from '@constants'
import { getBreadcrumb } from '@dataMapperHelper/breadcrumb.helper'
import { getImageData } from '@dataMapperHelper/image.helper'
import { getPageMetadata } from '@dataMapperHelper/pageMetadata.helper'
import { getExperienceData } from '@dataMapperHelper/experience.helper'
import { getFeatureData } from './helper/featureCard.helper'
import urlHelper from '@helpers/url.helper'

const getCategory = (category, isBasePath = true) => ({
    sys: category?.sys?.id || null,
    title: category?.fields?.title,
    url: urlHelper({
        locale: category?.sys?.locale || locales.japanese,
        pageType: pageTypes.elpPage,
        ...(isBasePath ? { slug: category?.fields?.slug } : {}),
        topicSlug: category?.fields?.topics,
        type: category?.fields?.type,
    }),
})
export const getMappedExperienceListingData = (
    content,
    container,
    experiences,
) => {
    const experienceListingData = {}
    const firstContentEntry = content.items[0] && content.items[0].fields
    const firstContainerEntry = container.items[0] && container.items[0]?.fields

    if (firstContentEntry) {
        experienceListingData.locale = container.items[0].sys.locale
        experienceListingData.title =
      firstContentEntry?.pageTitle || firstContentEntry?.title || null
        experienceListingData.subTitle = firstContentEntry?.subTitle || null
        experienceListingData.type = firstContentEntry?.type || null
        experienceListingData.bannerImage =
      (firstContentEntry?.banner && {
          desktopImage:
          (firstContentEntry?.banner?.fields?.desktopImage &&
            getImageData(firstContentEntry?.banner?.fields?.desktopImage)) ||
          null,
          smartphoneImage:
          (firstContentEntry?.banner?.fields?.smartphoneImage &&
            getImageData(firstContentEntry?.banner?.fields?.smartphoneImage)) ||
          null,
      }) ||
      null
        const breadcrumb = firstContentEntry?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata =
      (firstContentEntry?.pageMetadata &&
        getPageMetadata(firstContentEntry?.pageMetadata)) ||
      {}
        experienceListingData.filters =
      firstContainerEntry.filters?.fields?.filters?.map(({ fields }) => ({
          name: fields.name,
          options: fields.options,
      })) || []
        experienceListingData.mainCategories = [
            ...firstContainerEntry.conditions.map((category) =>
                getCategory(category),
            ),
            getCategory(firstContainerEntry.allCategories, false),
        ]

        experienceListingData.featurecards =
      firstContainerEntry?.featureCards?.map(getFeatureData) || []
        experienceListingData.experiences =
      experiences.items
          .map(({ fields }) => {
              return fields?.content[0]
          })
          .filter(
              (experience) =>
                  experience &&
            experience.fields &&
            experience.fields.experienceCategory &&
            firstContentEntry.experienceCategory[0].indexOf(
                experience.fields.experienceCategory,
            ) !== 1,
          )
          .map((experience) => {
              const data = getExperienceData(
                  experience,
                  experienceListingData.locale,
              )
              return data
          })
          .sort((a, b) => {
              if (b.categoryBasedFeatured && !a.categoryBasedFeatured) {
                  return 1
              } else if (a.categoryBasedFeatured && !b.categoryBasedFeatured) {
                  return -1
              } else {
                  return 0
              }
          }) || []
        return {
            props: {
                pageData: experienceListingData,
                pageType: pageTypes.elpPage,
                locale: experienceListingData.locale,
                breadcrumb,
                pageMetadata,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.elpPage,
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.japanese,
            },
        }
    }
}

export const getMappedExperienceListingSlug = (entries) => {
    const entry = entries?.items[0] && entries?.items[0].fields
    const array = [
        ...(entry?.conditions?.map((category) => ({
            params: {
                topics: category.fields.topics,
                listingSlug: category.fields.slug,
            },
        })) || []),
    ]
    return array
}
