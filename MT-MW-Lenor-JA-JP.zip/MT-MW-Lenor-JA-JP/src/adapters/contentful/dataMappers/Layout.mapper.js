import { getImageData } from '@dataMapperHelper/image.helper'
import { getMenuSlotData } from '@dataMapperHelper/layout.helper'

export const getMappedHeaderData = (entries) => {
    const headerData = {
        brandLogo: {},
        menuSlots: [],
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        headerData.locale = entries?.items[0].sys.locale || null
        headerData.brandList = firstItem?.brandList || null
        headerData.countryLanguage = firstItem?.countryLanguage || null
        headerData.pleaseSelectLocation = firstItem?.pleaseSelectLocation || null
        headerData.inquiry =
      (firstItem?.inquiry[0] && firstItem?.inquiry[0].fields) || null
        headerData.brandLogo = getImageData(firstItem?.brandLogo) || null
        headerData.menuSlots = getMenuSlotData(firstItem?.menuSlots) || null
        return headerData
    } else {
        return {}
    }
}

export const getMappedFooterData = (entries) => {
    const footerData = {
        menuSlots: [],
        footerLinks: [],
        instaCard: {},
        footerSubTitle: null,
        mobileFooterLinks: [],
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        footerData.locale = entries?.items[0].sys.locale || null
        footerData.footerSubTitle = firstItem?.footerSubTitle || null
        ;(footerData.menuSlots = getMenuSlotData(firstItem?.menuSlots) || null),
        (footerData.footerLinks =
        (firstItem?.footerLinks &&
          firstItem?.footerLinks.map((footerLink) => ({
              sys: footerLink?.sys?.id || null,
              url: footerLink.fields?.url || null,
              title: footerLink?.fields?.title || null,
          }))) ||
        null)
        footerData.mobileFooterLinks =
      (firstItem?.mobileFooterLinks &&
        firstItem?.mobileFooterLinks.map((footerLink) => ({
            sys: footerLink?.sys?.id || null,
            url: footerLink.fields?.url || null,
            title: footerLink?.fields?.title || null,
        }))) ||
      null
        return footerData
    } else {
        return {}
    }
}
