import {
    getMappedArticleListingData,
    getMappedArticleListingSlugWithParent,
    getMappedArticleListingSlugWithoutParent,
} from '@adapters/contentful/datamapper/ArticleListing.mapper'
import { getMappedContactUsData } from '@adapters/contentful/datamapper/ContactUs.mapper'
import {
    getMappedHeaderData,
    getMappedFooterData,
} from '@adapters/contentful/datamapper/Layout.mapper'
import { getMappedHomepageData } from '@adapters/contentful/datamapper/Homepage.mapper'

import {
    getMappedArticleSlug,
    getMappedArticleData,
} from 'src/adapters/contentful/datamapper/Article.mapper'
import {
    getMappedProductSlug,
    getMappedProductData,
} from '@adapters/contentful/datamapper/Product.mapper'

module.exports = {
    getMappedArticleListingSlugWithParent,
    getMappedArticleListingSlugWithoutParent,
    getMappedArticleListingData,
    getMappedContactUsData,
    getMappedArticleData,
    getMappedArticleSlug,
    getMappedHeaderData,
    getMappedFooterData,
    getMappedHomepageData,
    getMappedProductSlug,
    getMappedProductData,
}
