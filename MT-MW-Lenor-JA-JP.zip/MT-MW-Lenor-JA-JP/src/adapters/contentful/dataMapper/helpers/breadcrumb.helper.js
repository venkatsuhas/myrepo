export const getBreadcrumb = ({ sys, fields }) => ({
    sys: sys?.id || '',
    title: fields?.title || '',
    url: fields?.url || '',
})
