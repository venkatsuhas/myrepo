import { getImageData } from '@dataMapperHelper/image.helper'

export const getMenuData = (menuItems) => {
    let menuData = []
    menuData =
    (menuItems &&
      menuItems.length > 0 &&
      menuItems.map((menuItem) => ({
          sys: menuItem?.sys?.id || null,
          link: menuItem?.fields?.link || null,
          title: menuItem?.fields?.title || null,
          subMenu: getMenuData(menuItem?.fields?.subMenu) || null,
          menuImage:
          (menuItem?.fields?.menuImage &&
            getImageData(menuItem?.fields?.menuImage)) ||
          null,
      }))) ||
    null
    return menuData
}

export const getMenuSlotData = (menuSlots) => {
    let menuSlotsData = []
    menuSlotsData =
    (menuSlots &&
      menuSlots.length > 0 &&
      menuSlots.map((menuSlot) => ({
          sys: menuSlot?.sys?.id || null,
          title: menuSlot?.fields?.title || null,
          viewAllLink: menuSlot?.fields?.viewAllLink || null,
          viewAllLinkText: menuSlot?.fields?.viewAllLinkText || null,
          menuItems:
          (menuSlot?.fields?.menuItems &&
            getMenuData(menuSlot?.fields?.menuItems)) ||
          null,
          menuImage:
          (menuSlot?.fields?.menuImage &&
            getImageData(menuSlot?.fields?.menuImage)) ||
          null,
          footerIcon: menuSlot?.fields?.footerIcon || null,
      }))) ||
    null
    return menuSlotsData
}
