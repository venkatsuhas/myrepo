import { recentlyViewedItemsLength } from '@constants'

export const setRecentlyViewed = (item) => {
  const itemArray = []
  const items = JSON.parse(localStorage.getItem('recently_viewed_items')) || []

  const itemPresent =
    items.filter((arrayItem) => arrayItem.sys === item.sys).length > 0
  if (items.length < recentlyViewedItemsLength) {
    if (itemPresent) {
      items = items.filter((arrayItem) => arrayItem.sys !== item.sys)
      items.unshift(item)
    } else {
      items.push(item)
    }
  } else {
    if (itemPresent) {
      items = items.filter((arrayItem) => arrayItem.sys !== item.sys)
      items.unshift(item)
    } else {
      items.unshift(item)
      items.pop()
    }
  }
  localStorage.setItem('recently_viewed_items', JSON.stringify(items))
}

export const getRecentlyViewed = () => {
  const itemArray = []
  if (typeof window !== 'undefined') {
    if (localStorage.getItem('recently_viewed_items')) {
      let items = JSON.parse(localStorage.getItem('recently_viewed_items'))
      return items
    }
  }
  return itemArray
}
