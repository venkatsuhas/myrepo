import { locales, pageTypes } from '@constants'

const urlHelper = ({
  locale,
  pageType,
  slug,
  topicSlug,
  listingSlug,
  searchTerm,
}) => {
  if (pageType === pageTypes.pdpPage) {
    if (locale === locales.japanese) {
      return `/${locale?.toLowerCase()}/fabric-softener/${slug}`
    } else {
      return `/${locale?.toLowerCase()}/fabric-softener/${slug}`
    }
  } else if (pageType === pageTypes.adpPage) {
    return `/${locale?.toLowerCase()}/${topicSlug?.toLowerCase()}/${listingSlug?.toLowerCase()}/${slug}`
  } else if (pageType === pageTypes.alpPage) {
    return `/${locale?.toLowerCase()}/${topicSlug}/${slug ? `${slug}` : ''}`
  } else if (pageType === pageTypes.searchPage) {
    return `/${locale?.toLowerCase()}/search?term=${encodeURI(searchTerm)}`
  } else if (pageType === pageTypes.plpPage) {
    if (locale === locales.japanese) {
      return `/${locale?.toLowerCase()}/fabric-softener${
        topicSlug === 'by-need' ? `/${topicSlug}` : ''
      }${slug ? `/${slug}` : ''}`
    } else {
      return `/${locale?.toLowerCase()}/fabric-softener${
        slug ? `/${slug}` : ''
      }`
    }
  } else if (pageType === pageTypes.faqPage) {
    if (locale === locales.japanese) {
      return `/${locale?.toLowerCase()}/tips-and-articles/faqs${
        slug ? `/${slug}` : ''
      }`
    } else {
      return `/${locale?.toLowerCase()}/conseils-pour-soins-buccodentaires/faqs${
        slug ? `/${slug}` : ''
      }`
    }
  } else if (pageType === pageTypes.edpPage) {
    if (locale === locales.japanese) {
      return `/${locale?.toLowerCase()}/${topicSlug?.toLowerCase()}${
        listingSlug ? `/${listingSlug?.toLowerCase()}` : ''
      }/${slug}`
    }
  } else if (pageType === pageTypes.elpPage) {
    return `/${locale}/${topicSlug?.toLowerCase()}/${
      listingSlug ? `/${listingSlug?.toLowerCase()}` : ''
    }/${slug}`
  } else {
    return null
  }
}

export default urlHelper
