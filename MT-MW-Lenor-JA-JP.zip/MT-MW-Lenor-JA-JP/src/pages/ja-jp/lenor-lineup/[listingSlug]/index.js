import ExperiencePage from '@containers/ExperiencePage'
import FallbackPage from '@containers/FallBackPage'
import {
    getExperienceData,
    getExperienceListingSlug,
} from 'src/adapters/contentful/contentful.helper'
import { locales } from '@constants'

export const getStaticPaths = async () => {
    const paths = await getExperienceListingSlug({ locale: locales.japanese })
    return {
        paths: paths,
        fallback: true,
    }
}

export const getStaticProps = async ({ params: { listingSlug: slug } }) => {
    const ExperienceData = await getExperienceData({
        locale: locales.japanese,
        slug,
        topic: 'lenor-lineup',
    })

    return ExperienceData
}

export default FallbackPage(ExperiencePage)
