import ExperiencePage from '@containers/ExperiencePage'
import FallbackPage from '@containers/FallBackPage'
import {
    getExperienceData,
    getExperienceSlug,
} from 'src/adapters/contentful/contentful.helper'
import { locales } from '@constants'

export const getStaticPaths = async () => {
    const paths = await getExperienceSlug({ locale: locales.japanese })
    //console.log(paths, 'detail')
    return {
        paths: paths,
        fallback: true,
    }
}

export const getStaticProps = async ({ params: { detailSlug: slug } }) => {
    const ExperienceData = await getExperienceData({
        locale: locales.japanese,
        slug,
    })

    return ExperienceData
}

export default FallbackPage(ExperiencePage)
