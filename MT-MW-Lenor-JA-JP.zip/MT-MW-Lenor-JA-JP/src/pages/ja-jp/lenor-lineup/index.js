import ExperienceListingPage from 'src/containers/ExperienceListingPage'
import FallbackPage from '@containers/FallBackPage'
import { getExperienceListingData } from 'src/adapters/contentful/contentful.helper'
import { locales } from 'src/constants'

export const getStaticProps = async () => {
    const ExperienceListingData = await getExperienceListingData({
        locale: locales.japanese,
        slug: 'lenor-lineup',
    })

    return ExperienceListingData
}

export default FallbackPage(ExperienceListingPage)
