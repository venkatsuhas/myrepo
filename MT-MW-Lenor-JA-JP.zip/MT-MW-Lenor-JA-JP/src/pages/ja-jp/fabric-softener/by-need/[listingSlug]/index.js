import ProductListingPage from '@containers/ProductListingPage'
import FallbackPage from '@containers/FallBackPage'
import {
    getProductListingSlug,
    getProductListingData,
} from '@contentful/contentful.helper'
import { locales } from '@constants'

export const getStaticPaths = async () => {
    const paths = await getProductListingSlug({ locale: locales.japanese })
    return {
        paths: paths,
        fallback: true,
    }
}

export const getStaticProps = async ({ params: { listingSlug: slug } }) => {
    const PDPData = await getProductListingData({
        locale: locales.japanese,
        topic: 'by-need',
        slug,
    })
    return PDPData
}

export default FallbackPage(ProductListingPage)
