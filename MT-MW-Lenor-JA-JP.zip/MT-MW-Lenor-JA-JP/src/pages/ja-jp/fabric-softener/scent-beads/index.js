import ProductListingPage from '@containers/ProductListingPage'
import FallbackPage from '@containers/FallBackPage'
import { getProductListingData } from '@contentful/contentful.helper'
import { locales } from '@constants'

export const getStaticProps = async () => {
    const ProductListingData = await getProductListingData({
        locale: locales.japanese,
        slug: 'scent-beads',
    })
    return ProductListingData
}

export default FallbackPage(ProductListingPage)
