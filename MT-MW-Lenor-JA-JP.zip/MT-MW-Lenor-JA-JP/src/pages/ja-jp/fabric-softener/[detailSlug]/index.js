import ProductPage from '@containers/ProductPage'
import FallbackPage from '@containers/FallBackPage'
import { getPDPData, getPDPSlug } from '@contentful/contentful.helper'
import { locales } from '@constants'
export const getStaticPaths = async () => {
    const paths = await getPDPSlug({ locale: locales.japanese })
    return {
        paths: paths,
        fallback: true,
    }
}

export const getStaticProps = async ({ params: { detailSlug: slug } }) => {
    const PDPData = await getPDPData({
        locale: locales.japanese,
        slug,
    })
    return PDPData
}

export default FallbackPage(ProductPage)
