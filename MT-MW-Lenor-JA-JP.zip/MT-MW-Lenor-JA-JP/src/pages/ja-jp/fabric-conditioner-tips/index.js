import ArticleListingPage from 'src/containers/ArticleListingPage'
import FallbackPage from '@containers/FallBackPage'
import { getArticleListingData } from 'src/adapters/contentful/contentful.helper'
import { locales } from 'src/constants'

export const getStaticProps = async () => {
    const ArticleListingData = await getArticleListingData({
        locale: locales.japanese,
        slug: 'fabric-conditioner-tips',
    })

    return ArticleListingData
}

export default FallbackPage(ArticleListingPage)
