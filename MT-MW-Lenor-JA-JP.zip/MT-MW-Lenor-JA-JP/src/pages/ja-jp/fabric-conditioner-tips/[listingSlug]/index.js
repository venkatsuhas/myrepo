import ArticleListingPage from 'src/containers/ArticleListingPage'
import FallbackPage from 'src/containers/FallBackPage'
import {
    getArticleListingData,
    getArticleListingSlug,
} from 'src/adapters/contentful/contentful.helper'
import { locales } from 'src/constants'

export const getStaticPaths = async () => {
    const paths = await getArticleListingSlug({ locale: locales.japanese })
    return {
        paths: paths,
        fallback: true,
    }
}
export const getStaticProps = async ({ params: { listingSlug: slug } }) => {
    const ArticleListingData = await getArticleListingData({
        locale: locales.japanese,
        topic: 'fabric-conditioner-tips',
        slug,
    })
    return ArticleListingData
}

export default FallbackPage(ArticleListingPage)
