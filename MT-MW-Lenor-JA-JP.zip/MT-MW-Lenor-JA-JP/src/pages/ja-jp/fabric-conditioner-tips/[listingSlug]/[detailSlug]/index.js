import ArticlePage from '@containers/ArticlePage'
import FallbackPage from '@containers/FallBackPage'
import {
    getADPData,
    getADPSlug,
} from 'src/adapters/contentful/contentful.helper'
import { locales } from '@constants'
export const getStaticPaths = async () => {
    const paths = await getADPSlug({ locale: locales.japanese })
    // console.log(paths, 'path')
    return {
        paths: paths,
        fallback: true,
    }
}

export const getStaticProps = async ({
    params: { detailSlug: slug, listingSlug },
}) => {
    const ADPData = await getADPData({
        locale: locales.japanese,
        slug,
        listingSlug,
    })
    return ADPData
}

export default FallbackPage(ArticlePage)
