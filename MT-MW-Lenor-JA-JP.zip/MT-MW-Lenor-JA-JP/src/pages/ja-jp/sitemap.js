import { locales } from '@constants'
import Sitemap from '@containers/Sitemap'
import FallbackPage from '@containers/FallBackPage'
import { getSitemapData } from '@contentful/contentful.helper'

export const getStaticProps = async () => {
    const SitemapData = await getSitemapData({ locale: locales.japanese })
    return SitemapData
}

export default FallbackPage(Sitemap)
