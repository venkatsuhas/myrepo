import ContactUsPage from 'src/containers/ContactUsPage'
import FallbackPage from 'src/containers/FallBackPage'
import { locales } from 'src/constants'
import { getContactUsData } from 'src/adapters/contentful/contentful.helper'

export const getStaticProps = async () => {
    const ContactUs = await getContactUsData({
        slug: 'contact-us',
        locale: locales.japanese,
    })
    return ContactUs
}

export default FallbackPage(ContactUsPage)
