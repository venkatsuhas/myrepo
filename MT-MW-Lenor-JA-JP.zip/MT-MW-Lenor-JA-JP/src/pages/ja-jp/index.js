import HomePage from 'src/containers/HomePage'
import FallbackPage from 'src/containers/FallBackPage'
import { locales } from '@constants'
import { getHomePageData } from '@contentful/contentful.helper'

export const getStaticProps = async () => {
    const homePageData = await getHomePageData({ locale: locales.japanese })
    return homePageData
}

export default FallbackPage(HomePage)
