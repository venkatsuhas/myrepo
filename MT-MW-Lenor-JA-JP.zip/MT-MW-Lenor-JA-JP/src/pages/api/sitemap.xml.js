require('dotenv').config()
import { createSitemap } from '@generators/sitemap.generator'

const handler = async (req, res) => {
    if (req.method === 'GET') {
        res.setHeader('Content-type', 'text/xml')
        res.status(200).send(await createSitemap())
    } else {
        res.status(403).send('Unavailable method used')
    }
}

export default handler
