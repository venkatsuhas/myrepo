import '@helpers/wdyr'
import React, { useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import App from 'next/app'
import Head from 'next/head'
import Script from 'next/script'
import dynamic from 'next/dynamic'
import { telemetry } from '@adapters/telemetry'
import { useRouter } from 'next/router'
import { getHeaderData, getFooterData } from '@contentful/contentful.helper'
import { locales, pageTypes } from '@constants'
import '@styles/tailwind.css'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'
const Layout = dynamic(() => import('@components/Layout'))
const PageMetadata = dynamic(() => import('@components/PageMetadata'))

const MyApp = ({
    Component,
    pageProps: {
        pageData,
        pageType,
        headerData,
        footerData,
        japaneseHeaderData,
        japaneseFooterData,
        pageMetadata,
    },
}) => {
    const router = useRouter()
    useEffect(() => {
        telemetry.initialize()
    }, [])

    const [defaultData, setDefaultData] = useState({
        headerData,
        footerData,
    })

    useEffect(() => {
        const locale = router.asPath?.split('/')[1]
        if (
            pageType === pageTypes.errorPage &&
      locale === locales.japanese?.toLowerCase()
        ) {
            setDefaultData({
                headerData: japaneseHeaderData || {},
                footerData: japaneseFooterData || {},
            })
        } else {
            setDefaultData({
                headerData: headerData || {},
                footerData: footerData || {},
            })
        }
    }, [router.asPath])

    return (
        <>
            <Head>
                <meta
                    name='viewport'
                    content='width=device-width, initial-scale=1.0, maximum-scale=5.0, shrink-to-fit=no'
                />
            </Head>
            <Script
                id='pg-datalayer'
                async
                dangerouslySetInnerHTML={{
                    __html: `var PGdataLayer = { 'GTM': {
                            'SiteEnvironment': '${process.env.SITE_ENV}',
                            'SiteHost': '${process.env.SITE_HOST}',
                            'SiteTechnicalAgency': '${process.env.SITE_TA}',
                            'SiteLocale':'${
                              process.env.LANGUAGE
                            }-${process.env.COUNTRY?.toUpperCase()}',
                              'SiteCountry':'${process.env.COUNTRY?.toUpperCase()}',
                              'SiteBrand':'Febreze',
                              'SiteLanguage':'${process.env.LANGUAGE?.toUpperCase()}',
                              'SitePlatform': 'ModernWeb',
                            'SiteLocalContainer': '${process.env.SITE_LC}',
                            'GoogleAnalyticsLocal': '${process.env.GA_ID}',
                            'GoogleAnalyticsStaging': '${
                              process.env.GA_ID_STAGING
                            }',
                            'AdChoices': '${process.env.ADCHOICE}',
                            'AdChoicesID': '${process.env.ADCHOICE_ID}',
                            'EvidonOverlay':'${process.env.EVIDON_OVERLAY}',
                            'EvidonOverlayID': '${
                              process.env.EVIDON_OVERLAY_ID
                            }',
                            'GoogleAnalyticsDisabled': '${
                              process.env.GA_DISABLED
                            }'},
                            };`,
                }}
            ></Script>
            <Script
                id='gtm'
                async
                dangerouslySetInnerHTML={{
                    __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                                new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                                j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                                'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                                })(window,document,'script','dataLayer','${process.env.GTM_ID}');`,
                }}
            ></Script>
            <React.StrictMode>
                {pageMetadata && Object.keys(pageMetadata).length > 0 && (
                    <PageMetadata {...pageMetadata} />
                )}
                <Layout
                    headerData={defaultData.headerData}
                    footerData={defaultData.footerData}
                    pageType={pageType}
                >
                    <Component pageData={pageData} />
                </Layout>
            </React.StrictMode>
        </>
    )
}

MyApp.getInitialProps = async (context) => {
    const initialProps = await App.getInitialProps(context)
    const route_locale = context?.ctx?.asPath
        ?.split('/')
        ?.filter((text) => text)[0]
    const gen_locale = ((route_locale?.match('-') && route_locale) || '')
        .split('-')
        .map((entry, index) =>
            index > 0 ? entry?.toUpperCase() : entry?.toLowerCase(),
        )
        .join('-')
    const locale =
    Object.values(locales).indexOf(gen_locale) !== -1 ? gen_locale : null
    if (locale) {
        const headerData = await getHeaderData({ locale })

        const footerData = await getFooterData({ locale })

        return {
            ...initialProps,
            pageProps: { ...initialProps.pageProps, headerData, footerData },
        }
    } else {
        const japaneseHeaderData = await getHeaderData({ locale: locales.japanese })
        const japaneseFooterData = await getFooterData({ locale: locales.japanese })

        return {
            ...initialProps,
            pageProps: {
                ...initialProps.pageProps,
                japaneseHeaderData,
                japaneseFooterData,
            },
        }
    }
}

MyApp.propTypes = {
    Component: PropTypes.any,
    pageProps: PropTypes.object,
}

export default MyApp
