/* eslint-disable @next/next/next-script-for-ga */
// eslint-disable-next-line @next/next/no-document-import-in-page
import Document, { Html, Head, Main, NextScript } from 'next/document'
import React from 'react'

export default class MyDocument extends Document {
    static async getInitialProps(ctx) {
        const initialProps = await Document.getInitialProps(ctx)
        return { ...initialProps }
    }

    render() {
        return (
            <Html lang={process.env.SITE_LANG}>
                <Head>
                    <link
                        rel='shortcut icon preload'
                        as='image'
                        href='/static/images/favicon.ico'
                        type='image/x-icon'
                    />
                    <link
                        rel='icon preload'
                        as='image'
                        href='/static/images/favicon.ico'
                        type='image/x-icon'
                    />
                    <link
                        rel='preconnect'
                        href='https://fonts.gstatic.com'
                        crossOrigin='true'
                    />
                    <link
                        href='https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap'
                        rel='stylesheet'
                    />
                    <script
                        async
                        dangerouslySetInnerHTML={{
                            __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                                new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                                j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                                'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                                })(window,document,'script','dataLayer','${process.env.GTM_ID}');`,
                        }}
                    ></script>
                </Head>
                <body className='p-0 m-0 bg-none'>
                    <div className='bg-white bg-no-repeat pagewrapper  bg-centertop'>
                        <noscript
                            dangerouslySetInnerHTML={{
                                __html: `<iframe src='https://www.googletagmanager.com/ns.html?id=${process.env.GTM_ID}'
                                height='0' width='0' style='display:none;visibility:hidden'></iframe>`,
                            }}
                        ></noscript>
                        <Main />
                        <NextScript />
                    </div>
                </body>
            </Html>
        )
    }
}
