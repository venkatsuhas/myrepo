import ErrorPage from '@containers/ErrorPage'
import { getErrorPage } from '@adapters/contentful/contentful.helper'
import { locales } from '@constants'

ErrorPage.getInitialProps = async () => {
    const errorPageData = await getErrorPage({ locale: locales.japanese })
    return errorPageData
}

export default ErrorPage
