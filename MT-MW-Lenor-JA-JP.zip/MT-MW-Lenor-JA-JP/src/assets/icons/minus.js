import React from 'react'
import { svgNameSpace } from '@constants'

const MinusIcon = (className) => (
  <svg
    className={className}
    xmlns={svgNameSpace}
    width="15"
    height="15"
    viewBox="0 0 12 12"
  >
    <g transform="translate(-455 -264)">
      <path d="M455 269.25h12v1.46h-12z" />
    </g>
  </svg>
)

export default MinusIcon
