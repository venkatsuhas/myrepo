import MinusIcon from '@icons/minus'
import PlusIcon from '@icons/plus'
const Icons = {
  MinusIcon,
  PlusIcon,
}

export default Icons
