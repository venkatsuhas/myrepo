import React from 'react'
import { svgNameSpace } from '@constants'

const PlusIcon = (className) => (
  <svg
    className={className}
    xmlns={svgNameSpace}
    width="15"
    height="15"
    viewBox="0 0 12 12"
  >
    <path d="M5.272 0v5.273H-.004v1.455h5.273v5.273h1.455V6.728h5.272V5.273H6.727V0z" />
  </svg>
)

export default PlusIcon
