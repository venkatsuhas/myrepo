import React from 'react'
import PropTypes from 'prop-types'
import Button from '@components/Button'
import dynamic from 'next/dynamic'
const Icon = dynamic(() => import('@components/Icon'))

const ExperienceDetail = ({ Experience }) => {
  return (
    <div className="edp">
      {Experience && Experience.length > 0 && (
        <div className="mb-90 px-20 lg:px-0">
          {Experience.map((ele, index) => (
            <Button key={index} href={ele.href}>
              <div className="flex items-baseline">
                <Icon name="ArticleArrow" className="max-w-10" />
                <p>{ele.name}</p>
              </div>
            </Button>
          ))}
        </div>
      )}
    </div>
  )
}

ExperienceDetail.propTypes = {
  Experience: PropTypes.array,
}

export default ExperienceDetail
