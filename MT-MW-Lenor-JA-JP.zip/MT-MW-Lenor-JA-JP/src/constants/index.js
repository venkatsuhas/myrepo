module.exports = {
  locales: {
    japanese: 'ja-JP',
  },
  homePageText: 'ホーム',
  searchPlaceHolder: '検索キーワード',
  pageTypes: {
    adpPage: 'ArticleDetailPage',
    alpPage: 'ArticleListingPage',
    elpPage: 'ExperienceListingPage',
    edpPage: 'ExperienceDetailPage',
    sitemapPage: 'SitemapPage',

    errorPage: 'errorPage',
    contactUsPage: 'contactUsPage',
    homepage: 'HomePage',
    plpPage: 'ProductListingPage',
    searchPage: 'SearchPage',
    errorPage: 'ErrorPage',
    pdpPage: 'ProductDetailPage',
    plpPageView: 'ProductListingView',
  },
  productPage: {
    productDetailTitle: 'PRODUCT DETAILS',
    productUsageDetails: 'USAGE DETAILS',
    writeReviewLabel: 'WRITE A REVIEW',
    daysLabel: '$noDays days ago',
    sortByLabel: 'Sort by: ',
    moreReviewsLabel: 'Load More Reviews',
    ratings: 'From $count user(s)',
    relatedProductsTitle: `recommended products`,
    ourIngredientsTitle: 'OUR INGREDIENTS',
    // social share
    //   socialShareDescription: {
    //     shareTitle: "Lenorのサイトから外部のサイトへ移動します。",
    //     shareDesc:
    //       '移動する場合、P&Gのサイトと外部のサイトのプライバシーポリシーなどが異なりますので、別途確認いただく事を推奨します。外部のサイトで入力した個人情報は外部サイトのポリシーに沿って扱われますので、ご注意ください。Lenor のサイトをご利用いただき、ありがとうございます。'

    //     shareText: 'SHARE ON -',
    //     buttonLabel: '下記のリンクをクリックしてください。',

    //   },
    //   socialShareDetails: [
    //     {
    //       icon: 'facebookIcon',
    //       label: 'Facebook',
    //       href: `https://www.facebook.com/sharer.php`,
    //     },
    //     {
    //       icon: 'twitterIcon',
    //       label: 'Twitter',
    //       href: `https://twitter.com/intent/tweet`,
    //     },
    //   ]
    // },
    sortBy: {
      title: 'Sort',
      items: [
        { name: '470ml', value: 'featured' },
        { name: '570ml', value: 'ascending' },
        { name: '855ml', value: 'descending' },
      ],
    },
  },
  productsPerPagePLP: 8,
  productListingPage: {
    filters: 'Filters',
    products: '製品',
    show: 'を表示',
    hideFilters: 'Hide Filters',
    showFilters: 'Show Filters',
    applyFilter: 'APPLY FILTER',
    resetFilters: 'Reset filters',
    viewing: '商品表示中',
    viewingCount: 'Displaying products $count Products',
    plpBasePath: '/ja-jp/fabric-softener',
    sortBy: {
      title: '並び替え',
      items: [
        { name: 'おすすめ', value: 'featured' },
        { name: '人気順', value: 'featured1' },
        { name: '評価の高い順', value: 'featured2' },
        { name: '50音順（昇順）', value: 'ascending' },
        { name: '50音順（降順）', value: 'descending' },
        // { name: '価格（昇順）', value: 'lowToHigh' },
        // { name: '価格（降順）', value: 'highToLow' },
      ],
    },
    whereToBuy: 'WHERE TO BUY',
    clearAll: 'すべてクリア',
    filter: 'FILTER',
    loadMore: 'Load More Products',
    browseByLabels: {
      Category: 'カテゴリーから探す',
      Scents: 'SEARCH BY Scents',
    },
    recentlyViewedLabel: '最近見た商品',
  },
  ExperiencesPage: {
    socialShareDescription: {
      shareTitle: 'Lenorのサイトから外部のサイトへ移動します。',
      shareDesc:
        '移動する場合、P&Gのサイトと外部のサイトのプライバシーポリシーなどが異なりますので、別途確認いただく事を推奨します。外部のサイトで入力した個人情報は外部サイトのポリシーに沿って扱われますので、ご注意ください。Lenor のサイトをご利用いただき、ありがとうございます。',
      shareText: 'SHARE ON -',
      buttonLabel: '下記のリンクをクリックしてください。',
    },
    socialShareDetails: [
      {
        icon: 'instagram',
        label: 'Instagram',
        href: `https://www.instagram.com/`,
      },
    ],
  },
  Articlespage: {
    // Social Share
    socialShareDescription: {
      shareTitle: 'Lenorのサイトから外部のサイトへ移動します。',
      shareDesc:
        '移動する場合、P&Gのサイトと外部のサイトのプライバシーポリシーなどが異なりますので、別途確認いただく事を推奨します。外部のサイトで入力した個人情報は外部サイトのポリシーに沿って扱われますので、ご注意ください。Lenor のサイトをご利用いただき、ありがとうございます。',
      shareText: 'SHARE ON -',
      buttonLabel: '下記のリンクをクリックしてください。',
    },
    socialShareDetails: [
      {
        icon: 'facebookIcon',
        label: 'Facebook',
        href: `https://www.facebook.com/sharer.php`,
      },
      {
        icon: 'twitterIcon',
        label: 'Twitter',
        href: `https://twitter.com/intent/tweet`,
      },
    ],
  },

  searchPage: {
    sortBy: {
      title: '並び替え',
      sortLabel: '商品の並び替え',
      items: [
        {
          name: 'Highest Rating',
          value: 'highest rated',
          label: '評価の高い順',
        },
        { name: 'popular', value: 'popularity', label: '人気' },
        { name: 'relevance', value: 'relevancy', label: '関連度' },
        { name: 'ascending order', value: 'ascending', label: '昇順' },
        { name: 'descending order', value: 'descending', label: '降順' },
      ],
    },
    tabLabels: {
      product: { key: 'product', label: '商品から検索' },
      article: { key: 'article', label: '教えて！プロのコツから検索' },
    },
    searchText: 'の検索結果',
    noResultsLabel: 'を検索しましたが、何も見つかりませんでした',
  },
  siteCountries: {
    items: [
      {
        columns: [
          {
            name: 'NORTH AMERICA',
            items: [
              {
                name: 'Canada Canada',
                lang: 'English English',
                locale: 'en-ca',
                url: 'http://www.downy.com/en-CA/index.jspx',
              },
              {
                name: 'Canada Canada',
                lang: 'Français français',
                locale: 'fr-ca',
                url: 'https://downy.com/fr-CA/index.jspx',
              },
              {
                name: 'USA United',
                lang: 'English English',
                locale: 'en-us',
                url: 'https://downy.com/en-us',
              },
              {
                name: 'USA',
                lang: 'Español',
                locale: 'en-us',
                url: 'https://downy.com/es-US/index.jspx',
              },
            ],
          },
          {
            name: 'ASIA PACIFIC',
            items: [
              {
                name: 'Japan',
                lang: 'Japanese',
                locale: 'ja-jp',
                url: '/ja-jp',
              },
              {
                name: 'Thailand',
                lang: 'Thai',
                locale: 'th-th',
                url: 'https://www.downy.co.th/th-th',
              },
            ],
          },
          {
            name: 'MIDDLE EAST',
            items: [
              {
                name: 'Saudi Arabia العربية العربية',
                lang: 'المملكة',
                locale: 'ar-sa',
                url: 'https://www.downy.sa/ar-sa',
              },
              {
                name: 'Saudi Arabia',
                lang: 'English',
                locale: 'en',
                url: 'https://en.downy.sa/en',
              },
            ],
          },
        ],
      },
      {
        columns: [
          {
            name: 'AMÉRICA LATINA',
            items: [
              {
                name: 'Brasil',
                lang: '',
                locale: 'pt-br',
                url: 'https://www.downy.com.br/pt-br/',
              },
              {
                name: 'Centro America',
                lang: '',
                locale: '',
                url: 'http://www.downy.com.pa/home.aspx',
              },
              {
                name: 'Colombia',
                lang: '',
                locale: '',
                url: 'https://www.downy.com.co/home.aspx',
              },
              {
                name: 'Ecuador/Bolivia',
                lang: '',
                locale: '',
                url: 'http://www.downy.com.ec/home.aspx',
              },
              {
                name: 'México',
                lang: '',
                locale: 'es-mx',
                url: 'http://www.downy.com.mx/home.aspx',
              },
              {
                name: 'Perú',
                lang: '',
                locale: '',
                url: 'http://www.downy.com.pe/home.aspx',
              },
              {
                name: 'Venezuela',
                lang: '',
                locale: '',
                url: 'http://www.downy.com.ve/home.aspx',
              },
            ],
          },
          {
            name: 'EUROPE',
            items: [
              {
                name: 'Germany',
                lang: 'Deutsch',
                locale: 'de-de',
                url: 'https://www.lenor.de/de-de',
              },
              {
                name: 'UK United',
                lang: 'English English',
                locale: 'en-gb',
                url: 'https://www.lenor.co.uk/en-gb',
              },
            ],
          },
        ],
        items: [
          {
            name: 'Canada',
            lang: 'English',
            locale: 'en-ca',
            url: '/en-ca',
          },
          {
            name: 'Canada',
            lang: 'French',
            locale: 'fr-ca',
            url: '/fr-ca',
          },
          {
            name: 'USA',
            lang: 'English',
            locale: 'en-us',
            url: 'https://www.febreze.com/en-us',
          },
        ],
      },
    ],
  },
  footerBusinessLabel: {
    business: 'BusinessIcon',
  },
  svgNameSpace: 'https://www.w3.org/2000/svg',
  articlesPerPageALP: 15,
  experiencePerPageELP: 6,
  mobileFooterLabels: {
    countrySelectorLabel: '国・地域',
    brandListLabel: 'ブランド一覧',
    pleaseSelectLocation: '場所を選択してください',
    countryLanguage: ' 日本 | 日本語',
    enquiry: {
      text: 'お問い合わせ',
      href: '/ja-jp/contact-us',
    },
    viewPage: {
      text: 'ページ全体を見る',
      href: '',
    },
    copyRight: `© ${new Date().getFullYear()} Procter & Gamble`,
  },

  labels: {
    relatedArticles: '関連記事',
    Experience: 'experience cards',
    readArticle: 'Read article',
    readExperience: '詳しくはこちら',
    experienceListingPage: {
      listCategoryLabels: [
        {
          key: 'レノア超消臭1WEEK',
          label: 'レノア超消臭1WEEK',
          url: '/ja-jp/lenor-lineup',
        },

        {
          key: 'レノアハピネス',
          label: 'レノアハピネス',
          url: '/ja-jp/lenor-lineup',
        },

        {
          key: 'レノアリセット',
          label: 'レノアリセット',
          url: '/ja-jp/lenor-lineup',
        },

        {
          key: 'レノアオードリュクス',
          label: 'レノアオードリュクス',
          url: '/ja-jp/lenor-lineup',
        },

        {
          key: 'レノア超消臭抗菌ビーズ',
          label: 'レノア超消臭抗菌ビーズ',
          url: '/ja-jp/lenor-lineup',
        },
        {
          key: 'レノアハピネスアロマジュエル',
          label: 'レノアハピネスアロマジュエル',
          url: '/ja-jp/lenor-lineup',
        },
      ],
      categoryArray: [
        'レノア超消臭1WEEK',
        'レノアハピネス',
        'レノアリセット',
        'レノアオードリュクス',
        'レノア超消臭抗菌ビーズ',
        'レノアハピネスアロマジュエル',
      ],
      categorySlugObject: {
        レノア超消臭1WEEK: '/ja-jp/lenor-lineup/about-lenor-honkaku-shoushu',
        レノアハピネス: '/ja-jp/lenor-lineup/about-lenor-happiness',
        レノアリセット: '/ja-jp/lenor-lineup/about-lenor-reset',
        レノアオードリュクス: '/ja-jp/lenor-lineup/about-lenor-eaudeluxe',
        レノア超消臭抗菌ビーズ: '/ja-jp/lenor-lineup/about-lenor-kokin-beads',
        レノアハピネスアロマジュエル:
          '/ja-jp/lenor-lineup/about-lenor-aroma-jewel',
      },
      categoryObject: {
        レノア超消臭1WEEK: 'レノア超消臭1WEEK',
        レノアハピネス: 'レノアハピネス',
        レノアリセット: 'レノアリセット',
        レノアオードリュクス: 'レノアオードリュクス',
        レノア超消臭抗菌ビーズ: 'レノア超消臭抗菌ビーズ',
        レノアハピネスアロマジュエル: 'レノアハピネスアロマジュエル',
      },
    },
  },
  articleListingPage: {
    listCategoryLabels: [
      {
        key: '柔軟剤の使い方と大事さ',
        label: '柔軟剤の使い方と大事さ',
        url: 'ja-jp/fabric-conditioner-tips',
      },

      {
        key: '消臭、防臭',
        label: '消臭、防臭',
        url: 'ja-jp/fabric-conditioner-tips',
      },

      {
        key: '香り付け',
        label: '香り付け',
        url: 'ja-jp/fabric-conditioner-tips',
      },

      {
        key: '衣類のケア',
        label: '衣類のケア',
        url: 'ja-jp/fabric-conditioner-tips',
      },

      {
        key: 'よくある質問',
        label: 'よくある質問',
        url: 'ja-jp/fabric-conditioner-tips',
      },
    ],
    categoryArray: [
      '柔軟剤の使い方と大事さ',
      '消臭、防臭',
      '香り付け',
      '衣類のケア',
      'よくある質問',
    ],
    categorySlugObject: {
      柔軟剤の使い方と大事さ:
        '/ja-jp/fabric-conditioner-tips/how-to-use-liquid-fabric-softener',
      '消臭、防臭': '/ja-jp/fabric-conditioner-tips/odor-prevention',
      香り付け: '/ja-jp/fabric-conditioner-tips/scent-enjoyment',
      衣類のケア: '/ja-jp/fabric-conditioner-tips/protect-your-clothes',
      よくある質問: '/ja-jp/fabric-conditioner-tips/laundry-faqs',
    },
    categoryObject: {
      柔軟剤の使い方と大事さ: '柔軟剤の使い方と大事さ',
      '消臭、防臭': '消臭、防臭',
      香り付け: '香り付け',
      衣類のケア: '衣類のケア',
      よくある質問: 'よくある質問',
    },
    sortBy: {
      title: '並び替え',
      items: [
        { name: '人気順', value: 'featured' },
        { name: 'おすすめ順', value: 'descending' },
      ],
    },
    browseArticlesLabel: 'カテゴリーを選ぶ',
    filters: 'Filters',
    applyFilter: 'APPLY FILTER',
    loadMore: 'Load More Articles',
    showingCount: 'を表示 $count 記事',
    viewingCount: 'viewing $count items',
    browseArticlesLabel: 'カテゴリーを選ぶ',
    moreButton: 'MORE',
    viewing: 'VIEWING',
    clearAll: 'CLEAR ALL',
    filter: 'FILTER',
    filterBy: 'filter by',
    sort: 'Sort — Recommended',
    filterSpec: 'Filter specification',
  },

  allIcons: {
    menuClassNames: ['shops-dd', 'tips-dd', 'safety-dd', 'save-dd'],
    iconWithLabel: ['AdChoices'],
    iconSource: {
      facebookIcon:
        'https://images.ctfassets.net/2abb8ktwdiin/5SHjTaqufNL08PxxhPMbAb/62a756d49adeafd67b87c50ef515781f/social_FB.png',

      twitterIcon:
        'https://images.ctfassets.net/2abb8ktwdiin/35LliBCwBspuWXXAAzIUI0/6e0a75785f2bd2f41d14a5fb7d946129/social_twitter.png',
      ArielIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/55DjxITG8ugl1cZanhePmY/bdfa862060eede8d73de5e0bb83c1de7/Ariel_japan.png?h=250',
      PandGIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/3cLz3cYC0Y03QbgzG3itPt/0a31fdac4ba6a71250acb9a262618861/PGeStore_DT.png?h=250',
      BusinessIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/1CLIaorh92HClw7scFw6A2/7f7ed4fdfcd1b5a12d6bb7a939e50c59/BBB.png?h=250',
      BoldIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/7zQUM8rBAtTdLtI3zK9eti/8fa3539f9dc55fd91352686ad8c6f8e5/Bold_Desktop.png?h=250',
      HouseLogoIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/ZzSx5EN5PzZiWZVxPplKR/b96f196e5b2b745928a875803ff9aa69/HouseLogo_Desktop.png?h=250',
      Close:
        'https://images.ctfassets.net/5go9vi5tpqi4/m6bCsoXB13lBXjQXh9k4w/b2fbfb5f669c35c83193ced8a9807f92/ModalDialogClose.png?h=250',
      YouTubeIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/2hRZjHeN52dptl75xbgMzc/ba2676a88120c68b0a1831544b829052/YouTube_SP.png?h=250',
      Left_Arrow:
        'https://images.ctfassets.net/5go9vi5tpqi4/18cImP497AA0187eztpQJW/0867f39d35102f7c703e96acca9cc51a/arrow_left.png?h=250',
      Right_Arrow:
        'https://images.ctfassets.net/5go9vi5tpqi4/3jklhiaC02TFsAReWhFzuh/936613c83dd49a2a9f9ebda9eba8d9e7/arrowright.png?h=250',
      LogoWithBorder:
        'https://images.ctfassets.net/5go9vi5tpqi4/3fBE71YDGAcjG0LHUyk8vq/fb10529a533a487e917f2d3b8fbeebb6/DTWashinWowCallout_new.png?h=300',
      Icon_Article:
        'https://azcdn.pioneer.pgsitecore.com/ja-jp/-/media/Downy_JP/Images/Common/icon_article.png?v=1-201606301752',
      listIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/6GRzUKU7JI9zGCtWzrPkuz/31771036a8eb850354fe85c0b7cf3837/ListViewIcon.png?h=250',
      listIconActive:
        'https://images.ctfassets.net/5go9vi5tpqi4/494gNSIrtpSFNtrjyE2JZj/814c4b407a0d9722771687c0096ec9cc/ListViewIcon-on.png?h=250',
      gridIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/6ftH4G1CYM3iQR8tlf9MK8/be6458b163c87e21739b400c979661be/GridViewIcon.png?h=250',
      gridIconActive:
        'https://images.ctfassets.net/5go9vi5tpqi4/1ZgJuyGa0xtCPdA74OOlXm/502342e0404b899652735dc8d73b2d8a/GridViewIcon-on.png?h=250',
      listViewIcon:
        'https://images.ctfassets.net/2abb8ktwdiin/X1pN0RUtlWj1XvwlvlyHg/359081e5be240d3ad32dd655bca74d84/ListViewIcon.png?h=250',
      listViewIconOn:
        'https://images.ctfassets.net/2abb8ktwdiin/xa3ycz2SN9znMgVwA03a8/ac22896b0f1c07600b9d6685902fccaf/ListViewIcon-on.png?h=250',
      girdViewIcon:
        'https://images.ctfassets.net/2abb8ktwdiin/bcZnsc15dczQMt4IxAT5r/9f424ebb6807d2fb881f205be731d65d/GridViewIcon.png?h=250',
      girdViewIconOn:
        'https://images.ctfassets.net/2abb8ktwdiin/pDOvNud8b2AfHY1NAqwK0/d5f4aaf269918e309ba251577e67f7dd/GridViewIcon-on.png?h=250',

      FilterCloseIcon:
        'https://images.ctfassets.net/2abb8ktwdiin/Adc17s2cX8PnidfQABm1Q/3124ff2716940dfe1a2bb111a14d18c5/facet-close.png?h=250',
      FilterAccordionRight:
        'https://images.ctfassets.net/2abb8ktwdiin/2leKOF3dl6BPtIw22B5ixp/e3edf96511788b0bf27d5b8d97313313/icon-facet.png?h=250',
      FilterAccordionDown:
        'https://images.ctfassets.net/5go9vi5tpqi4/3ljllNgV1PJI3JA0R84T6r/747141d8f0e917374ebdde5eae48b416/icon-facet-on.png?h=250',
      FilterAccordDown:
        'https://images.ctfassets.net/5go9vi5tpqi4/3ljllNgV1PJI3JA0R84T6r/747141d8f0e917374ebdde5eae48b416/icon-facet-on.png?h=250',
      FilterAccordRight:
        'https://images.ctfassets.net/5go9vi5tpqi4/10r1XCTrTCjB5VGkvZD8UK/14c42ecb0113783035ae14a3d267c404/icon-facet_right.png',
      ArrowMainNav:
        'https://images.ctfassets.net/5go9vi5tpqi4/6DXvgMLdWeiSMWdLquiiGY/71f0d0bc2f40ce4f0c05553c5fb6c33e/DT_MainMenuIcon.png?h=250',
      ArrowMainWhiteNav:
        'https://images.ctfassets.net/5go9vi5tpqi4/56VO7aBSH4HV12mfnM6CpW/e04022b62191d3d2bd8dcb5c828717da/arrow_MainNav_white.png?h=250',
      RightMenuArrowMobile:
        'https://images.ctfassets.net/5go9vi5tpqi4/1qPDVq32RB3iwA6OUFxs7w/695d678c28ca52a5fcd9598f375b2052/MainMenuIcon.png?h=250',
      ArielFooterIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/7s9wiLFrFe1kDet9HW0DPt/390ea332213b8d33e9fcb2b2163fe62e/Ariel_Desktop_BrandMainLogo-1_Blue.jpg?h=250',
      PandGFooterIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/1yHtX87wKYC7szW4aUN6Y8/c44a4692a187de699ea900a94d2fe743/PGeStore.jpg?h=250',
      BoldFooterIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/7gSSa2F3OZJi2gUoCty2lI/4829d8f9dca89cc7a7af68efd7ba40d0/Bold_Mobile.png?h=250',
      HouseLogoFooterIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/UVm1dvIk8kRZCe9VaYtfY/593453a7a2069dd5184bbb24eab0fb62/HouseLogo_Mobile.png?h=250',
      SarasFooterIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/1JCOYQD4rOhVPq4aJvqJty/a475b542ea916bbb96067d267056efb5/Sarasa_Mobile.png?h=250',
      RightCountrySelectorMobileIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/74jPASrrsyVBYWFzKItloj/99fc623355e9311070b25059de0dc892/RightArrowNavigationIcon.png?h=250',
      plpFooterLogo:
        'https://images.ctfassets.net/5go9vi5tpqi4/in8kAPTagJ8BKF1upRze5/afcc8712f8da61d93d0dcbe5193e1a05/Honkaku-new.png?h=250',
      HamburgerIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/2ti39VAzPFAxzhtm1a8F1b/3a37e2968bd19b5583e3edb1a983b047/NavigationIcon.png?h=250',
      MobileSearchIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/5GpOaN0DoO8Uj3usa91YCT/52289c2c4a83670592ba9f730fe13345/SmartphoneSearchIcon.png?h=250',
      DownNavigationIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/5CTsFNeQtCpCRWq4JXXFEr/ceabde1bcfe80ab99370ea403216f825/DownNavigationIcon.png?h=250',
      UpNavigationIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/5pCHJUO0rNxnejSAJfrteL/36230791f69043eb04f7d6ee107e4928/UpNavigationIcon.png?h=250',
      SearchBoxIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/2Iz6nrbGYwMaP8CwXPezQP/8c843bb423f881347b5c13e3c5c55d43/SearchBoxIcon.png?h=250',
      AdChoicesIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/7MZNG23nLwBTk8qu8vOrBE/01c08b4474efd2c822c055d755a9bf3e/AdChoices.png?h=250',
      RightSliderIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/2Qa2UBybJ95fjVAThothJY/35841d28256892f7693a22f75a4275db/arrowright.png?h=250',
      NavigationCloseIcon:
        'https://images.ctfassets.net/5go9vi5tpqi4/6k49wQWAEWhBUeMXmXgBkV/ed15465c629ebac6fa9a616c6be80b53/NavigationIconClose.png?h=250',
    },
    sliderArrow: {
      rightAltText: 'RightArrow',
      leftAltText: 'LeftArrow',
    },
    headerIcons: {
      ariel: 'ArielIcon',
      pandg: 'PandGIcon',
      bold: 'BoldIcon',
      houseLogo: 'HouseLogoIcon',
    },
    adpSocial: {
      twitter: 'TwitterIcon',
      facebook: 'FacebookIcon',
      link: 'LinkIcon',
    },
    footerIcons: {
      ariel: 'ArielFooterIcon',
      pandg: 'PandGFooterIcon',
      bold: 'BoldFooterIcon',
      houseLogo: 'HouseLogoFooterIcon',
      sarasLogo: 'SarasFooterIcon',
    },

    footerSocial: {
      youtube: 'YouTubeIcon',
    },
    mostPopular: 'MOST POPULAR',
    pageTypes: {
      alpPage: 'ArticleListingPage',
      adpPage: 'ArticleDetailPage',
      elpPage: 'ExperienceListingPage',
      edpPage: 'ExperienceDetailPage',
    },
    logoWithBorder: 'LogoWithBorder',
    Icon_Article: 'Icon_Article',
    plpFooterLogo: 'plpFooterLogo',
  },
  allIconLinks: {
    ArielIcon: 'https://ariel.jp/ja-jp',
    PandGIcon: 'http://jp.pg.com/',
    BoldIcon: 'https://www.myrepi.com/brands/bold/',
    HouseLogoIcon: 'https://www.myrepi.com/',
    YouTubeIcon: 'https://www.youtube.com/channel/UCvRb6X3koJLVQCarA7slV1Q',
    ArielFooterIcon: 'https://ariel.jp/ja-jp',
    PandGFooterIcon: 'http://jp.pg.com/',
    BoldFooterIcon: 'https://www.myrepi.com/brands/bold/',
    HouseLogoFooterIcon: 'https://www.myrepi.com/',
    SarasFooterIcon: 'https://sarasajp.com/',
  },
  recentlyViewedItemsLength: 5,
}
