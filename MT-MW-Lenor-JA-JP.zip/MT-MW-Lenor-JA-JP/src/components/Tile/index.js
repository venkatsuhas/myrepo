import React from 'react'
import PropTypes from 'prop-types'
import ExternalLink from '@components/Common/ExternalLink'

const Tile = ({ title, children, href }) => {
    return (
        <ExternalLink
            href={href}
            className='flex flex-col p-4 rounded-md bg-white bg-opacity-20 cursor-pointer group hover:bg-opacity-10 duration-200'
        >
            <span className='text-lg font-bold mb-3 mr-3'>
                <span className='group-hover:underline'>{title}</span>
                <span className='ml-2 no-underline'>&rarr;</span>
            </span>
            <span>{children}</span>
        </ExternalLink>
    )
}

Tile.propTypes = {
    title: PropTypes.string.isRequired,
    href: PropTypes.string.isRequired,
    children: PropTypes.node.isRequired,
}

export default Tile
