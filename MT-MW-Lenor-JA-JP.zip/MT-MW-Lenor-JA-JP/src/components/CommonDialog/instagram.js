import React, { useState, useRef, useEffect, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { ExperiencesPage } from '@constants'
import styles from '@components/CommonDialog/Common.tw-style'
import Typography from '@components/Typography'

const Icon = dynamic(() => import('@components/Icon'))
const Button = dynamic(() => import('@components/Button'))

const SocialShareDialog = ({
    closeModal,
    variant,
    socialShareDetails,
    // media,
    // description,
}) => {
    const labels = ExperiencesPage || []
    const [outsideClick, setOutsideClick] = useState(false)
    const popUpNode = useRef()

    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (
                popUpNode.current &&
        (popUpNode.current === event.target ||
          popUpNode.current.contains(event.target))
            ) {
                setOutsideClick(false)
            } else {
                setOutsideClick(true)
            }
        }

        document.addEventListener('mousedown', handleOutsideClick)
        return () => {
            document.removeEventListener('mousedown', handleOutsideClick)
        }
    }, [])
    useEffect(() => {
        if (outsideClick) {
            closeModal()
            setOutsideClick(false)
        }
    }, [outsideClick])

    const style = variant ? styles[variant] : styles.default
    const socialShareLinks = {
        Instagram: `https://www.instagram.com/p?u=${window.location.href}`,
    }
    return (
        <div className={style.wrapperBlock}>
            <div className={style.container}>
                <div className={style.wapper} ref={popUpNode}>
                    <div className={style.close}>
                        <Button gaClass='event_button_click' onClick={closeModal}>
                            <Icon className='closeIcon' name='Close' />
                            <span className={style.closeicon}>&#215;</span>
                        </Button>
                    </div>
                    <div className={styles.adpSocialDialogContent.heading}>
                        <Typography
                            content={labels?.socialShareDescription?.shareTitle}
                        ></Typography>
                    </div>

                    <div>
                        <Button
                            href={socialShareLinks[socialShareDetails?.label]}
                            className={styles.adpSocialDialogContent.shareBtn}
                            onClick={closeModal}
                        >
                            <div className='bg-accent font-AvenirLTBook uppercase text-white w-fit font-normal rounded-full mt-20 py-5 px-40 mx-100  event_external_link'>
                                {`share on ${socialShareDetails?.label}`}
                            </div>
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    )
}

SocialShareDialog.propTypes = {
    closeModal: PropTypes.func,
    media: PropTypes.string,
    variant: PropTypes.string,
    socialShareDetails: PropTypes.object,
    description: PropTypes.string,
}

export default memo(SocialShareDialog)
