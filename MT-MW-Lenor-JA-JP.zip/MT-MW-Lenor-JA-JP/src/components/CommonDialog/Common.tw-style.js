module.exports = {
    default: {
        wrapperBlock: '',
        container:
      'CountrySelector-container  fixed z-50 overflow-y-auto inset-0 bg-countryOverlaybg flex items-baseline',
        wapper:
      'CountrySelector-wrapper relative px-20 mdl:w-1/2 bg-white fixed mt-40 left-40p rounded-2xl overflow-hidden py-25 mdl:py-20',
        close: 'closeDiv absolute right-20 top-0',
        body: 'bodyDiv pt-40 mdl:pt-0',
        bodyTitle:
      'titleDiv text-left text-17 text-primary leading-24 font-AvenirNextRoundedBold font-normal mb-20',
    },
    videoCardView: {
        wrapperBlock:
      'fixed z-50 overflow-y-auto inset-0 bg-countryOverlaybg flex items-baseline',
        container:
      'relative px-20 mdl:w-1/2 bg-white mt-100 left-25p overflow-hidden py-25 mdl:py-20 rounded-2xl',
        close: 'closeDiv absolute right-20 -top-20',
        body: 'bodyDiv pt-40 mdl:pt-0',
        heading: 'font-AvenirNextRoundedBold text-20 leading-4 mb-20',
        description:
      'text-16 leading-19 text-left text-primary font-AvenirNextRoundedReg',
        checkboxWrapper: 'w-full flex',
        shareBtn:
      'bg-black font-AvenirNextRoundedReg text-white font-bold mt-20 py-5 px-10',
        bodyTitle:
      'titleDiv text-left text-17 text-primary leading-24 font-AvenirNextRoundedBold font-normal mb-20',
    },
    emailDialogContent: {},
    adpSocialDialogContent: {
        wrapperBlock:
      'fixed z-50 overflow-y-auto inset-0 bg-countryOverlaybg flex items-baseline',
        container:
      'relative mdl:w-660 mdl:h-380 rounded-lg bg-white text-accent fixed top-50p -translate-y-2/4 left-35p overflow-hidden p-40',
        close: 'closeDiv absolute right-10 top-10 h-24 w-16',
        body: 'bodyDiv pt-40 mdl:pt-0',
        heading: 'font-AvenirLTLight text-30 leading-30 mb-20 pt-50 ml-100',
        description:
      'text-14 leading-20 pt-20 pb-10 text-left mx-100 text-darkgray font-AvenirLTBook',
        checkboxWrapper: 'w-full flex',
        closeicon:
      -'text-accent font-AvenirLTBook font-normal h-24 w-16 text-28 leading-28 opacity-1  closeTxtcls',
        shareBtn:
      'bg-accent font-AvenirLTBook uppercase text-white w-fit font-normal rounded-full mt-20 py-5 px-40 mx-100',
        bodyTitle:
      'titleDiv text-left text-17 text-primary leading-24 font-AvenirNextRoundedBold font-normal mb-20',
        errorMsg:
      'text-16 leading-19 text-left text-darkRed font-AvenirNextRoundedReg',
    },
    quickview: {
        wrapperBlock:
      'fixed z-50 overflow-y-auto inset-0 bg-countryOverlaybg flex items-baseline',
        container:
      'relative px-20 mdl:w-1/2 bg-white mt-100 left-25p overflow-hidden py-25 mdl:py-20 rounded-2xl',
        close: 'closeDiv absolute right-20 -top-20',
        body: 'bodyDiv pt-40 mdl:pt-0',
        heading: 'font-AvenirNextRoundedBold text-20 leading-4 mb-20',
        description:
      'text-16 leading-19 text-left text-primary font-AvenirNextRoundedReg',
        checkboxWrapper: 'w-full flex',
        shareBtn:
      'bg-black font-AvenirNextRoundedReg text-white font-bold mt-20 py-5 px-10',
        bodyTitle:
      'titleDiv text-left text-17 text-primary leading-24 font-AvenirNextRoundedBold font-normal mb-20',
    },
    compareproduct: {
        container:
      'CountrySelector-container  fixed z-50 overflow-y-auto inset-0 bg-countryOverlaybg flex items-baseline',
        wapper:
      'CountrySelector-wrapper relative px-20 mdl:w-1/2 bg-white fixed mt-40 left-40p rounded-2xl overflow-hidden py-25 mdl:py-20',
        close: 'closeDiv absolute right-20 top-0',
        body: 'bodyDiv pt-40 mdl:pt-0',
        bodyTitle:
      'titleDiv text-left text-17 text-primary leading-24 font-AvenirNextRoundedBold font-normal mb-20',
    },
    mobilefilter: {
        wrapperBlock:
      'filterOverlayBg fixed z-50 overflow-y-auto inset-0 bg-countryOverlaybg flex items-baseline',
        container:
      'relative px-0 mdl:w-full bg-white fixed mt-100 left-0 sm:w-full overflow-hidden py-25 mx-5p rounded-5',
        wapper: 'w-full relative',
        close: 'closeDiv absolute right-0 -top-50',
        body: 'w-full',
        heading:
      'text-center text-20 text-accent lowercase leading-24 font-AvenirLTBlack mb-20',
        description: 'w-full mdl:flex mdl:flex-wrap mb-0 mdl:mb-0 flex-col',
        shareBtn: 'bg-accent rounded-20 text-white px-20 py-5 uppercase text-16 ',
    },
    sortfilter: {
        wrapperBlock:
      'fixed z-50 overflow-y-auto inset-0 bg-countryOverlaybg flex items-baseline',
        container:
      'relative px-20 mdl:w-full bg-white fixed mt-40 left-0 sm:w-full overflow-hidden py-25 mdl:py-20',
        wapper: 'w-full relative',
        close: 'closeDiv absolute right-0 -top-50',
        body: 'w-full flex flex-wrap',
        heading:
      'text-left text-17 text-primary leading-24 uppercase font-AvenirNextRoundedBold font-normal mb-20',
        description: 'w-full mdl:flex mdl:flex-wrap mb-0 mdl:mb-0 flex-col',
        shareBtn: 'bg-black text-white px-20 py-5 lowercase text-xs float-right',
    },
    articleListingPage: {
        wrapper: '',
    },
}
