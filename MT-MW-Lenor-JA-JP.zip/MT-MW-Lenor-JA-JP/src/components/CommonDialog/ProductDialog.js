import React, { useState, useRef, useEffect, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import styles from '@components/CommonDialog/Common.tw-style'
import { articleListingPage, searchPage } from '@constants'

const Icon = dynamic(() => import('@components/Icon'))
const Button = dynamic(() => import('@components/Button'))

const ProductDialog = ({
    closeModal,
    variant,
    filters,
    toggleLocalFilter,
    sortBy,
    togglesortByFilter,
    sortLabels,
}) => {
    const [outsideClick, setOutsideClick] = useState(false)
    const popUpNode = useRef()
    const [selectedFilter, setSelectedFilter] = useState([])
    const labels = articleListingPage
    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (
                popUpNode.current &&
        (popUpNode.current === event.target ||
          popUpNode.current.contains(event.target))
            ) {
                setOutsideClick(false)
            } else {
                setOutsideClick(true)
            }
        }

        document.addEventListener('mousedown', handleOutsideClick)
        return () => {
            document.removeEventListener('mousedown', handleOutsideClick)
        }
    }, [])

    useEffect(() => {
        if (outsideClick) {
            closeModal()
            setOutsideClick(false)
        }
    }, [outsideClick])

    const handelFilterSelect = (filter) => {
        let tempFilter = selectedFilter
        let checkFilterExist = selectedFilter.find(
            (filterData) => filterData === filter.name,
        )
        if (checkFilterExist) {
            tempFilter = tempFilter.filter((filterData) => filterData != filter.name)
        } else {
            tempFilter.push(filter.name)
        }
        setSelectedFilter([...tempFilter])
    }
    const handleApplyFilter = () => {
        selectedFilter.map((filter) => {
            toggleLocalFilter(filter)
        })
        closeModal()
        setOutsideClick(false)
    }

    const handleSortFilter = (value) => {
        togglesortByFilter(value)
        closeModal()
        setOutsideClick(false)
    }

    const style = variant ? styles[variant] : styles.default

    return (
        <div className={style.wrapperBlock}>
            <div className={style.container}>
                <div className={style.wapper} ref={popUpNode}>
                    <div className={style.close}>
                        <Button gaClass='event_button_click' onClick={closeModal}>
                            <Icon className='closeIcon' name='Close' />
                            <span className=' text-primaryblue text-40 closeTxtcls'>
                &#215;
                            </span>
                        </Button>
                    </div>
                    {variant === 'mobilefilter' && (
                        <div className={style.body}>
                            <div className={style.heading}>{labels.filterSpec}</div>
                            {filters.length > 0 &&
                filters.map((filter, index) => (
                    <div
                        className='flex flex-wrap mb-20'
                        key={`${index}-filteroption`}
                    >
                        <div className='w-full pb-6 text-left font-ChaletLondon text-16 lowercase text-primaryblue  pt-15'>
                            {filter?.name}
                        </div>
                        <div className='flex flex-wrap w-full justify-between'>
                            {filter.options.length > 0 &&
                        filter.options.map((option, opt) => (
                            <div
                                key={`${opt}-filteroption`}
                                className={`${
                              selectedFilter.some(
                                  (selected) => selected === option.name,
                              )
                                  ? 'p-10 mr-2 my-2 text-12 text-white  bg-lightblue font-ChaletLondon whitespace-nowrap w-[calc(49%-0.2rem)] border-x-9 border-x-darkblue'
                                  : 'px-18 py-10 mr-2 my-2 text-12 text-primaryblue  bg-bgblue font-ChaletLondon whitespace-nowrap w-[calc(49%-0.2rem)]'
                            }`}
                            >
                                <Button
                                    gaClass='event_button_click'
                                    className=''
                                    onClick={() => {
                                        handelFilterSelect(option)
                                    }}
                                >
                                    {`${option?.name}(${option?.count})`}
                                </Button>
                            </div>
                        ))}
                        </div>
                    </div>
                ))}
                            <div>
                                <Button
                                    gaClass='event_menu_click'
                                    gaLabel={'Home'}
                                    className={style.shareBtn}
                                    onClick={handleApplyFilter}
                                >
                                    {'decide'}
                                </Button>
                            </div>
                        </div>
                    )}
                    {variant === 'sortfilter' && (
                        <div className={style.body}>
                            <div className={style.heading}>{searchPage.sortBy.sortLabel}</div>
                            {sortLabels.length > 0 &&
                sortLabels.map((sort, index) => (
                    <div
                        key={`${index}-sortoption`}
                        className={`${
                      sortBy === sort.value
                          ? 'text-lightGreenBg p-10 mr-2 my-2 text-15 bg-white font-AvenirNextRoundedBold whitespace-nowrap w-[calc(50%-0.2rem)]'
                          : 'text-accent p-10 mr-2 my-2 text-15 bg-purple font-AvenirNextRoundedBold whitespace-nowrap w-[calc(50%-0.2rem)]'
                    }`}
                    >
                        <Button
                            gaClass='event_button_click'
                            className=''
                            onClick={() => {
                                handleSortFilter(sort.value)
                            }}
                        >{`${sort?.label}`}</Button>
                    </div>
                ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

ProductDialog.propTypes = {
    locale: PropTypes.string,
    closeModal: PropTypes.func,
    variant: PropTypes.string,
    filters: PropTypes.array,
    toggleLocalFilter: PropTypes.func,
    togglesortByFilter: PropTypes.func,
    sortBy: PropTypes.string,
    sortLabels: PropTypes.array,
}

export default memo(ProductDialog)
