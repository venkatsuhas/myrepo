import React, { useState, useRef, useEffect, memo, useCallback } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import styles from '@components/CommonDialog/Common.tw-style'
import { labels as allLabels, pageTypes } from '@constants'

const Icon = dynamic(() => import('@components/Icon'))
const Button = dynamic(() => import('@components/Button'))
const Typography = dynamic(() => import('@components/Typography'))
const Image = dynamic(() => import('next/image'))
import { generateId } from '@helpers/generateId.helper'
import { imageLoader } from '@helpers/imageLoader'
import ProductImageSlider from '@components/ProductDetail/ProductImageSlider'

import { useRouter } from 'next/router'

const CommonDialog = ({
    locale,
    closeModal,
    variant,
    buttonName,
    products,
    productDetails,
    url,
    cardsCollection,
}) => {
    const [outsideClick, setOutsideClick] = useState(false)
    const [checkterms, setCheckTerms] = useState(false)
    const [formState, setFormState] = useState({})
    const popUpNode = useRef()
    const router = useRouter()
    const [showError, setShowError] = useState(false)

    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (
                popUpNode.current &&
        (popUpNode.current === event.target ||
          popUpNode.current.contains(event.target))
            ) {
                setOutsideClick(false)
            } else {
                setOutsideClick(true)
            }
        }

        document.addEventListener('mousedown', handleOutsideClick)
        return () => {
            document.removeEventListener('mousedown', handleOutsideClick)
        }
    }, [])

    useEffect(() => {
        if (outsideClick) {
            closeModal()
            setOutsideClick(false)
            setFormState({})
        }
    }, [outsideClick])

    useEffect(() => {
    // document.body.classList.add('overflow-hidden')
        return () => {
            // document.body.classList.remove('overflow-hidden')
        }
    }, [])
    const handleChange = useCallback((value) => {
        setCheckTerms(!value)
        setShowError(value)
    }, [])

    const handelFormChange = (e) => {
        e.persist()
        setFormState((formstate) => ({
            ...formstate,
            [e.target.name]: [e.target.value],
        }))
    }
    const style = variant ? styles[variant] : styles.default

    return (
        <div className={style.wrapperBlock}>
            <div className={style.container}>
                <div className={style.wapper} ref={popUpNode}>
                    <div className={style.close}>
                        <Button gaClass='event_button_click' onClick={closeModal}>
                            <Icon className='closeIcon' name='Close' />
                            <span className='text-primary text-40'>&#215;</span>
                        </Button>
                    </div>
                    {variant === pageTypes.socialDialogContent && (
                        <div className={style.body}>
                            <div className={style.heading}>
                                {allLabels[locale.toLowerCase()].socialDialogContent.header}
                            </div>
                            <div className={style.description}>
                                {allLabels[locale.toLowerCase()].socialDialogContent.subtitle}
                            </div>
                            <div className={style.description}>
                                {allLabels[locale.toLowerCase()].socialDialogContent.subtitle1}
                            </div>
                            <div className={style.description}>
                                {allLabels[locale.toLowerCase()].socialDialogContent.subtitle2}
                            </div>
                            <div className={style.checkboxWrapper}>
                                <input
                                    type='checkbox'
                                    // name={allLabels[locale.toLowerCase()].socialDialogContent.terms}
                                    id={'social-dialog-content'}
                                    value={checkterms}
                                    checked={checkterms}
                                    onChange={() => handleChange(checkterms)}
                                    className='pl-10 border border-accentBorder rounded-3 w-18 h-18 cursor-pointer text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0 focus:outline-none mt-5 mr-5'
                                />
                                <div className={style.description}>
                                    {allLabels[locale.toLowerCase()].socialDialogContent.terms}
                                </div>
                            </div>
                            {showError && (
                                <div className={style.errorMsg}>
                                    {allLabels[locale.toLowerCase()].socialDialogContent.errorMsg}
                                </div>
                            )}
                            <Button
                                href={
                                    checkterms
                                        ? `${url}${process.env.DOMAIN_URL}${router.asPath}`
                                        : null
                                }
                                gaClass='event_menu_click'
                                gaLabel={'Share'}
                                className={style.shareBtn}
                                onClick={() => {
                                    checkterms ? setShowError(false) : setShowError(true)
                                }}
                            >
                                {buttonName}
                            </Button>
                        </div>
                    )}
                    {variant === pageTypes.emailDialogContent && (
                        <div className={style.body}>
                            <div className=''>
                                {allLabels[locale.toLowerCase()].emailDialogContent.header}
                            </div>
                            <div>
                                {allLabels[locale.toLowerCase()].emailDialogContent.subtitle}
                            </div>
                            <div>
                                {allLabels[locale.toLowerCase()].emailDialogContent.field1}{' '}
                                <input
                                    type='text'
                                    onChange={handelFormChange}
                                    name={'name'}
                                    value={formState.name}
                                    placeholder=''
                                ></input>
                            </div>

                            <div>
                                {allLabels[locale.toLowerCase()].emailDialogContent.field2}{' '}
                                <input
                                    type='email'
                                    onChange={handelFormChange}
                                    name={'email'}
                                    value={formState.email}
                                    placeholder=''
                                ></input>
                            </div>

                            <div>
                                {allLabels[locale.toLowerCase()].emailDialogContent.field3}{' '}
                                <input
                                    type='text'
                                    onChange={handelFormChange}
                                    name={'friend_name'}
                                    value={formState.friend_name}
                                    placeholder=''
                                ></input>
                            </div>

                            <div>
                                {allLabels[locale.toLowerCase()].emailDialogContent.field4}
                                <input
                                    type='email'
                                    onChange={handelFormChange}
                                    name={'friend_email'}
                                    value={formState.friend_email}
                                    placeholder=''
                                ></input>
                            </div>
                            <input
                                type='checkbox'
                                // name={allLabels[locale.toLowerCase()].socialDialogContent.terms}
                                id={'social-dialog-content'}
                                value={checkterms}
                                checked={checkterms}
                                onChange={() => handleChange(checkterms)}
                                className='pl-10 border border-accentBorder rounded-3 w-18 h-18 cursor-pointer text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0 focus:outline-none'
                            />
                            <div className=''>
                                {allLabels[locale.toLowerCase()].socialDialogContent.terms}
                            </div>
                            <Button
                                href={null}
                                gaClass='event_menu_click'
                                gaLabel={'SEND'}
                                className=''
                            >
                                {'SEND'}
                            </Button>
                            <Button
                                href={null}
                                gaClass='event_menu_click'
                                gaLabel={'CANCEL'}
                                className=''
                            >
                                {'CANCEL'}
                            </Button>
                        </div>
                    )}
                    {variant === 'compareproduct' && (
                        <div className=''>
                            {products.map((product, index) => (
                                <div key={`${index}-${product.sys}`} className=''>
                                    <div>
                                        <Typography content={product.subTitle} component={'h6'} />
                                    </div>
                                    <div>
                                        {product.image?.url && (
                                            <Image
                                                imageLoader={imageLoader}
                                                key={product?.image?.sys}
                                                src={product?.image?.url}
                                                height={product?.image.height}
                                                width={product?.image.width}
                                                alt={product?.mage?.altText}
                                            />
                                        )}
                                    </div>
                                    <div>
                                        <Button
                                            gaClass='event_internal_link'
                                            gaLabel={'Buy Now'}
                                            className={''}
                                        >
                                            {'Buy Now'}
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                    {variant === 'quickview' && (
                        <div className='w-full bg-white p-30'>
                            <div className='quick-container flex'>
                                <div className='w-1/2'>
                                    {productDetails?.imageSets?.length > 1 && (
                                        <ProductImageSlider media={productDetails?.imageSets} />
                                    )}
                                </div>
                                <div className='quick-right'>
                                    {productDetails?.subTitle && (
                                        <div className='font-AvenirNextRoundedBold text-black text-20 mb-20'>
                                            {productDetails?.subTitle}
                                        </div>
                                    )}
                                    {
                                        <div
                                            data-bv-show='inline_rating'
                                            data-bv-product-id={productDetails?.BVProductID}
                                        ></div>
                                    }
                                    {productDetails?.description && (
                                        <div className='font-AvenirNextRoundedReg text-16 mt-20'>
                                            <Typography content={productDetails?.description} />
                                        </div>
                                    )}
                                    {productDetails?.smartLabel && (
                                        <Button href={productDetails?.smartLabel}>
                                            {/* <a> */}
                                            <div className='w-full flex my-20'>
                                                <Image
                                                    src='https://images.ctfassets.net/8s10hpjmifju/1i638OmrY2jP8ujGo3BifA/f0f32d2c03e3e7d7fc15b154ac00a309/SmartlabelIcon.png'
                                                    height={'55'}
                                                    width={'218'}
                                                    alt={'smartLabel'}
                                                    imageLoader={imageLoader}
                                                />
                                                <div className='p-20'>
                                                    {
                                                        allLabels[locale?.toLowerCase()]?.productDetailPage
                                                            ?.ingredients
                                                    }
                                                </div>
                                            </div>
                                            {/* </a> */}
                                        </Button>
                                    )}
                                    {
                                        <div className='w-full flex my-20'>
                                            <div className='w-1/2 mdl:text-16 lg:text-16 sm:text-xs'>
                                                {
                                                    allLabels[locale?.toLowerCase()]?.productDetailPage
                                                        ?.subscriptionText
                                                }
                                            </div>
                                            <Button>
                                                <a
                                                    href='/en-us/subscription'
                                                    className='p-10 bg-yellowBg text-white text-xs ml-5'
                                                >
                                                    {
                                                        allLabels[locale?.toLowerCase()]?.productDetailPage
                                                            ?.subscriptionButton
                                                    }
                                                </a>
                                            </Button>
                                        </div>
                                    }
                                    {productDetails?.href && (
                                        <div className='text-left font-AvenirNextRoundedReg text-16 text-purple'>
                                            <Button>
                                                <a href={productDetails?.href}>
                                                    {
                                                        allLabels[locale?.toLowerCase()]?.productDetailPage
                                                            ?.moredetails
                                                    }
                                                </a>
                                            </Button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                    {variant === 'videoCardView' &&
            cardsCollection.length > 0 &&
            cardsCollection.map((card) => (
                <div key={card.sys} className=''>
                    {card.type === 'videoCard' ? (
                        <div className='videoWrap mb-100'>
                            {/* <h2
                                            className="text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36"
                                            id={generateId(card?.title)}
                                        >
                                            {card?.title}
                                        </h2> */}
                            <iframe
                                width='100%'
                                height='180'
                                src={card?.url}
                                title='YouTube video player'
                                frameBorder='0'
                                allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture'
                                allowFullScreen
                                className='test'
                            />
                        </div>
                    ) : (
                        <div>
                            {card.title && (
                                <h2
                                    className='text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36'
                                    id={generateId(card?.title)}
                                >
                                    {card.title}
                                </h2>
                            )}
                            {card.description && (
                                <Typography
                                    content={card.description}
                                    className='text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36'
                                />
                            )}

                            {card.image && (
                                <div className='mb-40'>
                                    <Image
                                        key={card.image.sys}
                                        desktopClassName=''
                                        wrapperClassName='w-full'
                                        desktopImage={card.image}
                                        alt={card.image?.altText}
                                    />
                                </div>
                            )}
                        </div>
                    )}
                </div>
            ))}
                </div>
            </div>
        </div>
    )
}

CommonDialog.propTypes = {
    locale: PropTypes.string,
    closeModal: PropTypes.func,
    variant: PropTypes.string,
    buttonName: PropTypes.string,
    products: PropTypes.array,
    productDetails: PropTypes.object,
    url: PropTypes.string,
    cardsCollection: PropTypes.array,
}

export default memo(CommonDialog)
