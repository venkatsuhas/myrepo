import React, { useState, useEffect, useRef, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import styles from '@components/Carousel/Carousel.tw-styles'

const Button = dynamic(() => import('@components/Button'))
const Icon = dynamic(() => import('@components/Icon'))

const Carousel = ({ children, callback, variant }) => {
    const [carouselState, setCarouselState] = useState(0)
    const [childrenPerPage, setChildrenPerPage] = useState(1)
    const carouselRef = useRef()

    const scrollPage = useCallback(
        (i) => {
            if (i >= 0 && i < children.length) {
                setCarouselState(i)
                const carouselWrapper = carouselRef.current
                const unitWidth = carouselWrapper.children[0].offsetWidth
                const currentScrollPosition = carouselWrapper.scrollLeft
                const requiredScrollWidth = unitWidth * i
                const scrollToWidth = requiredScrollWidth - currentScrollPosition
                carouselWrapper.scrollBy({
                    left: scrollToWidth,
                    behavior: 'smooth',
                })
                if (typeof callback === 'function') {
                    callback(i)
                }
            }
        },
        [callback, children.length],
    )

    useEffect(() => {
        const carouselWrapper = carouselRef.current
        const scrollHandler = () => {
            const index =
        ((carouselWrapper.scrollLeft + carouselWrapper.offsetWidth / 2) /
          carouselWrapper.scrollWidth) *
        children.length
            const newCarouselState = parseInt(index)
            setCarouselState(newCarouselState)
            if (typeof callback === 'function') {
                callback(newCarouselState)
            }
        }
        if (children.length) {
            if (typeof callback === 'function') {
                callback(carouselState)
            }
            const childWidth = carouselWrapper.scrollWidth / children.length
            setChildrenPerPage(
                Math.round(carouselWrapper.offsetWidth / (childWidth || 1)),
            )
            carouselWrapper.addEventListener('scroll', scrollHandler)
        }

        return () => {
            if (carouselWrapper && carouselWrapper.removeEventListener)
                carouselWrapper.removeEventListener('scroll', scrollHandler)
        }
    }, [carouselState, callback, children])

    useEffect(() => {
        if (children.length) {
            if (carouselRef.current) {
                const carouselWrapper = carouselRef.current
                let initialX = 0
                let initialScrollLeft = 0
                carouselWrapper.scrollLeft = '0'
                const mouseDownHandler = (mouseDownEvent) => {
                    mouseDownEvent.preventDefault()
                    initialX = mouseDownEvent.pageX
                    initialScrollLeft = carouselWrapper.scrollLeft
                    if (
                        mouseDownEvent.target.localName === 'button' ||
            mouseDownEvent.target.getAttribute('role') === 'button'
                    ) {
                        document.removeEventListener('mousemove', mouseMoveTracker)
                    } else {
                        document.addEventListener('mousemove', mouseMoveTracker)
                    }
                }
                const mouseMoveTracker = (mouseMoveEvent) => {
                    document.addEventListener('mouseup', mouseUpHandler)
                    const x = mouseMoveEvent.pageX - carouselWrapper.offsetLeft
                    const walk = (x - initialX) * 3
                    carouselWrapper.scrollLeft = initialScrollLeft - walk
                }
                const mouseUpHandler = () => {
                    document.removeEventListener('mousemove', mouseMoveTracker)
                }
                carouselWrapper.addEventListener('mousedown', mouseDownHandler)
                return () => {
                    document.removeEventListener('mousemove', mouseMoveTracker)
                    document.removeEventListener('mouseup', mouseUpHandler)
                }
            }
        }
    }, [children.length])

    const style = styles[variant] || styles.default

    if (children.length)
        return (
            <div className={style.parentWrapper}>
                <div className={style.navWrapper}>
                    <Button
                        gaClass='event_button_click'
                        className={`${style.btnPrev} ${
              Math.round(carouselState - childrenPerPage / 2) <= 0 ||
              childrenPerPage === children.length
                  ? 'display'
                  : ''
            }`}
                        onClick={() =>
                            scrollPage(
                                parseInt(
                                    carouselState - childrenPerPage >= 0
                                        ? carouselState - childrenPerPage
                                        : 0,
                                ),
                            )
                        }
                    >
                        <span className='sr-only'>Previous</span>
                        <Icon className={style.btnPrevIcon} name={style.arrowName} />
                    </Button>
                    <div
                        ref={carouselRef}
                        className={`${style.scrollWrapper} ${
              children.length === 1 ? style.singleChild : ''
            }`}
                    >
                        {children}
                    </div>
                    <Button
                        gaClass='event_button_click'
                        className={`${style.btnNext} ${
              Math.round(carouselState + childrenPerPage / 2) >
                children.length - 1 || childrenPerPage === children.length
                  ? 'hidden'
                  : ''
            }`}
                        onClick={() =>
                            scrollPage(
                                parseInt(
                                    carouselState + childrenPerPage <= children.length - 1
                                        ? carouselState + childrenPerPage
                                        : children.length - 1,
                                ),
                            )
                        }
                    >
                        <span className='sr-only'>Next</span>
                        <Icon className={style.btnNextIcon} name={style.arrowName} />
                    </Button>
                </div>
                <div
                    className={`${style.dotNavWrapper} ${
            children.length <= 1 ? style.hideDots : ''
          }`}
                >
                    {children.map((item, index) => (
                        <Button
                            key={index}
                            role='button'
                            component='div'
                            gaClass='event_button_click'
                            onClick={() => scrollPage(index)}
                            onKeyDown={() => scrollPage(index)}
                            className={`${style.baseDots} ${
                index === carouselState
                    ? style.activeDrops
                    : style.inActiveDrops
              }`}
                        >
                            <span className='sr-only'>{`Scroll to Item ${index + 1}`}</span>
                        </Button>
                    ))}
                </div>
            </div>
        )
    else return null
}

Carousel.propTypes = {
    children: PropTypes.node.isRequired,
    callback: PropTypes.func,
    variant: PropTypes.string.isRequired,
}

Carousel.defaultProps = {
    variant: '',
}

export default memo(Carousel)
