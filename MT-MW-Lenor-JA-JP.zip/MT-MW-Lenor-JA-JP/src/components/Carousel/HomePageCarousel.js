import React, { memo, useRef } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import Slider from 'react-slick'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'
import styles from '@components/Carousel/Carousel.tw-styles'

const Button = dynamic(() => import('@components/Button'))
const Icon = dynamic(() => import('@components/Icon'))
const Image = dynamic(() => import('@components/Image'))
const Typography = dynamic(() => import('@components/Typography'))

const homePageSettings = {
    dots: true,
    dotsClass: 'slick-dots slick-thumb',
    infinite: true,
    speed: 1000,
    autoplay: true,
    autoplaySpeed: 4900,
}

export const NextArrow = ({ onClick, styleClass }) => (
    <Button onClick={onClick}>
        <Icon className={styleClass} name={'RightSliderIcon'} />
    </Button>
)

export const PrevArrow = ({ onClick, styleClass }) => (
    <Button onClick={() => onClick()}>
        <Icon className={styleClass} name={'RightSliderIcon'} />
    </Button>
)

const Carousel = (props) => {
    const { carouselData, variant } = props
    const sliderRef = useRef()
    const handlePrev = () => sliderRef.current.slickPrev()
    const handleNext = () => sliderRef.current.slickNext()
    const style = variant ? styles[variant] : styles.default
    return (
        <>
            <div className='relative w-full'>
                <div className='absolute left-1p prev top-50p z-1'>
                    <PrevArrow onClick={handlePrev} styleClass={style.prevArrow} />
                </div>

                <div className='relative mt-0 homepage'>
                    <Slider {...homePageSettings} ref={sliderRef}>
                        {carouselData?.map((slide, index) => (
                            <div className='slick-slide' key={slide.id}>
                                <div>
                                    {slide.image && (
                                        <Image
                                            desktopClassName='object-fill w-full h-318'
                                            //   smartphoneClassName={style.imgContainerSp}
                                            //   wrapperClassName={style.imgWrapper}
                                            desktopImage={slide.image}
                                            alt={slide.image?.altText}
                                            //   desktopClassName={style.Image}
                                            //   wrapperClassName={style.ImageWrapper}
                                        />
                                    )}
                                    {slide.imageSet &&
                    variant === 'homeGallery' &&
                    (index === 0 ? (
                        <h1>
                            {' '}
                            <Image
                                desktopClassName='hidden mdl:block object-fill w-full h-318'
                                smartphoneClassName='block mdl:hidden'
                                //   wrapperClassName={style.imgWrapper}
                                desktopImage={slide.imageSet.desktopImage}
                                smartphoneImage={slide.imageSet.smartphoneImage}
                                alt={slide.imageSet.desktopImage?.altText}
                                //   desktopClassName={style.Image}
                                //   wrapperClassName={style.ImageWrapper}
                            />
                        </h1>
                    ) : (
                        <Image
                            desktopClassName='hidden mdl:block object-fill w-full h-318'
                            smartphoneClassName='block mdl:hidden'
                            //   wrapperClassName={style.imgWrapper}
                            desktopImage={slide.imageSet.desktopImage}
                            smartphoneImage={slide.imageSet.smartphoneImage}
                            alt={slide.imageSet.desktopImage?.altText}
                        //   desktopClassName={style.Image}
                        //   wrapperClassName={style.ImageWrapper}
                        />
                    ))}
                                </div>
                                {variant === 'homeGallery' && slide?.href && slide?.linkText && (
                                    <Button
                                        gaClass='event_button_click '
                                        gaLabel={slide.linkText}
                                        href={slide.href}
                                        className={`${
                      slide.background ? 'blue-color' : ''
                    }rounded-lg uppercase font-hiraginoGothicPro text-12`}
                                    >
                                        <p className='buttonclass'>{slide.linkText}</p>
                                    </Button>
                                )}
                                {variant === 'productCard' ? (
                                    <>
                                        {slide?.name ? <Typography content={slide?.name} /> : null}
                                        {slide?.subTitle ? (
                                            <Typography content={slide?.subTitle} />
                                        ) : null}

                                        {slide?.cardLink ? (
                                            <Button
                                                gaClass='event_button_click rounded-lg bg-accent min-w-190 inline-block '
                                                href={slide.cardLink}
                                            >
                                                <p className='text-white uppercase px-19 font-hiraginoGothicPro text-12'>{`Shop now`}</p>
                                            </Button>
                                        ) : null}
                                    </>
                                ) : null}
                            </div>
                        ))}
                    </Slider>
                </div>

                <div className='absolute pt-8  next top-50p right-2p z-1'>
                    <NextArrow onClick={handleNext} styleClass={style.nextArrow} />
                </div>
            </div>
        </>
    )
}

Carousel.propTypes = {
    carouselData: PropTypes.array,
    variant: PropTypes.string,
}

NextArrow.propTypes = {
    onClick: PropTypes.func,
    styleClass: PropTypes.string,
}

PrevArrow.propTypes = {
    onClick: PropTypes.func,
    styleClass: PropTypes.string,
}

export default memo(Carousel)
