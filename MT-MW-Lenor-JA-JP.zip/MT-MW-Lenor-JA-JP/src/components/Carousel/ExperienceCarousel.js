import React, { memo, useRef } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import Slider from 'react-slick'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'
import { homePageSettings } from '@components/Carousel/CarouselSettings'
// import styles from '@components/Carousel/Carousel.tw-style'

const Image = dynamic(() => import('@components/Image'))

const Carousel = (props) => {
    const { banner } = props
    const sliderRef = useRef()
    return (
        <>
            <div className='relative w-full'>
                <div className='relative'>
                    <Slider {...homePageSettings} ref={sliderRef}>
                        {banner.map((slide) => (
                            <div className='slick-slide' key={slide.title}>
                                <div>
                                    {slide.image && (
                                        <Image
                                            desktopClassName='object-fill w-full h-318'
                                            desktopImage={slide.image}
                                            alt={slide.image?.altText}
                                        />
                                    )}
                                </div>
                            </div>
                        ))}
                    </Slider>
                </div>
            </div>
        </>
    )
}

Carousel.propTypes = {
    banner: PropTypes.array,
    variant: PropTypes.string,
}

export default memo(Carousel)
