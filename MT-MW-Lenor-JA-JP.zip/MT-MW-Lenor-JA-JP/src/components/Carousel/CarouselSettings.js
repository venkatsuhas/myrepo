import React from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'

const Button = dynamic(() => import('@components/Button'))
const Icon = dynamic(() => import('@components/Icon'))

export const NextArrow = ({ onClick }) => (
    <Button onClick={onClick}>
        <Icon className={'next'} name={'Right_Arrow'} />
    </Button>
)

NextArrow.propTypes = {
    onClick: PropTypes.func,
}

export const PrevArrow = ({ onClick }) => (
    <Button onClick={() => onClick()}>
        <Icon className={'prev'} name={'Left_Arrow'} />
    </Button>
)
PrevArrow.propTypes = {
    onClick: PropTypes.func,
}
const selectedPaging = {
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: '50%',
}

let currentSlide = 0
export const homePageSettings = {
    dots: true,
    infinite: true,
    speed: 1000,
    autoplay: true,
    autoplaySpeed: 4000,
    dotsClass: 'button__bar',
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    beforeChange: (prev, next) => {
        currentSlide = next
    },
    appendDots: (dots) => {
        return (
            <div>
                <ul className=''>
                    {dots.map((item, index) => {
                        return <li key={index}>{item.props.children}</li>
                    })}
                </ul>
            </div>
        )
    },
    customPaging: (index) => {
        return (
            <button
                className=''
                style={index === currentSlide ? selectedPaging : null}
            >
                <div
                    className=''
                    style={{
                        width: '10px',
                        height: '10px',
                        border: '1px solid #fff',
                        borderRadius: '50%',
                    }}
                ></div>
            </button>
        )
    },
}
