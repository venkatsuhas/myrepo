module.exports = {
    default: {
        wrapper: 'font-neutrafaceBook text-16 leading-22 text-left',
        titleContainer:
      'text-12 text-primaryblue font-ChaletLondon leading-22 text-left pl-10 pr-15 py-3 w-185 border-1 border-solid border-paleskyblue rounded-5 bg-white',
        title: 'flex justify-between w-full items-center text-left',
        dpIconContainer: '',
        dpIcon: 'w-9 fill-current text-lightGreyBlue',
        dpItems:
      'flex flex-col flex-wrap text-12 text-primaryblue font-ChaletLondon border px-6 absolute z-10 w-250 bg-white',
        dpItem:
      'text-12 leading-22 text-left text-primaryblue font-ChaletLondon border-t first:border-t-0 py-12 pl-3',
        dropDownIcon: 'DropDownArrow',
    },
    ArticleListingPage: {
        wrapper:
      'text-left w-210 mdl:w-auto mdl:flex mdl:justify-end mdl:relative border-1 border-black rounded-5 text-12',
        titleContainer:
      'border-lightGreyBlue border px-20 py-12 mdl:p-0 mdl:border-0 rounded-md',
        title:
      'flex justify-between w-full items-center text-left font-neutrafaceBook text-12  leading-30 text-ddgray pl-5',
        dpIconContainer: 'block pl-10 mdl:pl-50 mdl:pr-10',
        dpIcon: 'w-9 fill-current text-lightGreyBlue mdl:text-accent',
        dpItems:
      'flex flex-col flex-wrap border-lightGreyBlue border border-t-0 mdl:border mdl:px-15 mdl:pl-10 absolute z-10 mdl:top-40 bg-white w-175 mdl:w-max mdl:shadow-lightestGrey',
        dpItem: 'font-neutrafaceBook text-12 leading-30 text-secondary px-20',
        dropDownIcon: 'ChevronArrowDown',
    },
}
