import React, { useState, useEffect, useRef, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'
import styles from '@components/DropDown/DropDown.tw-styles'

const Button = dynamic(() => import('@components/Button'))
const Typography = dynamic(() => import('@components/Typography'))

const Icon = dynamic(() => import('@components/Icon'))

const DropDown = ({
    onSelect,
    defaultValue,
    options,
    variant,
    resetOnPathChange,
    gaClass,
    resetValue,
    resetValueComplete,
}) => {
    const [state, setState] = useState({
        dropDownOpen: false,
        dropDownValue: defaultValue,
    })
    const [outsideClick, setOutsideClick] = useState(false)
    const router = useRouter()

    const popUpNode = useRef()
    const titleNode = useRef()

    const updateValue = useCallback((option) => {
        setState({ dropDownOpen: false, dropDownValue: option.title })
        if (typeof onSelect === 'function') onSelect(option.value)
    }, [])

    const toggleDropDown = useCallback(
        () =>
            setState((prevState) => ({
                ...prevState,
                dropDownOpen: !prevState.dropDownOpen,
            })),
        [],
    )

    const handleOutsideClick = useCallback((event) => {
        if (
            (popUpNode.current &&
        (popUpNode.current === event.target ||
          popUpNode.current.contains(event.target))) ||
      (titleNode.current &&
        (titleNode.current === event.target ||
          titleNode.current.contains(event.target)))
        ) {
            setOutsideClick(false)
        } else {
            setOutsideClick(true)
        }
    }, [])

    useEffect(() => {
        document.addEventListener('click', handleOutsideClick, false)
        return () => {
            document.removeEventListener('click', handleOutsideClick, false)
        }
    }, [])

    useEffect(() => {
        if (resetValue) {
            setState((prevState) => {
                if (prevState.dropDownValue === defaultValue) {
                    return prevState
                } else {
                    return { ...prevState, dropDownValue: defaultValue }
                }
            })
            if (typeof resetValueComplete === 'function') {
                resetValueComplete()
            }
        }
    }, [resetValue, defaultValue])

    useEffect(() => {
        if (resetOnPathChange) {
            setState({ dropDownOpen: false, dropDownValue: defaultValue })
            if (typeof onSelect === 'function') onSelect(defaultValue)
        }
    }, [router?.asPath])

    useEffect(() => {
        if (outsideClick) {
            if (state.dropDownOpen) {
                toggleDropDown()
                setOutsideClick(false)
            }
        }
    }, [outsideClick])

    const style = styles[variant] || styles.default

    return (
        <div className={style.wrapper}>
            <div className={style.titleContainer} ref={titleNode}>
                <Button
                    gaClass='event_button_click'
                    className={style.title}
                    onClick={toggleDropDown}
                >
                    {state.dropDownValue}
                    <span className={style.dpIconContainer}>
                        <Icon
                            className={`${style.dpIcon}  ${
                state.dropDownOpen
                    ? 'transform rotate-180'
                    : 'transform rotate-0'
              }`}
                            name='FilterAccordionDown'
                        />
                    </span>
                </Button>
            </div>
            <div
                className={state.dropDownOpen ? style.dpItems : 'hidden'}
                ref={popUpNode}
            >
                {options?.map((option, index) => (
                    <div className={style.dpItem} key={`${option.value}-${index}`}>
                        {option?.label && (
                            <div>
                                <Typography content={option?.label} />
                            </div>
                        )}
                        <Button
                            gaClass={gaClass}
                            gaLabel={option.title}
                            onClick={() => updateValue(option)}
                        >
                            {option.title}
                        </Button>
                    </div>
                ))}
            </div>
        </div>
    )
}

DropDown.propTypes = {
    onSelect: PropTypes.func.isRequired,
    defaultValue: PropTypes.string.isRequired,
    options: PropTypes.arrayOf(
        PropTypes.shape({
            title: PropTypes.string.isRequired,
            value: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
                .isRequired,
        }),
    ).isRequired,
    variant: PropTypes.string,
    gaClass: PropTypes.string,
    resetOnPathChange: PropTypes.bool,
    resetValue: PropTypes.bool,
    resetValueComplete: PropTypes.func,
}

DropDown.defaultProps = {
    resetOnPathChange: false,
    enableUpdate: false,
    resetValueComplete: () => null,
    variant: '',
    gaClass: '',
    resetValue: false,
    defaultValue: '',
}

export default memo(DropDown)
