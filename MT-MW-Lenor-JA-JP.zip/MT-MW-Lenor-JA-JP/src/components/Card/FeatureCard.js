import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import styles from '@components/Card/FeatureCard-tw-styles'

const Icon = dynamic(() => import('@components/Icon'))
const Image = dynamic(() => import('@components/Image'))
const Button = dynamic(() => import('@components/Button'))
const Typography = dynamic(() => import('@components/Typography'))

const FeatureCard = ({
    href,
    imageset,
    image,
    title,
    subTitle,
    description,
    linkText,
    iconName,
    logo,
    variant,
}) => {
    const style = styles[variant] || styles?.default
    //   const [modalIsOpen, setIsOpen] = React.useState(false)

    //   function openModal() {
    //     setIsOpen(true)
    //   }

    //   function closeModal() {
    //     setIsOpen(false)
    //   }

    return (
        <div>
            {imageset && (
                <Image
                    //   desktopClassName={style.imgContainerDt}
                    //   smartphoneClassName={style.imgContainerSp}
                    //   wrapperClassName={style.imgWrapper}
                    desktopImage={imageset.desktopImage}
                    smartphoneImage={imageset.smartphoneImage}
                    alt={imageset.altText}
                />
            )}
            {image && (
                <Image
                    //   desktopClassName={style.imgContainerDt}
                    //   smartphoneClassName={style.imgContainerSp}
                    //   wrapperClassName={style.imgWrapper}
                    desktopImage={image}
                    alt={imageset?.altText}
                    desktopClassName={style.Image}
                    wrapperClassName={style.ImageWrapper}
                />
            )}

            <div>
                <div>
                    {logo && (
                        <div>
                            <Image
                                desktopClassName={style?.logoStyle}
                                smartphoneClassName={'w-100'}
                                desktopImage={logo.desktopImage}
                                smartphoneImage={logo.smartphoneImage}
                                alt={logo.altText}
                            />
                        </div>
                    )}

                    <span className={style.title}>
                        {title && <Typography content={title} />}
                    </span>

                    <span className={style.subTitle}>
                        {' '}
                        {subTitle && <Typography content={subTitle} />}{' '}
                    </span>

                    {description && <Typography content={description} />}
                    <span className='linkText'>
                        {href && linkText && (
                            <Button
                                gaClass='event_button_click'
                                gaLabel={linkText}
                                href={href}
                                className={style.innerLink}
                            >
                                {linkText}
                                {iconName && (
                                    <span className={style.innerIcon}>
                                        <Icon name={iconName} />
                                    </span>
                                )}
                            </Button>
                        )}
                    </span>
                </div>
            </div>
        </div>
    )
}

FeatureCard.propTypes = {
    href: PropTypes.string,
    image: PropTypes.object,
    imageset: PropTypes.object,
    linkText: PropTypes.string,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    description: PropTypes.string,
    iconName: PropTypes.string,
    variant: PropTypes.string,
    logo: {
        desktopImage: PropTypes.object,
        smartphoneImage: PropTypes.object,
        altText: PropTypes.string,
    },
}
FeatureCard.defaultProps = {
    iconName: '',
    href: '',
    linkText: '',
    title: '',
    subTitle: '',
    description: '',
    cardStyles: '',
}
export default memo(FeatureCard)
