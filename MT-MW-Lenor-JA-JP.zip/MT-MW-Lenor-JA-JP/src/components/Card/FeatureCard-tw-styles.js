module.exports = {
    bannerTop: {
        ImageWrapper: '',
        title:
      'text-40 absolute top-16p right-8p text-accent font-AvenirLTLight w-30p lowercase leading-10',
        subTitle:
      'text-20 absolute top-28p right-8p text-accent font-AvenirLTLight w-30p lowercase leading-10',
    },
    featureCards: {
        Image: 'w-610',
        ImageWrapper: 'flex justify-center',
        title:
      'text-40 absolute top-10p right-15p text-accent font-AvenirLTLight w-32p leading-10 text-right',
        linkText:
      'text-20 absolute top-28p right-8p text-accent font-AvenirLTLight w-30p lowercase leading-10',
        innerLink:
      'flex text-22 mt-5 pl-8p absolute top-28p right-8p text-accent font-AvenirLTLight w-30p lowercase leading-10',
        innerIcon: 'relative top-12 left-5',
        contentWrapper: '',
    },
    takeApeek: {
        Image: 'w-400',
        ImageWrapper: 'flex justify-center',
        title:
      'text-30 absolute top-10p left-10p text-white  font-AvenirLTLight lowercase leading-10 text-left w-225 ',
        linkText:
      'text-20 absolute top-28p right-8p text-accent font-AvenirLTLight w-30p lowercase leading-10',
        innerLink:
      'flex text-22 mt-5 pl-8p absolute top-28p right-8p text-accent font-AvenirLTLight w-30p lowercase leading-10',
        innerIcon: 'relative top-12 left-5',
    },
    trySmallSpace: {
        Image: 'h-170 takeapeek',
        innerLink:
      'flex text-17 mt-5  absolute top-70p right-8p text-white font-AvenirLTMedium leading-10 hover:underline',
        innerIcon: 'relative top-10 left-5',
    },
    cleanAwayOdors: {
        Image: ' w-410 mt-130 ml-238',
        ImageWrapper: 'flex justify-center',
        title:
      'text-40 absolute top-10p right-15p text-accent font-AvenirLTLight w-66p lowercase leading-10 text-left',
        linkText:
      'text-20 absolute top-28p right-8p text-accent font-AvenirLTLight w-30p leading-10',
        innerLink:
      'flex text-22 mt-32  absolute top-45p left-18p text-accent font-AvenirLTLight w-30p leading-10',
        innerIcon: 'relative top-12 left-5',
    },
    refresh: {
        Image: 'h-170 takeapeek',
        innerLink:
      'flex mt-5 w-60p text-20 text-center  absolute top-52p right-15p text-white font-AvenirLTLight leading-23',
        innerIcon: 'relative top-50 -left-19',
    },
    seeAllProducts: {
        Image: 'w-400',
        ImageWrapper: 'flex justify-center',
        title:
      'text-30 absolute top-10p left-10p text-white  font-AvenirLTLight lowercase leading-10 text-left w-225 ',
        linkText:
      'text-20 absolute top-28p right-8p text-accent font-AvenirLTLight w-30p lowercase leading-10',
        innerLink:
      'flex text-22 mt-5 pl-8p absolute top-5p right-30p text-white font-AvenirLTLight  lowercase leading-10',
        innerIcon: 'relative top-12 left-5',
    },

    default: {},
}
