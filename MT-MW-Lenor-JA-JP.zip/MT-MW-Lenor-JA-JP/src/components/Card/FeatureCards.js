import React, { memo, Fragment } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { readExperience } from '@constants'
import styles from '@components/Card/FeatureCards-tw-styles'

const Image = dynamic(() => import('@components/Image'))
const Button = dynamic(() => import('@components/Button'))

const FeatureCards = ({
    href,
    image,
    name,
    categoryBasedFeatured,
    variant,
}) => {
    const style = variant ? styles[variant] : styles.Experience
    const Component = href ? Button : Fragment
    return (
        <div
            className={`${style.cardWrapper} ${
        categoryBasedFeatured ? style.featuredWrapper : style.notFeaturedWrapper
      }`}
        >
            <Component
                {...(href
                    ? {
                        href,
                        className: style.linkWrap,
                        gaClass: 'event_internal_link',
                        gaLabel: href,
                    }
                    : {})}
            >
                <div className={style.imgContainer}>
                    {image && (
                        <Image
                            key={image.sys}
                            desktopClassName={style.imgContainer}
                            wrapperClassName={style.imgWrapper}
                            desktopImage={image}
                            alt={image.altText}
                        />
                    )}
                    {name && <div className={style.title}>{name}</div>}
                </div>
            </Component>
            {href && (
                <Button
                    href={href}
                    gaClass='event_internal_link'
                    gaLabel={readExperience}
                    className={style.experienceLink}
                >
                    {readExperience}
                </Button>
            )}
        </div>
    )
}

FeatureCards.propTypes = {
    locale: PropTypes.string,
    href: PropTypes.string,
    image: PropTypes.object,
    name: PropTypes.string,
    sys: PropTypes.string,
    categoryBasedFeatured: PropTypes.bool,
    variant: PropTypes.string,
    icon: PropTypes.string,
}

export default memo(FeatureCards)
