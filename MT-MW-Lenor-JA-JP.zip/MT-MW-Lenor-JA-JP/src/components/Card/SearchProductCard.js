import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { readArticle } from '@constants'
import styles from '@components/Card/ArticleCard-tw-styles'

const Image = dynamic(() => import('@components/Image'))
const Button = dynamic(() => import('@components/Button'))

const SearchProductCard = ({
    url,
    description,
    productHeroImage,
    productName,
    variant,
    categoryBasedFeatured,
    type,
}) => {
    const style = variant ? styles[variant] : styles.relatedArticles
    return (
        <div
            className={`${style.cardWrapper} ${
        categoryBasedFeatured ? style.featuredWrapper : style.notFeaturedWrapper
      }`}
        >
            <div className={style.contentWrapper}>
                <div className={style.imgContainer}>
                    {productHeroImage && (
                        <Image
                            key={productHeroImage.sys}
                            desktopClassName={style.imgContainer}
                            wrapperClassName={style.imgWrapper}
                            desktopImage={productHeroImage}
                            alt={productHeroImage.altText}
                        />
                    )}
                </div>
                <div>
                    {url && (
                        <Button
                            href={url}
                            gaClass='event_internal_link'
                            gaLabel={readArticle}
                            className={style.articleLink}
                        >
                            {productName && <div className={style.title}>{productName}</div>}
                        </Button>
                    )}
                    {type === 'list' && description && (
                        <div className={style.title}>{description}</div>
                    )}
                </div>
            </div>
        </div>
    )
}

SearchProductCard.propTypes = {
    type: PropTypes.string,
    productName: PropTypes.string,
    productHeroImage: PropTypes.object,
    variant: PropTypes.string,
    description: PropTypes.string,
    categoryBasedFeatured: PropTypes.bool,
    url: PropTypes.string,
}

export default memo(SearchProductCard)
