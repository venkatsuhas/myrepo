module.exports = {
    default: {
        cardWrapper: 'cardWrapper',
        cardContainer: 'cardContainer',
        cardTag: 'hidden',
        imgWrapper: 'imgWrapper',
        imgContainer: 'imgContainer',
        contentWrapper: 'contentWrapper',
        cardCategory: 'cardCategory',
        title: 'title',
        productLink: 'productLink',
        ratingContainer: 'ratingContainer',
        ratingIconContainer: 'ratingIconContainer',
        ratingIcon: 'ratingIcon',
        ratingCount: 'ratingCount',
        buyNow: 'buyNow',
    },
    pdpProductCard: {
        cardWrapper:
      'w-full mdl:w-4/12 px-15 flex-grow-0 flex-shrink-0 scroll-snap-center',
        cardContainer:
      'w-full bg-white py-20 mdl:py-30 relative px-20 mdl:px-30 flex flex-col items-center',
        cardTag:
      'font-neutrafaceBook text-14 leading-26 bg-darkRed px-20 py-5 text-white absolute top-0 left-0 z-10',
        imgWrapper: 'w-full mx-auto mb-20',
        imgContainer:
      'w-full mx-auto min-h-155 md:min-h-350 mdl:min-h-320 lg:min-h-350 mdl:max-w-250',
        contentWrapper: 'w-full mdl:min-h-150',
        cardCategory: 'text-center hidden',
        title:
      'text-center font-AvenirLTMedium text-18 leading-24 text-accent mb-20 mdl:mb-0',
        productLink: 'text-center block hidden',
        ratingContainer: 'w-full mx-auto flex justify-center items-center m-20',
        ratingIconContainer: '',
        ratingIcon: 'w-15',
        ratingCount: 'font-neutrafaceBook text-18 leading-26 text-secondary pl-10',
        buyNow:
      'font-neutrafaceDemi text-18 leading-24 px-40 lg:px-62 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled block mdl:w-max mx-auto',
        price:
      'text-center font-AvenirLTHeavy text-18 leading-24 text-secondary mb-20 mdl:mb-0',
    },
    pdpRecommendedCard: {
        cardWrapper:
      ' w-50p mdl:w-full  px-15 flex-grow-0 flex-shrink-0 scroll-snap-center recomended',
        cardContainer: 'w-full bg-white py-20 relative flex flex-col items-center',
        cardTag:
      'font-neutrafaceBook text-14 leading-26 bg-darkRed px-20 py-5 text-white absolute top-0 left-0 z-10',
        imgWrapper: 'w-full mx-auto mb-20 px-5',
        imgContainer: 'w-full mx-auto min-h-155 mdl:min-h-100',
        contentWrapper: 'w-full mdl:min-h-100',
        cardCategory: 'text-center hidden',
        title:
      'text-center font-ChaletParis1 text-15 text-primaryblue leading-24  mb-5',
        productLink: 'text-center block hidden',
        ratingContainer: 'w-full mx-auto flex justify-center items-center m-20',
        ratingIconContainer: '',
        ratingIcon: 'w-15',
        ratingCount: 'font-neutrafaceBook text-18 leading-26 text-secondary pl-10',
        buyNow:
      'font-neutrafaceDemi text-18 leading-24 px-40 lg:px-62 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled block mdl:w-max mx-auto',
        price:
      'text-center font-AvenirLTHeavy text-18 leading-24 text-secondary mb-20 mdl:mb-0',
    },
    ProductListingPage: {
        cardWrapper: 'cardWrapper px-10 pb-10 text-center flex flex-col',
        cardContainer: '',
        cardTag: 'hidden',
        imgWrapper: 'imgWrapper',
        imgContainer: 'imgContainerPrdListing mdl:h-211',
        contentWrapper: 'h-auto',
        cardCategory: 'hidden',
        title:
      'font-ChaletParis  text-14 leading-20 mdl:text-15 mdl:leading-15 text-primaryblue mt-15 mb-15 min-h-90 mdl:min-h-110 text-left mdl:text-center',
        productLink:
      'font-neutrafaceDemi text-16 leading-24 mdl:text-18 mdl:leading-24 px-18 mdl:px-40 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled block mdl:w-min mx-auto',
        ratingContainer: '',
        ratingIconContainer: '',
        ratingIcon: '',
        ratingCount: '',
        buyNow:
      'font-neutrafaceDemi text-16 leading-24 mdl:text-18 mdl:leading-24 px-18 mdl:px-40 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled block mdl:w-max mx-auto',
    },
    searchRecomandCard: {
        cardWrapper:
      'searchRecomandCard relative cardWrapper px-5 pb-10 text-center flex w-6/12 mdl:w-4/12 mb-30 mdl:mb-60 flex-col',
        cardContainer: '',
        cardTag: 'hidden',
        imgWrapper: 'imgWrapper mb-10',
        imgContainer: 'imgContainer mdl:min-h-257',
        contentWrapper: 'h-auto flex flex-col items-center px-10',
        cardCategory:
      'text-16 leading-20 font-neutrafaceDemi pb-60 text-primary mdl:text-18 mdl:leading-24',
        title:
      'font-neutrafaceDemi text-14 leading-20 mdl:text-18 mdl:leading-24 text-primary mb-20 min-h-90 mdl:min-h-110',
        productLink:
      'font-neutrafaceDemi text-16 leading-24 mdl:text-18 mdl:leading-24 px-18 mdl:px-40 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled block mdl:w-min mx-auto',
        ratingContainer: '',
        ratingIconContainer: '',
        ratingIcon: '',
        ratingCount: '',
        buyNow:
      'font-neutrafaceDemi text-16 leading-24 px-18 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled w-155 left-50p transform -translate-x-2/4 absolute bottom-0',
    },
    searchPageCard: {
        cardWrapper:
      'searchPageCard relative cardWrapper px-5 pb-10 text-center flex w-6/12 mdl:w-4/12 mb-30 flex-col mdl:px-15 mdl:mb-60',
        cardContainer: '',
        cardTag: 'hidden',
        imgWrapper: 'imgWrapper mb-10',
        imgContainer: 'imgContainer mdl:min-h-257',
        contentWrapper: 'h-auto flex flex-col items-center px-10',
        cardCategory:
      'text-16 leading-20 font-neutrafaceDemi mb-60 text-primary mdl:text-18 mdl:leading-24',
        title:
      'font-neutrafaceDemi text-14 leading-20 mdl:text-18 mdl:leading-24 text-primary mb-20 min-h-90 mdl:min-h-110',
        productLink:
      'font-neutrafaceDemi text-16 leading-24 mdl:text-18 mdl:leading-24 px-18 mdl:px-40 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled block mdl:w-min mx-auto',
        ratingContainer: '',
        ratingIconContainer: '',
        ratingIcon: '',
        ratingCount: '',
        buyNow:
      'font-neutrafaceDemi text-16 leading-24 px-18 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled w-155 left-50p transform -translate-x-2/4 absolute bottom-0',
    },
    homeFeatureProductCard: {
        cardWrapper:
      'homeFeatureProductCard w-full mdl:w-3/12 px-15 flex-grow-0 flex-shrink-0 scroll-snap-center relative',
        cardContainer: 'w-full bg-white mdl:py-30 relative px-0 mdl:pb-0',
        cardTag: 'hidden',
        imgWrapper: 'w-full mx-auto mb-25 mdl:mb-20',
        imgContainer: 'w-full mx-auto',
        contentWrapper: 'w-full',
        cardCategory: 'text-center hidden',
        title:
      'text-left font-neutrafaceBook text-18 leading-24 mdl:leading-22 text-primary mb-38 mdl:text-gradientDarkBlue min-h-40 mdl:min-h-88 mxl:min-h-66',
        productLink: 'text-center block hidden',
        ratingContainer: 'w-full mx-0 flex justify-start items-center mb-25',
        ratingIconContainer: '',
        ratingIcon: 'w-20 h-20 mr-1',
        ratingCount: 'font-neutrafaceBook text-18 leading-26 text-secondary pl-10',
        buyNow:
      'font-neutrafaceDemi text-18 leading-18 px-56 mdl:px-69 py-16 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled inline-block ',
    },

    adpWeRecommend: {
        cardWrapper: 'productCard w-6/12',
        cardContainer: 'w-full flex flex-wrap lg:flex-nowrap',
        cardTag: 'hidden',
        imgWrapper: 'productImg w-115 lg:w-120 mx-auto mb-5 lg:flex-shrink-0',
        imgContainer: 'w-full mx-auto',
        contentWrapper: 'contentWrap w-full lg:w-auto text-center mdl:text-left',
        cardCategory:
      'cardTitle text-18 leading-22 font-neutrafaceDemi mb-10 text-primary mdl:text-20 mdl:leading-24 mdl:mb-15',
        title:
      'cardSubitle hidden mb-10 mdl:block mdl:text-18 mdl:leading-24 font-neutrafaceBook mdl:mb-14',
        productLink:
      'cardAction text-18 leading-26 font-neutrafaceBook text-accent underline',
        ratingContainer: '',
        ratingIconContainer: '',
        ratingIcon: '',
        ratingCount: '',
        linkWrap:
      'linkWrap w-full mdl:flex mdl:flex-nowrap mdl:items-center mr-20 mb-20 block',
    },
    stannousProductCard: {
        cardWrapper: 'cardWrapper stannousProductCard mdl:w-290 ml-25',
        thumbnailsFacet: 'thumbnailsFacet',
        cardContainer: 'cardContainer',
        cardTag: 'hidden',
        imgWrapper: 'imgWrapper mb-10 w-175 mdl:w-290 mx-auto mdl:ml-0',
        imgContainer: 'imgContainer',
        cardCategory: 'cardCategory hidden',
        title:
      'title text-14 mdl:text-18 leading-20 mdl:leading-24 text-center text-primary font-neutrafaceDemi w-55p mdl:w-95p lg:w-95p mx-auto mdl:min-h-80',
        ratingContainer: 'ratingContainer hidden',
        articleLink: 'articleLink',
        productLink: 'productLink hidden',
        buyNow:
      'font-neutrafaceDemi text-16 leading-24 mdl:text-18 mdl:leading-24 px-18 mdl:px-40 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled block mx-auto text-center mt-20',
    },
    emulsionsProductCard: {
        cardWrapper: 'cardWrapper mdl:w-290 mdl:ml-25',
        thumbnailsFacet: 'thumbnailsFacet',
        cardContainer: 'cardContainer',
        cardTag: 'hidden',
        imgWrapper: 'imgWrapper mb-10 w-175 mdl:w-290 mx-auto mdl:ml-0',
        imgContainer: 'imgContainer',
        cardCategory: 'cardCategory hidden',
        title:
      'title text-14 mdl:text-18 leading-20 mdl:leading-24 text-center text-primary font-neutrafaceDemi w-55p mdl:w-95p lg:w-95p mx-auto mdl:min-h-80',
        ratingContainer: 'ratingContainer hidden',
        articleLink: 'articleLink',
        productLink: 'productLink hidden',
        buyNow:
      'font-neutrafaceDemi text-16 leading-24 mdl:text-18 mdl:leading-24 px-18 mdl:px-40 py-12 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled block mx-auto text-center mt-20',
    },
}
