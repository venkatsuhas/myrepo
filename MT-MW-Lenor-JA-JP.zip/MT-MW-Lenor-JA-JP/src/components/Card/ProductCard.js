import React, { memo, Fragment } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { mostPopular, pageTypes } from '@constants'
import styles from '@components/Card/ProductCard-tw-styles'

const Button = dynamic(() => import('@components/Button'))
const Image = dynamic(() => import('@components/Image'))
import Head from 'next/head'
const ProductCard = ({
    subTitle,
    description,
    href,
    image,
    isPopular,
    variant,
    onClick,
    isThumbnails,
    productFacets,
    minPrice,
    bazaarVoiceId,
}) => {
    const style = styles[variant] || styles.default
    const Component = href ? Button : Fragment
    return (
        <>
            <Head>
                {process.env.SITE_ENV === 'prod' ? (
                    <script
                        async
                        src='https://apps.bazaarvoice.com/deployments/febreze/main_site/staging/en_US/bv.js'
                    ></script>
                ) : (
                    <script
                        async
                        src='https://apps.bazaarvoice.com/deployments/febreze/main_site/production/en_US/bv.js'
                    ></script>
                )}
            </Head>
            <div className={style.cardWrapper}>
                <div className={style.cardContainer}>
                    <Component
                        {...{
                            ...(href
                                ? {
                                    href,
                                    className: style.linkWrap,
                                    gaClass: 'event_internal_link',
                                    gaLabel: href,
                                }
                                : {}),
                            ...(onClick ? { onClick } : {}),
                        }}
                    >
                        {isPopular && <span className={style.cardTag}>{mostPopular}</span>}
                        {isThumbnails && (
                            <div className={style.thumbnailsFacet}>{productFacets}</div>
                        )}
                        {image && (
                            <Image
                                key={image.sys}
                                desktopClassName={style.imgContainer}
                                wrapperClassName={style.imgWrapper}
                                desktopImage={image}
                                alt={image?.altText}
                            />
                        )}
                        <div className={style.contentWrapper}>
                            <h2>
                                {' '}
                                {subTitle && <div className={style.title}>{subTitle}</div>}
                            </h2>
                            {variant === pageTypes.plpPageView
                                ? description && (
                                    <div className='hidden mdl:block card-cls'>
                                        {description}
                                    </div>
                                )
                                : null}
                            <div
                                data-bv-show='inline_rating'
                                data-bv-product-id={bazaarVoiceId}
                            ></div>{' '}
                            {minPrice && (
                                <div className={style.price}>{`$${minPrice} MSRP`}</div>
                            )}
                        </div>
                    </Component>
                </div>
            </div>
        </>
    )
}

ProductCard.propTypes = {
    href: PropTypes.string,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    description: PropTypes.string,
    image: PropTypes.object,
    locale: PropTypes.string,
    minPrice: PropTypes.number,
    bazaarVoiceId: PropTypes.string,
    isPopular: PropTypes.bool,
    variant: PropTypes.string.isRequired,
    onClick: PropTypes.func,
    isThumbnails: PropTypes.bool,
    productFacets: PropTypes.arrayOf(PropTypes.string),
}
ProductCard.defaultProps = {
    isThumbnails: false,
}
export default memo(ProductCard)
