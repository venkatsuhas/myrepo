module.exports = {
    default: {
        cardWrapper: 'cardWrapper',
        imgWrapper: 'imgWrapper',
        imgContainer: 'imgContainer',
        cardCategory: 'cardCategory',
        title: 'title',
        ExperienceLink: 'experienceLink',
    },
    Experience: {
        cardWrapper:
      'w-full mdl:w-4/12 px-15 flex-grow-0 flex-shrink-0 scroll-snap-center mdl:mb-30',
        imgWrapper: 'w-full',
        imgContainer: 'imgContainer min-h-150 mxl:min-h-250 ',
        cardCategory:
      'font-neutrafaceBook text-14 leading-26 text-accent text-left py-20',
        title:
      'font-neutrafaceBook text-20 leading-26 text-primary text-left pb-15',
        experienceLink:
      'font-neutrafaceBook text-20 leading-26 text-accent text-left underline mb-40',
    },
    ELPExperienceCard: {
        cardWrapper:
      'w-full p-0 flex-grow-0 flex-shrink-0 mb-40 bg-footergray mdl:ml-20 rounded-5',
        featuredWrapper: ' mdl:w-1/2',
        notFeaturedWrapper: ' mdl:w-30p',
        imgWrapper: 'w-full ',
        imgContainer: 'imgContainer min-h-150 mb-25 mdl:min-h-100 bg-footergray',
        cardCategory:
      'font-AvenirLTBook text-18 leading-40  text-left uppercase bg-footergray',
        title:
      'text-18 text-left font-ChaletLondon font-light mdl:min-h-110 px-10 text-primaryblue ',
        experienceLink:
      'px-36 py-16 mdl:px-12 mdl:py-9 mx-20 my-20 text-12 leading-18 mdl:leading-20 font-hiraginoGothicProParis text-gradientDarkBlue bg-primaryblue text-white rounded-lg inline-block uppercase text-center',
    },
}
