import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { readArticle } from '@constants'
import styles from '@components/Card/ArticleCard-tw-styles'

const Image = dynamic(() => import('@components/Image'))
const Button = dynamic(() => import('@components/Button'))

const SearchArticleCard = ({
    url,
    heroImage,
    articleCategory,
    categoryBasedFeatured,
    variant,
    articleName,
}) => {
    const style = variant ? styles[variant] : styles.relatedArticles
    return (
        <div
            className={`${style.cardWrapper} ${
        categoryBasedFeatured ? style.featuredWrapper : style.notFeaturedWrapper
      }`}
        >
            <div className={style.contentWrapper}>
                <div className={style.imgContainer}>
                    {heroImage && (
                        <Image
                            key={heroImage.sys}
                            desktopClassName={style.imgContainer}
                            wrapperClassName={style.imgWrapper}
                            desktopImage={heroImage}
                            alt={heroImage.altText}
                        />
                    )}
                </div>
                <div>
                    {url && (
                        <Button
                            href={url}
                            gaClass='event_internal_link'
                            gaLabel={readArticle}
                            className={style.articleLink}
                        >
                            {articleCategory && (
                                <div className={style.title}>{articleCategory}</div>
                            )}
                        </Button>
                    )}
                    {articleName && <div className={style.title}>{articleName}</div>}
                </div>
            </div>
        </div>
    )
}

SearchArticleCard.propTypes = {
    articleName: PropTypes.string,
    articleCategory: PropTypes.string,
    heroImage: PropTypes.object,
    variant: PropTypes.string,
    sys: PropTypes.string,
    categoryBasedFeatured: PropTypes.bool,
    url: PropTypes.string,
}

export default memo(SearchArticleCard)
