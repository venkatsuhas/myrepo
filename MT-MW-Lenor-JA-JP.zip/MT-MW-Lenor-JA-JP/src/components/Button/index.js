import React, { useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import Link from 'next/link'
import propTypes from 'prop-types'
import { pageTypes } from '@constants'

const Button = ({
    children,
    className,
    type,
    href,
    target,
    tabIndex,
    anchor,
    component,
    role,
    gaClass,
    gaLabel,
    ...other
}) => {
    const scrollHandler = useCallback((event, hashLink) => {
        event.preventDefault()
        if (document.querySelector(hashLink)) {
            document.querySelector(hashLink).scrollIntoView({ behavior: 'smooth' })
        }
    }, [])
    let Tag = ''
    let compProps = {}
    if (href) {
        if (href[0] === '#') {
            return (
                <a
                    {...other}
                    href={href}
                    tabIndex={tabIndex}
                    data-action-detail={href}
                    className={`${className ? className + ' ' : ''} ${
            gaClass || 'event_internal_link'
          }`}
                    onClick={!anchor ? (event) => scrollHandler(event, href) : null}
                >
                    {children}
                </a>
            )
        } else if (href.match(/http.*|https.*|www.*/g) || anchor) {
            return (
                <a
                    {...other}
                    href={href}
                    target={target || 'button'}
                    rel='noopener noreferrer'
                    tabIndex={tabIndex}
                    data-action-detail={href}
                    className={`${className ? className + ' ' : ''} ${
            gaClass || 'event_external_link'
          }`}
                >
                    {children}
                </a>
            )
        } else {
            return (
                <Link href={href} passHref={true}>
                    <a
                        {...{
                            ...other,
                            tabIndex,
                            className: `${className ? className + ' ' : ''} ${
                gaClass || 'event_internal_link'
              }`,
                        }}
                        data-action-detail={gaLabel}
                        tabIndex={tabIndex}
                    >
                        {children}
                    </a>
                </Link>
            )
        }
    } else {
        Tag = component || 'button'
        compProps.type = role ? null : type || 'button'
    }
    return (
        <Tag
            className={`${className ? className + ' ' : ''} ${
        pageTypes.elpPage == 'ExperienceListingPage'
            ? gaClass || 'event_button_click w-full'
            : gaClass || 'event_button_click'
      }`}
            data-action-detail={gaLabel}
            {...other}
            {...compProps}
            tabIndex={tabIndex}
        >
            {children}
        </Tag>
    )
}

Button.propTypes = {
    className: PropTypes.string,
    type: PropTypes.string,
    children: PropTypes.node,
    href: PropTypes.string,
    target: PropTypes.string,
    role: PropTypes.string,
    tabIndex: PropTypes.number,
    anchor: PropTypes.bool,
    gaClass: PropTypes.string,
    gaLabel: PropTypes.string,
    component: PropTypes.string,
    pageTypes: propTypes.string,
}

Button.defaultProps = {
    type: 'button',
    href: '',
    target: '',
    anchor: false,
    tabIndex: 0,
}

export default memo(Button)
