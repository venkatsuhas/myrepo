module.exports = {
    default: {
        wrapper:
      'px-20 w-6/12 mdl:absolute top-130 left-130 pl-5p mdl:pl-13p pt-6p z-10',
        ulClass:
      'mdl:flex mdl:flex-row mdl:flex-wrap items-center justify-start pt-140 mdl:py-20',
        liClass: 'flex items-center justify-start',
        componentClass: 'font-AvenirLTBook text-12 text-accent leading-20  block ',
        spanClass: 'hidden mdl:inline-block mx-5 text-14 text-accent',
    },
    pdpPage: {
        wrapper:
      'px-20 w-full mdl:relative top-0 left-0 pb-20 mdl:pb-0 pl-0 mdl:pl-0 pt-0p',
        ulClass:
      'flex flex-row flex-wrap items-center justify-start pt-0 mdl:py-20',
        liClass: 'flex items-center justify-start',
        componentClass: 'font-AvenirLTBook text-12 text-accent leading-20  block ',
        spanClass: 'inline-block mx-5 text-12 text-accent',
    },
    ArticleListingPage: {
        wrapper:
      'alp-breadcrumb px-20 w-6/12 mdl:absolute top-130 left-130 pl-5p mdl:pl-2p mdl:pt-7p z-10',
        ulClass:
      'mdl:flex mdl:flex-row mdl:flex-wrap items-center justify-start pt-140 mdl:py-20',
        liClass: 'flex items-center justify-start',
        componentClass: 'font-AvenirLTBook text-12 text-accent leading-20  block ',
        spanClass: 'hidden mdl:inline-block mx-5 text-14 text-accent',
    },
    ArticleDetailPage: {
        wrapper: 'px-20 w-6/12 mdl:absolute top-130 left-130 pl-3p pt-6p z-10',
        ulClass:
      'mdl:flex mdl:flex-row mdl:flex-wrap items-center justify-start pt-140 mdl:py-20',
        liClass: 'flex items-center justify-start',
        componentClass: 'font-AvenirLTBook text-12 text-accent leading-20  block ',
        spanClass: 'hidden mdl:inline-block mx-5 text-14 text-accent',
    },
}
