import React, { useMemo, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'
import styles from '@components/Breadcrumb/Breadcrumb.tw-style'
const Button = dynamic(() => import('@components/Button'))

const Breadcrumb = ({ breadcrumb: breadcrumbs, variant }) => {
    const style = variant && styles[variant] ? styles[variant] : styles.default

    const router = useRouter()
    const currentPath = useMemo(
        () =>
            decodeURI(
                router?.asPath
                    ?.replace(/(.*)\?.*/g, (...node) => node[1])
                    .replace(/(.*)#.*/g, (...node) => node[1]),
            ),
        [router?.asPath],
    )
    return (
        <div className={style.wrapper}>
            <ul className={style.ulClass}>
                {breadcrumbs.map((breadcrumb, index) => {
                    const Component = currentPath !== breadcrumb.url ? Button : 'p'
                    const props =
            currentPath !== breadcrumb.url
                ? {
                    href: breadcrumb.url,
                    title: breadcrumb.title,
                    gaClass: 'event_internal_link',
                    'data-action-detail': breadcrumb.title,
                    'data-pgaction-redirection': '0',
                }
                : {}
                    return (
                        <li className={style.liClass} key={breadcrumb.sys}>
                            <Component
                                {...props}
                                itemProp='name'
                                className={`${style.componentClass} ${
                  currentPath !== breadcrumb.url
                      ? 'text-opacity-100'
                      : 'text-opacity-80'
                }`}
                            >
                                {breadcrumb.title}
                            </Component>
                            {currentPath !== breadcrumb.url && (
                            // <Icon
                            //     name='ChevronArrow'
                            //     className='inline-block w-10 h-10 transform -rotate-90 stroke-current stroke-2 mx-11 fill-none'
                            //     assetImageFlag={true}
                            // />
                                <span className={style.spanClass}>{'/'}</span>
                            )}
                            <meta itemProp='position' content={index + 1} />
                        </li>
                    )
                })}
            </ul>
        </div>
    )
}

Breadcrumb.propTypes = {
    breadcrumb: PropTypes.arrayOf(
        PropTypes.shape({
            sys: PropTypes.string,
            title: PropTypes.string,
            url: PropTypes.string,
        }),
    ),
    variant: PropTypes.string,
}

export default memo(Breadcrumb)
