// import React from 'react'
// import PropTypes from 'prop-types'
// import dynamic from 'next/dynamic'

// const Button = dynamic(() => import('@components/Button'))
// const Icon = dynamic(() => import('@components/Icon'))
