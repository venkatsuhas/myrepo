import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import styles from '@components/Accordion/Accordion.tw-style'

const Button = dynamic(() => import('@components/Button'))
const Icon = dynamic(() => import('@components/Icon'))

const Accordion = ({
    title,
    children: body,
    open,
    toggleOpen,
    variant,
    displayIcon,
}) => {
    const style = styles[variant]
    // const assetFlagOff = ['ArticleListingPage', 'header', 'ProductListingPage']
    return (
        <div className={style?.wrapper}>
            <Button
                className={`${style?.titleWrapper} ${
          open ? 'openAccor' : 'closeAccor'
        } `}
                gaClass='event_button_click'
                gaLabel={title}
                component='div'
                onClick={toggleOpen}
                role='button'
                onKeyPress={toggleOpen}
            >
                <div className={style.title}>{title}</div>
                {/* <Icon
                    className={style.iconcls}
                    name={open ? style.openStateArrow : style.closeStateArrow}
                    assetImageFlag={assetFlagOff.includes(variant) ? false : true}
                /> */}
                {displayIcon && (
                    <span>
                        <Icon
                            className={
                                open
                                    ? 'transform rotate-180 pl-5'
                                    : 'transform rotate-0 pl-5 hover:text-white'
                            }
                            name='ArrowMainNav'
                        />
                    </span>
                )}
            </Button>
            <div className={open ? style?.childOpen : style?.childClose}>{body}</div>
        </div>
    )
}

Accordion.propTypes = {
    title: PropTypes.string.isRequired,
    children: PropTypes.node.isRequired,
    open: PropTypes.bool.isRequired,
    toggleOpen: PropTypes.func.isRequired,
    variant: PropTypes.string,
    displayIcon: PropTypes.bool,
}

Accordion.defaultProps = {
    variant: 'default',
}

export default memo(Accordion)
