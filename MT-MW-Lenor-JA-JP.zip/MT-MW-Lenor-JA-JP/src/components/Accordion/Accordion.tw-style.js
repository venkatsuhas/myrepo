module.exports = {
    default: {
        wrapper: 'border-b border-lightestBorder first:border-t',
        titleWrapper: 'flex flex-row py-25 justify-between pr-20',
        title:
      'font-neutrafaceBold text-left text-primary text-16 lg:text-18 leading-22',
        childOpen:
      'font-neutrafaceBook block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left pr-20 flex flex-wrap flex-col pb-25 tab-content tab-open',
        childClose: 'font-neutrafaceBook block tab-content',
        openStateArrow: 'MinusIcon',
        closeStateArrow: 'PlusIcon',
    },
    pdpPage: {
        wrapper: 'border-b border-paleskyblue first:border-t-none',
        titleWrapper:
      'flex flex-row pl-25 py-15 mdl:py-25 justify-between pr-20 bg-bgblue font-ChaletLondon uppercase text-17',
        title:
      'font-AvenirLTHeavy text-left text-primary text-16 lg:text-18 leading-22 font-bold',
        childOpen:
      'font-AvenirLTMedium block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left pr-20 flex flex-wrap flex-col pb-25 tab-content tab-open pdp-accordion-text',
        childClose: 'font-neutrafaceBook block tab-content',
        openStateArrow: 'MinusIcon',
        closeStateArrow: 'PlusIcon',
    },
    PorductsPage: {
        wrapper: 'w-full accordian-wrapper',
        titleWrapper: 'flex flex-row pt-0 pr-20',
        title:
      'font-AvenirLTBlack text-left text-accent text-16 leading-26 cursor-pointer',
        childOpen:
      'font-neutrafaceBook block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left pr-20 flex flex-wrap flex-col pb-25 tab-content tab-open relative -left-2',
        childClose: 'font-neutrafaceBook block tab-content relative -left-2',
        openStateArrow: 'FilterAccordionDown',
        closeStateArrow: 'FilterAccordionRight',
    },
    ProductListingPage: {
        wrapper: 'w-full accordian-wrapper',
        titleWrapper:
      'flex flex-row pt-0 pr-20 bg-bgblue listing rounded-5 mb-10  justify-between',
        title:
      'font-ChaletParis text-left text-primaryblue text-15 leading-26 cursor-pointer pl-15',
        childOpen:
      'font-neutrafaceBook block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left pr-20 flex flex-wrap flex-col pb-25 tab-content tab-open relative -left-2',
        childClose: 'font-neutrafaceBook block tab-content relative -left-2',
        openStateArrow: 'FilterAccordDown',
        closeStateArrow: 'FilterAccordRight',
        iconcls: 'iconcls relative top-9',
    },
    header: {
        wrapper: 'border-b-1 border-lightgray',
        titleWrapper:
      'headerAccor flex flex-row px-20 py-20 justify-between items-center bg-menubg',
        title: 'text-left text-white text-20 font-hiraginoGothicProParis',
        childOpen:
      'font-neutrafaceBook block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left px-20 flex flex-wrap flex-col tab-content tab-open',
        childClose: 'font-neutrafaceBook  tab-content px-20 hidden',
        openStateArrow: 'UpNavigationIcon',
        closeStateArrow: 'DownNavigationIcon',
        iconcls: 'w-20 arwIcon icon mt-10',
    },
    footer: {
        wrapper: '',
        titleWrapper: 'footerAccor flex flex-row py-16 mdl:py-25 justify-between ',
        title:
      'footerAccorHead font-neutrafaceDemi text-left text-lightWhite text-18 leading-22 uppercase',
        childOpen:
      'font-neutrafaceBook block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left flex flex-wrap flex-col tab-content tab-open',
        childClose: 'font-neutrafaceBook block tab-content ',
        openStateArrow: 'MinusIcon',
        closeStateArrow: 'PlusIcon',
    },

    ArticleListingPage: {
        wrapper: 'w-full accordian-wrapper',
        titleWrapper: 'flex flex-row pt-0 pr-20',
        title:
      'font-AvenirLTBlack text-left text-accent text-16 leading-26 cursor-pointer',
        childOpen:
      'font-neutrafaceBook block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left pr-20 flex flex-wrap flex-col pb-25 tab-content tab-open relative -left-2',
        childClose: 'font-neutrafaceBook block tab-content relative -left-2',
        openStateArrow: 'FilterAccordionDown',
        closeStateArrow: 'FilterAccordionRight',
        iconcls: 'w-20 arwIcon icon',
    },
    ProductListingBrowse: {
        wrapper: 'w-full accordian-wrapper',
        titleWrapper: 'flex flex-row pt-0 pr-20',
        title: ' text-left text-12 font-AvenirLTLight cursor-pointer',
        childOpen:
      'font-neutrafaceBook block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left pr-20 flex flex-wrap flex-col pb-25 tab-content tab-open relative -left-2',
        childClose: 'font-neutrafaceBook block tab-content relative -left-2',
        openStateArrow: '',
        closeStateArrow: '',
    },
    SearchResultAccor: {
        wrapper: 'SearchResultAccor w-full',
        titleWrapper: 'flex flex-row pt-20 pb-10 justify-between pr-20',
        title:
      'font-neutrafaceBold text-left text-accentDark text-18 leading-26 uppercase',
        childOpen:
      'font-neutrafaceBook block text-15 leading-21 lg:text-18 lg:leading-24 text-secondary text-left pr-20 flex flex-wrap flex-col pb-15 tab-content tab-open',
        childClose: 'font-neutrafaceBook block tab-content',
        openStateArrow: 'ChevronArrowUp',
        closeStateArrow: 'ChevronArrowDown',
    },
    faqAccord: {
        wrapper:
      'faqAccord w-full border-t mdl:border-t-0 border-b border-solid border-lightGray',
        titleWrapper: 'faq-titleWrapper flex flex-row py-30',
        title:
      'title font-neutrafaceBook text-left text-secondary text-20 leading-26 w-full mdl:w-10/12 order-2 pl-25 mdl:pl-30',
        childOpen:
      'childOpen font-neutrafaceBook block text-left text-secondary text-20 leading-26 pr-20 flex flex-wrap flex-col pb-25 tab-content tab-open w-full mdl:w-10/12 pl-40 mdl:pl-45',
        childClose:
      'childClose font-neutrafaceBook block tab-content w-full mdl:w-10/12 hidden',
        arwIcon: 'arwIcon w-14 h-15 order-1',
        openStateArrow: 'ChevronArrowDown',
        closeStateArrow: 'ChevronArrowDown',
    },
}
