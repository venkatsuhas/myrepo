import React, { memo } from 'react'
import PropTypes from 'prop-types'
import NextImage from 'next/image'
import { imageLoader } from '@helpers/imageLoader'

const Image = ({
    desktopClassName,
    smartphoneClassName,
    wrapperClassName,
    desktopImage,
    smartphoneImage,
    priority,
    layout,
}) => {
    return (
        <div className={wrapperClassName}>
            {desktopImage && desktopImage.altText && (
                <div className={desktopClassName}>
                    <NextImage
                        {...(priority ? { priority } : {})}
                        {...(layout ? { layout } : { layout: 'responsive' })}
                        src={desktopImage.url}
                        height={desktopImage.height}
                        width={desktopImage.width}
                        alt={desktopImage.altText}
                        loader={imageLoader}
                        title={desktopImage.altText}
                    />
                </div>
            )}
            {smartphoneImage && smartphoneImage.altText && (
                <div className={smartphoneClassName}>
                    <NextImage
                        {...(priority ? { priority } : {})}
                        {...(layout ? { layout } : { layout: 'responsive' })}
                        src={smartphoneImage.url}
                        height={smartphoneImage.height}
                        width={smartphoneImage.width}
                        alt={smartphoneImage.altText}
                        loader={imageLoader}
                        title={smartphoneImage.altText}
                    />
                </div>
            )}
        </div>
    )
}

Image.propTypes = {
    /** This is the class name that will be used for the desktop image. */
    desktopClassName: PropTypes.string,
    /** This is the class name that will be used for the smartphone image. */
    smartphoneClassName: PropTypes.string,
    /** This is the class name that will be used for wrapper of the image. */
    wrapperClassName: PropTypes.string,
    /** This is the primary source of the image. */
    desktopImage: PropTypes.shape({
        url: PropTypes.string.isRequired,
        altText: PropTypes.string.isRequired,
        height: PropTypes.number.isRequired,
        width: PropTypes.number.isRequired,
    }),
    /** This is the secondary source of the image. */
    smartphoneImage: PropTypes.shape({
        url: PropTypes.string.isRequired,
        altText: PropTypes.string.isRequired,
        height: PropTypes.number.isRequired,
        width: PropTypes.number.isRequired,
    }),
    /** This specifies if the image should be prioritized or not. */
    priority: PropTypes.bool,
    /** This specifies layout of the image */
    layout: PropTypes.string,
}

export default memo(Image)
