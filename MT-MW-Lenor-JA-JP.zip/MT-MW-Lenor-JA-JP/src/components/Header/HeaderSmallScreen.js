import React, { useState, useEffect, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { mobileFooterLabels, homePageText } from '@constants'

const Button = dynamic(() => import('@components/Button'))
const Accordion = dynamic(() => import('@components/Accordion'))
const Icon = dynamic(() => import('@components/Icon'))

const HeaderSmallScreen = ({ menuSlots, toggleMenu, locale }) => {
    const [openAccordion, setOpenAccordion] = useState(null)

    const enquiry = mobileFooterLabels.enquiry

    const accordionClick = useCallback((value) => {
        setOpenAccordion((prevOpenAccordion) => {
            if (prevOpenAccordion === value) {
                return null
            } else {
                return value
            }
        })
    }, [])

    useEffect(() => {
        document.body.classList.add('overflow-hidden')
        return () => {
            document.body.classList.remove('overflow-hidden')
        }
    }, [])

    return (
        <div>
            {menuSlots?.length > 0 && (
                <div className='headeraccorWrap'>
                    <div>
                        <Button
                            href={`/${locale?.toLowerCase()}`}
                            gaClass='event_internal_link'
                            gaLabel={'Home'}
                            onClick={toggleMenu}
                        >
                            <div className='flex px-20 py-20 text-primaryblue text-20 font-hiraginoGothicProParis bg-menubg border-b-1 border-lightgray'>
                                <div>{homePageText}</div>
                                <Icon
                                    name={'NavigationCloseIcon'}
                                    className='absolute -left-35'
                                />
                            </div>
                        </Button>
                    </div>
                    {menuSlots.map((menuSlot) => {
                        return (
                            <div key={menuSlot.sys}>
                                {menuSlot.menuItems && menuSlot.menuItems.length > 0 ? (
                                    <Accordion
                                        key={menuSlot.sys}
                                        open={openAccordion === menuSlot?.mobileTitle}
                                        title={menuSlot?.mobileTitle}
                                        toggleOpen={() => {
                                            accordionClick(menuSlot?.mobileTitle)
                                        }}
                                        variant='header'
                                        displayIcon={true}
                                    >
                                        <div>
                                            {menuSlot.menuItems &&
                        menuSlot.menuItems.map((menuItem) => (
                            <div key={menuItem.sys}>
                                {!menuItem.displayMobileSubMenu && (
                                    <Button
                                        href={menuItem.link}
                                        gaClass='event_menu_click'
                                        gaLabel={menuItem.mobileTitle}
                                        onClick={toggleMenu}
                                    >
                                        {menuItem.mobileTitle}
                                    </Button>
                                )}
                                <div className='mb-30'>
                                    {menuItem &&
                                menuItem.displayMobileSubMenu &&
                                menuItem.subMenu &&
                                menuItem.subMenu.length > 0 &&
                                menuItem.subMenu.map(({ title, link, sys }) => (
                                    <div key={sys} className=' '>
                                        <Button
                                            href={link}
                                            gaClass='event_menu_click'
                                            gaLabel={title}
                                            onClick={toggleMenu}
                                        >
                                            {title}
                                        </Button>
                                    </div>
                                ))}
                                </div>
                            </div>
                        ))}
                                        </div>
                                    </Accordion>
                                ) : (
                                    <Button
                                        href={menuSlot?.viewAllLink || null}
                                        gaClass='event_menu_click'
                                        gaLabel={menuSlot.title}
                                        onClick={toggleMenu}
                                        className='flex px-20 py-20'
                                    >
                                        {menuSlot.title}
                                    </Button>
                                )}
                            </div>
                        )
                    })}
                    <div>
                        <Button
                            href={enquiry.href}
                            gaClass='event_internal_link'
                            onClick={toggleMenu}
                        >
                            <div className='flex px-20 py-20 justify-between items-center text-white text-20 font-hiraginoGothicProParis bg-menubg'>
                                <div> {enquiry.text}</div>

                                <Icon name='RightMenuArrowMobile' />
                            </div>
                        </Button>
                    </div>
                </div>
            )}
        </div>
    )
}
HeaderSmallScreen.propTypes = {
    menuSlots: PropTypes.array,
    toggleMenu: PropTypes.func.isRequired,
    locale: PropTypes.string,
    contactUs: PropTypes.object,
}

HeaderSmallScreen.defaultProps = {
    locale: '',
    styles: '',
    menuSlots: [],
}

export default memo(HeaderSmallScreen)
