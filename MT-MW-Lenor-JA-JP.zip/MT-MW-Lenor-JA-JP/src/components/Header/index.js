import React, { useState, useRef, useCallback, memo, useEffect } from 'react'
import PropTypes, { object } from 'prop-types'
import dynamic from 'next/dynamic'
import { allIcons, pageTypes, searchPlaceHolder } from '@constants'
import { useRouter } from 'next/router'
import urlHelper from '@helpers/url.helper'
import Icon from '@components/Icon'

const Button = dynamic(() => import('@components/Button'))
const Image = dynamic(() => import('@components/Image'))
const HeaderTop = dynamic(() => import('@components/HeaderTop'))

const Header = ({
    brandLogo,
    menuSlots,
    locale,
    countryLanguage,
    pleaseSelectLocation,
    inquiry,
    brandList,
    toggleMenu,
    // isMenuOpen,
}) => {
    const { menuClassNames } = allIcons
    const [, setStickyStatus] = useState(false)
    const [inputText, setInputText] = useState('')
    const [selMenuIndex, changeSelectedIndex] = useState(null)
    const [mobileSearchInput, setMobileSearchInput] = useState(false)
    // const [isMenuOpen, setIsMenuOpen] = useState(false)
    const indexRef = useRef(selMenuIndex)
    const router = useRouter()

    const handleEnter = useCallback((menuIndex) => {
        indexRef.current = menuIndex
        changeSelectedIndex(menuIndex)
        const element = document.getElementById('navBar')
        element.classList.add(menuClassNames[menuIndex])
    }, [])

    const toggleMobileView = useCallback(() => {
        setMobileSearchInput((mobileSearchInput) => !mobileSearchInput)
    }, [])

    const handleLeave = useCallback(() => {
        changeSelectedIndex(null)
        const element = document.getElementById('navBar')
        menuClassNames.forEach((className) => element.classList.remove(className))
        if (window.scrollY > 0) {
            element.classList.add('menuEntered')
        }
    }, [])

    const scrollHandler = useCallback(() => {
        if (typeof window !== 'undefined') {
            const currentScroll = window.pageYOffset
            const scrollDirection =
        (currentScroll > 0 && currentScroll - window.lastScrollPosition >= 0) ||
        currentScroll === 0
            ? 'down'
            : 'up'
            window.lastScrollPosition = currentScroll
            setStickyStatus(scrollDirection === 'down' ? false : true)
        }
    }, [])

    useEffect(() => {
        if (typeof window !== undefined) {
            window.lastScrollPosition = 0
            window.addEventListener('scroll', scrollHandler)
        }
        return () => {
            window.removeEventListener('scroll', scrollHandler)
        }
    }, [])
    const onSearchHandler = () => {
        toggleMobileView()
        if (inputText)
            router.push(
                urlHelper({
                    locale,
                    pageType: pageTypes.searchPage,
                    searchTerm: inputText,
                }),
            )
    }
    const onChangeHandler = (event) => {
        setInputText(event.target.value)
    }

    return (
        <header className=''>
            <div className='bg-primaryblue m-auto homepage hidden mdl:block'>
                <div className='mx-auto w-full mdl:w-940'>
                    <HeaderTop
                        locale={locale}
                        brandList={brandList}
                        countryLanguage={countryLanguage}
                        pleaseSelectLocation={pleaseSelectLocation}
                        inquiry={inquiry}
                    />
                </div>
            </div>
            <div className=' '>
                <div className='mdl:mx-auto w-full mdl:w-940'>
                    <div className='flex py-10 px-20 mdl:p-0'>
                        <div className='text-center header-logo min-w-15p mt-3p h-fit'>
                            {brandLogo && (
                                <Button
                                    href={`/${locale?.toLowerCase()}`}
                                    gaClass='inline-block'
                                    gaLabel='Home'
                                    onClick={handleLeave}
                                    className=''
                                >
                                    <div>
                                        <Image
                                            key={brandLogo.sys}
                                            desktopClassName=''
                                            wrapperClassName='w-93 mdl:mr-0'
                                            desktopImage={brandLogo}
                                            alt={brandLogo?.altText}
                                            priority={true}
                                        />
                                    </div>
                                </Button>
                            )}
                        </div>
                        <div
                            id='navBar'
                            className='items-center hidden h-full m-auto mt-4p mdl:flex relative min-w-65p'
                        >
                            {menuSlots?.length > 0 &&
                menuSlots.map((menuSlot, menuIndex) => {
                    return (
                        <div
                            key={menuSlot.sys}
                            onMouseOver={() => handleEnter(menuIndex)}
                            onFocus={() => handleEnter(menuIndex)}
                            onMouseLeave={handleLeave}
                            onKeyDown={() => null}
                            role='presentation'
                            className={'h-full flex items-center group'}
                        >
                            <Button
                                onClick={handleLeave}
                                gaLabel={menuSlot.title}
                                gaClass='event_menu_click'
                                href={menuSlot?.viewAllLink || null}
                                className={`px-20 flex items-baseline text-primaryblue font-bold uppercase bg-scroll bg-right bg-no-repeat text-13 p-15 mb-9 leading-22 mdl:text-center rounded-t-lg bg-menuarrow bg-top-38 group-hover:bg-menuhover group-hover:text-white tracking-1  ${
                          router?.asPath.indexOf(menuSlot?.viewAllLink) > -1
                              ? 'activeHeader'
                              : ''
                        }`}
                            >
                                {menuSlot.title}
                                <span>
                                    <Icon
                                        className={'transform rotate-0 pl-5'}
                                        name='ArrowMainNav'
                                    />
                                </span>
                            </Button>
                            {selMenuIndex === menuIndex &&
                        menuSlot.menuItems &&
                        menuSlot.menuItems.length > 0 && (
                                <div className='absolute z-10 w-auto pt-20 bg-white subMenu border-menuhover border-t-8'>
                                    <div className='relative'>
                                        <div className='flex w-full px-20 mx-auto subMenuWrap lg:w-lg mxl:w-mxl xl:w-xl lg:px-0 lg:min-h-400'>
                                            {menuSlot.viewAllLinkText && (
                                                <div className='w-full mdl:w-3/12'>
                                                    <Button
                                                        onClick={handleLeave}
                                                        gaClass='event_menu_click'
                                                        gaLabel={menuSlot.viewAllLinkText}
                                                        href={menuSlot?.viewAllLink || null}
                                                        className='uppercase text-18 leading-22 mdl:pt-50 mdl:inline-flex'
                                                    >
                                                        {menuSlot.viewAllLinkText}
                                                    </Button>
                                                </div>
                                            )}
                                            <div className='submenuinnerwrap mdl:w-6/12'>
                                                {menuSlot.menuImage && (
                                                    <div className='safetyimg-cls'>
                                                        <Image
                                                            key={menuSlot.menuImage.sys}
                                                            desktopClassName=''
                                                            wrapperClassName='mdl:w-250 lg:w-350'
                                                            desktopImage={menuSlot.menuImage}
                                                            alt={menuSlot.menuImage?.altText}
                                                            priority={true}
                                                        />
                                                    </div>
                                                )}
                                                {menuSlot.menuItems &&
                                    menuSlot.menuItems.map((menuItem) => (
                                        <div
                                            key={menuItem.sys}
                                            className={
                                                menuIndex === menuSlots?.length - 1
                                                    ? 'aboutmenu'
                                                    : 'categoryMenu'
                                            }
                                        >
                                            {!menuItem.link && menuItem.title && (
                                                <div>
                                                    <p
                                                        className={`text-primaryblue font-hiraginoGothicPro ${
                                                menuItem.styleName || ''
                                              }`}
                                                    >
                                                        {menuItem.title}
                                                    </p>
                                                </div>
                                            )}
                                            {menuItem.link && (
                                                <Button
                                                    href={menuItem.link}
                                                    onClick={handleLeave}
                                                >
                                                    {menuItem.title && (
                                                        <p
                                                            className={`text-primaryblue ${
                                                  menuItem.styleName || ''
                                                }`}
                                                        >
                                                            {menuItem.title}
                                                        </p>
                                                    )}
                                                    {menuItem.menuImage && (
                                                        <div>
                                                            <Image
                                                                key={menuItem.menuImage.sys}
                                                                desktopClassName=''
                                                                wrapperClassName='w-350 mdl:w-150 mb-10'
                                                                desktopImage={
                                                                    menuItem.menuImage
                                                                }
                                                                alt={
                                                                    menuItem.menuImage?.altText
                                                                }
                                                                priority={true}
                                                            />
                                                        </div>
                                                    )}
                                                </Button>
                                            )}
                                            <div>
                                                {menuItem &&
                                            menuItem.subMenu &&
                                            menuItem.subMenu.length > 0 &&
                                            menuItem.subMenu.map(
                                                ({
                                                    title,
                                                    link,
                                                    sys,
                                                    menuImage,
                                                }) => (
                                                    <div key={sys}>
                                                        <Button
                                                            href={link}
                                                            onClick={handleLeave}
                                                            gaClass='event_menu_click'
                                                            gaLabel={title}
                                                            className='inline-flex mb-10 pr-40 text-13 items-center font-hiraginoGothicPro leading-normal text-primaryblue'
                                                        >
                                                            {title}
                                                            {menuImage && (
                                                                <div>
                                                                    <Image
                                                                        key={menuImage.sys}
                                                                        desktopClassName=''
                                                                        wrapperClassName='w-10 mdl:w-5 mdl:ml-5'
                                                                        desktopImage={
                                                                            menuImage
                                                                        }
                                                                        alt={
                                                                            menuImage?.altText
                                                                        }
                                                                        priority={true}
                                                                    />
                                                                </div>
                                                            )}
                                                        </Button>
                                                    </div>
                                                ),
                                            )}
                                            </div>
                                        </div>
                                    ))}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    )
                })}
                        </div>
                        <div className='flex flex-grow text-right searchWrap mdl:justify-end mt-15 hidden mdl:block'>
                            <div className='inline-block bg-scroll bg-repeat mr-0 w-190 bg-none border-r-25 rounded-25 bg-lightbg h-22'>
                                <div className='hidden'>Search for:</div>
                                <input
                                    type='text'
                                    placeholder={searchPlaceHolder}
                                    className='float-left hidden mdl:block text-primaryblue font-hiraginoGothicPro bg-scroll  bg-transparent bg-repeat border-solid border-1 mt-7 bg-none text-10 px-5'
                                    onChange={onChangeHandler}
                                    onFocus={(e) => (e.target.placeholder = '')}
                                    onBlur={(e) => (e.target.placeholder = searchPlaceHolder)}
                                />
                                <button
                                    className='float-left mt-12 -ml-20 hidden mdl:block'
                                    onClick={onSearchHandler}
                                    onKeyDown={onSearchHandler}
                                >
                                    <img
                                        className='h-15'
                                        alt='search'
                                        src='https://images.ctfassets.net/5go9vi5tpqi4/2ov6UoAO14HakLA091I0aa/29e922fb3ac3b8bf34857f2b20966273/SearchBoxImage.png?h=250'
                                    />
                                </button>
                                {/* </a> */}
                            </div>
                        </div>
                        <div className='mobile-search w-55p'>
                            <button
                                className='float-right mt-10 mr-18'
                                onClick={toggleMobileView}
                            >
                                <Icon name='MobileSearchIcon' />
                            </button>
                        </div>
                        <div className='mobile-menu mdl:hidden block'>
                            <div>
                                <div
                                    //   className={`mdl:hidden h-24 w-27   float-right ${
                                    //     isMenuOpen ? 'menuOpen' : 'menuClose'
                                    //   }`}
                                >
                                    <Button
                                        onClick={toggleMenu}
                                        gaClass='event_menu_click'
                                        gaLabel='Menu'
                                        name='Hamburger'
                                    >
                                        <Icon
                                            name='HamburgerIcon'
                                            className='float-right ml-20 mt-10'
                                        />
                                    </Button>
                                </div>
                                {/* {isMenuOpen && (
                                    <div className='absolute top-0 right-0 z-30 bg-white border-solid mdl:hidden min-w-65p border-l-1 border-lightgray'>
                                        <HeaderSmallScreen
                                            menuSlots={menuSlots}
                                            toggleMenu={toggleMenu}
                                            inquiry={inquiry}
                                            locale={locale}
                                        />
                                    </div>
                                )} */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* <div className={isSticky ? 'h-55 mdl:h-72' : 'hidden'}></div> */}
            {mobileSearchInput && (
                <div className='flex justify-center bg-searcbg px-30 py-20 mb-10'>
                    <label className='hidden' htmlFor='search-input'>
                        {' '}
                    </label>
                    <input
                        type='text'
                        id='search-input'
                        placeholder={searchPlaceHolder}
                        className='mt-3 text-lightergray placeholder-lightergray bg-scroll bg-white border-none outline-none font-hiraginoGothicPro text-12 h-40px rounded-md w-268 mr-26 pl-15'
                        onChange={onChangeHandler}
                    />
                    <button
                        className='relative'
                        onClick={onSearchHandler}
                        onKeyDown={onSearchHandler}
                    >
                        <Icon name='SearchBoxIcon' />
                    </button>
                </div>
            )}
        </header>
    )
}
Header.propTypes = {
    locale: PropTypes.string,
    menuSlots: PropTypes.array,
    brandLogo: PropTypes.object,
    brandList: PropTypes.string,
    inquiry: PropTypes.object,
    pleaseSelectLocation: PropTypes.string,
    countryLanguage: PropTypes.string,
    toggleMenu: PropTypes.func,
}

Header.defaultProps = {
    locale: '',
    styles: '',
    menuSlots: [],
    brandLogo: {},
    countryLanguage: '',
    pleaseSelectLocation: '',
    inquiry: object,
    brandList: '',
}

export default memo(Header)
