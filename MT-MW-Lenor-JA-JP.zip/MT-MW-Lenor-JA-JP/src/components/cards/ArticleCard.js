import React, { memo, Fragment } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { readArticle } from '@constants'
import styles from '@components/Card/ArticleCard-tw-styles'
// import Icon from '@components/Icon'

const Image = dynamic(() => import('@components/Image'))
const Button = dynamic(() => import('@components/Button'))

const ArticleCard = ({
    href,
    image,
    name,
    categoryBasedFeatured,
    variant,
    // icon,
}) => {
    const style = variant ? styles[variant] : styles.relatedArticles
    const Component = href ? Button : Fragment
    return (
        <div
            className={`${style.cardWrapper} ${
        categoryBasedFeatured ? style.featuredWrapper : style.notFeaturedWrapper
      }`}
        >
            {/* {icon && <Icon name={icon} />} */}
            <Component
                {...(href
                    ? {
                        href,
                        className: style.linkWrap,
                        gaClass: 'event_internal_link',
                        gaLabel: href,
                    }
                    : {})}
            >
                <div className={style.imgContainer}>
                    {image && (
                        <Image
                            key={image.sys}
                            desktopClassName={style.imgContainer}
                            wrapperClassName={style.imgWrapper}
                            desktopImage={image}
                            alt={image.altText}
                        />
                    )}
                    {name && <div className={style.title}>{name}</div>}
                </div>
            </Component>
            {href && (
                <Button
                    href={href}
                    gaClass='event_internal_link'
                    gaLabel={readArticle}
                    className={style.articleLink}
                >
                    {readArticle}
                </Button>
            )}
        </div>
    )
}

ArticleCard.propTypes = {
    locale: PropTypes.string,
    href: PropTypes.string,
    image: PropTypes.object,
    name: PropTypes.string,
    sys: PropTypes.string,
    categoryBasedFeatured: PropTypes.bool,
    variant: PropTypes.string,
    // icon: PropTypes.string,
}

export default memo(ArticleCard)
