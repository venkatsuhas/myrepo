module.exports = {
    HomefeatureCard: {
        cardWrapper: 'HomefeatureCard ',
        imgWrapper: 'imgWrapper',
        imgContainerSp: 'sp imgContainer mdl:hidden',
        imgContainerDt: 'dt imgContainer hidden mdl:block',
        cardCategory: 'cardCategory',
        title:
      'text-23 mdl:text-18 mb-11 leading-30 font-hiraginoGothicProNormal  font-bold text-black mdl:mb-25  mx-30 mdl:mt-15 text-center',
        subTitle:
      'text-23 mdl:text-11 mb-11 leading-5 font-hiraginoGothicProParis  font-bold text-black  mx-30 text-center',
        description:
      'description text-13 mdl:text-13 leading-5 font-hiraginoGothicProParis items-center font-bold mx-30 text-black mdl:mt-24 text-center',
        articleLink:
      'px-36 py-16 mdl:px-12 mdl:py-9 mx-20 my-20 text-18 mdl:text-12 leading-18 mdl:leading-20 font-hiraginoGothicProParis text-gradientDarkBlue bg-primaryblue text-white rounded-lg inline-block uppercase text-center',
        contentWrapper: 'contentWrapper mdl:min-h-120',
        contentContainer:
      'contentContainer px-20 py-33 absolute top-0 left-0 mdl:p-40',
    },
    LineupfeatureCard: {
        cardWrapper: 'HomefeatureCard ',
        imgWrapper: 'imgWrapper',
        imgContainerSp: 'sp imgContainer mdl:hidden',
        imgContainerDt: 'dt imgContainer hidden mdl:block',
        cardCategory: 'cardCategory',
        title:
      'text-23 mdl:text-18 mb-11 leading-30 font-hiraginoGothicProParis  font-bold text-black mdl:mb-25  mx-30',
        subTitle:
      'text-23 mdl:text-11 mb-11 leading-5 font-hiraginoGothicProParis  font-bold text-black  mx-30 ',
        description:
      'description text-13 mdl:text-13 leading-5 font-hiraginoGothicProParis items-center font-bold mx-30 text-black mdl:mt-24 text-center',
        articleLink:
      'px-36 py-16 mdl:px-12 mdl:py-9 mx-20 my-20 text-18 mdl:text-12 leading-18 mdl:leading-20 font-hiraginoGothicProParis text-gradientDarkBlue bg-primaryblue text-white rounded-lg inline-block uppercase text-center',
        contentWrapper: 'contentWrapper min-h-120',
        contentContainer:
      'contentContainer px-20 py-33 absolute top-0 left-0 mdl:p-40',
    },
}
