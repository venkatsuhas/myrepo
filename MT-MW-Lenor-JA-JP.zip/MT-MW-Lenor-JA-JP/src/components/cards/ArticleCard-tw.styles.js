module.exports = {
    default: {
        cardWrapper: 'cardWrapper',
        imgWrapper: 'imgWrapper',
        imgContainer: 'imgContainer',
        cardCategory: 'cardCategory',
        title: 'title',
        articleLink: 'articleLink',
    },
    relatedArticles: {
        cardWrapper:
      'w-full mdl:w-4/12 px-15 flex-grow-0 flex-shrink-0 scroll-snap-center mdl:mb-30',
        imgWrapper: 'w-full',
        // imgContainer: 'imgContainer min-h-150 mxl:min-h-250 ',
        cardCategory:
      'font-neutrafaceBook text-14 leading-26 text-accent text-left py-20',
        title:
      'font-neutrafaceBook text-20 leading-26 text-primary text-left pb-15',
        articleLink:
      'font-neutrafaceBook text-20 leading-26 text-accent text-left underline mb-40',
    },
    alpArticlesCard: {
        cardWrapper: 'w-full px-15 flex-grow-0 flex-shrink-0 mb-40',
        featuredWrapper: ' mdl:w-1/2',
        notFeaturedWrapper: ' mdl:w-4/12',
        imgWrapper: 'w-full',
        imgContainer:
      'imgContainer min-h-150 mb-25 mdl:min-h-195 lg:min-h-260 mxl:min-h-300',
        cardCategory:
      'font-neutrafaceBook text-16 leading-40 text-accent text-left uppercase',
        title: 'font-neutrafaceDemi text-20 leading-26 text-primary text-left',
        articleLink: 'hidden',
    },
    faqArticlesCard: {
        cardWrapper:
      'w-full mdl:w-4/12 mdl:pr-15 flex-grow-0 flex-shrink-0 scroll-snap-center mb-40 mdl:mb-0 faqArticlesCard',
        imgWrapper: 'w-full',
        imgContainer: 'imgContainer min-h-150 mxl:min-h-250 ',
        cardCategory:
      'font-neutrafaceBook text-16 leading-40 text-accent text-left mdl:pt-20 pb-10 py-15 uppercase',
        title: 'font-neutrafaceBook text-20 leading-26 text-primary text-left',
        articleLink: 'articleLink',
    },
}
