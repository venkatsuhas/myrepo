import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import styles from '@components/cards/FeatureCard-tw-styles'

const Image = dynamic(() => import('@components/Image'))
const Button = dynamic(() => import('@components/Button'))
const Typography = dynamic(() => import('@components/Typography'))

const FeatureCard = ({
    href,
    image,
    title,
    description,
    linkText,
    variant,
    subTitle,
}) => {
    const style = styles[variant] || styles?.default
    return (
        <div>
            {image && (
                <Image
                    desktopImage={image}
                    alt={title}
                    desktopClassName={style?.Image}
                    wrapperClassName={style?.ImageWrapper}
                />
            )}
            <div>
                <div className={style.contentWrapper}>
                    {description &&
            (variant === 'HomefeatureCard' ? (
                <h2 className={style?.description}>{description}</h2>
            ) : (
                <Typography
                    content={description}
                    className={style?.description}
                />
            ))}
                    {subTitle && (
                        <Typography content={subTitle} className={style?.subTitle} />
                    )}
                    {title &&
            (variant === 'HomefeatureCard' ? (
                <h3 className={style?.title}>{title}</h3>
            ) : (
                <Typography content={title} className={style?.title} />
            ))}
                </div>
                {href && linkText && (
                    <Button
                        gaClass='event_button_click'
                        gaLabel={linkText}
                        href={href}
                        className={style?.articleLink}
                    >
                        {linkText}
                    </Button>
                )}
            </div>
        </div>
    )
}

FeatureCard.propTypes = {
    href: PropTypes.string,
    image: PropTypes.object,
    linkText: PropTypes.string,
    title: PropTypes.string,
    description: PropTypes.string,
    variant: PropTypes.string,
    subTitle: PropTypes.string,
}
FeatureCard.defaultProps = {
    href: '',
    linkText: '',
    title: '',
    description: '',
}

export default memo(FeatureCard)
