import React from 'react'
import PropTypes from 'prop-types'
import ReactImageMagnify from 'react-image-magnify'

const Magnifier = ({ alt, magnifierSize, url }) => {
    return (
        <ReactImageMagnify
            {...{
                smallImage: {
                    alt: alt,
                    isFluidWidth: true,
                    height: magnifierSize.smallImage && magnifierSize.smallImage.height,
                    width: magnifierSize.smallImage && magnifierSize.smallImage.width,
                    src: url.selectedImageUrl,
                },
                largeImage: {
                    src: url && url.magnifiedImageUrl,
                    width: magnifierSize.largeImage && magnifierSize.largeImage.width,
                    height: magnifierSize.largeImage && magnifierSize.largeImage.height,
                },
                shouldUsePositiveSpaceLens: true,
                hoverDelayInMs: 0,
                fadeDurationInMs: 0,
                lensStyle: {
                    background: 'rgba(253,255,213,0.3)',
                    border: '1px solid rgba(0,0,0,0.3)',
                },
                imageStyle: {
                    cursor: 'pointer',
                },
                imageClassName: 'image-media',
                enlargedImageClassName: 'video-image',
                enlargedImageContainerDimensions: {
                    width: 250,
                    height: 250,
                },
                enlargedImageContainerStyle: {
                    top: '100px',
                    left: '180px',
                    border: '1px solid rgb(0,0,0)',
                },
                enlargedImageStyle: {
                    maxWidth: 'none',
                },
            }}
        />
    )
}

export default Magnifier

Magnifier.propTypes = {
    /*
   * alt text of image
   */
    alt: PropTypes.string,

    /*
   * object of magnifier size
   */
    magnifierSize: PropTypes.shape({
        smallImage: PropTypes.object,
        largeImage: PropTypes.object,
    }),

    /*
   * contains url object
   */
    url: PropTypes.shape({
        selectedImageUrl: PropTypes.string,
        magnifiedImageUrl: PropTypes.string,
    }),
}

Magnifier.defaultProps = {
    alt: 'Image not available',
    magnifierSize: {
        smallImage: {
            height: 460,
            width: 460,
        },
        largeImage: {
            height: 1210,
            width: 1210,
        },
    },
    url: {
        selectedImageUrl: '',
        magnifiedImageUrl: '',
    },
}
