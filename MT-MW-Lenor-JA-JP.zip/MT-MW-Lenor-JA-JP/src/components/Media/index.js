import React from 'react'
import PropTypes from 'prop-types'
import LazyLoad from 'react-lazyload'
// import { getCdnImage } from "../../adapters/cloudinary.adapters"
import classNames from 'classnames'
const MEDIA_COMPONENTS = ['video', 'audio', 'picture', 'iframe', 'img']
const getCdnImage = (url) => url

export function Media({
    className,
    wrapperClassName,
    component: Component,
    image,
    src,
    srcset,
    tabletSrcSet,
    altText,
    lazyLoad,
    lazyloadOffset,
    lazyLoadHeight,
    imageStyle,
    optimize,
    title,
}) {
    const isMediaComponent = MEDIA_COMPONENTS.indexOf(Component) !== -1
    const smallScreenDimension = optimize ? { w: 400 } : {}
    const mobileDimension = optimize ? { w: 500 } : {}
    const tabletDimension = optimize ? { w: 1366 } : {}

    const LazyLoadWrapper = (child) =>
        lazyLoad ? (
            <LazyLoad
                {...(lazyLoadHeight ? { height: lazyLoadHeight } : {})}
                offset={lazyloadOffset}
            >
                {child}
            </LazyLoad>
        ) : (
            child
        )

    const Picture = () => (
        <picture className={wrapperClassName}>
            <source srcSet={getCdnImage(srcset)} media={`(min-width: 1024px)`} />
            {tabletSrcSet && (
                <source
                    srcSet={getCdnImage(tabletSrcSet, tabletDimension)}
                    media={`(min-width: 768px)`}
                />
            )}
            {optimize && (
                <source
                    srcSet={getCdnImage(image, mobileDimension)}
                    media={`(min-width: 400px)`}
                />
            )}
            <img
                className={classNames(className, imageStyle)}
                src={getCdnImage(image, smallScreenDimension)}
                alt={altText ? altText : ''}
                title={title ? title : altText}
            />
        </picture>
    )

    if (Component === 'picture') {
        if (!lazyLoad) {
            return <Picture />
        }
        return LazyLoadWrapper(<Picture />)
    }

    return LazyLoadWrapper(
        <div className={wrapperClassName}>
            <Component
                className={className}
                src={isMediaComponent ? getCdnImage(image) || src : undefined}
                srcSet={srcset}
                alt={altText}
            />
        </div>,
    )
}

Media.propTypes = {
    className: PropTypes.string,
    wrapperClassName: PropTypes.string,
    srcset: PropTypes.string,
    tabletSrcSet: PropTypes.string,
    title: PropTypes.string,
    altText: PropTypes.string,
    component: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
    image: PropTypes.string,
    src: PropTypes.string,
    lazyLoad: PropTypes.bool,
    lazyloadOffset: PropTypes.number,
    lazyLoadHeight: PropTypes.number,
    minWidth: PropTypes.number,
    imageStyle: PropTypes.string,
    optimize: PropTypes.bool,
}

Media.defaultProps = {
    component: 'div',
    className: '',
    wrapperClassName: '',
    image: '',
    src: '',
    lazyLoad: true,
    lazyloadOffset: 400,
    minWidth: 992,
    optimize: false,
    lazyLoadHeight: 20,
}

export default Media
