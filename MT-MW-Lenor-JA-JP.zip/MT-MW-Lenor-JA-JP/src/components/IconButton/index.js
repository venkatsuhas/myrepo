import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { allIcons, allIconLinks, labels } from 'src/constants'

const Button = dynamic(() => import('@components/Button'))
const Icon = dynamic(() => import('@components/Icon'))

export const getButton = ({
    iconName,
    copiedToClipboard,
    locale,
    gaClass,
    smallFooter,
}) => {
    const props = { href: allIconLinks[iconName] }

    return (
        <>
            {iconName && iconName.toLowerCase() === 'linkicon' && (
                <div
                    className={`${
            copiedToClipboard ? 'block' : 'hidden'
          } clipText absolute left-35 whitespace-nowrap bg-darkBlue text-white p-5 inline-flex w-90 right-auto rounded-3 top-50p transform -translate-y-2/4 lg:-left-30 lg:-top-25 `}
                >
                    {labels[locale?.toLowerCase()]?.linkCopied}
                </div>
            )}
            <Button
                {...{ ...props, anchor: !props.href }}
                gaClass={gaClass}
                gaLabel={props.href || iconName}
                name={iconName}
            >
                <span className='sr-only'>{iconName}</span>
                <Icon name={iconName} className={''} />
                <div>
                    {!smallFooter && iconName && labels
                        ? [iconName] && labels[iconName]
                        : null}
                </div>
            </Button>
        </>
    )
}

const IconButton = ({
    variant,
    articleName,
    articleURL,
    copyToClipboard,
    copiedToClipboard,
    locale,
    gaClass,
    smallFooter,
}) => {
    return (
        <div className='flex justify-evenly'>
            {Object.keys(allIcons[variant]).map((key, index) => (
                <div key={index} className={''}>
                    {getButton({
                        iconName: allIcons[variant][key],
                        articleName,
                        articleURL,
                        copyToClipboard,
                        copiedToClipboard,
                        locale,
                        gaClass,
                        smallFooter,
                    })}
                </div>
            ))}
        </div>
    )
}
IconButton.propTypes = {
    variant: PropTypes.string,
    articleName: PropTypes.string,
    articleURL: PropTypes.string,
    copyToClipboard: PropTypes.func,
    copiedToClipboard: PropTypes.bool,
    locale: PropTypes.string,
    gaClass: PropTypes.string,
    smallFooter: PropTypes.bool,
}

IconButton.defaultprops = {
    variant: '',
    articleName: '',
    locale: '',
    gaClass: '',
    articleURL: '',
}

export default memo(IconButton)
