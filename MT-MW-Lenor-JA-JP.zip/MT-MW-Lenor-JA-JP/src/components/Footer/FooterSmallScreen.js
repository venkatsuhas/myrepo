import React, { useState, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { mobileFooterLabels, allIcons } from '@constants'

const Button = dynamic(() => import('@components/Button'))
const Icon = dynamic(() => import('@components/Icon'))
const IconButton = dynamic(() => import('@components/IconButton'))
const CountrySelector = dynamic(() => import('@components/CountrySelector'))

const FooterSmallScreen = ({ footerLinks, locale, footerSubTitle }) => {
    const {
        countrySelectorLabel,
        countryLanguage,
        brandListLabel,
        pleaseSelectLocation,
        enquiry,
        copyRight,
        viewPage,
    } = mobileFooterLabels
    const [modalOpen, setModalOpen] = useState(false)

    const openModal = useCallback(() => {
        setModalOpen(true)
    }, [])

    const closeModal = useCallback(() => {
        setModalOpen(false)
    }, [])
    return (
        <div className=' '>
            <div className='flex justify-between text-12 text-primaryblue font-bold font-hiraginoGothicProParis uppercase pb-10 mb-15 border-b-2 border-gray-300 px-20'>
                {countrySelectorLabel}
                <Button
                    // gaClass="text-white text-13 pt-10 hover:underline items-baseline"
                    gaLabel={countryLanguage}
                    className='flex w-auto text-12 items-center'
                    onClick={openModal}
                >
                    {countryLanguage}
                    <Icon name='RightCountrySelectorMobileIcon' className='h-15 ml-5' />
                </Button>
            </div>
            <div className='smallscreenyoutube flex justify-between font-bold py-20 mb-15 border-b-2 border-gray-300 px-20'>
                <div className='text-12 text-primaryblue uppercase font-Arial'>
                    {footerSubTitle}
                </div>
                <IconButton
                    variant='footerSocial'
                    gaClass='event_socialmedia_exit'
                    className='w-20 h-20'
                />
            </div>
            <div className='pb-20 mb-15 border-b-2 border-gray-300 px-20'>
                <div className='mb-20 text-12 text-primaryblue font-bold uppercase font-Arial '>
                    {brandListLabel}
                </div>
                <IconButton
                    variant='footerIcons'
                    gaClass='event_socialmedia_exit'
                    className='max-w-20'
                />
            </div>
            <ul className='footerlink text-center text-16 flex flex-wrap items-center justify-center m-auto w-70p text-primaryblue font-bold font-Arial'>
                <li className='inline p-7  leading-28'>
                    <Button
                        gaLabel={'event_informational_action'}
                        gaClass={'event_outbound_link'}
                        href={enquiry.href}
                    >
                        {enquiry.text}
                    </Button>
                </li>
                <span className='inline p-7'> / </span>
                <li className='inline p-7  leading-28'>
                    <Button
                        gaLabel={'event_informational_action'}
                        gaClass={'event_outbound_link'}
                        href={viewPage.href}
                    >
                        {viewPage.text}
                    </Button>
                </li>

                {footerLinks &&
          footerLinks.length > 0 &&
          footerLinks.map((footerLink) => (
              <li
                  key={footerLink.sys}
                  className='relative inline p-7  leading-28'
              >
                  <Button
                      gaLabel={'event_informational_action'}
                      gaClass={'event_outbound_link'}
                      href={footerLink.url}
                  >
                      {footerLink.title}
                      {allIcons.iconWithLabel.includes(footerLink.title) && (
                          <div className='absolute w-20p top-12 -right-12 pl-5'>
                              <Icon name={`${footerLink.title + 'Icon'}`} />
                          </div>
                      )}
                  </Button>
                  <span className='relative inline p-7'> / </span>
              </li>
          ))}
            </ul>
            <div className='text-center text-12 text-primaryblue font-bold font-Arial leading-28'>
                {copyRight}
            </div>
            {modalOpen && (
                <CountrySelector
                    locale={locale}
                    isOpen={modalOpen}
                    closeModal={closeModal}
                    pleaseSelectLocation={pleaseSelectLocation}
                />
            )}
        </div>
    )
}

FooterSmallScreen.propTypes = {
    locale: PropTypes.string,
    menuSlots: PropTypes.array,
    dentalCare: PropTypes.string,
    footerLinks: PropTypes.array,
    instaCard: PropTypes.object,
    viewFullSite: PropTypes.string,
    contactUs: PropTypes.object,
    footerSubTitle: PropTypes.string,
}

FooterSmallScreen.defaultProps = {
    locale: '',
    menuSlots: [],
    dentalCare: '',
    footerLinks: [],
    insaCard: {},
}

export default memo(FooterSmallScreen)
