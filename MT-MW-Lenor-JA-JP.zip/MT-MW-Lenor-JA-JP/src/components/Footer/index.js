import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { allIcons, mobileFooterLabels } from '@constants'

const Button = dynamic(() => import('@components/Button'))
const Icon = dynamic(() => import('@components/Icon'))
const IconButton = dynamic(() => import('@components/IconButton'))
const Image = dynamic(() => import('@components/Image'))
const FooterSmallScreen = dynamic(() =>
    import('@components/Footer/FooterSmallScreen'),
)

const Footer = ({
    menuSlots,
    footerLinks,
    footerSubTitle,
    mobileFooterLinks,
}) => {
    const { copyRight } = mobileFooterLabels
    return (
        <div className='mx-auto my-0 footerwrapper text-darkgray'>
            <footer className='px-0 pt-20 footer mdl:pt-0 pb-30 border-t-2 border-gray-300 mdl:border-0'>
                <div className='block mdl:hidden px-10'>
                    <FooterSmallScreen
                        footerSubTitle={footerSubTitle}
                        footerLinks={mobileFooterLinks}
                    />
                </div>
                <div className='hidden mdl:block bg-footergray  m-auto py-20 youtubeicon'>
                    <div className='flex m-auto w-full mdl:w-50p'>
                        <div className='pr-20 font-semibold text-12 pl-10'>
                            {footerSubTitle}
                        </div>{' '}
                        <IconButton
                            variant='footerSocial'
                            gaClass='event_socialmedia_exit'
                            className='max-w-20'
                        />
                    </div>
                </div>
                <div className='hidden mx-auto w-940 lg:w-lg mxl:w-mxl xl:w-xl mdl:block mdl:mt-30'>
                    <div>
                        <div className='flex productswrap mb-30  pb-30 border-b-1'>
                            <div className='hidden mdl:w-full mdl:flex'>
                                {menuSlots?.length > 0 &&
                  menuSlots.map((menuSlot) => {
                      return (
                          <div key={menuSlot.sys} className=' mdl:w-3/12 mdl:pr-30'>
                              <h4 className='uppercase text-12 leading-22 font-bold font-ChaletLondon mb-15'>
                                  {menuSlot.title || ''}
                              </h4>
                              <ul>
                                  {menuSlot.menuItems &&
                            menuSlot.menuItems.length > 0 &&
                            menuSlot.menuItems.map((menuItem) => (
                                <li key={menuItem.sys} className='mb-15'>
                                    {menuItem.title && (
                                        <>
                                            <Button
                                                href={menuItem.link || null}
                                                gaClass='event_internal_link'
                                                gaLabel={menuItem.title || null}
                                                className=' text-12 leading-22'
                                            >
                                                {menuItem.title}
                                            </Button>
                                        </>
                                    )}
                                    {menuItem.menuImage && (
                                        <div>
                                            <Image
                                                key={menuItem.sys}
                                                desktopClassName=''
                                                wrapperClassName='w-93 mdl:mr-0'
                                                desktopImage={menuItem?.menuImage}
                                                alt={menuItem?.altText}
                                                priority={true}
                                            />
                                        </div>
                                    )}
                                </li>
                            ))}
                                  {menuSlot.viewAllLink && (
                                      <li>
                                          <Button
                                              gaClass='event_internal_link'
                                              gaLabel={menuSlot?.viewAllLink || null}
                                              href={menuSlot?.viewAllLink || null}
                                              className=' text-12 leading-22'
                                          >
                                              {menuSlot?.viewAllLinkText || null}
                                          </Button>
                                      </li>
                                  )}
                              </ul>
                          </div>
                      )
                  })}
                            </div>
                        </div>
                    </div>
                </div>
                <div></div>
                <div className='hidden mdl:block mdl:flex w-50p m-auto'>
                    <div className='mdl:w-12/12 mdl:flex mdl:flex-wrap'>
                        <div className='flex flex-wrap px-20 mb-30 mdl:w-auto mdl:px-0 mdl:mb-0'>
                            {footerLinks &&
                footerLinks.length > 0 &&
                footerLinks.map((footerLink) => (
                    <div
                        key={footerLink.sys}
                        className='relative w-6/12 mb-20 mdl:px-7 text-12 leading-20 mdl:w-auto mdl:pl-0 mdl:pr-30 mdl:mb-0'
                    >
                        <Button
                            gaLabel={'event_informational_action'}
                            gaClass={'event_outbound_link'}
                            href={footerLink.url}
                        >
                            {footerLink.title}
                            {allIcons.iconWithLabel.includes(footerLink.title) && (
                                <div className='absolute w-10 top-5 right-12'>
                                    <Icon name={`${footerLink.title + 'Icon'}`} />
                                </div>
                            )}
                        </Button>
                    </div>
                ))}
                            <div className='relative w-6/12 mb-20 mdl:px-7 text-12 leading-20 mdl:w-auto mdl:pl-0 mdl:pr-30 mdl:mb-0'>
                                {copyRight}
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    )
}
Footer.propTypes = {
    menuSlots: PropTypes.array,
    footerLinks: PropTypes.array,
    footerSubTitle: PropTypes.string,
    mobileFooterLinks: PropTypes.array,
}

export default memo(Footer)
