import React, { useCallback, memo, useState } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'
import { productListingPage, pageTypes } from '@constants'
import Accordion from '@components/Accordion'

const Button = dynamic(() => import('@components/Button'))
const FilterAccordion = dynamic(() => import('@components/FilterAccordion'))

const FilterLargeScreen = ({
    type,
    variant,
    mainCategories,
    secondMainCategories,
    filters,
    toggleFilter,
    activeFilters,
    resetFilter,
}) => {
    const [openAccordion, setOpenAccordion] = useState(false)

    const labels = productListingPage || {}
    const router = useRouter()
    const resetFilters = useCallback(() => {
        if (typeof resetFilter === 'function') resetFilter()
    }, [resetFilter])
    return (
        <div className='hidden mdl:block'>
            {
                <ul className='mdl:pt-25 mdl:pb-5'>
                    <h2 className='w-full font-ChaletLondon  text-12 leading-30 text-primaryblue px-15 mb-20 bg-bgblue rounded-5'>
                        {labels.browseByLabels[type]}
                    </h2>
                    {mainCategories?.length > 0 &&
            mainCategories?.map((category, index) => {
                return (
                    <li
                        key={index}
                        className='text-14 font-ChaletParis leading-20 text-primaryblue mb-10 pl-20 '
                    >
                        <Button
                            className={
                                decodeURI(router?.asPath) === category.url
                                    ? ' font-ChaletLondon text-primary font-bold'
                                    : 'font-AvenirLTLight text-secondary'
                            }
                            href={category.url}
                            gaClass='event_internal_link'
                            gaLabel={category.url}
                        >
                            {category.title}
                        </Button>
                    </li>
                )
            })}
                    {secondMainCategories?.length > 0 && (
                        <Accordion
                            open={openAccordion}
                            title={'効果から選ぶ'}
                            toggleOpen={() => setOpenAccordion(!openAccordion)}
                            variant={'ProductListingBrowse'}
                            displayIcon={false}
                        >
                            {secondMainCategories?.map((category, index) => {
                                return (
                                    <li
                                        key={index}
                                        className='text-14 font-ChaletParis leading-20 text-primaryblue mb-10 pl-20 '
                                    >
                                        <Button
                                            className={
                                                decodeURI(router?.asPath) === category.url + '/'
                                                    ? ' font-ChaletLondon text-primary font-bold'
                                                    : 'font-AvenirLTLight text-secondary'
                                            }
                                            href={category.url}
                                            gaClass='event_internal_link'
                                            gaLabel={category.url}
                                        >
                                            {category.title}
                                        </Button>
                                    </li>
                                )
                            })}
                        </Accordion>
                    )}
                </ul>
            }
            <div className='w-full filter-btm-cls'>
                {variant !== pageTypes.alpPage && variant !== pageTypes.productsPage && (
                    <div className='flex-wrap flex-row justify-between items-center  pb-10 mb-40 border-b border-lightestBorder hidden'>
                        <p className='font-AvenirLTMedium text-20 leading-30 text-secondary'>
                            {labels.filters}
                        </p>
                        <Button
                            className='font-AvenirLTMedium text-10 leading-30 text-secondary text-opacity-70'
                            gaClass='event_button_click'
                            onClick={resetFilters}
                        >
                            {labels.resetFilters}
                        </Button>
                    </div>
                )}
                {filters &&
          filters
              .filter(
                  (filter) =>
                      filter.options.filter((option) => option.count).length,
              )
              .map((filter) => (
                  <FilterAccordion
                      key={filter?.name?.toLowerCase().replace(' ', '-')}
                      title={filter.name}
                      options={filter.options.map((option) => ({
                          name: option.name,
                          state: activeFilters.indexOf(option.name) !== -1,
                          count: option.count,
                      }))}
                      variant={variant}
                      filterUpdate={toggleFilter}
                      constant='LargeScreen'
                  />
              ))}
            </div>
        </div>
    )
}

FilterLargeScreen.propTypes = {
    type: PropTypes.string,
    locale: PropTypes.string,
    variant: PropTypes.string,
    filters: PropTypes.array,
    mainCategories: PropTypes.array,
    secondMainCategories: PropTypes.array,
    resetFilter: PropTypes.func,
    toggleFilter: PropTypes.func,
    activeFilters: PropTypes.array,
}

export default memo(FilterLargeScreen)
