import React, { useState, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { articleListingPage } from '@constants'
const Button = dynamic(() => import('@components/Button'))
const ProductDialog = dynamic(() =>
    import('@components/CommonDialog/ProductDialog'),
)
const Icon = dynamic(() => import('@components/Icon'))

const SmallScreenAlp = ({
    locale,
    filters,
    toggleFilter,
    activeFilters,
    resetFilter,
}) => {
    const [openFilterDialog, setOpenFilterDialog] = useState(false)
    const labels = articleListingPage

    const toggleLocalFilter = useCallback(
        (value) => {
            toggleFilter(value)
        },
        [toggleFilter],
    )

    return (
        <>
            {activeFilters && activeFilters.length > 0 && (
                <div className='flex flex-row flex-wrap items-center justify-start w-full px-20 mr-10'>
                    <span className='inline-flex pr-10 h-35 font-AvenirLTHeavy text-12 text-darkgray'>
                        {labels.viewing}
                    </span>
                    {activeFilters.map((filter, index) => (
                        <div
                            key={`${filter}-${index}`}
                            className='flex flex-row items-center justify-between py-2 mb-10 mr-10 bg-lightergray px-15'
                        >
                            <label className='uppercase font-AvenirLTBook text-12 text-darkgray pr-15'>
                                {filter}
                            </label>
                            <Button
                                gaClass='event_button_click'
                                onClick={() => toggleFilter(filter)}
                            >
                                <Icon
                                    // className="w-10 h-10 stroke-current stroke-2 text-secondary ml-15"
                                    name='FilterCloseIcon'
                                />
                            </Button>
                        </div>
                    ))}
                    {
                        <div className='flex flex-row items-center justify-between py-2 mb-10 mr-10 bg-lightergray px-15'>
                            <label className='uppercase font-AvenirLTBlack text-12 pr-15 text-accent'>
                                {labels.clearAll}
                            </label>
                            <Button
                                gaClass='event_button_click'
                                onClick={() => resetFilter()}
                            >
                                <Icon
                                    // className="w-10 h-10 stroke-current stroke-2 text-secondary ml-15"
                                    name='FilterCloseIcon'
                                />
                            </Button>
                        </div>
                    }
                </div>
            )}
            {openFilterDialog && (
                <ProductDialog
                    locale={locale}
                    variant='mobilefilter'
                    filters={filters}
                    toggleLocalFilter={toggleLocalFilter}
                    closeModal={() => {
                        setOpenFilterDialog(!openFilterDialog)
                    }}
                    activeFilters={activeFilters}
                />
            )}
        </>
    )
}

SmallScreenAlp.propTypes = {
    locale: PropTypes.string,
    filters: PropTypes.array,
    toggleFilter: PropTypes.func,
    activeFilters: PropTypes.array,
    resetFilter: PropTypes.func,
}

export default memo(SmallScreenAlp)
