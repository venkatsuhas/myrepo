import React, { useState, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { articleListingPage } from '@constants'
const Button = dynamic(() => import('@components/Button'))
const ProductDialog = dynamic(() =>
    import('@components/CommonDialog/ProductDialog'),
)
const Icon = dynamic(() => import('@components/Icon'))

const MobileSmallScreen = ({
    locale,
    filters,
    toggleFilter,
    activeFilters,
    resetFilter,
    girdIconActive,
    listIconActive,
    setListIconActive,
    setGirdIconActive,
    setView,
}) => {
    const [openFilterDialog, setOpenFilterDialog] = useState(false)
    const labels = articleListingPage

    const toggleLocalFilter = useCallback(
        (value) => {
            toggleFilter(value)
        },
        [toggleFilter],
    )

    return (
        <>
            {activeFilters && activeFilters.length > 0 && (
                <div className='flex flex-row flex-wrap items-center justify-start w-full px-20 mr-10'>
                    <span className='inline-flex pr-10 h-35 font-AvenirLTHeavy text-12 text-darkgray'>
                        {labels.viewing}
                    </span>
                    {activeFilters.map((filter, index) => (
                        <div
                            key={`${filter}-${index}`}
                            className='flex flex-row items-center justify-between py-2 mb-10 mr-10 bg-lightergray px-15'
                        >
                            <label className='uppercase font-AvenirLTBook text-12 text-darkgray pr-15'>
                                {filter}
                            </label>
                            <Button
                                gaClass='event_button_click'
                                onClick={() => toggleFilter(filter)}
                            >
                                <Icon
                                    // className="w-10 h-10 stroke-current stroke-2 text-secondary ml-15"
                                    name='FilterCloseIcon'
                                />
                            </Button>
                        </div>
                    ))}
                    {
                        <div className='flex flex-row items-center justify-between py-2 mb-10 mr-10 bg-lightergray px-15'>
                            <label className='uppercase font-AvenirLTBlack text-12 pr-15 text-accent'>
                                {labels.clearAll}
                            </label>
                            <Button
                                gaClass='event_button_click'
                                onClick={() => resetFilter()}
                            >
                                <Icon name='FilterCloseIcon' />
                            </Button>
                        </div>
                    }
                </div>
            )}
            <div className='flex justify-between py-10 mb-20'>
                <div className='filter-block flex'>
                    <div className='mr-5'>
                        <Button
                            onClick={() => {
                                setOpenFilterDialog(!openFilterDialog)
                            }}
                            className='inline-flex justify-center py-6 bg-primaryblue px-15 rounded-5 min-w-70  text-12 border-1 border-accent text-white lowercase font-ChaletLondon'
                        >
                            {labels.filter}
                        </Button>
                    </div>
                    <div>
                        <Button
                            onClick={() => {
                                setOpenFilterDialog(!openFilterDialog)
                            }}
                            className='inline-flex justify-center py-6 bg-primaryblue px-15 rounded-5 min-w-70  text-12 border-1 border-accent text-white lowercase font-ChaletLondon'
                        >
                            {labels.sort}
                        </Button>
                    </div>
                </div>
                <div className='grid-viewblock'>
                    <p className='pt-5 pl-5 font-AvenirLTLight text-14 leading-30 text-darkgray'>
                        <Button
                            gaClass='event_button_click'
                            onClick={() => {
                                setGirdIconActive(true)
                                setListIconActive(false)
                                setView(true)
                            }}
                        >
                            <Icon name={girdIconActive ? 'girdViewIconOn' : 'girdViewIcon'} />
                        </Button>
                    </p>
                    <p className='pt-5 pl-5 font-AvenirLTLight text-14 leading-30 text-darkgray'>
                        <Button
                            gaClass='event_button_click'
                            onClick={() => {
                                setListIconActive(true)
                                setGirdIconActive(false)
                                setView(false)
                            }}
                        >
                            <Icon name={listIconActive ? 'listViewIconOn' : 'listViewIcon'} />
                        </Button>
                    </p>
                </div>
            </div>
            {openFilterDialog && (
                <ProductDialog
                    locale={locale}
                    variant='mobilefilter'
                    filters={filters}
                    toggleLocalFilter={toggleLocalFilter}
                    closeModal={() => {
                        setOpenFilterDialog(!openFilterDialog)
                    }}
                    activeFilters={activeFilters}
                />
            )}
        </>
    )
}

MobileSmallScreen.propTypes = {
    locale: PropTypes.string,
    filters: PropTypes.array,
    toggleFilter: PropTypes.func,
    activeFilters: PropTypes.array,
    resetFilter: PropTypes.func,
    girdIconActive: PropTypes.bool,
    listIconActive: PropTypes.bool,
    setListIconActive: PropTypes.func,
    setGirdIconActive: PropTypes.func,
    setView: PropTypes.func,
}

export default memo(MobileSmallScreen)
