import React, { memo } from 'react'
import { productListingPage } from '@constants'
import dynamic from 'next/dynamic'
import PropTypes from 'prop-types'

const ProductCard = dynamic(() => import('@components/Card/ProductCard'))

const RecentlyViewed = ({ items }) => {
    return (
        <div>
            <h2>{productListingPage.recentlyViewedLabel}</h2>
            <div>
                {items.map((item, index) => (
                    <div key={index}>
                        <ProductCard {...item} variant='pdpProductCard' />
                    </div>
                ))}
            </div>
        </div>
    )
}

RecentlyViewed.propTypes = {
    items: PropTypes.array,
}

export default memo(RecentlyViewed)
