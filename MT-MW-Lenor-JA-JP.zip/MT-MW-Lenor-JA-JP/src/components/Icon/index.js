import React, { memo } from 'react'
import Icons from '../../assets/icons/index'

import PropTypes from 'prop-types'
import { allIcons } from '@constants'

const Icon = ({ name, className, assetImageFlag }) => {
    //  if (!name) return <span>Icon not found</span>
    if (assetImageFlag) {
        const SelectedAssetIcon = Icons[name] ? Icons[name] : null
        if (SelectedAssetIcon) return SelectedAssetIcon(className)
        else return null
    } else {
        const SelectedIcon = allIcons.iconSource[name]
            ? allIcons.iconSource[name]
            : null
        if (SelectedIcon)
            return (
                <div>
                    <img
                        src={SelectedIcon}
                        alt={name}
                        className={className}
                        title={name}
                    />
                </div>
            )
        else return null
    }
}

Icon.propTypes = {
    name: PropTypes.string.isRequired,
    className: PropTypes.string,
    assetImageFlag: PropTypes.bool,
}

export default memo(Icon)
