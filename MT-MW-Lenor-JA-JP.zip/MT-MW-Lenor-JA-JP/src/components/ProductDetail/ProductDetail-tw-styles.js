export const productHeadStyles = {
    pdpWrapper: 'pdpWrapper bg-white md:px-20 lg:px-0',
    shareContainer: 'shareContainer container text-right m-auto sm:pr-20 lg:pr-0',
    shareText: 'shareText montserratRegular text-16 text-darkGray uppercase ',
    pdpTopContainer: 'pdpTopContainer container flex flex-wrap py-10 m-auto',
    pdpbottomContainer:
    'pdpbottomContainer container flex flex-wrap py-10 m-auto text-darkGray',
    productImages:
    'productImages sm:w-full sm:block md:w-1/2 overflow-hidden sm:min-h-460',
    productDetails: 'productDetails sm:w-full sm:block px-20 md:w-1/2 md:px-0',

    productTitle:
    'productTitle sm:text-22 productTitle montserratRegular text-darkerBlue md:text-26 uppercase',
    productDesc:
    'productDesc montserratRegular text-darkGray text-14 leading-normal py-10',
    productVariant: {
        index: 'productVariant md:flex md:flex-wrap',
        productSize:
      'productSize text-16 md:pt-3 montserratRegular pb-20 text-darkGray md:w-1/4',
    },
    productPrice:
    'productPrice sm:font-semibold md:font-medium productPrice text-18 montserratMedium text-darkGray py-20',
    productReviewCount: 'productReviewCount flex flex-wrap pt-10',
    totoalCountSection: 'totoalCountSection text-14 text-darkGray',
    reviewButton: 'reviewButton text-14 text-darkGray pl-5',
    pdpTabSection: 'pdpTabSection hidden lg:block md:block  w-9/12 md:pr-20',
    pdpAccordian: 'pdpAccordian lg:hidden md:hidden sm:block ',
    relatedProductHd: 'relatedProductHd',
    relatedProduct:
    'relatedProduct sm:w-full sm:px-20 md:w-3/12 md:border text-darkGray relative md:border-darkBule text-center md:mt-45 py-15 lg:min-h-355',
    reviewSection: 'w-full',
}

export const productImageSliderStyles = {
    carousel: 'carousel',
    prodImageSection: 'prodImageSection pdpProdctImgSec',
    zoomIcon: 'hidden zoomIcon relative float-right lg:block -mt-115 mr-30',
    dialogTitle:
    'dialogTitle py-10 px-10 flex flex-wrap text-24 montserratRegular text-darkerBlue border-b border-backgroundGray justify-between',
    dialogclose:
    'dialogclose flex flex-wrap items-center float-right mr-12 px-10 py-10 ',
    dialogTitleclose: 'dialogTitleclose px-5',
    productTitle: 'productTitle',
    dialogTitleright: 'dialogTitleright',
    modalProduct: 'modalProduct border max-w-640 text-darkGray mt-100',
    videoDisp: 'videoDisp',
    videoThumbnail: 'videoThumbnail',
    dialogWrapper: 'dialogWrapper',
    imageDialog: 'imageDialog',
    videoDialog: 'videoDialog',
    videoDialogTitle: 'videoDialogTitle',
    dialogVideoContent: 'dialogVideoContent max-w-full px-20 py-20',
    carousalimgwrap: 'carousalimgwrap border-1 solid border-bordergray',
    carouselList: 'carouselList cursor-pointer mx-auto w-93 h-93 m-1',
    next: 'next absolute mdl:top-25 right-0 z-1  pt-4',
    galleryList:
    'prodGalary mx-auto items-center mt-17  relative  overflow-hidden h-150',
    prev: 'prev absolute mdl:top-25 left-0 z-1  pt-4',
    listImg: 'lg:w-full mx-30 mdl:w-435',
}

export const productAccordianStyles = {
    accordianWrapper: 'accordianWrapper',
    commonBody:
    'commonBody text-13 montserratRegular text-darkGray leading-normal ',
    commonHeading:
    'commonHeading sm:w-12/12 text-left text-white montserratRegular text-17 uppercase hover:text-white',
    tabAccordianCommon: {
        description: 'faq-content md:px-15  ',
        accordion: {
            panel: 'panel w-full',
            panelHeader:
        'panelHeader MontserratRegular my-5 text-black bg-white  px-15 py-10 bg-lightBlue',
            panelDetail: 'trans-500-max-h p-0',
            icon: ' icon float-right pt-3 ',
            expanded:
        'md:max-h-500 py-20 overflow-auto border-b md:max-h-500 py-20 overflow-auto border-b border-lightBlue px-15 text-13 px-15 text-13',
            collapsed: 'max-h-0 overflow-hidden p-0',
            panel_head:
        ' text-black bg-white py-15 border-grey-light border-b md:border-none text-base ',
            icon_span: 'mt-15',
        },
    },
    accordian: {
        panelHeader: ' text-black bg-white  px-15 py-0',
        panel_head:
      ' text-black bg-white py-15 border-grey-light border-b md:border-none text-base',
        panel: 'w-full',
        icon: 'float-right',
        expanded: 'md:max-h-500 overflow-auto pt-10 pb-30',
        panel_header: ' text-black bg-white  px-15',
        icon_span: 'mt-15',
    },
}

export const productTabStyles = {
    tabWrapper:
    'tabListMain border0 -mb-10 py-9 text-darkBule montserratRegular text-16',
}
