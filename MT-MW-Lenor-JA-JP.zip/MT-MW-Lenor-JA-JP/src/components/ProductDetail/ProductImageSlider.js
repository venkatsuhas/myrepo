import React from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames'
// import { getCdnImage } from '../../adapters/cloudinary.adapters'
import Slider from 'react-slick'
// import { Button } from '../Button/Button'
import Media from '../Media'
import Magnifier from '../Magnifier/Magnifier'
import { productImageSliderStyles } from './ProductDetail-tw-styles'
import {
    productNavigationCarouselSetting,
    magnifierSize,
} from './productSettings'
import Button from '@components/Button'
const getCdnImage = (url) => url
export const NextArrow = ({ arrowSrc, onClick }) => (
    <button type='button' tabIndex='0' onClick={onClick}>
        <img src={arrowSrc} alt='next-arrow' />
    </button>
)

export const PrevArrow = ({ arrowSrc, onClick }) => (
    <button type='button' tabIndex='0' onClick={() => onClick()}>
        <img src={arrowSrc} alt='prev-arrow' />
    </button>
)

class ProductImageSlider extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            isImageDialogOpen: false,
            selectedImageIndex: 0,
            isVideo: false,
            currentSlide: 0,
            navSlider: null,
            productSlider: null,
        }
    }

    componentDidMount() {
        this.setState({
            navSlider: this.slider1,
            productSlider: this.slider2,
        })
    }

  goNext = () => {
      const { currentSlide } = this.state
      this.slider2.slickGoTo(currentSlide + 1)
  }

  goPrev = () => {
      const { currentSlide } = this.state
      this.slider2.slickGoTo(currentSlide - 1)
  }

  toggleDialogState = (e, index, isVideo) => {
      const { isImageDialogOpen } = this.state
      this.setState({
          isImageDialogOpen: !isImageDialogOpen,
          selectedImageIndex: index || 0,
          isVideo: isVideo,
      })
  }

  getSelctedImage = () => {
      const { media } = this.props
      const { selectedImageIndex } = this.state
      const details = (media.items && media.items[selectedImageIndex].url) || {}
      return details
  }

  render() {
      const { media } = this.props
      const { selectedImageIndex } = this.state
      const twStyles = productImageSliderStyles
      let imagePaging = []
      const arrowImages = {
          prev: 'https://images.ctfassets.net/5go9vi5tpqi4/3u97kIqh30l1LRU7n3TSbT/6e3bf31beebbb7fe01ecf70a0f283f0f/previous.png',
          next: 'https://images.ctfassets.net/5go9vi5tpqi4/x0eU3HK6fPzImJhFzJV3j/849e61921a28db3118240c94e39b39fb/Next.png',
      }
      const productImages = media.items.map((mediaDetails, index) => {
          let cldImage = '',
              urlMagnifier = {}
          switch ('Image') {
          //   case 'Video':
          //       cldImage = getCdnImage(mediaDetails.videoThumbnail.url)
          //       imagePaging[index] = cldImage
          //       return (
          //           <div
          //               key={index.toString()}
          //               onClick={(e) => {
          //                   this.toggleDialogState(e, index, true)
          //               }}
          //               className={classNames(
          //                   twStyles.videoDisp,
          //                   mediaDetails.gaEventClass,
          //               )}
          //               {...(mediaDetails.gaEventLabel && {
          //                   'data-action-detail': mediaDetails.gaEventLabel,
          //               })}
          //           >
          //               <img
          //                   src={cldImage}
          //                   alt='video'
          //                   className={twStyles.videoThumbnail}
          //               />
          //           </div>
          //       )
          case 'Image':
              cldImage = getCdnImage(mediaDetails.url)
              imagePaging[index] = cldImage
              urlMagnifier = {
                  selectedImageUrl: cldImage,
                  magnifiedImageUrl: cldImage,
              }
              return (
                  <Button
                      key={index.toString()}
                      onClick={(e) => {
                          this.toggleDialogState(e, index, false)
                      }}
                      className={classNames(twStyles.prodImageSection)}
                      // {...mediaDetails.gaEventLabel && {
                      //     'data-action-detail': mediaDetails.gaEventLabel,
                      // }}
                  >
                      <div style={{ width: '400px' }}>
                          <Magnifier magnifierSize={magnifierSize} url={urlMagnifier} />
                      </div>
                  </Button>
              )
          }
      })
      return (
          <div className={twStyles.carousel}>
              <Slider
                  asNavFor={this.state.navSlider}
                  ref={(slider) => (this.slider2 = slider)}
                  dots={false}
                  arrows={false}
                  slidesToShow={1}
                  slidesToScroll={1}
                  infinite
                  lazyLoad={false}
                  autoplay={false}
                  afterChange={(current) => this.setState({ currentSlide: current })}
              >
                  <div>{productImages[selectedImageIndex]}</div>
                  {/* {imagePaging.length === 1 && (<div style={{ visibility: 'hidden' }} />)} */}
              </Slider>
              <span className={twStyles.zoomIcon}>
                  <img
                      src='https://res.cloudinary.com/mtree/image/upload/v1582091837/HeadandShoulders_PH_MW/custom/images/magnifier.png'
                      alt='magnifier'
                  />
              </span>
              <div className={twStyles.galleryList}>
                  {media.items.length > 3 && (
                      <div className={twStyles.prev}>
                          <PrevArrow onClick={this.goPrev} arrowSrc={arrowImages.prev} />
                      </div>
                  )}

                  <div className={twStyles.listImg}>
                      <Slider
                          {...productNavigationCarouselSetting}
                          infinite={false}
                          swipeToSlide
                          arrows={false}
                          focusOnSelect
                          asNavFor={this.state.productSlider}
                          ref={(slider) => (this.slider1 = slider)}
                          className='h-full'
                      >
                          {media.items?.map(
                              ({ sys, url, altText }, index) =>
                                  url && (
                                      <Button
                                          onClick={() =>
                                              this.setState({ selectedImageIndex: index })
                                          }
                                      >
                                          <Media
                                              key={sys}
                                              component='img'
                                              image={url}
                                              altText={altText}
                                              className={twStyles.carouselList}
                                              wrapperClassName={twStyles.carousalimgwrap}
                                          />
                                      </Button>
                                  ),
                          )}
                      </Slider>
                  </div>
                  {media.items.length > 3 && (
                      <div className={twStyles.next}>
                          <NextArrow onClick={this.goNext} arrowSrc={arrowImages.next} />
                      </div>
                  )}
              </div>
              {/* <Dialog
                    open={isImageDialogOpen}
                    onClose={this.toggleDialogState}
                    modalStyle={twStyles.modalProduct}
                >
                    <div className={twStyles.dialogWrapper}>
                        {!isVideo ?
                            (<div className={twStyles.imageDialog}>
                                <div className={classNames(twStyles.dialogTitle)}>
                                    <Typography component='h1' className={twStyles.productTitle} dangerouslySetInnerHTML={{ __html: productShortName }} />
                                    <Button onClick={this.toggleDialogState} className={classNames(twStyles.dialogclose)}>
                                        <Typography component='span' className={classNames(twStyles.dialogTitleclose)} >Close</Typography>
                                        <img src='https://res.cloudinary.com/mtree/image/upload/v1582091833/HeadandShoulders_PH_MW/custom/images/Close.png' alt='Close' />
                                    </Button>
                                </div>
                                {media.items[selectedImageIndex] && (getImage(media.items[selectedImageIndex]))}
                            </div>) :
                            <div className={twStyles.videoDialog}>
                                <div className={classNames(twStyles.videoDialogTitle)}>
                                    <Button onClick={this.toggleDialogState} className={classNames(twStyles.dialogclose)}>
                                        <img src='https://res.cloudinary.com/mtree/image/upload/v1582091833/HeadandShoulders_PH_MW/custom/images/Close.png' alt='Close' />
                                    </Button>
                                </div>
                                <div className={twStyles.dialogVideoContent}>
                                    {getVideo(media.items[selectedImageIndex])}
                                </div>
                            </div>
                        }
                    </div>
                </Dialog> */}
          </div>
      )
  }
}

ProductImageSlider.propTypes = {
    media: PropTypes.shape({
        items: PropTypes.instanceOf(Array),
    }),
    productShortName: PropTypes.string,
}

ProductImageSlider.defaultProps = {
    productShortName: '',
}

NextArrow.propTypes = {
    onClick: PropTypes.func,
    arrowSrc: PropTypes.string,
}

PrevArrow.propTypes = {
    onClick: PropTypes.func,
    arrowSrc: PropTypes.string,
}

export default ProductImageSlider
