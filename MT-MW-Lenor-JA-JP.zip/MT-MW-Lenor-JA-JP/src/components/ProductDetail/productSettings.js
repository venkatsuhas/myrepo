export const carouselSetting = {
    dots: true,
    dotsClass: 'slick-dots slick-thumb',
    autoplay: false,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
}

export const ProductCarouselSetting = {
    dots: false,
    dotsClass: 'slick-dots slick-thumb',
    autoplay: false,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
}

export const productNavigationCarouselSetting = {
    dots: false,
    dotsClass: 'slick-dots slick-thumb',
    autoplay: false,
    arrows: true,
    infinite: false,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
            },
        },
        {
            breakpoint: 1023,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
            },
        },
    ],
}

export const magnifierSize = {
    smallImage: {
        height: 460,
        width: 460,
    },
    largeImage: {
        height: 1210,
        width: 1210,
    },
}
