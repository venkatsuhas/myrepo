module.exports = {
    default: {
        background: 'pagewrapper',
    },
    ProductDetailPage: {
        background:
      'mdl:bg-bodypdpbg bg-no-repeat bg-centertop bg-white bg-no-repeat ',
    },
    ExperienceListingPage: {
        background:
      'mdl:bg-bodyexpcard bg-no-repeat bg-centertop bg-white bg-no-repeat ',
    },
    ProductListingPage: {
        background:
      'mdl:bg-bodybg bg-no-repeat bg-centertop bg-white bg-no-repeat ',
    },
    ArticleListingPage: {
        background:
      'mdl:bg-bodybg bg-no-repeat bg-centertop bg-white bg-no-repeat ',
    },

    // pdpPage: {

    // },
}
