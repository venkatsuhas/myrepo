import React, { memo, useState, useCallback } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import style from './Layout.tw-style'

const Header = dynamic(() => import('@components/Header'))
const Footer = dynamic(() => import('@components/Footer'))
const HeaderSmallScreen = dynamic(() =>
    import('@components/Header/HeaderSmallScreen'),
)

const Layout = ({ children, headerData, footerData, pageType }) => {
    const layoutStyle = style[pageType] || style['default']
    const [showMenuToggle, setShowMenuToggle] = useState(false)
    const [isMenuOpen, setIsMenuOpen] = useState(false)

    const toggleMenu = useCallback(() => {
        setIsMenuOpen((prevIsMenuOpen) => !prevIsMenuOpen)
        setShowMenuToggle((prevShowMenuToggle) => !prevShowMenuToggle)
    }, [])
    return (
        <>
            <div
                className={`${layoutStyle.background} ${
          showMenuToggle ? 'menu-toggle' : ''
        }`}
            >
                <Header
                    {...headerData}
                    toggleMenu={toggleMenu}
                    isMenuOpen={isMenuOpen}
                />
                {children}
                <Footer
                    {...footerData}
                    smallFooterSlots={headerData?.menuSlots || null}
                />
            </div>
            {isMenuOpen && (
                <div className='mobile-slide-nav absolute p-10 top-0 z-30 bg-navBg -right-25p w-5/6'>
                    <HeaderSmallScreen
                        menuSlots={headerData?.menuSlots}
                        toggleMenu={toggleMenu}
                        inquiry={headerData?.inquiry}
                        locale={headerData?.locale}
                    />
                </div>
            )}
        </>
    )
}

Layout.propTypes = {
    children: PropTypes.node.isRequired,

    headerData: PropTypes.shape({
        locale: PropTypes.string.isRequired,

        menuSlots: PropTypes.array,

        brandList: PropTypes.string,

        inquiry: PropTypes.object,

        pleaseSelectLocation: PropTypes.string,

        countryLanguage: PropTypes.string,
    }).isRequired,

    footerData: PropTypes.shape({
        locale: PropTypes.string.isRequired,

        footerSubTitle: PropTypes.string,

        menuSlots: PropTypes.array,
    }).isRequired,
    pageType: PropTypes.string,
}

export default memo(Layout)
