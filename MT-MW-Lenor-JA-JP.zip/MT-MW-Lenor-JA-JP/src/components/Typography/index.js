import { Fragment, createElement, memo } from 'react'
import PropTypes from 'prop-types'
import { marked } from 'marked'
import parse from 'html-react-parser'
import Button from '@components/Button'

const getImageURL = (imageURL) =>
    imageURL
        ?.replace(
      `//images.ctfassets.net/${process.env.CF_SPACE_ID}/`,
      `//res.cloudinary.com/mtree/${process.env.CLOUDINARY_FOLDER}/`,
        )
        .replace(
      `//images.contentful.com/${process.env.CF_SPACE_ID}/`,
      `//res.cloudinary.com/mtree/${process.env.CLOUDINARY_FOLDER}/`,
        ) || ''
const allowed_br = ['p']

const Typography = ({
    className,
    component: Component,
    content,
    br_allowed,
    ...other
}) =>
    createElement(
        Component,
        {
            ...(className ? { className } : {}),
            ...other,
        },
        parse(marked.parse(content || ''), {
            replace: (domNode) => {
                if (domNode.type == 'tag' && domNode.name === 'br') {
                    return createElement(Fragment)
                } else if (domNode.type == 'tag' && domNode.name === 'a') {
                    return createElement(
                        Button,
                        { ...domNode.attribs },
                        domNode.children.map((childDomNode, index) => {
                            if (childDomNode.type == 'tag' && childDomNode.name === 'img') {
                                return createElement('img', {
                                    key: index,
                                    src: getImageURL(childDomNode.attribs.src),
                                    alt: childDomNode.attribs.alt || 'image',
                                })
                            } else if (childDomNode.data) {
                                return childDomNode.data
                            } else {
                                return createElement(Fragment, { key: index })
                            }
                        }),
                    )
                } else if (
                    ((domNode.parent && allowed_br.indexOf(domNode.parent.name) !== -1) ||
            (!domNode.parent && domNode.prev && domNode.next)) &&
          domNode.type == 'text' &&
          domNode.data === '\n' &&
          br_allowed
                ) {
                    return createElement('br')
                } else if (domNode.type == 'tag' && domNode.name === 'img') {
                    return createElement('img', {
                        src: getImageURL(domNode.attribs.src),
                        alt: domNode.attribs.alt || 'image',
                    })
                }
            },
            trim: true,
        }),
    )

Typography.propTypes = {
    className: PropTypes.string,
    component: PropTypes.string,
    content: PropTypes.string,
    br_allowed: PropTypes.bool,
}

Typography.defaultProps = {
    className: '',
    component: 'div',
    content: '',
    br_allowed: true,
}

export default memo(Typography)
