import React from 'react'
import ExternalLink from '../Common/ExternalLink'
import Image from 'next/image'

const MWLogo = () => {
    return (
        <ExternalLink
            href='https://mw-wiki.pg.com'
            className='text-white text-xl font-bold flex items-center pr-3 py-1 rounded hover:underline'
        >
            <div className={`relative h-16 w-32 -mx-1`}>
                <Image
                    src='/static/images/mw-logo.svg'
                    alt='Modern Web Logo'
                    title='Modern Web Logo'
                    className='z-auto object-contain block w-full h-full'
                />
            </div>
            <p>
        Modern <br />
        Web
            </p>
        </ExternalLink>
    )
}

export default MWLogo
