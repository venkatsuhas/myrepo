import React from 'react'
import PropTypes from 'prop-types'
import Button from '@components/Button'
import dynamic from 'next/dynamic'
const Icon = dynamic(() => import('@components/Icon'))

const RelatedArticle = ({ relatedArticles }) => {
    return (
        <div className='adp'>
            {relatedArticles && relatedArticles.length > 0 && (
                <div className='mb-90 px-20 lg:px-0'>
                    <h2>関連記事</h2>
                    {relatedArticles.map((ele, index) => (
                        <Button key={index} href={ele.href}>
                            <div className='flex items-baseline'>
                                <Icon name='ArticleArrow' className='max-w-10' />
                                <p>{ele.name}</p>
                            </div>
                        </Button>
                    ))}
                </div>
            )}
        </div>
    )
}

RelatedArticle.propTypes = {
    relatedArticles: PropTypes.array,
}

export default RelatedArticle
