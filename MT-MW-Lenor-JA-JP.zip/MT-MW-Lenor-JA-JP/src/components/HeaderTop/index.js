import React, { useState, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'

const IconButton = dynamic(() => import('@components/IconButton'))
const CountrySelector = dynamic(() => import('@components/CountrySelector'))
const Button = dynamic(() => import('@components/Button'))
const Icon = dynamic(() => import('@components/Icon'))

const HeaderTop = ({
    locale,
    brandList,
    countryLanguage,
    inquiry,
    pleaseSelectLocation,
}) => {
    const [modalOpen, setModalOpen] = useState(false)

    const openModal = useCallback(() => {
        setModalOpen(true)
    }, [])

    const closeModal = useCallback(() => {
        setModalOpen(false)
    }, [])
    return (
        <div className='flex h-38 justify-between'>
            <div className='flex'>
                <div className='pt-12 pb-10 pl-5 pr-10 text-white text-12'>
                    {brandList}
                </div>
                <IconButton
                    variant='headerIcons'
                    gaClass='inline-block flex min-w-45 pt-5 mx-20'
                />
            </div>
            <div className='flex min-w-50p right-0'>
                <Button href={`${inquiry.url}`}>
                    <div className='pt-10 text-white text-13 pr-25'>{inquiry.title}</div>
                </Button>
                <div className='flex'>
                    <Button
                        gaClass='text-white text-13 pt-10 hover:underline items-baseline'
                        gaLabel={countryLanguage}
                        className='flex'
                        onClick={openModal}
                    >
                        {countryLanguage}
                        <span>
                            <Icon
                                className={'transform rotate-0 pl-5'}
                                name='ArrowMainWhiteNav'
                            />
                        </span>
                        {/* <Icon
                            className='w-10 h-auto mt-6 ml-5 fill-current text-lightGreyBlue '
                            name='DropDownArrow'
                        />
                        <span className='w-8 h-6 ml-5 bg-no-repeat mt-7 display-inline bg-caret'>
                            {' '}
                        </span> */}
                    </Button>
                </div>
            </div>
            {modalOpen && (
                <CountrySelector
                    locale={locale}
                    isOpen={modalOpen}
                    closeModal={closeModal}
                    pleaseSelectLocation={pleaseSelectLocation}
                />
            )}
        </div>
    )
}

HeaderTop.propTypes = {
    locale: PropTypes.string,
    menuSlots: PropTypes.array,
    brandList: PropTypes.string,
    countryLanguage: PropTypes.string,
    inquiry: PropTypes.object,
    pleaseSelectLocation: PropTypes.string,
}

HeaderTop.defaultProps = {
    locale: '',
    menuSlots: [],
    brandList: '',
    countryLanguage: '',
    inquiry: {},
    pleaseSelectLocation: '',
}

export default memo(HeaderTop)
