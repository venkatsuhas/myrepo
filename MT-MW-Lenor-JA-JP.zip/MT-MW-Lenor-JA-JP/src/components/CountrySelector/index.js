import React, { useState, useRef, useEffect, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { siteCountries } from '@constants'

const Icon = dynamic(() => import('@components/Icon'))
const Button = dynamic(() => import('@components/Button'))

const CountrySelector = ({ locale, closeModal, pleaseSelectLocation }) => {
    const [outsideClick, setOutSideClick] = useState(false)
    const popUpNode = useRef()

    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (
                popUpNode.current &&
        (popUpNode.current === event.target ||
          popUpNode.current.contains(event.target))
            ) {
                setOutSideClick(false)
            } else {
                setOutSideClick(true)
            }
        }

        document.addEventListener('mousedown', handleOutsideClick)
        return () => {
            document.removeEventListener('mousedown', handleOutsideClick)
        }
    }, [])

    useEffect(() => {
        if (outsideClick) {
            closeModal()
            setOutSideClick(false)
        }
    }, [outsideClick])

    useEffect(() => {
        document.body.classList.add('overflow-hidden')
        return () => {
            document.body.classList.remove('overflow-hidden')
        }
    }, [])

    return (
        <div className='fixed inset-0 z-50 flex items-center overflow-y-auto CountrySelector-container backdrop-opacity-10 bg-black/90'>
            <div
                className='fixed top-0 bottom-0 left-0 top-auto left-30p w-full px-20 overflow-hidden text-primaryblue bg-white CountrySelector-wrapper mdl:w-40p mdl:left-25p mdl:top-30p mdl:bottom-auto py-25 mdl:py-20 rounded-20 border-20 border-lightgray text-20'
                ref={popUpNode}
            >
                <div className='float-right closeDiv'>
                    <Button gaClass='event_button_click' onClick={closeModal}>
                        <Icon className='closeIcon' name='Close' />
                    </Button>
                </div>
                <div className='pt-40 bodyDiv mdl:pt-0'>
                    <div className='mb-40 text-left font-ChaletNewYork font-bold titleDiv text-20 text-primary leading-24'>
                        {pleaseSelectLocation}
                    </div>
                    <div className='w-full countryDiv mdl:flex mdl:justify-evenly mb-50 mdl:mb-20'>
                        {siteCountries.items.map((country, index) => {
                            return (
                                <div
                                    key={index}
                                    className='eachCountryDiv mb-30 mdl:mb-0 mdl:w-33p'
                                >
                                    {country.columns.map((column, columnIndex) => (
                                        <div className='' key={columnIndex}>
                                            <div className='text-left countryName text-14 font-bold text-primaryblue leading-26 text-primary font-ChaletNewYork'>
                                                {column.name}
                                            </div>
                                            {column.items.map((item, itemIndex) => (
                                                <Button
                                                    gaClass='event_button_click'
                                                    onClick={closeModal}
                                                    href={item.url}
                                                    key={itemIndex}
                                                >
                                                    <Icon
                                                        className='mt-5 countryIcon'
                                                        name={
                                                            locale.toLowerCase() === item.locale
                                                                ? 'LocationDark'
                                                                : 'LocationLight'
                                                        }
                                                    />
                                                    <div className='ml-8 countryNameDiv'>
                                                        <div className='text-left countryName text-14 font-ChaletLondon leading-26 text-primary'>
                                                            {`${item.name} ${
                                item.lang ? ' | ' + item.lang : ''
                              }`}
                                                        </div>
                                                    </div>
                                                </Button>
                                            ))}
                                        </div>
                                    ))}
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        </div>
    )
}
CountrySelector.propTypes = {
    locale: PropTypes.string,
    closeModal: PropTypes.func,
    pleaseSelectLocation: PropTypes.string,
}

export default memo(CountrySelector)
