module.exports = {
    default: {
        wrapper: 'flex cursor-pointer pl-20',
        checkbox:
      'pl-10 border cursor-pointer border-accentBorder rounded-3 text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0',
        label:
      'pl-10  font-ChaletParis text-12 leading-24 mdl:leading-30  text-primaryblue -mt-8',
    },
    ArticleListingPage: {
        wrapper: 'flex flex-wrap items-center justify-start cursor-pointer mb-0',
        checkbox:
      'pl-10 border cursor-pointer border-darkgray rounded-3 w-15 h-15 text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0',
        label:
      'pl-10 font-AvenirLTMedium text-10 leading-1 mdl:leading-1 text-darkgray',
    },
}
