import React, { useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { locales } from '@constants'

const Typography = dynamic(() => import('@components/Typography'))
const Image = dynamic(() => import('@components/Image'))

const ErrorPage = ({ pageData: { card } }) => {
  return (
    <div>
      <div className="pt-216 pb-221 mdl:pt-190 mdl:pb-210 text-center w-full max-w-647 mx-auto px-20 mdl:px-0">
        {card && card.title && (
          <Typography
            content={card.title}
            className="font-neutrafaceBold text-50 leading-50 mdl:text-80 mdl:leading-80 text-secondary mb-20 opacity-60"
          />
        )}
        {card && card.subTitle && (
          <Typography
            content={card.subTitle}
            className="font-neutrafaceBook text-24 leading-30 mdl:text-28 mdl:leading-34 text-secondary mb-30 mdl:mb-35"
            br_allowed={false}
          />
        )}
        {card.image && (
          <Image desktopImage={card.image} alt={card.image.title} />
        )}
      </div>
    </div>
  )
}

ErrorPage.propTypes = {
  [locales.japanese]: PropTypes.object,
}

export default ErrorPage
