import React, { useEffect, useState, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'
import { productListingPage, pageTypes, allIcons } from '@constants'
import useProductListingPageReducer, {
  ACTIONS,
} from '@containers/ProductListingPage/ProductLisitingPage.reducer'
import {
  getRecentlyViewed,
  setRecentlyViewed,
} from '@helpers/recentlyViewed.helper'
import Icons from '@icons'
import Breadcrumb from '@components/Breadcrumb'

const Icon = dynamic(() => import('@components/Icon'))
const Image = dynamic(() => import('@components/Image'))
const Button = dynamic(() => import('@components/Button'))
const DropDown = dynamic(() => import('@components/DropDown'))
const ProductCard = dynamic(() => import('@components/Card/ProductCard'))
const FeatureCard = dynamic(() => import('@components/Card/FeatureCard'))
const Carousel = dynamic(() => import('@components/Carousel/HomePageCarousel'))
const FilterLargeScreen = dynamic(() =>
  import('@components/Filters/LargeScreen'),
)
const FilterSmallScreen = dynamic(() =>
  import('@components/Filters/SmallScreen'),
)
const MobileSmallScreen = dynamic(() =>
  import('@components/Filters/MobileSmallScreen'),
)
const RecentlyViewed = dynamic(() => import('@components/RecentlyViewed'))

const ProductListingPage = ({
  pageData: {
    locale,
    bannerImage,
    title,
    subTitle,
    mainCategories,
    secondMainCategories,
    filters,
    products,
    discoverCardsCollection,
    promoCardDetails,
    type,
    pageType,
    bannerCollection,
    breadcrumb,
  },
}) => {
  const labels = productListingPage
  const router = useRouter()
  const [isScrollUp, setScrollUp] = useState(false)
  const { state, dispatch } = useProductListingPageReducer()
  const [recentItems, setRecentItems] = useState([])
  const [view, setView] = useState(true)
  const [listIconActive, setListIconActive] = useState(false)
  const [girdIconActive, setGirdIconActive] = useState(false)

  useEffect(() => {
    setRecentItems(getRecentlyViewed())
    dispatch({ type: ACTIONS.SET_SORT_BY, value: labels.sortBy.items[0].name })
  }, [])

  useEffect(() => {
    dispatch({ type: ACTIONS.SET_ALL_FILTERS, value: filters })
    dispatch({ type: ACTIONS.SET_PRODUCTS, value: products })
    dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })
  }, [router.asPath])

  const productListingSmallPage = () => {
    return (
      <div className="px-20 smart-area-cls mt-10 mdl:mt-50">
        {/* <div className='flex flex-col-reverse flex-wrap px-20'>
                    {
                        mainCategories?.map((item, index) => (
                            <Button
                                key={index}
                                href={item?.url}
                                className='block w-full h-65'
                            >
                                <div className='flex justify-between'>
                                    <p className='uppercase font-AvenirLTLight text-25 text-accent'>
                                        {item?.title}
                                    </p>
                                    <Icon name={'MenuFooterIcon'} className='h-18 mt-9' />
                                </div>
                            </Button>
                        ))}
                </div> */}
        <div>
          <div>
            <p className="text-left text-darkgray text-14 mdl:text-left font-ChaletLondon lowercase text-primaryblue mdl:mt-150">
              {labels?.viewingCount?.replace(
                '$count',
                state?.filteredProducts?.length,
              )}
            </p>
            <MobileSmallScreen
              locale={locale}
              variant={pageTypes.plpPage}
              filters={state.filterData}
              toggleFilter={(value) => {
                dispatch({
                  type: ACTIONS.TOGGLE_ACTIVE_FILTER,
                  value,
                })
              }}
              activeFilters={state.activeFilters}
              resetFilter={() =>
                dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })
              }
              handleDropDown={(value) =>
                dispatch({ type: ACTIONS.SET_SORT_BY, value })
              }
              girdIconActive={girdIconActive}
              listIconActive={listIconActive}
              setListIconActive={setListIconActive}
              setGirdIconActive={setGirdIconActive}
              setView={setView}
            />
          </div>
        </div>
      </div>
    )
  }

  useEffect(() => {
    if (!state.showFilter) {
      document.body.classList.remove('overflow-hidden')
      document.body.classList.remove('mdl:overflow-auto')
    } else {
      document.body.classList.add('overflow-hidden')
      document.body.classList.add('mdl:overflow-auto')
    }
    return () => {
      document.body.classList.remove('overflow-hidden')
      document.body.classList.remove('mdl:overflow-auto')
    }
  }, [state.showFilter])
  const handleScroll = useCallback(() => {
    if (
      document.getElementById('navBar') &&
      document.getElementById('navBar').className
    ) {
      const headerClassName = document
        .getElementById('navBar')
        .className.split(' ')
      const isHeaderSticky =
        headerClassName[headerClassName.length - 1] === 'header-sticky'
          ? true
          : false
      setScrollUp(isHeaderSticky)
    }
  }, [])

  useEffect(() => {
    if (window) {
      window.addEventListener('scroll', handleScroll)
    }
    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])
  const handleDropDown = useCallback(
    (value) => dispatch({ type: ACTIONS.SET_SORT_BY, value }),
    [],
  )
  const renderLink = (href, linkText, iconName) => (
    <span className="linkText">
      {href && linkText && (
        <Button
          gaClass="event_button_click"
          gaLabel={linkText}
          href={href}
          className={'text-white text-20 font-AvenirLTLight'}
        >
          {linkText}
          {iconName && (
            <span className={''}>
              <Icon name={iconName} />
            </span>
          )}
        </Button>
      )}
    </span>
  )
  return (
    <div className="mdl:relative mdl:top-0 w-full mdl:w-940 mx-auto">
      <div className="breadcrumb h-26 bg-bgblue mdl:bg-none">
        {breadcrumb && breadcrumb.length > 0 && (
          <Breadcrumb breadcrumb={breadcrumb} variant="pdpPage" />
        )}
      </div>
      <div className="mdl:hidden">
        {title && (
          <h1 className="w-full font-ChaletLondon text-18 text-primaryblue uppercase font-bold ">
            {title}
          </h1>
        )}
      </div>
      {router.asPath !== productListingPage.plpBasePath && (
        <div className="w-full mdl:flex  mdl:relative justify-around">
          {bannerCollection?.length > 0 && (
            <Carousel carouselData={bannerCollection} variant="productCard" />
          )}

          {bannerImage && bannerImage.desktopImage && (
            <Image
              key={bannerImage.desktopImage.sys}
              desktopClassName="plp-banner-cls"
              smartphoneClassName="hidden"
              wrapperClassName="w-full min-h-155"
              desktopImage={bannerImage.desktopImage}
              smartphoneImage={bannerImage.smartphoneImage}
              alt={bannerImage.desktopImage?.altText}
            />
          )}
          <div className="w-full hidden mdl:block">
            {subTitle && (
              <p className="w-full mt-105 ml-15 font-hiraginoGothicPro text-30 text-white leading-37 text-left">
                {subTitle}
              </p>
            )}
          </div>
        </div>
      )}
      {router.asPath !== productListingPage.plpBasePath && (
        <div className="hidden mdl:block listing">
          {title && (
            <h1 className="w-full font-hiraginoGothicPro text-24 text-primaryblue">
              {title}
            </h1>
          )}
        </div>
      )}
      <div className="smartblock mdl:hidden">{productListingSmallPage()}</div>

      <div className="mx-auto w-full flex flex-row flex-wrap justify-center items-start plp-page">
        <div
          className={`w-full mdl:w-3/12 text-left mdl:pr-15 lg:pr-60${
            state.showFilter
              ? ' block mdl:hidden mdl:animate-toLeft'
              : ' hidden mdl:block animate-toLeft mdl:animate-none'
          }`}
        >
          <FilterLargeScreen
            type={type}
            locale={locale}
            variant={pageType}
            mainCategories={mainCategories}
            secondMainCategories={secondMainCategories}
            filters={state.filterData}
            toggleFilter={(value) =>
              dispatch({ type: ACTIONS.TOGGLE_ACTIVE_FILTER, value })
            }
            activeFilters={state.activeFilters}
            resetFilter={() => dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })}
          />

          <div
            className={`${
              !state.showFilter
                ? 'animate-toLeft mdl:hidden'
                : 'block px-20 bg-white mdl:hidden fixed z-100 w-full top-0 left-0 h-screen overflow-hidden animate-fromLeft'
            }`}
          >
            <FilterSmallScreen
              locale={locale}
              variant={pageType}
              filters={state.filterData}
              toggleFilter={(value) =>
                dispatch({ type: ACTIONS.TOGGLE_ACTIVE_FILTER, value })
              }
              activeFilters={state.activeFilters}
              resetFilter={() =>
                dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })
              }
              handleDropDown={(value) =>
                dispatch({ type: ACTIONS.SET_SORT_BY, value })
              }
              sortBy={state.sortBy}
              toggleFilterIconState={() =>
                dispatch({ type: ACTIONS.TOGGLE_FILTER_BUTTON })
              }
            />
          </div>
        </div>
        <div className="w-full mdl:w-9/12 filter">
          <div
            className={`hidden mdl:block sticky mdl:static top-0 z-20 bg-white pt-30 ${
              isScrollUp ? 'scrollUp' : 'scrollDown'
            }`}
          >
            {state.activeFilters && state.activeFilters.length > 0 && (
              <div className="mdl:flex flex-row flex-wrap items-center justify-start w-full pl-6 mr-10 hidden">
                <span className="inline-flex pr-10 h-35  font-ChaletLondon text-13 text-primaryblue ">
                  {labels.viewing}
                </span>

                {state.activeFilters.map((filter, index) => (
                  <div
                    key={`${filter}-${index}`}
                    className="flex flex-row items-center justify-between py-2 mb-10 mr-10  px-15 border-1 border-lightgray border-solid rounded-5"
                  >
                    <label className="text-primaryblue text-13 font-ChaletLondon pr-15">
                      {filter}
                    </label>
                    <Button
                      gaClass="event_button_click h-9 w-9"
                      onClick={() =>
                        dispatch({
                          type: ACTIONS.TOGGLE_ACTIVE_FILTER,
                          value: filter,
                        })
                      }
                    >
                      <Icon
                        // className="w-10 h-10 stroke-current stroke-2 text-secondary ml-15"
                        name="FilterCloseIcon"
                      />
                    </Button>
                  </div>
                ))}
                {
                  <div className="flex flex-row items-center justify-between py-2 mb-10 mr-10  px-15 ">
                    <label className="text-primaryblue text-13 font-ChaletLondon pr-15">
                      {labels.clearAll}
                    </label>
                    <Button
                      gaClass="event_button_click h-9 w-9"
                      onClick={() =>
                        dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })
                      }
                    >
                      <Icon
                        // className="w-10 h-10 stroke-current stroke-2 text-secondary ml-15"
                        name="FilterCloseIcon"
                      />
                    </Button>
                  </div>
                }
              </div>
            )}
            {router.asPath === productListingPage.plpBasePath && (
              <h1>全ての製品</h1>
            )}
            <div
              className={`w-full flex justify-between flex-row items-start mdl:pb-20 px-5 lg:px-0 mb-30`}
            >
              <p className="w-1/2 mdl:w-5/12 lg:w-6/12 font-AvenirLTLight text-14 leading-30 text-darkgray">
                {pageType === pageTypes.plpPage
                  ? `${labels.show} ${state.filteredProducts.length} ${labels.products}`
                  : `Showing 0 products`}
              </p>
              <div className="w-1/2 mdl:w-7/12 lg:w-6/12 flex flex-wrap flex-row justify-end items-start">
                <p className="pt-5 pl-5 font-AvenirLTLight text-14 leading-30 text-darkgray">
                  <Button
                    gaClass="event_button_click"
                    onClick={() => {
                      setGirdIconActive(true)
                      setListIconActive(false)
                      setView(true)
                    }}
                  >
                    <Icon
                      name={girdIconActive ? 'girdViewIconOn' : 'girdViewIcon'}
                    />
                  </Button>
                </p>
                <p className="pt-5 pl-5 font-AvenirLTLight text-14 leading-30 text-darkgray">
                  <Button
                    gaClass="event_button_click"
                    onClick={() => {
                      setListIconActive(true)
                      setGirdIconActive(false)
                      setView(false)
                    }}
                  >
                    <Icon
                      name={listIconActive ? 'listViewIconOn' : 'listViewIcon'}
                    />
                  </Button>
                </p>

                <div className="w-full mdl:w-max block mdl:flex mdl:justify-end mdl:items-start mdl:flex-row">
                  <p className="font-AvenirLTLight text-12 leading-30 text-left text-secondary pr-10 pl-10">
                    {labels.sortBy.title}
                  </p>
                  <DropDown
                    onSelect={(value) =>
                      dispatch({ type: ACTIONS.SET_SORT_BY, value })
                    }
                    variant={pageTypes.plpPage}
                    defaultValue={labels.sortBy.items[0].name}
                    options={labels.sortBy.items.map((item) => ({
                      title: item.name,
                      value: item.value,
                    }))}
                    resetOnPathChange={true}
                  />
                </div>
              </div>
            </div>
          </div>
          {state.activeFilters && state.activeFilters.length > 0 && (
            <div className="mdl:hidden w-full flex flex-row flex-wrap justify-start items-center px-20">
              {state.activeFilters.map((filter, index) => (
                <div
                  key={`${filter}-${index}`}
                  className="bg-lightGreyBlue rounded-full py-9 px-15 mr-10 mb-10 flex flex-row justify-between items-center"
                >
                  <label className="font-neutrafaceBook text-18 leading-22 text-primary">
                    {filter}
                  </label>
                  <Button
                    gaClass="event_button_click"
                    onClick={() =>
                      dispatch({
                        type: ACTIONS.TOGGLE_ACTIVE_FILTER,
                        value: filter,
                      })
                    }
                  >
                    <Icon
                      className="w-10 h-10 stroke-current stroke-2 text-secondary ml-15"
                      name="Close"
                    />
                  </Button>
                </div>
              ))}
            </div>
          )}
          <div
            className={
              view
                ? 'w-full flex flex-wrap flex-row justify-start items-start h-full lg:px-0'
                : 'listingView'
            }
          >
            {state.filteredProducts.length > 0 &&
              state.filteredProducts
                .slice(0, state.productsToDisplay)
                .map((product, index) => (
                  <div
                    key={`${product.sys}-${index}`}
                    className="w-1/2 mdl:w-4/12 mb-30 mdl:mb-65 h-full flex justify-center items-start"
                  >
                    <ProductCard
                      locale={locale}
                      {...product}
                      variant={
                        view ? pageTypes?.plpPage : pageTypes?.plpPageView
                      }
                    />
                  </div>
                ))}
            {promoCardDetails && view && (
              <div className="relative w-1/2 mdl:w-25p">
                <>
                  {promoCardDetails.imageset && (
                    <Image
                      //   desktopClassName={style.imgContainerDt}
                      //   smartphoneClassName={style.imgContainerSp}
                      //   wrapperClassName={style.imgWrapper}
                      desktopImage={promoCardDetails?.imageset?.desktopImage}
                      smartphoneImage={
                        promoCardDetails?.imageset?.smartphoneImage
                      }
                      alt={promoCardDetails?.imageset?.altText}
                    />
                  )}
                  <div className="absolute top-20 left-20 pr-0 pl-0 mdl:pr-10p mdl:pl-5p">
                    <div className="text-white">
                      {renderLink(
                        promoCardDetails?.titleHref,
                        promoCardDetails?.titleLinkText,
                      )}
                      {renderLink(
                        promoCardDetails?.subTitleHref,
                        promoCardDetails?.subTitleLinkText,
                      )}
                      <div className="float-right">
                        <Icon
                          className="pt-9 pr-50 mdl:pr-10"
                          name="RightArrowHomeIconWhite"
                        />
                      </div>
                    </div>
                  </div>
                </>
              </div>
            )}
          </div>

          {state.productsToDisplay < state.filteredProducts.length && (
            <Button
              gaClass="event_button_click"
              onClick={() => dispatch({ type: ACTIONS.LOAD_MORE })}
              className="flex flex-wrap flex-col mdl:flex-row justify-start items-center mx-auto"
            >
              <p className="font-neutrafaceDemi text-20 leading-30 text-gradientDarkBlue mb-20 underline cursor-pointer">
                {labels.loadMore}
              </p>
            </Button>
          )}
          <div className="block mdl:flex mt-40 mdl:mt-0 px-20">
            {view &&
              discoverCardsCollection &&
              discoverCardsCollection.map((discoverCard) => (
                <>
                  <FeatureCard
                    {...discoverCard}
                    variant="Productlisting"
                    iconName="RightArrowHomeIconWhite"
                  />
                </>
              ))}
          </div>
        </div>
      </div>
      {recentItems && recentItems.length > 0 && (
        <RecentlyViewed items={recentItems} />
      )}
      <div>
        {router.asPath !== productListingPage.plpBasePath ? (
          <Icon
            name={allIcons?.logoWithBorder}
            alt={allIcons?.logoWithBorder}
            className={''}
          />
        ) : (
          <Icon
            name={allIcons?.plpFooterLogo}
            alt={allIcons?.plpFooterLogo}
            className={''}
          />
        )}
      </div>
    </div>
  )
}

ProductListingPage.propTypes = {
  pageData: PropTypes.shape({
    locale: PropTypes.string.isRequired,
    bannerImage: PropTypes.object.isRequired,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    mainCategories: PropTypes.array.isRequired,
    secondMainCategories: PropTypes.array.isRequired,
    type: PropTypes.string.isRequired,
    filters: PropTypes.array.isRequired,
    pageType: PropTypes.string,
    promoCardDetails: PropTypes.object,
    products: PropTypes.array,
    discoverCardsCollection: PropTypes.array,
    bannerCollection: PropTypes.array,
  }),
}

export default memo(ProductListingPage)
