import React, { memo, useState, useCallback, useEffect, useRef } from 'react'
import PropTypes from 'prop-types'
import Magnifier from '@components/Magnifier/Magnifier'
import ProductImageSlider from '@components/ProductDetail/ProductImageSlider'
import DropDown from '@components/DropDown'
import dynamic from 'next/dynamic'
// import { useRouter } from 'next/router'
import { allIcons, pageTypes, productPage } from '@constants'
import Typography from '@components/Typography'
import Icon from '@components/Icon'
import ArticleCard from '@components/Card/ArticleCard'
import Accordion from '@components/Accordion'
const Carousel = dynamic(() => import('@components/Carousel/HomePageCarousel'))
// import { generateId } from '@helpers/generateId.helper'
import CommonDialog from '@components/CommonDialog'
import { setRecentlyViewed } from '@helpers/recentlyViewed.helper'
import Breadcrumb from '@components/Breadcrumb'

// const Accordion = dynamic(() => import('@components/Accordion'))
const Button = dynamic(() => import('@components/Button'))
// const BuyNowButton = dynamic(() => import('@components/Button/BuyNowButton'))
// const Carousel = dynamic(() => import('@components/Carousel'))
const ProductCard = dynamic(() => import('@components/Card/ProductCard'))
// const ProductGallery = dynamic(() => import('@components/ProductGallery'))
// const Rating = dynamic(() => import('@components/Rating'))
// const SmartLabel = dynamic(() => import('@components/SmartLabel'))
// const Typography = dynamic(() => import('@components/Typography'))
// const Image = dynamic(() => import('@components/Image'))

let tabStates = ['Product details', 'faq', 'related page']
const getVariantData = ({
  productVariants,
  hasMainVariant,
  hasSubVariant,
  mainIndex,
  subIndex,
  productDetails,
}) => {
  if (hasMainVariant) {
    if (
      productVariants[mainIndex].subVariants &&
      productVariants[mainIndex].subVariants.length > 0
    )
      return productVariants[mainIndex].subVariants[subIndex]
    else return productVariants[mainIndex]
  } else if (hasSubVariant) {
    return productVariants[subIndex]
  } else {
    return productDetails
  }
}
const ProductPage = ({
  pageData: {
    name,
    description,
    locale,
    minPrice,
    productImages,
    relatedArticles,
    relatedProducts,
    productDetails,
    cardsCollection,
    faq,
    videos,
    cardData,
    breadcrumb,
  },
}) => {
  const [openVideoDialog, setOpenVideoDialog] = useState(false)
  if (videos) {
    tabStates = ['Product details', 'Movies', 'faq', 'related page']
  }
  const renderVideoDetails = (productDetails) => {
    return (
      productDetails && (
        <>
          <Typography
            content={productDetails}
            onClick={() => {
              setOpenVideoDialog(!openVideoDialog)
            }}
            className="mb-20 cardDesc text-16 leading-26 font-AvenirLTLight text-secondary"
          />
          {openVideoDialog && (
            <CommonDialog
              variant="videoCardView"
              locale={locale}
              cardsCollection={cardsCollection}
              closeModal={() => {
                setOpenVideoDialog(!openVideoDialog)
              }}
            />
          )}
        </>
      )
    )
  }
  const renderCardDetails = (productDetails) => {
    return (
      productDetails && (
        <Typography
          content={productDetails}
          className="mt-20 mb-20 cardDesc text-14 font-ChaletParis text-primaryblue px-15"
        />
      )
    )
  }
  const [openAccordion, setOpenAccordion] = useState()
  const [activeTab, setActiveTab] = useState(tabStates[0])
  // const [capacity, setCapacity] = useState('')

  // const [selectedVariant, setSelectedVariant] = useState({
  //   mainIndex: 0,
  //   subIndex: 0,
  //   data: getVariantData({
  //     productVariants,
  //     hasMainVariant,
  //     hasSubVariant,
  //     mainIndex: 0,
  //     subIndex: 0,
  //     productDetails: { productImages, smartLabelId, buyNowId },
  //   }),
  // })
  const labels = productPage || {}
  // const router = useRouter()
  // const buyNowRef = useRef(null)
  // useEffect(() => {
  //   window?.dataLayer?.push({
  //     event: 'customEvent',
  //     GAeventCategory: 'event_informational_action',
  //     GAeventAction: 'event_view_product_detail_page',
  //     GAeventLabel: name,
  //     GAeventValue: name,
  //     GAeventNonInteraction: false,
  //   })

  //   setSelectedVariant({
  //     mainIndex: 0,
  //     subIndex: 0,
  //     data: getVariantData({
  //       productVariants,
  //       hasMainVariant,
  //       hasSubVariant,
  //       mainIndex: 0,
  //       subIndex: 0,
  //       productDetails: { productImages, smartLabelId, buyNowId },
  //     }),
  //   })
  // }, [router.asPath])

  // const handleScroll = useCallback(() => {}, [])

  // useEffect(() => {
  //   document.addEventListener('scroll', handleScroll, false)
  //   return () => {
  //     document.removeEventListener('scroll', handleScroll, false)
  //   }
  // }, [])

  // useEffect(handleScroll, [openAccordion, handleScroll])

  const accordionClick = useCallback((value) => {
    setOpenAccordion((prevState) => {
      if (prevState === value) {
        return null
      } else {
        if (document.querySelector('#accordion-wrapper')) {
          document
            .querySelector('#accordion-wrapper')
            .scrollIntoView({ behavior: 'smooth' })
        }
        return value
      }
    })
  }, [])
  const displayArticleCards = (relatedArticles) => {
    return (
      <div>
        <div className="flex flex-wrap mt-20">
          <div className="flex-1 pl-20">
            {relatedArticles &&
              relatedArticles.length > 0 &&
              relatedArticles.map((article) => {
                return (
                  <>
                    <ArticleCard
                      key={article.sys}
                      locale={locale}
                      {...article}
                      variant="pdpArticlesCard"
                    />
                  </>
                )
              })}
          </div>
        </div>
      </div>
    )
  }
  useEffect(() => {
    // setRecentItems(getRecentlyViewed())
    setRecentlyViewed({ ...cardData, minPrice })
    // document.addEventListener('scroll', handleScroll, false)
    // return () => {
    //   document.removeEventListener('scroll', handleScroll, false)
    // }
  }, [])
  return (
    <div className="mx-auto mdl:w-940">
      <div className="breadcrumb h-26 bg-bgblue mdl:bg-none">
        {breadcrumb && breadcrumb.length > 0 && (
          <Breadcrumb breadcrumb={breadcrumb} variant="pdpPage" />
        )}
      </div>
      <div className="smartblock mdl:hidden">
        <Carousel
          carouselData={productImages?.[0]?.productImages.map((ele) => ({
            image: ele,
          }))}
          variant="homeGallery"
        />
      </div>
      <div className="justify-between mt-10 mdl:flex pdpdttop-block-cls">
        <div className="hidden mdl:block w-485">
          {productImages?.[0]?.productImages && (
            <ProductImageSlider
              productShortName={''}
              media={{ items: productImages?.[0]?.productImages }}
            />
          )}
        </div>
        <div className="mx-20 w-410 my-15">
          <h1 className="font-semibold text-primaryblue mdl:text-white font-ChaletLondon mdl:font-ChaletParisorg text-23 leading-37">
            {name}
          </h1>
          <p className="text-paleskyblue mdl:text-white font-ChaletLondon mdl:font-ChaletParis text-14 leading-22">
            {description}
          </p>
          {/* <p className="hidden mt-20 mdl:block">
            <DropDown
              onSelect={() => {}}
              variant={pageTypes.pdpPage}
              defaultValue={labels.sortBy.items[0].name}
              options={labels.sortBy.items.map((item) => ({
                title: item.name,
                value: item.value,
              }))}
              resetOnPathChange={true}
            />
          </p> */}
        </div>
      </div>

      {/* <div className="smartblock mdl:hidden">
        <p className="px-20 font-bold text-primaryblue font-ChaletLondon">
          Capacity
        </p>
        {labels.sortBy.items.map((item, index) => (
          <button
            href={'#capacity' + index}
            onClick={() => setCapacity(item)}
            className={
              item === capacity
                ? 'usagebutton bg-menuhover font-AvenirLTLight text-12 leading-40 mdl:text-25 mdl:leading-60 text-white mdl:mb-30  px-20  mx-10 border-r border-lightestBorder ml-20'
                : 'usagebutton bg-bggray font-AvenirLTLight text-12 leading-40 mdl:text-25 mdl:leading-60 text-darkgray mdl:mb-30  px-20 mx-10 border-r border-lightestBorder ml-20'
            }
          >
            {item.name}
          </button>
        ))}
      </div> */}

      <div className="flex flex-col flex-wrap items-start justify-center w-full mx-auto mt-20 md:flex-row lg:w-lg mxl:w-mxl xl:w-xl lg:px-0">
        <div className="flex flex-col flex-wrap items-start justify-center w-full mx-auto mdl:w-full md:flex-row ">
          <div className="w-full mdl:w-75p md:pl-10 mdl:pl-0">
            <div
              className="flex-col hidden w-full border-r mt-15 flex-flex-wrap border-lightestBorder mdl:block mdl:min-h-400"
              id="accordion-wrapper"
            >
              <div className="w-full mx-auto lg:w-lg mxl:w-mxl xl:w-xl">
                <div className="flex border-solid pdpbutton border-l-1 border-bgblue">
                  {tabStates.map((tabState, index) => (
                    <button
                      href={'#panel' + index}
                      onClick={() => setActiveTab(tabState)}
                      className={
                        tabState === activeTab
                          ? 'usagebutton font-ChaletParisorg text-19  text-primaryblue   lowercase px-20 mr-2'
                          : 'usagebutton bg-bgblue font-ChaletParisorg text-primaryblue  text-19 lowercase px-20 py-10 mr-2'
                      }
                    >
                      {tabState}
                    </button>
                  ))}
                </div>
              </div>
              {tabStates[0] === activeTab && renderCardDetails(productDetails)}
              {tabStates[1] === activeTab && renderVideoDetails(videos)}
              {tabStates[2] === activeTab && renderCardDetails(faq)}
              {tabStates[3] === activeTab &&
                displayArticleCards(relatedArticles)}
            </div>
          </div>
          <div className="smartblock mdl:hidden">
            <div
              className="flex-col w-full flex-flex-wrap mt-31"
              id="accordion-wrapper"
            >
              {productDetails && (
                <Accordion
                  open={openAccordion === tabStates[0]}
                  title={tabStates[0]}
                  toggleOpen={() => {
                    accordionClick(tabStates[0])
                  }}
                  variant="pdpPage"
                >
                  {renderCardDetails(productDetails)}
                </Accordion>
              )}
              {cardsCollection && (
                <Accordion
                  open={openAccordion === tabStates[1]}
                  title={tabStates[1]}
                  toggleOpen={() => {
                    accordionClick(tabStates[1])
                  }}
                  variant="pdpPage"
                >
                  {renderVideoDetails(videos)}
                </Accordion>
              )}
              {faq && (
                <Accordion
                  open={openAccordion === tabStates[2]}
                  title={tabStates[2]}
                  toggleOpen={() => {
                    accordionClick(tabStates[2])
                  }}
                  variant="pdpPage"
                >
                  {renderCardDetails(faq)}
                </Accordion>
              )}
              {relatedArticles && (
                <Accordion
                  open={openAccordion === tabStates[3]}
                  title={tabStates[3]}
                  toggleOpen={() => {
                    accordionClick(tabStates[3])
                  }}
                  variant="pdpPage"
                >
                  {displayArticleCards(relatedArticles)}
                </Accordion>
              )}
            </div>
          </div>
          {relatedProducts && relatedProducts.length > 0 && (
            <div className="mb-40 mdl:w-25p">
              <h2 className="items-center table w-full pb-0 mx-auto mt-20 mb-0 text-center mdl:pt-16 mdl:mt-0 mdl:px-20 font-ChaletParis1 text-24 text-primaryblue bg-bgblue mdl:bg-white">
                {labels.relatedProductsTitle}
              </h2>
              <div className="flex flex-wrap w-full px-20 mx-auto mdl:py-0">
                {relatedProducts?.map((product) => (
                  <ProductCard
                    key={product.sys}
                    locale={locale}
                    {...product}
                    variant="pdpRecommendedCard"
                    minPrice={minPrice}
                  />
                ))}
              </div>
            </div>
          )}
          <div>
            <Icon
              name={allIcons?.logoWithBorder}
              alt={allIcons?.logoWithBorder}
              className={''}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

// ProductPage.propTypes = {
//   pageData: PropTypes.shape({
//     locale: PropTypes.string.isRequired,
//     name: PropTypes.string.isRequired,
//     mainCategory: PropTypes.string.isRequired,
//     minPrice: PropTypes.number.isRequired,
//     productImages: PropTypes.arrayOf(
//       PropTypes.shape({
//         sys: PropTypes.string,
//         url: PropTypes.string,
//         altText: PropTypes.string,
//         height: PropTypes.number,
//         width: PropTypes.number,
//       }),
//     ),
//     smartLabelId: PropTypes.string,
//     buyNowId: PropTypes.string,
//     relatedProducts: PropTypes.array,
//     heroImage: PropTypes.shape({
//       sys: PropTypes.string,
//       url: PropTypes.string,
//       altText: PropTypes.string,
//       height: PropTypes.number,
//       width: PropTypes.number,
//     }),
//     description: PropTypes.string.isRequired,
//     usageDetailsCardsCollection: PropTypes.array.isRequired,
//     productDetailsCardsCollection: PropTypes.array.isRequired,
//     productVariants: PropTypes.array.isRequired,
//     hasMainVariant: PropTypes.bool.isRequired,
//     hasSubVariant: PropTypes.bool.isRequired,
//     bazaarVoiceId: PropTypes.string.isRequired,
//   }),
// }

export default memo(ProductPage)
