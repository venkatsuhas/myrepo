import React, { useState, useEffect, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'
import { searchPage, pageTypes, allIcons } from '@constants'
import searchHandler from '@adapters/algolia/searchHandler'
import useSearchPageReducer, {
  ACTIONS,
} from '@containers/SearchPage/SearchPage.reducer'

const Button = dynamic(() => import('@components/Button'))
const SearchProductCard = dynamic(() =>
  import('@components/Card/SearchProductCard'),
)
const Image = dynamic(() => import('@components/Image'))
const DropDown = dynamic(() => import('@components/DropDown'))
const SearchArticleCard = dynamic(() =>
  import('@components/Card/SearchArticleCard'),
)
const ProductDialog = dynamic(() =>
  import('@components/CommonDialog/ProductDialog'),
)
const Icon = dynamic(() => import('@components/Icon'))
const Breadcrumb = dynamic(() => import('@components/Breadcrumb'))

const SearchPage = ({ pageData: { locale, breadcrumb } }) => {
  const router = useRouter()
  const labels = searchPage
  const tabLabels = searchPage.tabLabels
  const [searchTerm, setSearchTerm] = useState(null)
  const [selectedTab, setSelectedTab] = useState(tabLabels.product.key)
  const [viewType, setViewType] = useState('grid')
  const { state, dispatch } = useSearchPageReducer()
  const [openSortByDialog, setOpenSortByDialog] = useState(false)

  const handleView = (type) => {
    setViewType(type)
  }

  useEffect(() => {
    if (router.asPath.match(/[^?]*\?term=([^&]+)/g)) {
      const term = decodeURI(
        router.asPath.replace(/[^?]*\?term=([^&]+)/g, (...node) => node[1]),
      )
      if (term) {
        setSearchTerm(term)
      }
    }
  }, [router.asPath])

  const closeModal = () => setOpenSortByDialog(true)

  useEffect(() => {
    if (searchTerm) {
      searchHandler({ searchTerm, locale, type: 'all', limit: 200 })
        .then(({ results }) => {
          dispatch({
            type: ACTIONS.SET_SORT_BY,
            value: labels.sortBy.items[0].label,
          })
          dispatch({
            type: ACTIONS.SET_SEARCH_PRODUCTS,
            value: results[0].hits,
          })
          dispatch({
            type: ACTIONS.SET_SEARCH_ARTICLES,
            value: results[1].hits,
          })
        })
        .catch((err) => {
          console.error(err)
        })
    }
  }, [searchTerm])

  return (
    <>
      <div className="breadcrumb h-26 bg-bgblue mdl:bg-none">
        {breadcrumb && breadcrumb.length > 0 && (
          <Breadcrumb breadcrumb={breadcrumb} variant="pdpPage" />
        )}
      </div>
      <h1 className="mt-20 mb-20 font-AvenirNextRoundedBold sm:text-18 mdl:text-28 lg:text-28 sm:w-full mdl:w-3/5 lg:w-3/5 mx-auto">
        {`${labels.searchText} ${searchTerm}`}
      </h1>
      <div className="search-wrapper sm:w-full mdl:w-3/5 lg:w-3/5 m-auto sm:w-full relative bg-whiteGreyBg shadow-md">
        <div className="sm:w-full mdl:w-3/5 lg:w-3/5 flex flex-wrap justify-between">
          <Button
            gaClass="event_button_click bg-whiteGreyBg py-5 font-AvenirNextRoundedReg sm:lowercase mdl:uppercase lg:uppercase sm:text-16 mdl:text-18 lg:text-18 w-1/2"
            gaLabel={tabLabels.product.key}
            onClick={() => {
              setSelectedTab(tabLabels.product.key)
            }}
          >
            {`${tabLabels.product.label}(${state.products.length})`}
          </Button>
          <Button
            gaClass="event_button_click bg-geryBg py-5 font-AvenirNextRoundedReg text-white sm:lowercase mdl:uppercase lg:uppercase sm:text-16 mdl:text-18 lg:text-18  w-1/2"
            gaLabel={tabLabels.article.key}
            onClick={() => {
              setSelectedTab(tabLabels.article.key)
            }}
          >
            {`${tabLabels.article.label}(${state.articles.length})`}
          </Button>
        </div>
        {selectedTab === tabLabels.product.key && (
          <div className="w-full flex flex-wrap">
            <div className=" w-full px-10 flex-wrap mt-20 mb-10">
              <Button
                gaClass="event_button_click w-1/2"
                className={
                  'bg-black text-white font-AvenirNextRoundedReg text-xs p-0 m-0 h-30'
                }
                onClick={() => {
                  setOpenSortByDialog(true)
                }}
              >
                {`${labels.sortBy.title}-${state.sortBy}`}
              </Button>
              <div className="checkk">
                <div className={'w-25 mr-10'}>
                  <Button onClick={() => handleView('grid')}>
                    <Icon
                      name={viewType === 'grid' ? 'gridIconActive' : 'gridIcon'}
                      className={`${viewType === 'grid' ? '' : ''}`}
                    />
                  </Button>
                </div>

                <div className={'w-25'}>
                  <Button onClick={() => handleView('list')}>
                    <Icon
                      name={viewType === 'list' ? 'listIconActive' : 'listIcon'}
                      className={`${viewType === 'list' ? '' : ''}`}
                    />
                  </Button>
                </div>
              </div>
            </div>

            <div
              className={`desktopFilter sm:hidden mdl:flex lg:flex flex-wrap w-full mt-20 mb-20`}
            >
              <div className="flex w-1/3">
                <div className="w-full flex justify-end">
                  <p className="text-block text-16 font-AvenirNextRoundedBold">
                    {labels.sortBy.title}
                  </p>
                  <DropDown
                    onSelect={(value) =>
                      dispatch({ type: ACTIONS.SET_SORT_BY, value })
                    }
                    variant={pageTypes.plpPage}
                    defaultValue={labels.sortBy.items[0].label}
                    options={labels.sortBy.items.map((item) => ({
                      title: item.label,
                      value: item.value,
                    }))}
                    // resetOnPathChange={true}
                  />
                </div>
              </div>
            </div>
            {state.filteredProducts.length > 0 &&
              state.filteredProducts.map((product, index) => {
                return (
                  <div
                    key={`${product.sys}-${index}`}
                    className={'sm:w-1/2 mdl:w-1/3 lg:w-1/3'}
                  >
                    <SearchProductCard
                      locale={locale}
                      {...product}
                      variant={pageTypes.searchPage}
                      type={viewType}
                    />
                  </div>
                )
              })}
            {state.filteredProducts.length === 0 && (
              <div>
                <div>{`${labels.noResultsLabel} ${searchTerm}`}</div>
              </div>
            )}
          </div>
        )}
        <div className="w-full">
          {selectedTab === tabLabels.article.key && (
            <div>
              {state.articles.length > 0 &&
                state.articles.map((article, index) => {
                  return (
                    <div key={`${article.sys}-${index}`}>
                      <SearchArticleCard
                        locale={locale}
                        {...article}
                        variant={pageTypes.searchPage}
                      />
                    </div>
                  )
                })}

              {state.articles.length === 0 && (
                <div>
                  <div>{`${labels.noResultsLabel} ${searchTerm}`}</div>
                </div>
              )}
            </div>
          )}
        </div>
        {openSortByDialog && (
          <ProductDialog
            locale={locale}
            variant="sortfilter"
            togglesortByFilter={(value) => {
              dispatch({ type: ACTIONS.SET_SORT_BY, value })
            }}
            closeModal={closeModal}
            sortBy={state.sortBy}
            sortLabels={labels.sortBy.items}
          />
        )}
      </div>
    </>
  )
}

SearchPage.propTypes = {
  locale: PropTypes.string,
}

export default memo(SearchPage)
