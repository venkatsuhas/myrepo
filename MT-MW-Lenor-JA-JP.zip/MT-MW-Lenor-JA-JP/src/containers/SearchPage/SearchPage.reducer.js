import { useReducer } from 'react'

export const ACTIONS = {
  SET_SORT_BY: 'SET_SORT_BY',
  SET_SEARCH_PRODUCTS: 'SET_SEARCH_PRODUCTS',
  SET_SEARCH_ARTICLES: 'SET_SEARCH_ARTICLES',
}

const useSearchPageReducer = () => {
  const initialState = {
    sortBy: null,
    products: [],
    articles: [],
    filteredProducts: [],
  }

  const getSortedProducts = (filteredProducts, sortOption) => {
    switch (sortOption) {
      case 'ascending':
        return filteredProducts.sort((a, b) =>
          a.productName.trim().localeCompare(b.productName.trim()),
        )
      case 'descending':
        return filteredProducts.sort(
          (a, b) =>
            -1 * a.productName.trim().localeCompare(b.productName.trim()),
        )
      case 'featured':
        return filteredProducts.sort(
          (a, b) => a.featuredRating - b.featuredRating,
        )
      default:
        return filteredProducts
    }
  }

  const reducer = (state, action) => {
    switch (action.type) {
      case ACTIONS.SET_SEARCH_PRODUCTS:
        return {
          ...state,
          products: [...action.value],
          filteredProducts: [...action.value],
        }
      case ACTIONS.SET_SEARCH_ARTICLES:
        return { ...state, articles: [...action.value] }

      case ACTIONS.SET_SORT_BY:
        return {
          ...state,
          sortBy: action.value,
          filteredProducts: getSortedProducts(state.products, action.value),
        }
      default:
        return state
    }
  }

  const [state, dispatch] = useReducer(reducer, initialState)
  return { state, dispatch }
}

export default useSearchPageReducer
