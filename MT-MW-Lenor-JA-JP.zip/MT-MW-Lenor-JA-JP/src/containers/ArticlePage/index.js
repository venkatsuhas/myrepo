import { generateId } from '@helpers/generateId.helper'
import React, { useState, useEffect, useRef, useCallback, memo } from 'react'
import dynamic from 'next/dynamic'
import PropTypes from 'prop-types'
import RelatedArticle from '@components/RelatedArticle'
import { allIcons, Articlespage, locale } from '@constants'

const ArticleCard = dynamic(() => import('@components/cards/ArticleCard'))
const ProductCard = dynamic(() => import('@components/Card/ProductCard'))
const Button = dynamic(() => import('@components/Button'))
const Carousel = dynamic(() => import('@components/Carousel'))
const Image = dynamic(() => import('@components/Image'))
const IconButton = dynamic(() => import('@components/IconButton'))
const Typography = dynamic(() => import('@components/Typography'))
const Icon = dynamic(() => import('@components/Icon'))
const SocialShare = dynamic(() =>
  import('@components/CommonDialog/socialShare'),
)

const getVariantData = ({ ArticleDetails }) => {
  return ArticleDetails
}
const ArticlePage = ({
  pageData: {
    locale,
    name,
    bannerImage,
    descriptionCard,
    relatedArticles,
    cardsCollection,
    indentedCard,
    discoverMoreCard,
    videoCard,
    relatedProducts,
    listingPageURL,
  },
}) => {
  const [isSticky, setSticky] = useState(false)
  const [copiedToClipboard, setCopiedToClipboard] = useState(false)
  const labels = Articlespage || {}
  const contentRef = useRef(null)
  const stickyRef = useRef(null)

  const handleScroll = useCallback(() => {
    if (contentRef.current && stickyRef.current) {
      const contentElement = contentRef.current,
        stickyElement = stickyRef.current
      if (
        contentElement.getBoundingClientRect().top <=
          stickyElement.getBoundingClientRect().top &&
        contentElement.getBoundingClientRect().bottom >=
          stickyElement.getBoundingClientRect().bottom
      ) {
        setSticky(true)
      } else {
        setSticky(false)
      }
    }
  }, [])
  const [socialShareOpenDialog, setSocialShareOpenDialog] = useState(false)
  const [selectedSocialShare, setSelectedSocialShare] = useState(
    labels?.socialShareDetails[0],
  )
  const copyToClipboard = useCallback(() => {
    setCopiedToClipboard(true)
    setTimeout(setCopiedToClipboard, 2000, false)
  }, [])
  const [selectedVariant, setSelectedVariant] = useState({
    mainIndex: 0,
    subIndex: 0,
    data: getVariantData({
      ArticleDetails: { relatedArticles },
    }),
  })
  useEffect(() => {
    window?.dataLayer?.push({
      event: 'customEvent',
      GAeventCategory: 'event_informational_action',
      GAeventAction: 'event_view_article_page',
      GAeventLabel: name,
      GAeventValue: name,
      GAeventNonInteraction: false,
    })
    setSelectedVariant({
      data: getVariantData({
        ArticleDetails: { relatedArticles },
      }),
    })
    document.addEventListener('scroll', handleScroll, false)
    return () => {
      document.removeEventListener('scroll', handleScroll, false)
    }
  }, [])

  return (
    <div className="adp">
      <div className="mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl">
        <div className="lg:w-10/12 lg:mx-auto">
          <h1 className="text-28 leading-34 font-neutrafaceDemi text-primary px-20 mb-20 lg:px-0 mdl:text-34 mdl:leading-40">
            {name}
          </h1>
          {bannerImage && bannerImage.desktopImage && (
            <div className="">
              <Image
                key={bannerImage.desktopImage.sys}
                desktopClassName="hidden mdl:block"
                smartphoneClassName="block mdl:hidden"
                wrapperClassName="w-full"
                desktopImage={bannerImage.desktopImage}
                smartphoneImage={bannerImage.smartphoneImage}
                alt={bannerImage.desktopImage?.altText}
              />
            </div>
          )}
        </div>
        <div className="sideBarSec mdl:mx-auto lg:ml-auto mdl:w-full lg:w-11/12 px-20 pt-30 mdl:pt-40 mdl:px-0 mdl:flex mdl:flex-wrap lg:mr-0 lg:px-0">
          <IconButton variant="adpSocial" gaClass="event_socialmedia_exit" />{' '}
          <div className="mdl:w-8/12 lg:w-9/12" ref={contentRef}>
            <div className="mdl:w-9/12">
              {descriptionCard && (
                <div>
                  {descriptionCard.title && <h2>{descriptionCard.title}</h2>}
                  {descriptionCard.description && (
                    <Typography
                      content={descriptionCard.description}
                      className="cardDesc mb-20 text-20 leading-26 font-neutrafaceBook text-secondary"
                    />
                  )}
                  {descriptionCard.image && (
                    <Image
                      key={descriptionCard.image.sys}
                      desktopClassName=""
                      smartphoneClassName=""
                      wrapperClassName="w-full "
                      desktopImage={bannerImage.desktopImage}
                      smartphoneImage={bannerImage.smartphoneImage}
                      alt={bannerImage.desktopImage?.altText}
                    />
                  )}
                </div>
              )}
              <div className="hidden md:block mx-auto w-full mdl:w-5/12 lg:w-lg mxl:w-mxl px-20 lg:px-0 mdl:absolute top-0 mb-15 mdl:right-15p mdl:mt-15p">
                {selectedVariant?.data?.relatedArticles &&
                  selectedVariant?.data?.relatedArticles.length > 0 && (
                    <ArticleCard
                      isMobile={false}
                      relatedArticles={selectedVariant?.data?.relatedArticles}
                    />
                  )}
                <div className="flex mt-30">
                  <span className="font-AvenirLTLight pr-10 text-darkgray text-12">
                    SHARE
                  </span>{' '}
                  {labels?.socialShareDetails.map((item) => (
                    <>
                      <Button
                        gaClass="event_social_action"
                        gaLabel={'event_share'}
                        className={'w-10p'}
                        name={item?.label}
                        key={`${item.label}`}
                        onClick={() => {
                          setSocialShareOpenDialog(true)
                          setSelectedSocialShare(item)
                        }}
                      >
                        <Icon name={item?.icon}> </Icon>
                      </Button>
                    </>
                  ))}
                </div>
                {socialShareOpenDialog && (
                  <SocialShare
                    variant="adpSocialDialogContent"
                    socialShareDetails={selectedSocialShare}
                    media={
                      selectedVariant?.data?.relatedArticles?.relatedArticles
                        ?.url || ''
                    }
                    closeModal={() => {
                      setSocialShareOpenDialog(!socialShareOpenDialog)
                    }}
                  />
                )}
              </div>
              {cardsCollection.length > 0 &&
                cardsCollection.map((card) => (
                  <div key={card.sys} className="">
                    {card.type === 'videoCard' ? (
                      <div className="videoWrap mb-100">
                        <h2
                          className="text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36"
                          id={generateId(card?.title)}
                        >
                          {card?.title}
                        </h2>
                        <iframe
                          width="100%"
                          height="180"
                          src={card?.url}
                          title="YouTube video player"
                          frameBorder="0"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                          className="test"
                        />
                      </div>
                    ) : (
                      <div>
                        {card.title && (
                          <h2
                            className="text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36"
                            id={generateId(card?.title)}
                          >
                            {card.title}
                          </h2>
                        )}
                        {card.description && (
                          <Typography
                            content={card.description}
                            className="text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36"
                          />
                        )}

                        {card.image && (
                          <div className="mb-40">
                            <Image
                              key={card.image.sys}
                              desktopClassName=""
                              wrapperClassName="w-full"
                              desktopImage={card.image}
                              alt={card.image?.altText}
                            />
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              {relatedProducts && relatedProducts.length > 0 && (
                <div className="w-full  mb-40">
                  <div className="mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 py-60">
                    <h2>関連製品</h2>
                    <Carousel variant="productCard">
                      {relatedProducts.map((product) => (
                        <ProductCard
                          key={product.sys}
                          locale={locale}
                          {...product}
                          rating={{ value: 0, count: 0 }}
                          variant="pdpProductCard"
                        />
                      ))}
                    </Carousel>
                  </div>
                </div>
              )}

              {indentedCard && indentedCard.description && (
                <Typography
                  content={indentedCard.description}
                  className="pl-24 border-l-4 border-lightGreyBlue mb-40 lg:mb-60 mt-40 text-20 leading-26 font-neutrafaceBook text-secondary"
                />
              )}
              {videoCard && (
                <div className="videoWrap mb-100">
                  <h2
                    className="text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36"
                    id={generateId(videoCard?.title)}
                  >
                    {videoCard?.title}
                  </h2>
                  <iframe
                    width="100%"
                    height="180"
                    src={videoCard?.url}
                    title="YouTube video player"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="test"
                  />
                </div>
              )}
            </div>
          </div>
          <div
            className={`hidden bottom-10 right-30 mdl:w-3/12 lg:w-2/12 mdl:block  ${
              isSticky ? 'visible' : 'visible'
            }`}
            ref={stickyRef}
          >
            <div className="mb-90 px-20 lg:px-0">
              <h2 className="text-24 leading-30 font-neutrafaceDemi mb-20 text-center lg:text-34 lg:leading-40">
                <RelatedArticle relatedArticles={relatedArticles} />
              </h2>
            </div>
            {discoverMoreCard && (
              <div className="w-200 mxl:w-250">
                <h4 className="text-24 leading-30 font-neutrafaceDemi mb-20 text-accentDark">
                  {labels.discoverMore}
                </h4>
                <Button href={discoverMoreCard.href}>
                  {discoverMoreCard.image && (
                    <div className="mb-15">
                      <Image
                        desktopClassName=""
                        smartphoneClassName=""
                        wrapperClassName="w-full"
                        desktopImage={discoverMoreCard.image}
                        alt={discoverMoreCard.image?.altText}
                      />
                    </div>
                  )}
                  {discoverMoreCard.description && (
                    <Typography
                      content={discoverMoreCard.description}
                      className="text-18 leading-24 font-neutrafaceBook text-secondary"
                    />
                  )}
                </Button>
              </div>
            )}
          </div>
        </div>
        <div>
          <Icon
            name={allIcons?.logoWithBorder}
            alt={allIcons?.logoWithBorder}
            className={''}
          />
        </div>
      </div>
    </div>
  )
}

ArticlePage.propTypes = {
  pageData: PropTypes.shape({
    locale: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    category: PropTypes.string.isRequired,
    bannerImage: PropTypes.object,
    descriptionCard: PropTypes.object,
    featureCard: PropTypes.array,
    recommendedProducts: PropTypes.array,
    discoverMoreCard: PropTypes.object,
    relatedArticles: PropTypes.array,
    videoCard: PropTypes.object,
    indentedCard: PropTypes.object,
    listingPageURL: PropTypes.string,
    articleURL: PropTypes.string,
  }),
}

export default memo(ArticlePage)
