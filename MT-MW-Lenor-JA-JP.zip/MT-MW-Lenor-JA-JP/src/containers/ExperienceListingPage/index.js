// import React, { memo, useCallback, useEffect, useState } from 'react'
// import PropTypes from 'prop-types'
// import dynamic from 'next/dynamic'
// import {
//   labels as allLabels,
//   allIcons,
//   pageTypes,
//   experiencePerPageELP,
// } from '@constants'
// import { useRouter } from 'next/router'
// import Button from '@components/Button'

// const ExperienceCard = dynamic(() => import('@components/Card/ExperienceCard'))
// const Icon = dynamic(() => import('@components/Icon'))
// const FilterLargeScreen = dynamic(() =>
//   import('@components/Filters/LargeScreen'),
// )
// const MobileSmallScreen = dynamic(() =>
//   import('@components/Filters/MobileSmallScreen'),
// )

// const ExperienceListingPage = ({ pageData: { locale, experiences, type } }) => {
//   const labels = allLabels.experienceListingPage
//   const router = useRouter()

//   const [next, setNext] = useState(experiencePerPageELP)
//   const [experiencesToShow, setExperiencesToShow] = useState([])
//   const getSortedArray = useCallback(
//     (limit = next, sortOption) => {
//       switch (sortOption) {
//         default:
//           return experiences?.slice(0, limit)
//       }
//     },
//     [experiences, next],
//   )

//   useEffect(() => {
//     setExperiencesToShow(getSortedArray(next))
//   }, [next])
//   useEffect(() => {
//     setExperiencesToShow([])
//     setNext(experiencePerPageELP)
//     setExperiencesToShow(getSortedArray(experiencePerPageELP))
//   }, [router.asPath])

//   const experienceCategory = {}
//   experiences?.forEach((ele) => {
//     experienceCategory[ele['category']] = {
//       value: ele['category'],
//       url: labels.categorySlugObject[ele['category']],
//       label: labels.categoryObject[ele['category']],
//     }
//   })

//   const displayExperienceCards = () => {
//     return (
//       <div>
//         <div className="flex flex-row flex-wrap items-start justify-start w-full ">
//           {experiencesToShow &&
//             experiencesToShow.length > 0 &&
//             experiencesToShow.map((experience) => (
//               <>
//                 <ExperienceCard
//                   key={experience.sys}
//                   locale={locale}
//                   {...experience}
//                   variant="ELPExperienceCard"
//                 />
//               </>
//             ))}
//         </div>
//         <div>
//           <Icon
//             name={allIcons?.logoWithBorder}
//             alt={allIcons?.logoWithBorder}
//             className={''}
//           />
//         </div>
//       </div>
//     )
//   }
//   const ExperienceListingSmallPage = () => {
//     return (
//       <div className="px-20 smart-area-cls mt-50">
//         <div className="flex flex-col-reverse flex-wrap px-20">
//           {Object.keys(experienceCategory)
//             .reverse()
//             .map((ele, index) => (
//               <Button
//                 key={index}
//                 href={experienceCategory[ele].url}
//                 onClick={() => handleFilter(ele)}
//                 className="block w-full h-65"
//               >
//                 <div className="flex justify-between">
//                   <p className="uppercase font-AvenirLTLight text-25 text-accent">
//                     {ele}
//                   </p>
//                 </div>
//               </Button>
//             ))}
//         </div>
//         <div>
//           <div>
//             <MobileSmallScreen
//               locale={locale}
//               variant={pageTypes.elpPage}
//             />
//           </div>
//           {displayExperienceCards(true)}
//           <div className="smartblock mdl:hidden">
//           {ExperienceListingSmallPage()}
//         </div>
//         </div>
//       </div>
//     )
//   }

//   return (
//     <div>

//       <div className="mx-auto smart-area-cls mt-50 w-940">
//         <div className="hidden dt-area-cls mdl:block">
//           <div className="flex mx-auto elp-content-wrapper">
//             <div className="w-220">
//               <h2 className="w-full mb-10 font-semibold font-ChaletLondon text-14 leading-30 text-primaryblue px-15 bg-bgblue rounded-5">
//                 カテゴリーから探す
//               </h2>
//               <div>
//                 {Object.keys(experienceCategory)
//                   .reverse()
//                   .map((ele, index) => (
//                     <Button
//                       key={index}
//                       href={experienceCategory[ele].url}
//                       classname="text-left text-14 font-ChaletParis text-primaryblue"
//                     >
//                       <div>
//                         <p className="text-14 font-ChaletParis1 text-primaryblue mb-7 ml-15">
//                           {experienceCategory[ele].label}
//                         </p>{' '}
//                       </div>
//                     </Button>
//                   ))}
//               </div>
//             </div>
//             <div className="w-700">
//               <div>{displayExperienceCards()}</div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }

// ExperienceListingPage.propTypes = {
//   pageData: PropTypes.shape({
//     locale: PropTypes.string.isRequired,
//     title: PropTypes.string,
//     subTitle: PropTypes.string,
//     banner: PropTypes.object,
//     filters: PropTypes.array,
//     experiences: PropTypes.array,
//   }),
// }

// export default memo(ExperienceListingPage)

import React, { memo, useCallback, useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import {
  labels as allLabels,
  allIcons,
  pageTypes,
  experiencePerPageELP,
} from '@constants'
import { useRouter } from 'next/router'
import Button from '@components/Button'

const ExperienceCard = dynamic(() => import('@components/Card/ExperienceCard'))
const Icon = dynamic(() => import('@components/Icon'))

const SmallScreenAlp = dynamic(() =>
  import('@components/Filters/SmallScreenAlp'),
)

const ExperienceListingPage = ({ pageData: { locale, experiences, type } }) => {
  const labels = allLabels.experienceListingPage
  const router = useRouter()

  const [next, setNext] = useState(experiencePerPageELP)
  const [experiencesToShow, setExperiencesToShow] = useState([])
  const getSortedArray = useCallback(
    (limit = next, sortOption) => {
      switch (sortOption) {
        default:
          return experiences?.slice(0, limit)
      }
    },
    [experiences, next],
  )

  useEffect(() => {
    setExperiencesToShow(getSortedArray(next))
  }, [next])
  useEffect(() => {
    setExperiencesToShow([])
    setNext(experiencePerPageELP)
    setExperiencesToShow(getSortedArray(experiencePerPageELP))
  }, [router.asPath])

  const experienceCategory = {}
  experiences?.forEach((ele) => {
    experienceCategory[ele['category']] = {
      value: ele['category'],
      url: labels.categorySlugObject[ele['category']],
      label: labels.categoryObject[ele['category']],
    }
  })

  const displayExperienceCards = () => {
    return (
      <div>
        <div className="flex flex-row flex-wrap items-start justify-start w-full ">
          {experiencesToShow &&
            experiencesToShow.length > 0 &&
            experiencesToShow.map((experience) => (
              <>
                <ExperienceCard
                  key={experience.sys}
                  locale={locale}
                  {...experience}
                  variant="ELPExperienceCard"
                />
              </>
            ))}
        </div>
        <div>
          <Icon
            name={allIcons?.logoWithBorder}
            alt={allIcons?.logoWithBorder}
            className={''}
          />
        </div>
      </div>
    )
  }
  const ExperienceListingSmallPage = () => {
    return (
      <div className="px-20 smart-area-cls mt-50">
        <div className="flex flex-col-reverse flex-wrap px-20">
          <h1 className="uppercase text-24 font-ChaletLondon">レノア 柔軟剤</h1>
        </div>
        <div>
          <div>
            <SmallScreenAlp locale={locale} variant={pageTypes.elpPage} />
          </div>
          {displayExperienceCards(true)}
        </div>
      </div>
    )
  }

  return (
    <div>
      <div className="smartblock mdl:hidden ">
        {ExperienceListingSmallPage()}
      </div>
      <div className="mx-auto smart-area-cls mt-50 w-940">
        <div className="hidden dt-area-cls mdl:block">
          <div className="flex mx-auto elp-content-wrapper">
            <div className="w-220">
              <h2 className="w-full mb-10 font-semibold font-ChaletLondon text-14 leading-30 text-primaryblue px-15 bg-bgblue rounded-5">
                カテゴリーから探す
              </h2>
              <div>
                {Object.keys(experienceCategory)
                  .reverse()
                  .map((ele, index) => (
                    <Button
                      key={index}
                      href={experienceCategory[ele].url}
                      classname="text-left text-14 font-ChaletParis text-primaryblue"
                    >
                      <div>
                        <p className="text-14 font-ChaletParis1 text-primaryblue mb-7 ml-15">
                          {experienceCategory[ele].label}
                        </p>{' '}
                      </div>
                    </Button>
                  ))}
              </div>
            </div>
            <div className="w-700">
              <div>{displayExperienceCards()}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

ExperienceListingPage.propTypes = {
  pageData: PropTypes.shape({
    locale: PropTypes.string.isRequired,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    banner: PropTypes.object,
    filters: PropTypes.array,
    experiences: PropTypes.array,
  }),
}

export default memo(ExperienceListingPage)
