import React, { memo } from 'react'
import PropTypes from 'prop-types'

const ContactUsPage = (props) => {
  const link = props.pageData.gcr.replace('Lenor', 'レノア')

  return (
    <div className="pageWrapper">
      <div>
        <iframe
          className="contactus mx-auto mt-50 mb-100"
          width="60%"
          height="500px"
          title="Contact us"
          src={link}
        />
      </div>
    </div>
  )
}

ContactUsPage.propTypes = {
  gcr: PropTypes.string,
}

export default memo(ContactUsPage)
