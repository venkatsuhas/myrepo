import React, { memo, useCallback, useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import {
  articleListingPage,
  pageTypes,
  articlesPerPageALP,
  allIcons,
} from '@constants'
import useArticleLisitingPageReducer, {
  ACTIONS,
} from '@containers/ArticleListingPage/ArticleLisitingPage.reducer'
import { useRouter } from 'next/router'
import Button from '@components/Button'
import DropDown from '@components/DropDown'

const ArticleCard = dynamic(() => import('@components/Card/ArticleCard'))
const Image = dynamic(() => import('@components/Image'))
const Icon = dynamic(() => import('@components/Icon'))
const FilterLargeScreen = dynamic(() =>
  import('@components/Filters/LargeScreen'),
)
const MobileSmallScreen = dynamic(() =>
  import('@components/Filters/MobileSmallScreen'),
)

const ArticleListingPage = ({
  pageData: { locale, articles, type, filters, mainCategories },
}) => {
  const labels = articleListingPage
  const router = useRouter()

  const [next, setNext] = useState(articlesPerPageALP)
  const { state, dispatch } = useArticleLisitingPageReducer()
  const [sortBy, setSetSortBy] = useState(labels.sortBy.items[0].value)
  const [activeFilterCategory, setActiveFilterCategory] = useState('')
  const [articlesToShow, setArticlesToShow] = useState([])

  useEffect(() => {
    dispatch({ type: ACTIONS.SET_ALL_FILTERS, value: filters })
    dispatch({ type: ACTIONS.SET_ARTICLES, value: articles })
    dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })
  }, [router.asPath])

  const getSortedArray = useCallback(
    (limit = next, sortOption = sortBy) => {
      switch (sortOption) {
        case 'ascending':
          return articles
            .map((article) => ({ ...article, categoryBasedFeatured: false }))
            .sort((a, b) => a.name.localeCompare(b.name))
            .slice(0, limit)
        case 'descending':
          return articles
            .map((article) => ({ ...article, categoryBasedFeatured: false }))
            .sort((a, b) => -1 * a.name.localeCompare(b.name))
            .slice(0, limit)
        case 'featured':
          return articles
            .sort((a, b) => {
              if (b.categoryBasedFeatured && !a.categoryBasedFeatured) {
                return 1
              } else if (a.categoryBasedFeatured && !b.categoryBasedFeatured) {
                return -1
              } else {
                return 0
              }
            })
            .slice(0, limit)
        default:
          return articles.slice(0, limit)
      }
    },
    [articles, next, sortBy],
  )

  useEffect(() => {
    setArticlesToShow(getSortedArray(next, sortBy))
  }, [next, sortBy])
  useEffect(() => {
    setArticlesToShow([])
    setNext(articlesPerPageALP)
    setSetSortBy(labels.sortBy.items[0].value)
    setArticlesToShow(
      getSortedArray(articlesPerPageALP, labels.sortBy.items[0].value),
    )
  }, [router.asPath])

  const articleCategory = {}
  articles?.forEach((ele) => {
    articleCategory[ele['category']] = {
      value: ele['category'],
      url: labels.categorySlugObject[ele['category']],
      label: labels.categoryObject[ele['category']],
    }
  })

  const handleFilter = (categoryValue) => {
    const result = articles?.filter((ele) => ele['category'] === categoryValue)
    setArticlesToShow(result)
  }
  //   const handleFilter = (categoryValue) => {
  //     dispatch({ type: ACTIONS.FILTER_CATEGORY, value: categoryValue })
  //     setActiveFilterCategory(categoryValue)
  // }

  const checkArticleCount = (key) =>
    (articlesToShow &&
      articlesToShow.length > 0 &&
      articlesToShow.some((val) => val.category === key)) ||
    false

  const displayArticleCards = (variant) => {
    return (
      <div>
        <h1 className="mdl:hidden">教えて！プロのコツ</h1>
        {labels.listCategoryLabels
          .filter(
            ({ url }) =>
              (activeFilterCategory && activeFilterCategory === url) ||
              !activeFilterCategory,
          )
          .map(({ key, label }) => {
            if (checkArticleCount(key))
              return (
                <div>
                  {!activeFilterCategory && (
                    <h3 className="hidden w-full mb-10 font-semibold text-24 mdl:block font-ChaletParis leading-40 text-primaryblue px-15 bg-bgblue rounded-5">
                      {label}
                    </h3>
                  )}
                  <div className="flex flex-wrap">
                    {articlesToShow &&
                      articlesToShow.length > 0 &&
                      articlesToShow.map((article) => {
                        if (article.category === key)
                          return (
                            <>
                              <div className="flex wrapper-cls w-50p">
                                <ArticleCard
                                  key={article.sys}
                                  locale={locale}
                                  {...article}
                                  variant="alpArticlesCard"
                                />
                                <Icon
                                  name={allIcons?.Icon_Article}
                                  alt={allIcons?.Icon_Article}
                                  className={''}
                                />
                              </div>
                            </>
                          )
                      })}
                  </div>
                </div>
              )
          })}
        <div>
          <Icon
            name={allIcons?.logoWithBorder}
            alt={allIcons?.logoWithBorder}
            className={''}
          />
        </div>
      </div>
    )
  }

  const ArticleListingSmallPage = () => {
    return (
      <div className="px-20 smart-area-cls mt-50">
        <div className="flex flex-col-reverse flex-wrap px-20">
          {Object.keys(articleCategory)
            .reverse()
            .map((ele, index) => (
              <Button
                key={index}
                href={articleCategory[ele].url}
                onClick={() => handleFilter(ele)}
                className="block w-full h-65"
              >
                <div className="flex justify-between">
                  <p className="uppercase font-AvenirLTLight text-25 text-accent">
                    {ele}
                  </p>
                </div>
              </Button>
            ))}
        </div>

        <div>
          <div>
            <p className="text-right text-darkgray text-15 mdl:text-right font-AvenirLTBook mt-150">
              {labels.viewingCount.replace('$count', articlesToShow.length)}
            </p>
            <MobileSmallScreen
              locale={locale}
              variant={pageTypes.alpPage}
              filters={state.filterData}
              toggleFilter={(value) => {
                dispatch({
                  type: ACTIONS.TOGGLE_ACTIVE_FILTER,
                  value,
                })
              }}
              activeFilters={state.activeFilters}
              resetFilter={() =>
                dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })
              }
              handleDropDown={(value) =>
                dispatch({ type: ACTIONS.SET_SORT_BY, value })
              }
            />
          </div>
          <div w-400> {displayArticleCards(true)}</div>
        </div>
      </div>
    )
  }
  const handleDropDown = useCallback(
    (value) => dispatch({ type: ACTIONS.SET_SORT_BY, value }),
    [],
  )
  return (
    <div>
      <div className="w-full mx-auto mdl:relative mdl:top-0 mdl:w-lgm">
        <div className="hidden dt-area-cls mdl:block">
          <div className="flex mx-auto alp-content-wrapper w-940 mt-30">
            <div
              className={`w-220 ${activeFilterCategory ? 'mdl:mt-234' : ''}`}
            >
              <div className="w-full font-ChaletLondon text-14 leading-30 text-primaryblue px-15 bg-bgblue rounded-5">
                {articleListingPage.browseArticlesLabel}
              </div>
              <div className="">
                <FilterLargeScreen
                  type={type}
                  locale={locale}
                  variant={pageTypes.alpPage}
                  mainCategories={mainCategories}
                  filters={state.filterData}
                  toggleFilter={(value) =>
                    dispatch({
                      type: ACTIONS.TOGGLE_ACTIVE_FILTER,
                      value,
                    })
                  }
                  activeFilters={state.activeFilters}
                  resetFilter={() =>
                    dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })
                  }
                />
              </div>
            </div>
            <div
              className={`w-full mdl:ml-20 article-rightarea-cls mdl:w-700 ${
                activeFilterCategory ? 'mdl:mt-130' : ''
              }`}
            >
              <h1 className="capitalize text-22 font-ChaletParis text-primaryblue">
                教えて！プロのコツ
              </h1>
              <div className="flex flex-col-reverse flex-wrap items-center justify-between w-full mdl:flex-row mdl:pb-20 mdl:mt-15 ">
                <div className="flex justify-between w-full ">
                  <p className="text-right text-primaryblue text-12 mdl:text-left text-secondary font-AvenirLTMedium">
                    {labels.showingCount.replace(
                      '$count',
                      articlesToShow.length,
                    )}
                  </p>
                  <div className="block w-full mdl:w-max mdl:flex mdl:justify-end mdl:items-start mdl:flex-row">
                    <p className="pl-10 pr-10 text-left font-ChaletParisorg text-14 leading-30 text-primaryblue mr-25">
                      {labels.sortBy.title}
                    </p>
                    <DropDown
                      onSelect={handleDropDown}
                      variant={pageTypes.alpPage}
                      defaultValue={labels.sortBy.items[0].name}
                      options={labels.sortBy.items.map((item) => ({
                        title: item.name,
                        value: item.value,
                      }))}
                      resetOnPathChange={true}
                    />
                  </div>
                </div>{' '}
              </div>
              <div>{displayArticleCards()}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="smartblock mdl:hidden">{ArticleListingSmallPage()}</div>
    </div>
  )
}

ArticleListingPage.propTypes = {
  pageData: PropTypes.shape({
    locale: PropTypes.string.isRequired,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    banner: PropTypes.object,
    filters: PropTypes.array,
    articles: PropTypes.array,
  }),
}

export default memo(ArticleListingPage)
