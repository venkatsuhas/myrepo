import { useReducer } from 'react'
import { pageTypes } from '@constants'

export const ACTIONS = {
  SET_PRODUCTS: 'SET_ARTICLES',
  SET_ALL_FILTERS: 'SET_ALL_FILTERS',
  TOGGLE_ACTIVE_FILTER: 'TOGGLE_ACTIVE_FILTER',
  RESET_ACTIVE_FILTER: 'RESET_ACTIVE_FILTER',
  TOGGLE_FILTER_BUTTON: 'TOGGLE_FILTER_BUTTON',
  LOAD_MORE: 'LOAD_MORE',
  SET_SORT_BY: 'SET_SORT_BY',
  FILTER_CATEGORY: 'FILTER_CATEGORY',
}

const useArticleLisitingPageReducer = () => {
  const initialState = {
    articles: [],
    filteredArticles: [],
    articlesToDisplay: pageTypes.articlesPerPageALP,
    allFilters: [],
    activeFilters: [],
    filterData: [],
    showFilter: false,
    sortBy: null,
  }

  const getSortedArticles = (filteredArticles, sortOption) => {
    switch (sortOption) {
      case 'ascending':
        return filteredArticles.sort((a, b) =>
          a.name.trim().localeCompare(b.name.trim()),
        )
      case 'descending':
        return filteredArticles.sort(
          (a, b) => -1 * a.name.trim().localeCompare(b.name.trim()),
        )
      case 'featured':
        return filteredArticles.sort(
          (a, b) => a.featuredRating - b.featuredRating,
        )
      default:
        return filteredArticles
    }
  }

  const getFilterWithCountData = (filter, computedFilterData, value) => {
    return filter.map((article) => {
      if (
        value &&
        article.options.some((option) =>
          typeof option === 'object' ? option.name === value : option === value,
        )
      ) {
        return {
          name: article.name,
          options: article.options.map((option) =>
            typeof option === 'object'
              ? {
                  name: option.name,
                  count:
                    computedFilterData[option.name] &&
                    computedFilterData[option.name] > option.count
                      ? computedFilterData[option.name]
                      : option.count,
                }
              : {
                  name: option,
                  count: computedFilterData[option] || 0,
                },
          ),
        }
      } else {
        return {
          name: article.name,
          options: article.options.map((option) =>
            typeof option === 'object'
              ? {
                  name: option.name,
                  count: computedFilterData[option.name] || 0,
                }
              : {
                  name: option,
                  count: computedFilterData[option] || 0,
                },
          ),
        }
      }
    })
  }

  const generateFilterData = (activeFilters, state, value) => {
    const filteredArticles = getSortedArticles(
      state.articles.filter((product) => {
        if (activeFilters.length > 0 && product.articleFacets) {
          const optionSets = state.allFilters
            .map((filterSet) =>
              filterSet.options.filter(
                (option) => activeFilters.indexOf(option) !== -1,
              ),
            )
            .filter((filterSet) => filterSet.length)
          return optionSets.every((optionSet) =>
            optionSet.some((filter) => product.articleFacets.includes(filter)),
          )
        } else if (!product.articleFacets) {
          return false
        } else {
          return true
        }
      }),
      state.sortBy,
    )
    const computedFilterData = filteredArticles.reduce(
      (prevState, product) =>
        product.articleFacets
          ? product.articleFacets.reduce(
              (prevObject, facet) => ({
                ...prevObject,
                [facet]: prevObject[facet] ? prevObject[facet] + 1 : 1,
              }),
              prevState,
            )
          : prevState,
      {},
    )
    const filtersWithCount = getFilterWithCountData(
      state.filterData,
      computedFilterData,
      value,
    )

    return { filteredArticles, filterData: filtersWithCount }
  }

  const toggleActiveFilterHandler = (state, value) => {
    const activeFilters =
      state.activeFilters.indexOf(value) === -1
        ? [...state.activeFilters, value]
        : state.activeFilters.filter((filter) => filter !== value)
    const { filteredArticles, filterData } = generateFilterData(
      activeFilters,
      state,
      value,
    )
    return {
      ...state,
      activeFilters,
      filterData,
      filteredArticles,
      productsToDisplay: pageTypes.articlesPerPageALP,
    }
  }

  const resetActiveFilterHandler = (state) => {
    const activeFilters = []
    const { filteredArticles, filterData } = generateFilterData(
      activeFilters,
      state,
    )
    return {
      ...state,
      activeFilters,
      filteredArticles,
    }
  }

  const getCategoryFilteredArticle = (filteredArticles, category, state) => {
    const categoryFilteredArticles = filteredArticles.filter(
      (ele) => ele['category'] === category,
    )
    const filtersWithCount = getFilterWithCountData(state.filterData)
    return {
      ...state,
      filteredArticles: categoryFilteredArticles,
      filterData: filtersWithCount,
    }
  }

  const reducer = (state, action) => {
    switch (action.type) {
      case ACTIONS.SET_ARTICLES:
        return {
          ...state,
          articles: [...action.value],
          filteredArticles: [...action.value],
          // productsToDisplay: pageTypes.articlesPerPageALP,
          // activeFilters: [],
          // ...(state.allFilters
          //   ? generateFilterData([], { ...state, articles: [...action.value] })
          //   : {}),
        }
      case ACTIONS.SET_ALL_FILTERS:
        return {
          ...state,
          allFilters: [...action.value],
          filterData: getFilterWithCountData(action.value, {}),
        }
      case ACTIONS.TOGGLE_ACTIVE_FILTER:
        return toggleActiveFilterHandler(state, action.value)
      case ACTIONS.RESET_ACTIVE_FILTER:
        return resetActiveFilterHandler(state)
      case ACTIONS.TOGGLE_FILTER_BUTTON:
        return { ...state, showFilter: !state.showFilter }
      case ACTIONS.SET_SORT_BY:
        return {
          ...state,
          sortBy: action.value,
          filteredArticles: getSortedArticles(
            state.filteredArticles,
            action.value,
          ),
        }
      case ACTIONS.FILTER_CATEGORY:
        return getCategoryFilteredArticle(
          state.filteredArticles,
          action.value,
          state,
        )

      default:
        return state
    }
  }

  const [state, dispatch] = useReducer(reducer, initialState)
  return { state, dispatch }
}

export default useArticleLisitingPageReducer
