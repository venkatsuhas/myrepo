import { labels } from 'src/constants'
import { generateId } from '@helpers/generateId.helper'
import React, { useState, useEffect, useRef, useCallback, memo } from 'react'
import dynamic from 'next/dynamic'
import PropTypes from 'prop-types'
import { ExperiencesPage } from '@constants'
import RelatedArticle from '@components/RelatedArticle'

const ExperienceCard = dynamic(() => import('@components/Card/ExperienceCard'))
const ProductCard = dynamic(() => import('@components/Card/ProductCard'))
const FeatureCard = dynamic(() => import('@components/cards/FeatureCard'))
const Button = dynamic(() => import('@components/Button'))
const Carousel = dynamic(() => import('@components/Carousel'))
const Image = dynamic(() => import('@components/Image'))
const Typography = dynamic(() => import('@components/Typography'))
const Icon = dynamic(() => import('@components/Icon'))
const instagram = dynamic(() => import('@components/CommonDialog/instagram'))

const getVariantData = ({ ExperienceDetails }) => {
  return ExperienceDetails
}
const ExperiencePage = ({
  pageData: {
    locale,
    name,
    bannerImage,
    featureCards,
    descriptionCard,
    cardsCollection,
    relatedArticles,
    recommendedProducts,
    relatedProducts,
    indentedCard,
    discoverMoreCard,
    videoCard,
    instaCardsCollection,
  },
}) => {
  const [isSticky, setSticky] = useState(false)
  const [copiedToClipboard, setCopiedToClipboard] = useState(false)
  const labels = ExperiencesPage || {}
  const contentRef = useRef(null)
  const stickyRef = useRef(null)
  const handleScroll = useCallback(() => {
    if (contentRef.current && stickyRef.current) {
      const contentElement = contentRef.current,
        stickyElement = stickyRef.current
      if (
        contentElement.getBoundingClientRect().top <=
          stickyElement.getBoundingClientRect().top &&
        contentElement.getBoundingClientRect().bottom >=
          stickyElement.getBoundingClientRect().bottom
      ) {
        setSticky(true)
      } else {
        setSticky(false)
      }
    }
  }, [])
  const [socialShareOpenDialog, setSocialShareOpenDialog] = useState(false)
  const [selectedSocialShare, setSelectedSocialShare] = useState(
    labels?.socialShareDetails[0],
  )
  const copyToClipboard = useCallback(() => {
    setCopiedToClipboard(true)
    setTimeout(setCopiedToClipboard, 2000, false)
  }, [])
  const [selectedVariant, setSelectedVariant] = useState({
    mainIndex: 0,
    subIndex: 0,
    data: getVariantData({
      ExperienceDetails: { instaCardsCollection },
    }),
  })

  useEffect(() => {
    window?.dataLayer?.push({
      event: 'customEvent',
      GAeventCategory: 'event_informational_action',
      GAeventAction: 'event_view_article_page',
      GAeventLabel: name,
      GAeventValue: name,
      GAeventNonInteraction: false,
    })
    setSelectedVariant({
      data: getVariantData({
        ExperienceDetails: { instaCardsCollection },
      }),
    })

    document.addEventListener('scroll', handleScroll, false)
    return () => {
      document.removeEventListener('scroll', handleScroll, false)
    }
  }, [])

  return (
    <div className="edp">
      <div className="w-full mx-auto lg:w-lg mxl:w-mxl xl:w-xl">
        <div className="lg:w-10/12 lg:mx-auto">
          {bannerImage && bannerImage.desktopImage && (
            <div className="">
              <Image
                key={bannerImage.desktopImage.sys}
                desktopClassName="hidden mdl:block"
                smartphoneClassName="block mdl:hidden"
                wrapperClassName="w-full"
                desktopImage={bannerImage.desktopImage}
                smartphoneImage={bannerImage.smartphoneImage}
                alt={bannerImage.desktopImage?.altText}
              />
            </div>
          )}
        </div>
        <div className="px-20 sideBarSec mdl:mx-auto lg:ml-auto mdl:w-full lg:w-11/12 pt-30 mdl:pt-40 mdl:px-0 mdl:flex mdl:flex-wrap lg:mr-0 lg:px-0">
          <div className="mdl:w-8/12 lg:w-9/12" ref={contentRef}>
            <div className="px-20 mb-90 lg:px-0">
              {cardsCollection &&
                cardsCollection.length > 0 &&
                cardsCollection.map((card) => (
                  <div key={card.sys} className="">
                    {card.type === 'videoCard' ? (
                      <div className="videoWrap mb-100">
                        <h2
                          className="mb-20 text-24 leading-30 font-neutrafaceDemi text-primary lg:text-30 lg:leading-36"
                          id={generateId(card?.title)}
                        >
                          {card?.title}
                        </h2>
                        <iframe
                          width="100%"
                          height="180"
                          src={card?.url}
                          title="YouTube video player"
                          frameBorder="0"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                          className="test"
                        />
                      </div>
                    ) : (
                      <div>
                        {card.title && (
                          <h2
                            className="mb-20 text-24 leading-30 font-neutrafaceDemi text-primary lg:text-30 lg:leading-36"
                            id={generateId(card?.title)}
                          >
                            {card.title}
                          </h2>
                        )}
                        {card.description && (
                          <Typography
                            content={card?.description}
                            className="mb-20 text-24 leading-30 font-neutrafaceDemi text-primary lg:text-30 lg:leading-36"
                          />
                        )}
                        {card.content && (
                          <Typography
                            content={card.content}
                            className="mb-20 cardDesc text-20 leading-26 font-neutrafaceBook text-secondary"
                          />
                        )}
                        {card.image && (
                          <div className="mb-40">
                            <Image
                              key={card.image.sys}
                              desktopClassName=""
                              wrapperClassName="w-full"
                              desktopImage={card.image}
                              alt={card.image?.altText}
                            />
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}

              <div className="hidden md:block mx-auto w-full mdl:w-5/12 lg:w-lg mxl:w-mxl px-20 lg:px-0 mdl:absolute top-0 mb-15 mdl:right-15p mdl:mt-15p">
                {selectedVariant?.data?.instaCardsCollection &&
                  selectedVariant?.data?.instaCardsCollection.length > 0 && (
                    <ExperienceCard
                      isMobile={false}
                      instaCardsCollection={
                        selectedVariant?.data?.instaCardsCollection
                      }
                    />
                  )}
                <div className="flex mt-30">
                  <span className="font-AvenirLTLight pr-10 text-darkgray text-12">
                    {/* SHARE */}
                  </span>{' '}
                  {labels?.socialShareDetails.map((item) => (
                    <>
                      <Button
                        gaClass="event_social_action"
                        gaLabel={'event_share'}
                        className={'w-10p'}
                        name={item?.label}
                        key={`${item.label}`}
                        onClick={() => {
                          setSocialShareOpenDialog(true)
                          setSelectedSocialShare(item)
                        }}
                      >
                        <Icon name={item?.icon}> </Icon>
                      </Button>
                    </>
                  ))}
                </div>
                {socialShareOpenDialog && (
                  <SocialShare
                    variant="adpSocialDialogContent"
                    socialShareDetails={selectedSocialShare}
                    media={
                      selectedVariant?.data?.instaCardsCollection
                        ?.instaCardsCollection?.url || ''
                    }
                    closeModal={() => {
                      setSocialShareOpenDialog(!socialShareOpenDialog)
                    }}
                  />
                )}
              </div>
              {instaCardsCollection &&
                instaCardsCollection.length > 0 &&
                instaCardsCollection.map((card) => (
                  <div key={card.sys} className="">
                    <div>
                      {card.image && (
                        <div className="mb-40">
                          <Image
                            key={card.image.sys}
                            desktopClassName=""
                            wrapperClassName="w-full"
                            desktopImage={card.image}
                            alt={card.image?.altText}
                          />
                        </div>
                      )}
                    </div>
                    )
                  </div>
                ))}

              {relatedProducts && relatedProducts.length > 0 && (
                <div className="w-full mb-40">
                  <div className="w-full px-20 mx-auto lg:w-lg mxl:w-mxl xl:w-xl lg:px-0 py-60">
                    {' '}
                    <h2>関連製品</h2>
                    <Carousel variant="productCard">
                      {relatedProducts.map((product) => (
                        <ProductCard
                          key={product.sys}
                          locale={locale}
                          {...product}
                          rating={{ value: 0, count: 0 }}
                          variant="pdpProductCard"
                        />
                      ))}
                    </Carousel>
                  </div>
                </div>
              )}
              {indentedCard && indentedCard.description && (
                <Typography
                  content={indentedCard.description}
                  className="pl-24 mt-40 mb-40 border-l-4 border-lightGreyBlue lg:mb-60 text-20 leading-26 font-neutrafaceBook text-secondary"
                />
              )}
              {videoCard && (
                <div className="videoWrap mb-100">
                  <h2
                    className="mb-20 text-24 leading-30 font-neutrafaceDemi text-primary lg:text-30 lg:leading-36"
                    id={generateId(videoCard?.title)}
                  >
                    {videoCard?.title}
                  </h2>
                  <iframe
                    width="100%"
                    height="180"
                    src={videoCard?.url}
                    title="YouTube video player"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="test"
                  />
                </div>
              )}
            </div>
          </div>
          <h2>
            <RelatedArticle relatedArticles={relatedArticles} />
          </h2>
          <h2>
            {' '}
            {recommendedProducts.map((product) => (
              <ProductCard key={product.sys} locale={locale} {...product} />
            ))}
          </h2>
          <div>
            {discoverMoreCard && (
              <div className="w-200 mxl:w-250">
                <Button href={discoverMoreCard.href}>
                  {discoverMoreCard.image && (
                    <div className="mb-15">
                      <Image
                        desktopClassName=""
                        smartphoneClassName=""
                        wrapperClassName="w-full"
                        desktopImage={discoverMoreCard.image}
                        alt={discoverMoreCard.image?.altText}
                      />
                    </div>
                  )}
                  {discoverMoreCard.description && (
                    <Typography
                      content={discoverMoreCard.description}
                      className="text-18 leading-24 font-neutrafaceBook text-secondary"
                    />
                  )}
                </Button>
              </div>
            )}
          </div>
        </div>
        <div className="relative">
          <div className="flex flex-wrap w-full mb-20 featureCardSection mdl:mb-70">
            {featureCards?.map((card, index) => (
              <div
                key={index}
                className="relative w-full featureCards mdl:w-4/12"
              >
                <FeatureCard {...card} variant="LineupfeatureCard" />
              </div>
            ))}
          </div>
        </div>
        <div>
          {/* <Icon
            name={allIcons?.logoWithBorder}
            alt={allIcons?.logoWithBorder}
            className={''}
          /> */}
        </div>
      </div>
    </div>
  )
}

ExperiencePage.propTypes = {
  pageData: PropTypes.shape({
    locale: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    category: PropTypes.string.isRequired,
    bannerImage: PropTypes.array,
    descriptionCard: PropTypes.object,
    relatedArticles: PropTypes.array,
    featureCards: PropTypes.array,
    recommendedProducts: PropTypes.array,
    discoverMoreCard: PropTypes.object,
    videoCard: PropTypes.object,
  }),
}

export default memo(ExperiencePage)
