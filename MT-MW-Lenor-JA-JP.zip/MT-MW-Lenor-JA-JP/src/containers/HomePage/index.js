import React, { memo } from 'react'
import dynamic from 'next/dynamic'
import PropTypes from 'prop-types'

const Icon = dynamic(() => import('@components/Icon'))
const FeatureCard = dynamic(() => import('@components/cards/FeatureCard'))
const Carousel = dynamic(() => import('@components/Carousel/HomePageCarousel'))
const Button = dynamic(() => import('@components/Button'))
const Image = dynamic(() => import('@components/Image'))

const HomePage = ({
  pageData: { banner, featureCards, mobileMenu, bottomImage },
}) => {
  return (
    <div className="home-page-wrapper">
      <div className="">
        <Carousel carouselData={banner} variant="homeGallery" />
      </div>
      <div className="block mdl:hidden">
        {mobileMenu && (
          <ul className="mt-20">
            {mobileMenu.map((menu, index) => {
              return (
                <li
                  key={index}
                  className="p-15 bg-lightgray text-primaryblue text-18 font-hiraginoGothicProParis mb-5 font-bold leading-35"
                >
                  <Button href={menu.url} gaClass="event_internal_link">
                    <div className="flex justify-between items-center">
                      {menu.title}
                      <Icon name="RightMenuArrowMobile" className="w-10" />
                    </div>
                  </Button>
                </li>
              )
            })}
          </ul>
        )}
      </div>
      <div className="relative m-auto mdl:bg-bodybg mdl:bg-bottom mdl:-mt-1 pt-15 mdl:pt-30">
        <div className="featureCardSection flex flex-wrap mdl:w-940 px-20 mdl:px-0 m-auto mb-20 mdl:mb-70">
          {featureCards?.map((card, index) => (
            <div
              key={index}
              className="featureCards w-full mdl:w-30p relative border rounded-lg mb-20 mdl:mr-20 h-fit"
            >
              <FeatureCard {...card} variant="HomefeatureCard" />
            </div>
          ))}
        </div>
        {bottomImage && (
          <div className="m-auto py-20 mdl:py-0 mdl:w-50p">
            <Image
              desktopClassName="hidden mdl:block"
              smartphoneClassName="block mdl:hidden"
              desktopImage={bottomImage.desktopImage}
              smartphoneImage={bottomImage.smartphoneImage}
            />
          </div>
        )}
      </div>
    </div>
  )
}

HomePage.propTypes = {
  banner: PropTypes.array,
  featureCards: PropTypes.array,
}

export default memo(HomePage)
