import React from 'react'
import { useRouter } from 'next/router'

const FallbackPage = (Component) => {
  const HOCComponent = (props) => {
    const router = useRouter()
    return router.isFallback || Object.keys(props).length === 0 ? (
      <div>Loading...</div>
    ) : (
      <Component {...props} />
    )
  }
  return HOCComponent
}

export default FallbackPage
