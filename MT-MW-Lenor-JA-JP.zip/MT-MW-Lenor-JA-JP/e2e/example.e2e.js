import { page, puppeteerInit } from '../config/puppeteer-config'

describe('MW-seed Example', () => {
    puppeteerInit()

    it('should display "mw-seed" text on page', async () => {
        await expect(page).toMatch('mw-seed')
    })
})