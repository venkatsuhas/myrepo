# Seed of  Modern Web (MW) project using Next.js framework
Opinionated kick starter for MW projects on Next.js framework. Consist of useful  features, tricks  & configurations that boost start of development process.

## Features included
For information about MW and the features it provides please follow this [link](https://mw-wiki.pg.com) and read more on the topic.

## Getting Started
1. In order to use locally @MW packages (like @mw/image and @mw/video) you need to connect to private npm feed. To do so, set up authentication by following [this guide](https://docs.microsoft.com/en-us/azure/devops/artifacts/npm/npmrc?view=azure-devops&tabs=windows#set-up-authentication-on-your-dev-box)
1. Fill in placeholders in package.json
    - `--author--`
    - `--project_name--`
1. Create `.env` file in the project root and fill in the required environment variables according to [doc](./docs/environment-variables.md)
1. Run `npm install`  to install dependencies
1. Create Labels architecture in Contentful:
    1. Ensure you have defined all [contentful environment variables](./docs/environment-variables.md#Contentful)
    1. Run `npm migrate-labels-architecture`
        1. By default, upload is made to contentful `master` if `CF_ENVIRONMENT` environmental variable is not defined.
1. Run `npm run dev` to launch the project in development SSR mode and start coding
1. Open `localhost:PORT` to see the project website
1. Setup CI/CD (see [Azure Pipelines](./docs/azure-pipelines.md))
1. Setup tests (see [Tests](./docs/tests.md))
1. Setup/request [monitoring alerts](./docs/monitoring.md#Alerts)
1. Adjust the README.md

## Troubleshooting
>`E401 Unable to authenticate` error while running `npm install`:

Visit https://pg-consumer.visualstudio.com/MW-Framework/_packaging?_a=connect&feed=ModernWeb and follow the steps for npm authentication.

## Roadmap
- Provisioning of cloud resources from pipelines using approved ARM templates

## Release to operations

## Environment details
|Environment|Azure URL|Website URL|
|---|---|---|
|PROD|||
|QA|||
|PREVIEW|||

## Available features in website
|Features/Pages|Scope (Y/N)|Comments|
|---|---|---|
|Home Page|| |
|Preference Center Pages (Login/Registration) - Janrain|||
|Buynow Lite/Price Spider|| |
|Ratings & Reviews|| |
|Product Collection Pages|| |
|Shop Products Landing|| |
|Product Category|| |
|Product Sub-Category|||
|Product Compare Feature|| |
|Products|||
|Facet Group|| |
|Product Variation Selection|| |
|Article landing|| |
|Article Category|| |
|Article Detail|| |
|Offers & Promo Landing|| |
|Offers & Promo Detail|| |
|Brand Experience Landing|| |
|Brand Experience Topics|| |
|Brand Experience Detail|| |
|Search Results Page|| |
|Chat Bot/Proactive Chat|| |
|Store Locator|| |
|Country Selector|| |
|GCR Widget|| |

## Link to the designs
Designs:

## Stakeholder contacts
|Topics|Vendor|Point of Contact|
|---|---|---|
|Brand|P&G||
|Creative Agency|||
|Tech Lead (development)|||

## Thirdparty tools used
|Thirdparty tool|Production|QA|Dev|Comments|Details|
|---|---|---|---|---|---|
|Bazaar Voice| | | | |Provide API URL and Passkey details|
|Janrain| | | | |Provide App Url, Server Url, App Id, Client id, Client key, flow name, flow version, owner id, owner key|
|Swiftype| | | | |Provide API URL, Auth token, Engine key and Engine name details|
|Contentful| | | | |Provide Space id and access token details|
|Cloudinary| | | | |Provide Cloudinary URL|
|BuyNowLite/PriceSpider| | | | |Provide API URL and Passkey details|
