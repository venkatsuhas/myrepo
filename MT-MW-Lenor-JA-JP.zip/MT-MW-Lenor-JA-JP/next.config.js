module.exports = {
  reactStrictMode: true,
  compress: true,
  images: {
    disableStaticImages: true,
    domains: ['images.ctfassets.net'],
    formats: ['image/avif', 'image/webp'],
  },
  redirects: async () => [
    {
      source: '/',
      destination: '/ja-jp',
      permanent: true,
    },
  ],
  async rewrites() {
    return [
      {
        source: '/sitemap.xml',
        destination: '/api/sitemap.xml',
      },
      {
        source: '/robots.txt',
        destination: '/api/robots.txt',
      },
    ]
  },
  swcMinify: true,
  trailingSlash: false,
  env: {
    CF_SPACE_ID: process.env.CF_SPACE_ID,
    CF_ENVIRONMENT: process.env.CF_ENVIRONMENT,
    CF_DELIVERY_ACCESS_TOKEN: process.env.CF_DELIVERY_ACCESS_TOKEN,
    CF_PREVIEW_ACCESS_TOKEN: process.env.CF_PREVIEW_ACCESS_TOKEN,
    DOMAIN: process.env.DOMAIN,
    PORT: process.env.PORT,
    SITE_LANG: process.env.SITE_LANG,
    COUNTRY: process.env.PS_COUNTRY,
    LANGUAGE: process.env.PS_LANGUAGE,
    GTM_ID: process.env.GTM_ID,
    SITE_ENV: process.env.SITE_ENV,
    SITE_HOST: process.env.SITE_HOST,
    SITE_TA: process.env.SITE_TA,
    SITE_LC: process.env.SITE_LC,
    GA_ID: process.env.GA_ID,
    GA_ID_STAGING: process.env.GA_ID_STAGING,
    ADCHOICE: process.env.ADCHOICE,
    ADCHOICE_ID: process.env.ADCHOICE_ID,
    EVIDON_OVERLAY: process.env.EVIDON_OVERLAY,
    EVIDON_OVERLAY_ID: process.env.EVIDON_OVERLAY_ID,
    GA_DISABLED: process.env.GA_DISABLED,
    ALGOLIA_APP_ID: process.env.ALGOLIA_APP_ID,
    ALGOLIA_READ_KEY: process.env.ALGOLIA_READ_KEY,
    ALGOLIA_WRITE_KEY: process.env.ALGOLIA_WRITE_KEY,
    ALGOLIA_PRODUCT_INDEX_ID: process.env.ALGOLIA_PRODUCT_INDEX_ID,
    ALGOLIA_ARTICLE_INDEX_ID: process.env.ALGOLIA_ARTICLE_INDEX_ID,
  },
}
