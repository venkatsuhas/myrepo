"use strict";
var mon = require('mongoose');
// import mon from 'mongoose';
var reviewSchema = new mon.Schema({
    book_id: {
        type: String,
    },
    username: {
        type: String,
    },
    review: {
        type: String,
    },
    rating: {
        type: Number,
    },
});
module.exports = mon.model('review', reviewSchema);
