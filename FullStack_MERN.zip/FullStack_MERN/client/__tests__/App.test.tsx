import App from '../App';

describe(`App Component`,()=>{
    it (`should not regress`,()=>{
        expect(2+2).toBe(4);
    })
})