import express from 'express';
// import mongoose from 'mongoose';
import User from './registratonSchema';
// import Otp from './otpSchema'
// const Otp = require('./otpSchema')
import jwt from 'jsonwebtoken';
import { getAllUsers,setRoles } from './loginController';
export const userRouter = express.Router()

const accountSid = "AC07b9d1e3b64bf09a98dafac19369d5c6";
const authToken = "b4f93e93b70c463e164d4797a4ccfd94";
const client = require('twilio')(accountSid, authToken);

userRouter.get('/',getAllUsers)
userRouter.patch('/:username',setRoles)

// function authorize(admin:any){
//     let users = User.findOne({roles:admin})
//     if(users){
//     return authenticate
//     }else{
//         return 0;
//     }
// }
userRouter.post('/login', async (req: any, res: any) => {
    const username = req.body.username;
    const password = req.body.password;
    if (username && password) {
        try {
            const userData = await User.findOne({ username: username, password: password })
            if (userData) {
                // console.log("line:20");
                
                otpGenerator(req, res);
                // const user={username:username,password:password}
                // const token=jwt.sign(user,"suhas007");
                // res.json(token);
                //send a jwt token to client containing encrypted otp and expiery date.call a ticket
                // res.status(200).json("logged In")
            } else {
                res.status(401).json("Invalid")
            }
        }
        catch (err) {
            res.send("Error" + err)
        }
    }
})

function otpGenerator(req: any, res: any) {

    // userRouter.post('/sendOTP', (req: any, res: any) => {
        const username = req.body.username;
        console.log(username+"nene");
        const otp = Math.floor(100000 + Math.random() * 900000).toString()
        const ttl = 2 * 60 * 60
        const expires = Date.now() + ttl;
        // console.log(expires);
        
        // const data = `${phone}.${otp}.${expires}`

        client.messages.create({
            body: `your OneTime Login Password is ${otp}`,
            from: +17046120688,
            to: +919490202969,
        }).then(async(msg: any) =>await User.updateOne({"otp":otp,"time":expires}) ).catch((err: any) => console.error(err))
        //send a ticket which is a jwt token containing otp and ticket
        const verified = {"otp":otp,"time":expires,"username":username}
        const encry = jwt.sign(verified,"suhas");
        console.log(verified+"username1");
        
        res.status(200).send({ msg: "otp sent",ticket:encry})
    // })
}

userRouter.post('/otpverification',ticketverify,async(req:any,res:any,next:any)=>{
    //req.body should contain otp and ticket
    const Otp = req.body.otp;
    // console.log(typeof Otp+" 79");
    const ticket = req.body.ticket;
    // console.log(typeof req.ticket.otp+" 82");
    if(ticket){
        try{
                    // if(req.ticket.otp===req.body.otp){
                        console.log("verification");
                        
                    const authData = {otp:Otp}
                    const token=jwt.sign(authData,"suhas007");
                    // console.log(token);
                    // console.log(User.username+"username")
                    res.status(200).json({token:token,username:req.ticket.username});
                    // }
        }catch(err){
            console.log(err);
            
        }
    }else{
        res.status(403).json("Wrong Otp");
    }
})
export function ticketverify(req:any,res:any,next:any){
    const ticket = req.body.ticket;

    jwt.verify(ticket, "suhas", (err: any, ticketData: any) => {
        if (err) {
            return res.status(403).json("wrong ticket:" + err.message);
        }
        // console.log("ticketData",ticketData);
        
        req.ticket = ticketData;
        next();
    })
}

export function authenticate(req: any, res: any, next: any) {
    const header = req.header("Authorization")
    console.log(header);
    
    const token = header && header.split(' ')[1];
    console.log(token);
    

    if (token == null) {
        return res.sendStatus(401);
    }
    jwt.verify(token, "suhas007", (err: any, user: any) => {
        if (err) {
            if (err.name === "TokenExpiredError") {
                return res.status(401).json("Session Expired...Please Login Again!")
            }
            return res.status(403).json("SomeThing Went Wrong:" + err.message);
        }
        console.log("authentication middleware",user);
        
        req.user = user;
        next();
    })
}


userRouter.post('/registration', async (req: any, res: any) => {
    const newUser = new User(req.body)
    try {
        const u1 = await newUser.save()
        res.json(u1)
    } catch (e:any) {
        res.status(500).send({message:e.messsage})
    }
})


