import book from './bookModel'


export const getAllAuthors=async(req:any,res:any)=>{
    try{
        let books = await book.distinct('author')
        console.log(books);
        
        res.send(books)
    }catch(err){
        res.send("error")
    }
}