function greet(name) {
    console.log(`Hello ${name}`);
}

function higherOrderFunction(callback) {
    const name = 'Suhas'
    callback(name)
}

higherOrderFunction(greet)