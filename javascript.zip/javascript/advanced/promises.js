const promise = new Promise((resolve,reject)=>{
    const x = 17;
    setTimeout(()=>{
        if(x>=18)
        resolve("Eligible")
        else
        reject("Not Eligible")
    },3000)
})

promise.then((msg)=>{console.log(msg);})
.catch((msg)=>{console.log(msg);})