function Parent() {
    this.value=2
    method= function () {
      return this.value + 1;
    }
  };
  
  Parent.prototype.getValue=function(){
    return this.value
  }

  const hero = new Parent();

  console.log(hero.getValue()+" parent");

  function Child (){
    // __proto__: Parent
    Parent.call(this);
    // this.value=6;
  };
  Child.prototype=Object.create(Parent.prototype)

  const lable = new Child()
  Child.prototype.constructor = Child
  console.log(lable.getValue()+" child");
