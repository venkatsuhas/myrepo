const fun=(a)=>{
return fun1=(b)=>{
return fun2=(c)=>{
    return a+b+c
}
}
}
console.log(fun(3)(5)(7));