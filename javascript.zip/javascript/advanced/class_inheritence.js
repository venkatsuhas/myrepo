class Person{
    constructor(fName,lName){
        this.fName=fName
        this.lName=lName
    }

    sayMyName(){
        return this.fName+" "+this.lName
    }
}

const classP1 = new Person('suhas','nunepalli')
console.log(classP1.sayMyName());

class SuperHero extends Person{
    constructor(fName,lName){
        super(fName,lName)
    }
}

const batman = new SuperHero('suahs','nunepalli')
console.log(batman.fName);