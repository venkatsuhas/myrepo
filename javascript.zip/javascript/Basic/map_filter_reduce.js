let a = [2,6,8,5,4]
let a1 = a.map((value)=>{return value*=2})
console.log(a1,a);

let a2 = a.filter((value)=>{return value>=2})
console.log(a2,a);

let a3 = a.reduce((c1,c2)=>{return c1*c2})
console.log(a3,a);