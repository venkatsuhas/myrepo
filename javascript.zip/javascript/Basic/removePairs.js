
// JavaScript implementation of the above approach

// Function to remove adjacent duplicates
	function removeDuplicates( S) {
		var ans = "";

		// Iterate for every character
		// in the string
		for (i = 0; i < S.length; i++) {

			// If ans string is empty or its last
			// character does not match with the
			// current character then append this
			// character to the string
			if (ans.length==0 ||
			ans.charAt(ans.length - 1) != S.charAt(i))
				ans += S.charAt(i);

			// Matches with the previous one
			else if (ans.charAt(ans.length - 1) == S.charAt(i))
				ans = ans.substring(0, ans.length - 1);
		}

		// Return the answer
		return ans;
	}

	// Driver Code
	
		var str = "keexxllx";
		document.write(removeDuplicates(str));

// This code contributed by Rajput-Ji

