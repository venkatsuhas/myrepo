let myString = 'abababc';
let result = {};
for(i=0;i<myString.length;i++){
    for(j=i+1;j<=myString.length;j++){
        if(myString[i]===myString[j]){
            result[myString[i]]=result[myString[i]]?result[myString[i]]+1:1;
        }
    }
}
console.log(result);










// let myString = 'abababc';
// let result = {};
// for (let str of myString) {
//   result[str] = result.hasOwnProperty(str) ? result[str] + 1 : 1;
// }
// console.log(result);













// var obj={}
// var repeats=[];
// str='banana'

// for(x = 0, length = str.length; x < length; x++) {
//     var l = str.charAt(x)
//     console.log(obj[l]);
//     console.log(isNaN(obj[l]));
//     obj[l] = (isNaN(obj[l]) ? 1 : obj[l] + 1);
// }

// console.log(obj)