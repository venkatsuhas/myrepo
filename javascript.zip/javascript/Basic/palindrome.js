// program to check if the str is palindrome or not
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function checkPalindrome(str) {
// console.log(str);
    // find the length of a str
    const len = str.length;

    // loop through half of the str
    for (let i = 0; i < len / 2; i++) {

        // check if first and last str are same
        if (str[i] !== str[len - 1 - i]) {
            return 'It is not a palindrome';
        }
    }
    return 'It is a palindrome';
}

// take input
const string = rl.question('Enter a string: ',function (string){
    const value = checkPalindrome(string);
    console.log(value);
    rl.close();

});

// call the function
