const fs = require('fs')

const generateSSGWebConfig = () => {
    const webConfig = `<?xml version="1.0" encoding="utf-8"?>
    <configuration>
      <system.web>
        <httpCookies httpOnlyCookies="true" requireSSL="true" lockItem="true" />
      </system.web>
      <system.webServer>
        <urlCompression doStaticCompression="true" doDynamicCompression="true" />
        <security>
          <requestFiltering removeServerHeader="true" />
        </security>
        <httpRedirect configSource="httpRedirects.config" />
        <defaultDocument enabled="true"></defaultDocument>
        <rewrite>
          <rules>
            <rule name="Remove trailing slash" stopProcessing="true">
              <match url="(.*)/$" />
              <action type="Redirect" redirectType="Permanent" url="{R:1}" />
            </rule>
            <rule name="Abort for Folders" stopProcessing="true">
              <match url="^(.*)" ignoreCase="true" />
              <conditions>
                <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
                <add input="{REQUEST_FILENAME}" matchType="IsDirectory" />
                <add input="{REQUEST_FILENAME}.html" matchType="IsFile" negate="true" />
                <add input="{REQUEST_URI}" pattern="^/$" negate="true" />
              </conditions>
              <action type="CustomResponse" statusCode="404" />
            </rule>
            <rule name="Hide .html extension" stopProcessing="true">
              <match url="^(.*)" ignoreCase="true" />
              <conditions>
                <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
                <add input="{REQUEST_FILENAME}.html" matchType="IsFile" />
                <add input="{REQUEST_URI}" pattern=".*404$" negate="true" />
              </conditions>
              <action type="Rewrite" url="{R:0}.html" />
            </rule>
            <rule name="Redirecting .html ext" stopProcessing="true">
              <match url="^(.*).html" />
              <conditions logicalGrouping="MatchAny">
                <add input="{URL}" pattern="(.*).html" />
              </conditions>
              <action type="Redirect" url="{R:1}" />
            </rule>
          </rules>
          <outboundRules>
            <rule name="Add Strict-Transport-Security when HTTPS" enabled="true">
              <match serverVariable="RESPONSE_Strict_Transport_Security" pattern=".*" />
              <conditions>
                <add input="{HTTPS}" pattern="on" ignoreCase="true" />
              </conditions>
              <action type="Rewrite" value="max-age=31536000" />
            </rule>
            <rule name="RewriteCacheControlForHTMLFiles" preCondition="FileEndsWithHtml">
              <match serverVariable="RESPONSE_Cache_Control" pattern=".*" />
              <action type="Rewrite" value="max-age=0" />
            </rule>
            <rule name="RewriteCacheControlForJSFiles" preCondition="FileEndsWithJS">
              <match serverVariable="RESPONSE_Cache_Control" pattern=".*" />
              <action type="Rewrite" value="public, max-age=31536000,immutable" />
            </rule>
            <rule name="RewriteCacheControlForCSSFiles" preCondition="FileEndsWithCSS">
              <match serverVariable="RESPONSE_Cache_Control" pattern=".*" />
              <action type="Rewrite" value="public, max-age=31536000,immutable" />
            </rule>
            <preConditions>
              <preCondition name="FileEndsWithJS">
                  <add input="{REQUEST_FILENAME}" pattern="\\.js$" />
              </preCondition>
              <preCondition name="FileEndsWithHtml">
                  <add input="{REQUEST_FILENAME}" pattern="\\.html$" />
              </preCondition>
              <preCondition name="FileEndsWithCSS">
                  <add input="{REQUEST_FILENAME}" pattern="\\.css$" />
              </preCondition>
              <preCondition name="FileEndsWithTTF">
                  <add input="{REQUEST_FILENAME}" pattern="\\.ttf$" />
              </preCondition>
              <preCondition name="FileEndsWithWoff">
                  <add input="{REQUEST_FILENAME}" pattern="\\.woff$" />
              </preCondition>
              <preCondition name="FileEndsWithWoff2">
                  <add input="{REQUEST_FILENAME}" pattern="\\.woff2$" />
              </preCondition>
              <preCondition name="FileEndsWithMAP">
                  <add input="{REQUEST_FILENAME}" pattern="\\.map$" />
              </preCondition>
            </preConditions>
          </outboundRules>
        </rewrite>
        <staticContent>
          <remove fileExtension=".js" />
          <mimeMap fileExtension=".js" mimeType="text/javascript"/>
          <remove fileExtension=".json" />
          <mimeMap fileExtension=".json" mimeType="application/json"/>
          <remove fileExtension=".html" />
          <mimeMap fileExtension=".html" mimeType="text/html"/>
          <remove fileExtension=".aspx" />
          <mimeMap fileExtension=".aspx" mimeType="text/html"/>
          <remove fileExtension=".ttf" />
          <mimeMap fileExtension=".ttf" mimeType="font/ttf"/>
          <remove fileExtension=".woff" />
          <mimeMap fileExtension=".woff" mimeType="application/font-woff"/>
          <remove fileExtension=".woff2" />
          <mimeMap fileExtension=".woff2" mimeType="font/woff2"/>
          <remove fileExtension=".map" />
          <mimeMap fileExtension=".map" mimeType="application/json"/>
          <remove fileExtension=".otf" />
          <mimeMap fileExtension=".otf" mimeType="font/otf"/>
          <remove fileExtension=".svg" />
          <mimeMap fileExtension=".svg" mimeType="image/svg+xml" />
        </staticContent>
        <httpProtocol>
          <customHeaders>
            <remove name="Strict-Transport-Security" />
            <remove name="X-Content-Type-Options" />
            <remove name="X-Frame-Options" />
            <remove name="X-XSS-Protection" />
            <remove name="Cache-Control" />
            <remove name="Content-Security-Policy" />
            <remove name="X-Powered-By" />
            <add name="Strict-Transport-Security" value="max-age=31536000; includeSubdomains" />
            <add name="X-Content-Type-Options" value="nosniff" />
            <add name="X-Frame-Options" value="DENY" />
            <add name="X-XSS-Protection" value="1;mode=block" />
          </customHeaders>
        </httpProtocol>
        <httpErrors errorMode="Custom">
          <clear />
          ${[401,403,404,411,500,501].map((code)=>`<remove statusCode="${code}" subStatusCode="-1"/>
          <error statusCode="${code}" path="${code !== 404?'/404':'404.html'}" ${code !== 404?'responseMode="Redirect"':''} />`).join('')}
        </httpErrors>
      </system.webServer>
      <location path="static/images/favicon.ico">
        <system.webServer>
          <staticContent>
            <clientCache cacheControlCustom="public" cacheControlMode="UseMaxAge" cacheControlMaxAge="365.00:00:00" />
          </staticContent>
        </system.webServer>
      </location>
      <location path="_next/static/css">
        <system.webServer>
          <staticContent>
            <clientCache cacheControlMode="UseMaxAge" cacheControlMaxAge="30.00:00:00" />
          </staticContent>
        </system.webServer>
      </location>
      <location path="_next/static/chunks">
        <system.webServer>
          <staticContent>
            <clientCache cacheControlMode="UseMaxAge" cacheControlMaxAge="30.00:00:00" />
          </staticContent>
        </system.webServer>
      </location>
    </configuration>`

    fs.writeFileSync(`out/web.config`, webConfig)
}

module.exports = generateSSGWebConfig
