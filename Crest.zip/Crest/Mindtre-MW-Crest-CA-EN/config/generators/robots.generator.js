const fs = require("fs")
const { robots } = require("package.json")
const { DOMAIN } = process.env
import { locales } from "@constants"

const formattedString = (s) => {
    s = s.replace(/([A-Z])/g, "-$1").trim()
    s = s.replace(/^./, s[0].toUpperCase())
    return s
}

export const createRobots = (dev) => {
    let robotsEnv = robots.prod

    if (dev) {
        robotsEnv = robots.dev
    }

    const generatedRobots = Object.keys(robotsEnv).map((config) => robotsEnv[config].map((configValue) => `${formattedString(config)}: ${configValue}`))

    generatedRobots.push(`Sitemap: ${DOMAIN}/${locales.english.toLowerCase()}/sitemap.xml`)
    generatedRobots.push(`Sitemap: ${DOMAIN}/${locales.french.toLowerCase()}/sitemap.xml`)
    return generatedRobots.toString().replace(/,/g, "\n")
}

const generateRobots = () => {
    fs.writeFileSync(`out/robots.txt`, createRobots(process.env.DEPLOYMENT !== 'production'))
    console.info("Robots.txt Created")
}

export default generateRobots
