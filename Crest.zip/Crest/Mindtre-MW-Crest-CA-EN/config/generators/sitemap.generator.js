const fs = require("fs")
require("dotenv").config()
const { DOMAIN } = process.env
const formatDate = require("@helpers/dateFormat.helper")

const locales = ["en-ca", "fr-ca"]

const getAllPaths = () => {
    const fileObj = []
    const walkSync = (directory) => {
        const files = fs.readdirSync(directory)
        files.forEach((file) => {
            let filePath = `${directory}${file}`
            const fileStats = fs.statSync(filePath)
            if (directory != "out/static/" && fileStats.isDirectory()) {
                if (filePath != "out/404") walkSync(`${filePath}/`)
            } else {
                if (file.endsWith(".html") && file != "404.html" && !file.match('writereview') && !file.match('search')) {
                    filePath = filePath.replace(`out`, "")
                    filePath = filePath.replace(
                        /\/index.html|index.html|.html/gi,
                        ""
                    )
                    fileObj.push({
                        path: filePath,
                        locale: filePath.split("/")[1],
                        lastModified: fileStats.mtime,
                    })
                }
            }
        })
    }
    walkSync(`out/`)
    return fileObj
}

const generateSitemap = async () => {
    const allPaths = getAllPaths()

    locales.map((locale) => {
        const hrefMapper = require(`../data/${locale}.json`)
        //Fetching the hreflangs based on the locale
        const currentLocalePaths = allPaths
            .filter((pathObject) => pathObject.path !== "" && pathObject.locale === locale)

        //Sorting based on the path length
        currentLocalePaths.sort((firstUrl, secondUrl) => firstUrl.path.length - secondUrl.path.length)

        //Sorting based on the locale
        const xmlString = currentLocalePaths.reduce((currentString, pathObject) => {
            const url = pathObject.path
            const lastModified = formatDate(new Date(pathObject.lastModified))
            const hrefLangObject = hrefMapper[url]
            return `${currentString}
            <url>
            <loc>${DOMAIN}${url}</loc>
            <lastmod>${lastModified}</lastmod>
            ${hrefLangObject?.enCA?.replace('https://ca.crest.com',DOMAIN)||''}
            ${hrefLangObject?.frCA?.replace('https://ca.crest.com',DOMAIN)||''}
            ${hrefLangObject?.enUS||''}
            </url>`
        },'')

        const sitemapXml =
            `<?xml version="1.0" encoding="UTF-8"?>
            <urlset xmlns="https://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="https://www.w3.org/1999/xhtml" xmlns:mobile="https://www.google.com/schemas/sitemap-mobile/1.0" xmlns:image="https://www.google.com/schemas/sitemap-image/1.1" xmlns:video="https://www.google.com/schemas/sitemap-video/1.1">` +
            `${xmlString}
            </urlset>`
        if (!fs.existsSync(`./out`)) {
            fs.mkdirSync(`./out`)
        }
        if (!fs.existsSync(`./out/${locale}`)) {
            fs.mkdirSync(`./out/${locale}`)
        }
        fs.writeFileSync(`out/${locale}/sitemap.xml`, sitemapXml?.replace(/ {12}/g,'').replace(/^\s*\n/gm, "") )
    })

    console.info("Sitemap.xml Created")
}

export default generateSitemap
