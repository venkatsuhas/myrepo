import generateSitemap from '@config/generators/sitemap.generator'
import generateRobots from '@config/generators/robots.generator'
import generateHttpRedirects from '@config/generators/httpRedirects.generator'
import generateSSGWebConfig from '@config/generators/ssg-web.config.generator'
import generateSSRWebConfig from '@config/generators/ssr-web.config.generator'
const fs = require('fs')

module.exports = {
    generateSSGConfigs:()=>{
        generateRobots()
        generateSitemap()
        generateHttpRedirects()
        generateSSGWebConfig()
        if(fs.existsSync('out/404.html.html')){
            fs.unlink('out/404.html.html',(err)=>{
                if(err) return console.error(err)
                console.info('404.html.html deleted successfully')
            })
        }

    },
    generateSSRConfigs:()=>{
        generateSSRWebConfig()
    }
}
