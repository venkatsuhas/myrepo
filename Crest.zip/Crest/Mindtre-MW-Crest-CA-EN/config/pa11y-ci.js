require('dotenv').config()
const { spawn } = require('child_process')

const domain = process.env.domain
const PORT = process.env.PORT || 3000

spawn(`pa11y-ci --sitemap ${'http://localhost:'+PORT+'/sitemap.xml'} --sitemap-find ${domain} --sitemap-replace ${'http://localhost:'+PORT} --json > pa11y-report.json`, { shell: true })
