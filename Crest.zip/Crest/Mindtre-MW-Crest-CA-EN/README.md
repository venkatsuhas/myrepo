# Seed of Modern Web (MW) project using Next.js framework
Opinionated kick starter for MW projects on Next.js framework. Consist of useful  features, tricks  & configurations that boost start of development process.

## More information on Seed Project
For information about MW Seed Project please follow this [link](https://mw-wiki.pg.com/tech-stack/cg/mw-seed) and read more on the topic.
## Release to operations

## Environment details
| Environment  |                                            URL                                                        |
| -------------| ----------------------------------------------------------------------------------------------------- |
| Production   | [https://prod-ca.crest.com](https://prod-ca.crest.com)                                                |
| Canary       | [https://crest-ca-en-prod-canary.azurewebsites.net](https://crest-ca-en-prod-canary.azurewebsites.net)|
| Preview      | [https://preview-ca.crest.com](https://preview-ca.crest.com)                                          |
| Staging      | [https://stage-ca.crest.com](https://stage-ca.crest.com)                                              |
| Development  | [https://dev-ca.crest.com](https://dev-ca.crest.com)                                                  |


## Available features in website
|Features/Pages                                        |Scope (Y/N)|Comments         |
|------------------------------------------------------|-----------|-----------------|
|Home Page                                             |     Y     |                 |
|Preference Center Pages (Login/Registration) - Janrain|     N     |                 |
|Buynow Lite/Price Spider                              |     Y     |                 |
|Ratings & Reviews                                     |     Y     |                 |
|Product Collection Pages                              |     Y     |                 |
|Shop Products Landing                                 |     Y     |                 |
|Product Category                                      |     Y     |                 |
|Product Sub-Category                                  |     N     |                 |
|Product Compare Feature                               |     N     |                 |
|Products                                              |     Y     |                 |
|Facet Group                                           |     Y     |                 |
|Product Variation Selection                           |     Y     |                 |
|Article landing                                       |     Y     |                 |
|Article Category                                      |     Y     |                 |
|Article Detail                                        |     Y     |                 |
|Offers & Promo Landing                                |     Y     |                 |
|Offers & Promo Detail                                 |     N     |                 |
|Brand Experience Landing                              |     N     | Not Migrated    |
|Brand Experience Topics                               |     N     |                 |
|Brand Experience Detail                               |     N     |                 |
|Search Results Page                                   |     Y     |                 |
|Chat Bot/Proactive Chat                               |     N     |                 |
|Store Locator                                         |     Y     | In Price Spider |
|Country Selector                                      |     Y     |                 |
|GCR Widget                                            |     N     |                 |

## Link to the designs
Designs:
[LINK 1](https://xd.adobe.com/view/1556b68b-8aee-4ad8-bc42-481a98dfda7f-4005/)
[LINK 2](https://xd.adobe.com/view/43e94ccf-c63d-4123-adbc-3824d21eaf53-16ba/)
Link 2 takes is to be consider if a design is present in both Link 1 and Link 2

## Stakeholder contacts
| Topics            | Vendor         | Point of Contact                                     |
| ----------------- | -------------- | ---------------------------------------------------- |
| Brand             | P&G            | Kerry James  <james.k@pg.com>                        |
| Creative Agency   | PGOne          | Claire Standridge <claire.standridge@saatchi.com>    |
| Technical Agency  | Mindtree       | Alex Xavier <alex.xavier@mindtree.com>               |
| SEO               | Mindtree       | Sabitha Chittibabu <Sabitha.Chittibabu@mindtree.com> |

## Thirdparty tools used
| Thirdparty tool      | Production      | Dev                | Details |
| -------------------- | --------------- | ------------------ | ------- |
| Algolia              | ```{ PRODUCT_INDEX:"crest_ca_prod_product", ARTICLE_INDEX: "crest_ca_prod_article" }``` | ```{ PRODUCT_INDEX:"crest_ca_dev_product", ARTICLE_INDEX: "crest_ca_dev_article" }``` | ```{ WRITE_KEY: "06a0e9d37ed0b1f2a4429837a628c52d", READ_KEY: "c44429703888cb8bb2e5ca83d51e84dc", APP_ID:"CF2Y2BS7NE" }``` |
| BuyNow               ||| ```{ ClientId: "1766", WidgetId: "610acdfc56f66e001f1ebbb9" }``` |
| BazaarVoice          | ```{ EN_CA: "s8nyq8wqtrjzv5wksgfxzyjx", FR_CA: "fpun2xyg55kzhfv5kexepwcr" }``` |  ```{ EN_CA: "2grb6urjrum4szorsyyv5l9vn", FR_CA: "2bsks7lxy9t81h0cd53ksfqn5" }``` |||
| Contentful           ||| ```{ "Space ID": "kyl4ub5sv0it" }``` |
| Cloudinary           ||| ```{ "Folder" : "Crest_CA_MW" }```  |
