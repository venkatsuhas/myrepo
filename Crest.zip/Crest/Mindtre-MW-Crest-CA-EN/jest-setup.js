import Enzyme from 'enzyme'
import Adapter from '@wojtekmaj/enzyme-adapter-react-17'

Enzyme.configure({ adapter: new Adapter() })

jest.mock('next/dynamic', () => (callback) => {
    if(typeof callback === 'function'){
        callback()
        return ()=>null
    }else{ 
        const DynamicComponent = () => null
        DynamicComponent.displayName = 'LoadableComponent'
        DynamicComponent.preload = jest.fn()
        return DynamicComponent
    }
})