const nextConfig = {
    compress: true,
    images: {
        disableStaticImages: true,
        loader: 'cloudinary',
        path: 'https://res.cloudinary.com/mtree',
        imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
        deviceSizes: [320, 375, 480, 640, 750, 828, 1080, 1200, 1920, 2048]
    },
    redirects: async () => [
        {
            source: '/',
            destination: '/en-ca',
            permanent: true,
        },
    ],
    trailingSlash: false,
    reactStrictMode: true,
    env: {
        CF_SPACE_ID: process.env.CF_SPACE_ID,
        CF_ENVIRONMENT: process.env.CF_ENVIRONMENT,
        CF_DELIVERY_ACCESS_TOKEN: process.env.CF_DELIVERY_ACCESS_TOKEN,
        CF_PREVIEW_ACCESS_TOKEN: process.env.CF_PREVIEW_ACCESS_TOKEN,
        CF_PREVIEW: process.env.CF_PREVIEW,
        CLOUDINARY_FOLDER: process.env.CLOUDINARY_FOLDER,
        BV_LOADER_URL: process.env.BV_LOADER_URL,
        BV_ENCODING_KEY: process.env.BV_ENCODING_KEY,
        BV_ENCODING_KEY_EN_CA: process.env.BV_ENCODING_KEY_EN_CA,
        BV_ENCODING_KEY_FR_CA: process.env.BV_ENCODING_KEY_FR_CA,
        ALGOLIA_APP_ID: process.env.ALGOLIA_APP_ID,
        ALGOLIA_READ_KEY: process.env.ALGOLIA_READ_KEY,
        ALGOLIA_PRODUCT_INDEX_ID: process.env.ALGOLIA_PRODUCT_INDEX_ID,
        ALGOLIA_ARTICLE_INDEX_ID: process.env.ALGOLIA_ARTICLE_INDEX_ID,
        PS_CLIENT_ID: process.env.PS_CLIENT_ID,
        PS_WIDGET_ID: process.env.PS_WIDGET_ID,
        
        DOMAIN: process.env.DOMAIN,
        AZURE_INSTRUMENTATION_KEY: process.env.AZURE_INSTRUMENTATION_KEY,
        DEPLOYMENT:process.env.DEPLOYMENT,

        SITE_ENV: process.env.SITE_ENV,
        SITE_HOST: process.env.SITE_HOST,
        SITE_TA: process.env.SITE_TA,
        GTM_ID: process.env.GTM_ID,
        GA_ID: process.env.GA_ID,
        GA_ID_STAGING: process.env.GA_ID_STAGING,
        GA_DISABLED: process.env.GA_DISABLED,
        BIN_PLATFORM_ID: process.env.BIN_PLATFORM_ID,
        FB_REMARKETING_ID: process.env.FB_REMARKETING_ID,
        NEUSTAR_DISABLED: process.env.NEUSTAR_DISABLED,
        SITE_STATUS: process.env.SITE_STATUS,
        SITE_LC_EN: process.env.SITE_LC_EN,
        SITE_LC_FR: process.env.SITE_LC_FR,
        SITE_TP_EN: process.env.SITE_TP_EN,
        SITE_TP_FR: process.env.SITE_TP_FR,
        SITE_LANG_EN: process.env.SITE_LANG_EN,
        SITE_LANG_FR: process.env.SITE_LANG_FR,
        SITE_GA_RV_EN: process.env.SITE_GA_RV_EN,
        SITE_GA_RV_FR: process.env.SITE_GA_RV_FR,
        GCS_BASE_URL: process.env.GCS_BASE_URL,
        GCS_CAMPAIGN_SLUG: process.env.GCS_CAMPAIGN_SLUG,
        GCS_REGISTRATION_SLUG: process.env.GCS_REGISTRATION_SLUG,
        GCS_ACCESS_TOKEN: process.env.GCS_ACCESS_TOKEN,
        GCS_CAMPAIGN_ID: process.env.GCS_CAMPAIGN_ID
    }
}

module.exports = nextConfig
