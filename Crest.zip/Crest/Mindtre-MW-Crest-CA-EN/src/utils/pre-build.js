import { dataPushHandler } from '@adapters/algolia/contentPushHandler'

module.exports = ()=>{
    dataPushHandler()
}