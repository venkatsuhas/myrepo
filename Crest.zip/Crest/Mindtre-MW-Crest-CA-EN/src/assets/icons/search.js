import React from "react"
import { svgNameSpace } from "@constants"

const Search = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='24' height='24' viewBox='0 0 24 24'>
        <g transform='translate(-8.07 -8.07)'>
            <path
                d='M31.865,30.652,26.8,25.644a10.324,10.324,0,0,0,2.818-7.073A10.65,10.65,0,0,0,18.844,8.07,10.65,10.65,0,0,0,8.07,18.571a10.653,10.653,0,0,0,10.774,10.5,10.906,10.906,0,0,0,6.68-2.272l5.142,5.074a.861.861,0,0,0,1.2-1.225ZM9.771,18.573a8.928,8.928,0,0,1,9.052-8.78A8.944,8.944,0,0,1,27.9,18.571a8.934,8.934,0,0,1-9.052,8.783,8.934,8.934,0,0,1-9.052-8.783Z'
                transform='translate(0)'
            />
        </g>
    </svg>
)

export default Search
