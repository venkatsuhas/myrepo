import React from "react"
import { svgNameSpace } from "@constants"

const FacebookFooterIcon = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='41' height='41' viewBox='0 0 41 41'>
        <g transform='translate(0.5 0.5)'>
            <circle fill='none' stroke='#fff' cx='20' cy='20' r='20' />
            <path
                fill='#fff'
                d='M5.456,16.41H1.818V8.661H0V5.675H1.818V3.884C1.818,1.449,2.844,0,5.76,0H8.188V2.986H6.671c-1.136,0-1.211.417-1.211,1.2l0,1.493h2.75L7.883,8.661H5.456V16.41Z'
                transform='translate(15.897 11.795)'
            />
        </g>
    </svg>
)

export default FacebookFooterIcon
