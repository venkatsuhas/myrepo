import React from "react"
import { svgNameSpace } from "@constants"

const FilterClosed = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='28.459' height='27' viewBox='0 0 28.459 27'>
        <defs>
            <filter id='a' x='0' y='0' width='27' height='27' filterUnits='userSpaceOnUse'>
                <feOffset dy='3' input='SourceAlpha' />
                <feGaussianBlur stdDeviation='3' result='b' />
                <feFlood floodColor='#830b0c' floodOpacity='0.302' />
                <feComposite operator='in' in2='b' />
                <feComposite in='SourceGraphic' />
            </filter>
        </defs>
        <g transform='translate(7.041 7)'>
            <line fill='none' stroke='#1e4f90' strokeLinecap='round' x2='20.919' transform='translate(0 3.5)' />
            <line fill='none' stroke='#1e4f90' strokeLinecap='round' x2='20.919' transform='translate(0 10.5)' />
            <g filter='url(#a)' transform='matrix(1, 0, 0, 1, -7.04, -7)'>
                <circle fill='#b50b0c' stroke='#fff' cx='4' cy='4' r='4' transform='translate(9.5 6.5)' />
            </g>
            <circle fill='#f5f5f5' stroke='#1e4f90' strokeLinecap='round' cx='3.5' cy='3.5' r='3.5' transform='translate(10.959 7)' />
        </g>
    </svg>
)

export default FilterClosed
