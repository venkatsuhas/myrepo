import React from "react"
import { svgNameSpace } from "@constants"

const InstagramIcon = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='40' height='40' viewBox='0 0 40 40'>
        <g fill='none' stroke='#fff' strokeMiterlimit='10'>
            <circle stroke='none' cx='20' cy='20' r='20' />
            <circle fill='none' cx='20' cy='20' r='19.5' />
        </g>
        <path
            fill='#fff'
            d='M12.242,17.436H5.194A5.2,5.2,0,0,1,0,12.242V5.194A5.2,5.2,0,0,1,5.194,0h7.048a5.2,5.2,0,0,1,5.194,5.194v7.048A5.2,5.2,0,0,1,12.242,17.436ZM5.194,1.754a3.444,3.444,0,0,0-3.44,3.44v7.048a3.444,3.444,0,0,0,3.44,3.44h7.048a3.444,3.444,0,0,0,3.44-3.44V5.194a3.444,3.444,0,0,0-3.44-3.44ZM8.718,13.227a4.509,4.509,0,1,1,4.51-4.509A4.515,4.515,0,0,1,8.718,13.227Zm0-7.265a2.755,2.755,0,1,0,2.755,2.755A2.759,2.759,0,0,0,8.718,5.963Zm4.518-.64a1.081,1.081,0,1,1,1.081-1.08A1.082,1.082,0,0,1,13.236,5.323Z'
            transform='translate(11.282 11.282)'
        />
    </svg>
)

export default InstagramIcon
