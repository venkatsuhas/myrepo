import React from "react"
import { svgNameSpace } from "@constants"

const DropDownArrow = (className) => (
    <svg
        className={className}
        xmlns={svgNameSpace}
        viewBox='0 0 12 12'
    >
        <path d='M0 0 L6 12 L12 0 Z' />
    </svg>
)

export default DropDownArrow
