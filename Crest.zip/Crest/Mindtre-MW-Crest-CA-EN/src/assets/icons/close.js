import React from "react"
import { svgNameSpace } from "@constants"

const Close = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='18' height='18' viewBox='0 0 18 18'>
        <path
            fill='none'
            strokeLinecap='round'
            strokeLinejoin='round'
            strokeWidth='2px'
            d='M-1763,8l-8,8,8-8-8-8,8,8,8-8-8,8,8,8Z'
            transform='translate(1772 1)'
        />
    </svg>
)

export default Close
