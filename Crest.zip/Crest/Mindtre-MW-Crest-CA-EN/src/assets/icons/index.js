import CarouselArrow from "@icons/carouselArrow"
import DropDownArrow from "@icons/dropDownArrow"
import FacebookIcon from "@icons/facebook"
import ThumbsUpIcon from "@icons/thumbsup"
import ThumbsDownIcon from "@icons/thumbsdown"
import LinkIcon from "@icons/link"
import MinusIcon from "@icons/minus"
import PlusIcon from "@icons/plus"
import SmartLabelIcon from "@icons/smartLabel"
import TwitterIcon from "@icons/twitter"
import Search from "@icons/search"
import AdChoicesIcon from "@icons/adChoices"
import BusinessIcon from "@icons/business"
import InstagramIcon from "@icons/instagram"
import TikTokIcon from "@icons/tiktok"
import YouTubeIcon from "@icons/youtube"
import FacebookFooterIcon from "@icons/facebookFooter"
import ChevronArrow from "@icons/chevronArrow"
import ChevronArrowUp from "@icons/chevronArrowUp"
import ChevronArrowDown from "@icons/chevronArrowDown"
import Close from "@icons/close"
import FilterClosed from "@icons/filterClosed"
import FilterOpened from "@icons/filterOpened"
import LocationDark from "@icons/locationDark"
import LocationLight from "@icons/locationLight"

const Icons = {
    Close,
    CarouselArrow,
    DropDownArrow,
    FacebookIcon,
    ThumbsUpIcon,
    ThumbsDownIcon,
    LinkIcon,
    MinusIcon,
    PlusIcon,
    SmartLabelIcon,
    TwitterIcon,
    Search,
    AdChoicesIcon,
    BusinessIcon,
    InstagramIcon,
    TikTokIcon,
    YouTubeIcon,
    FacebookFooterIcon,
    ChevronArrow,
    ChevronArrowUp,
    ChevronArrowDown,
    FilterClosed,
    FilterOpened,
    LocationDark,
    LocationLight,
}

export default Icons
