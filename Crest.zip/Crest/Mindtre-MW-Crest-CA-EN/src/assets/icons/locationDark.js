import React from "react"
import { svgNameSpace } from "@constants"

const LocationDark = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='11.002' height='15.684' viewBox='0 0 11.002 15.684'>
        <path
            fill='#898787'
            d='M22727.494,17887.68v0a41.589,41.589,0,0,1-2.76-3.67c-2.281-3.41-2.748-5.355-2.74-6.387v-.125a5.5,5.5,0,0,1,11,0v.176c.148,3.037-5.443,9.938-5.5,10.006Zm0-13.682a3.252,3.252,0,1,0,3.252,3.252A3.256,3.256,0,0,0,22727.494,17874Z'
            transform='translate(-22721.994 -17871.996)'
        />
    </svg>
)

export default LocationDark
