import React from "react"
import { svgNameSpace } from '@constants'

const CarouselArrow = (className) => (
    <svg
        className={className}
        xmlns={svgNameSpace}
        viewBox='12 8 50 50'>
        <g transform='translate(-1266.261 -4992)'>
            <path fill='none' stroke='#1d4486' strokeLinecap='round'
                strokeWidth='3px' d='M2749.818,5018.33l9,9-9,8' 
                transform='translate(-1448.057 -0.83)' />
        </g>
    </svg>
)

export default CarouselArrow