import React from "react"
import { svgNameSpace } from "@constants"

const FilterOpened = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='21.919' height='15' viewBox='0 0 21.919 15'>
        <g transform='translate(0.5 0.5)'>
            <line stroke='#1e4f90' strokeLinecap='round' fill='none' x2='20.919' transform='translate(0 3.5)' />
            <line stroke='#1e4f90' strokeLinecap='round' fill='none' x2='20.919' transform='translate(0 10.5)' />
            <circle stroke='#1e4f90' strokeLinecap='round' fill='#f5f5f5' cx='3.5' cy='3.5' r='3.5' transform='translate(2.959)' />
            <circle stroke='#1e4f90' strokeLinecap='round' fill='#f5f5f5' cx='3.5' cy='3.5' r='3.5' transform='translate(10.959 7)' />
        </g>
    </svg>
)

export default FilterOpened
