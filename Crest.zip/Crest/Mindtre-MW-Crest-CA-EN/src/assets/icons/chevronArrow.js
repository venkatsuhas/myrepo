import React from "react"
import { svgNameSpace } from "@constants"

const ChevronArrow = (className) => (
    <svg className={className} xmlns={svgNameSpace} viewBox='0 0 18.569 10.699'>
        <path
            strokeLinecap='round'
            strokeWidth='2px'
            d='M11339.258-22980.348l7.871,7.871,7.87-7.871'
            transform='translate(-11337.844 22981.762)'
        />
    </svg>
)

export default ChevronArrow
