import React from "react"
import { svgNameSpace } from "@constants"
const TikTokIcon = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='40' height='40' viewBox='0 0 40 40'>
        <g transform='translate(-1268 -1849)'>
            <g fill='none' stroke='#fff' strokeMiterlimit='10' transform='translate(1268 1849)'>
                <circle stroke='none' cx='20' cy='20' r='20' />
                <circle fill='none' cx='20' cy='20' r='19.5' />
            </g>
            <path
                fill='#fff'
                d='M550.994,422.184q-.225.022-.451.023a4.9,4.9,0,0,1-4.1-2.215v7.541a5.574,5.574,0,1,1-5.574-5.574h0c.116,0,.23.01.344.018v2.747a2.838,2.838,0,1,0-.344,5.655,2.915,2.915,0,0,0,2.959-2.809l.027-12.808h2.628a4.895,4.895,0,0,0,4.511,4.37v3.053'
                transform='translate(744.579 1444.902)'
            />
        </g>
    </svg>
)

export default TikTokIcon
