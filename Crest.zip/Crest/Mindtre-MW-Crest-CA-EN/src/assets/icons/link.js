import React from "react"
import { svgNameSpace } from "@constants"

const LinkIcon = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='22' height='11' viewBox='0 0 22 11'>
        <g transform='translate(0 -106.667)'>
            <g transform='translate(0 106.667)'>
                <g transform='translate(0 0)'>
                    <path
                        fill='#555'
                        d='M1.995,112.167a3.338,3.338,0,0,1,3.255-3.41h4.2v-2.09H5.25a5.506,5.506,0,0,0,0,11h4.2v-2.09H5.25A3.338,3.338,0,0,1,1.995,112.167Z'
                        transform='translate(0 -106.667)'
                    />
                    <rect fill='#555' width='8.4' height='2.1' rx='1' transform='translate(6.8 4.45)' />
                    <path
                        fill='#555'
                        d='M238.867,106.667h-4.2v2.09h4.2a3.414,3.414,0,0,1,0,6.82h-4.2v2.09h4.2a5.506,5.506,0,0,0,0-11Z'
                        transform='translate(-222.117 -106.667)'
                    />
                </g>
            </g>
        </g>
    </svg>
)

export default LinkIcon
