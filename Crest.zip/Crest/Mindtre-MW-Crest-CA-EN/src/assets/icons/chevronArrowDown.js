import React from "react"
import { svgNameSpace } from "@constants"

const ChevronArrowDown = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='100%' height='100%' viewBox='0 0 18.569 10.699'>
        <path
            fill='none'
            stroke='#0c457c'
            strokeLinecap='round'
            strokeWidth='2px'
            d='M11339.258-22980.348l7.871,7.871,7.87-7.871'
            transform='translate(-11337.844 22981.762)'
        />
    </svg>
)

export default ChevronArrowDown
