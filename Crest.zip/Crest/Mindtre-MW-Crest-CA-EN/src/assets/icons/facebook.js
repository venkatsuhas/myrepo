import React from "react"
import { svgNameSpace } from '@constants'

const FacebookIcon = (className) => (
    <svg className={className} xmlns={svgNameSpace} width='22' height='22' viewBox='0 0 22 22'>
        <path
            fill='#555'
            d='M18.777,0H3.223A3.227,3.227,0,0,0,0,3.223V18.777A3.227,3.227,0,0,0,3.223,22H9.711V14.223H7.133V10.355H9.711V7.734a3.871,3.871,0,0,1,3.867-3.867h3.91V7.734h-3.91v2.621h3.91l-.645,3.867H13.578V22h5.2A3.227,3.227,0,0,0,22,18.777V3.223A3.227,3.227,0,0,0,18.777,0Zm0,0'
        />
    </svg>
)

export default FacebookIcon
