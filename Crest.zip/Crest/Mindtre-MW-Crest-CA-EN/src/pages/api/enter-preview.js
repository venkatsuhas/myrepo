const enterPreview = (req, res) => {
    const { url } = req.query
    res.setPreviewData({})
    res.writeHead(307, { Location: url || '/' })
    res.end()
}

export default enterPreview