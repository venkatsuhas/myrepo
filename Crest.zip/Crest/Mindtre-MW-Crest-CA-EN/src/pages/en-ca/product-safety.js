import ProductSafetyPage from '@containers/ProductSafetyPage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getProductSafetyPage } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const productSafetyPage = await getProductSafetyPage({ locale: locales.english,slug:"product-safety" })
    return productSafetyPage
}

export default FallbackPage(ProductSafetyPage)
