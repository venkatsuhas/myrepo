import StannousPage from '@containers/StannousFlouridePage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getStannousPage } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const stannousPage = await getStannousPage({ locale: locales.english,slug:"stannous-fluoride-toothpaste" })
    return stannousPage
}

export default FallbackPage(StannousPage)
