import ProductListingPage from "@containers/ProductListingPage"
import FallbackPage from "@containers/FallbackPage"
import { getProductListingSlug, getProductListingData } from "@contentful/contentful.helper"
import { locales } from "@constants"

export const getStaticPaths = async () => {
    const paths = await getProductListingSlug({ locale: locales.english })
    return {
        paths: paths,
        fallback: process.env.CF_PREVIEW === "true" && process.env.BUILD_ENV === "preview",
    }
}

export const getStaticProps = async ({ params: { listingSlug: slug } }) => {
    const ProductListingData = await getProductListingData({ locale: locales.english, slug, topic: 'oral-care-products' })
    return ProductListingData
}

export default FallbackPage(ProductListingPage)
