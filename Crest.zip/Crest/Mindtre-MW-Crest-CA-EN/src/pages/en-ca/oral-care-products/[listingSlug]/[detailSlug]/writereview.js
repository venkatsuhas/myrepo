import WriteReview from "@containers/WriteReview"
import FallbackPage from '@containers/FallbackPage'
import { getProductReviewData, getPDPSlug } from '@contentful/contentful.helper'
import { locales } from '@constants'

export const getStaticPaths = async () => {
    const paths = await getPDPSlug({ locale: locales.english })
    return ({
        paths:paths,
        fallback: process.env.CF_PREVIEW === 'true' && process.env.BUILD_ENV === 'preview',
    })
}

export const getStaticProps = async ({ params: { detailSlug: slug, listingSlug } }) => {
    const WriteReviewData = await getProductReviewData({ locale: locales.english, slug, listingSlug })
    return WriteReviewData
}

export default FallbackPage(WriteReview)
