import SustainabilityPage from '@containers/Sustainability'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getSustainabilityPage } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const SustainabilityPage = await getSustainabilityPage({ locale: locales.english,slug:"sustainability" })
    return SustainabilityPage
}

export default FallbackPage(SustainabilityPage)
