import FAQPage from '@containers/FAQPage'
import FallbackPage from '@containers/FallbackPage'
import { getFAQData, getFAQSlug } from '@contentful/contentful.helper'
import { locales } from '@constants'

export const getStaticPaths = async () => {
    const paths = await getFAQSlug({ locale: locales.english })
    return ({
        paths:paths,
        fallback: process.env.CF_PREVIEW === 'true' && process.env.BUILD_ENV === 'preview',
    })
}

export const getStaticProps = async ({ params: { endSlug: slug } }) => {
    const FAQData = await getFAQData({ locale: locales.english, slug })
    return FAQData
}

export default FallbackPage(FAQPage)
