import ReviewGuidelinesPage from '@containers/ReviewGuidelinesPage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getReviewGuidelinesData } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const ReviewGuidelinesPage = await getReviewGuidelinesData({ slug:"review-guildelines", locale: locales.english })
    return ReviewGuidelinesPage
}

export default FallbackPage(ReviewGuidelinesPage)
