import { locales } from '@constants'
import Sitemap from '@containers/Sitemap'
import FallbackPage from '@containers/FallbackPage'
import { getSitemapData } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const SitemapData = await getSitemapData({ locale: locales.english })
    return SitemapData
}

export default FallbackPage(Sitemap)
