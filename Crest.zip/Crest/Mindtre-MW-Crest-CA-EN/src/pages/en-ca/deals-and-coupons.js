import OffersPage from '@containers/OffersPage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getOffersPageData } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const OffersPageData = await getOffersPageData({ locale: locales.english, slug:"deals-and-coupons" })
    return OffersPageData
}

export default FallbackPage(OffersPage)
