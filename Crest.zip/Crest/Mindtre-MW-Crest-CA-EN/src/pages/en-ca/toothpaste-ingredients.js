import IngredientsPage from "@containers/IngredientsPage"
import FallbackPage from "@containers/FallbackPage"
import { locales } from "@constants"
import { getIngredientsPageData } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const ingredientsData = await getIngredientsPageData({ locale: locales.english })
    return ingredientsData
}

export default FallbackPage(IngredientsPage)
