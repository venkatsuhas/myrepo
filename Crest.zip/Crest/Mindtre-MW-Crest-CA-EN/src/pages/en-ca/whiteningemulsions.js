import WhiteningEmulsionspage from '@containers/WhiteningEmulsionspage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getWhiteningemulsionsPage } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const whiteningEmulsionspage = await getWhiteningemulsionsPage({ locale: locales.english,slug:"whiteningemulsions" })
    return whiteningEmulsionspage
}

export default FallbackPage(WhiteningEmulsionspage)
