import React, { useEffect, useState, useCallback, StrictMode } from "react"
import PropTypes from "prop-types"
import App from "next/app"
import Head from "next/head"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import BuyNowContext from "@components/BuyNow/BuyNowContext"
import { getHeaderData, getFooterData } from "@contentful/contentful.helper"
import { locales, pageTypes } from "@constants"
import "@styles/tailwind.css"

const BuyNow = dynamic(() => import("@components/BuyNow"))
const Breadcrumb = dynamic(() => import("@components/Breadcrumb"))
const Layout = dynamic(() => import("@components/Layout"))
const PageMetadata = dynamic(() => import("@components/PageMetadata"))
const SEOSchema = dynamic(()=>import("@components/SEOSchema"))
const Telemetry = dynamic(() => import("@adapters/telemetry"))

const MyApp = ({ Component, pageProps: { pageData, pageType, breadcrumb, pageMetadata, schemaData, headerData, footerData, frenchHeaderData, frenchFooterData, locale } }) => {
    const router = useRouter()

    const [buyNowState, setBuyNowState] = useState({
        sku: null,
        open: false,
    })
    const [defaultData, setDefaultData] = useState({
        headerData,
        footerData
    })

    const virtualPageViewHandler = useCallback(() => {
        console.info("Virtual Page View Event fired")
        if (window.dataLayer) window.dataLayer.push({ event: "virtualPageview" })
    },[])

    useEffect(() => {
        if (process.env.AZURE_INSTRUMENTATION_KEY) {
            Telemetry()
        }
        router.events.on("routeChangeComplete", virtualPageViewHandler)
        return () => {
            router.events.off("routeChangeStart", virtualPageViewHandler)
        }
    }, [])

    useEffect(()=>{
        const locale = router.asPath?.split('/')[1]
        if(pageType === pageTypes.errorPage && locale === locales.french?.toLowerCase()){
            setDefaultData({
                headerData: frenchHeaderData || {},
                footerData: frenchFooterData || {}
            })
        }else{
            setDefaultData({
                headerData: headerData || {},
                footerData: footerData || {}
            })
        }
    },[router.asPath])

    const openBuyNow = useCallback((sku) => {
        setBuyNowState({ sku, open: true })
    },[])

    const closeBuyNow = useCallback(() => {
        setBuyNowState({ sku: null, open: false })
    },[])

    return (
        <>
            <Head>
                <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=2.0, shrink-to-fit=no' />
            </Head>
            <StrictMode>
                {pageMetadata && Object.keys(pageMetadata).length > 0 && <PageMetadata {...pageMetadata} />}
                <SEOSchema pageType={pageType} locale={locale} breadcrumb={breadcrumb} schemaData={schemaData} />
                <BuyNowContext.Provider value={{ openBuyNow }}>
                    <Layout headerData={defaultData.headerData} footerData={defaultData.footerData}>
                        {breadcrumb && breadcrumb.length > 0 && <Breadcrumb breadcrumb={breadcrumb} />}
                        <Component {...pageData} />
                    </Layout>
                </BuyNowContext.Provider>
                {locale && <BuyNow buyNowState={buyNowState} closeBuyNow={closeBuyNow} locale={locale} />}
            </StrictMode>
        </>
    )
}

MyApp.getInitialProps = async (context) => {
    const initialProps = await App.getInitialProps(context)
    const route_locale = context?.ctx?.asPath?.split('/')?.filter(text=>text)[0]
    const gen_locale = (route_locale?.match('-') && route_locale || '').split('-').map((entry,index)=>index>0?entry?.toUpperCase():entry?.toLowerCase()).join('-')
    const locale = Object.values(locales).indexOf(gen_locale) !== -1 ? gen_locale: null
    if(locale){
        const headerData = await getHeaderData({ locale })
        const footerData = await getFooterData({ locale })
        return { ...initialProps, pageProps: { ...initialProps.pageProps, headerData, footerData } }
    }else{
        const englishHeaderData = await getHeaderData({ locale: locales.english })
        const englishFooterData = await getFooterData({ locale: locales.english })
        
        const frenchHeaderData = await getHeaderData({ locale: locales.french })
        const frenchFooterData = await getFooterData({ locale: locales.french })
        
        return { ...initialProps, pageProps: { ...initialProps.pageProps, headerData: englishHeaderData, footerData: englishFooterData, frenchHeaderData, frenchFooterData } }
    }
}

MyApp.propTypes = {
    Component: PropTypes.any.isRequired,
    pageProps: PropTypes.shape({
        pageData: PropTypes.object.isRequired,
        pageType: PropTypes.string.isRequired,
        breadcrumb: PropTypes.array,
        pageMetadata: PropTypes.object,
        schemaData: PropTypes.object,
        headerData: PropTypes.object.isRequired,
        footerData: PropTypes.object.isRequired,
        frenchHeaderData: PropTypes.object,
        frenchFooterData: PropTypes.object,
        locale: PropTypes.string.isRequired,
    }).isRequired,
}

export default MyApp
