import React from 'react'
import Document, { Html, Head, Main, NextScript } from 'next/document'
import { locales } from '@constants'
import packageJSON from 'package.json'

export default class MyDocument extends Document {
    static async getInitialProps(context) {
        const initialProps = await Document.getInitialProps(context)
        const locale = context.asPath.split('/') && context.asPath.split('/')[1] || locales.english
        const robots = process.env.DEPLOYMENT !== 'production' ? packageJSON.robots.dev : packageJSON.robots.prod
        const blockPath = !!(robots?.disallow?.some((regex)=>context.asPath.match(new RegExp(regex.replace('*','.*')))))
        const [language, country] = locale.split('-')
        return { ...initialProps, locale, language, country, blockPath }
    }

    render() {
        const { language, country, blockPath } = this.props
        return (
            <Html lang={language}>
                <Head>
                    <link rel='preconnect' href='https://res.cloudinary.com' />
                    <link
                        rel='shortcut icon preload'
                        as='image'
                        href='https://res.cloudinary.com/mtree/Crest_CA_MW/3Hbn3Uxldw8nxXJC8knoe0/c85c91e6aff2f212a37fcb637fa1d291/crest-favIcon.png'
                        type='image/x-icon'
                    />
                    <link
                        rel='icon preload'
                        as='image'
                        href='https://res.cloudinary.com/mtree/Crest_CA_MW/3Hbn3Uxldw8nxXJC8knoe0/c85c91e6aff2f212a37fcb637fa1d291/crest-favIcon.png'
                        type='image/x-icon'
                    />
                    {blockPath ? <meta name='robots' content='noindex, nofollow' /> : <meta name='robots' content='index, follow' />}
                    <meta name='ps-account' content={process.env.PS_CLIENT_ID}/>
                    <meta name='ps-country' content={country?.toUpperCase()}/>
                    <meta name='ps-language' content={language}/>
                    <script
                        async
                        dangerouslySetInnerHTML={{
                            __html: `var PGdataLayer = { 'GTM': {
                                'SiteLocale':'${language}-${country?.toUpperCase()}',
                                'SiteCountry':'${country?.toUpperCase()}',
                                'SiteBrand':'Crest',
                                'SiteLanguage':'${country?.toUpperCase()}',
                                'SitePlatform': 'ModernWeb',
                                'SiteEnvironment': '${process.env.SITE_ENV}',
                                'SiteHost': '${process.env.SITE_HOST}',
                                'SiteTechnicalAgency': '${process.env.SITE_TA}',
                                'SiteStatus': '${process.env.SITE_STATUS}',
                                'BINPlatform': "Price Spider",
                                'BinPlatformId': '${process.env.BIN_PLATFORM_ID}',
                                'FacebookRemarketingID': '${process.env.FB_REMARKETING_ID}',
                                'GoogleAnalyticsLocal': '${process.env.GA_ID}',
                                'GoogleAnalyticsStaging': '${process.env.GA_ID_STAGING}',
                                'GoogleAnalyticsDisabled': '${process.env.GA_DISABLED}',
                                'NeustarDisabled': '${process.env.NEUSTAR_DISABLED}',
                                'SiteLocalContainer': '${process.env[`SITE_LC_${language?.toUpperCase()}`]}',
                                'SiteTouchpoint': '${process.env[`SITE_TP_${language?.toUpperCase()}`]}',
                                'SiteLanguage': '${process.env[`SITE_LANG_${language?.toUpperCase()}`]}',
                                'GoogleAnalyticsReportingView': '${process.env[`SITE_GA_RV_${language?.toUpperCase()}`]}',
                            }};`,
                        }}
                    ></script>
                    <script
                        async
                        dangerouslySetInnerHTML={{
                            __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                                new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                                j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                                'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                                })(window,document,'script','dataLayer','${process.env.GTM_ID}');`,
                        }}
                    ></script>
                </Head>
                <body className='p-0 m-0 font-neutrafaceBook'>
                    <noscript
                        dangerouslySetInnerHTML={{
                            __html: `<iframe src='https://www.googletagmanager.com/ns.html?id=${process.env.GTM_ID}'
                                height='0' width='0' style='display:none;visibility:hidden'></iframe>`,
                        }}
                    ></noscript>
                    <Main />
                    <NextScript />
                </body>
            </Html>
        )
    }
}
