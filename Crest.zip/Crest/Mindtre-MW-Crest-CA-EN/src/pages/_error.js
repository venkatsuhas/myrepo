import ErrorPage from '@containers/ErrorPage'
import { getErrorPage } from "@adapters/contentful/contentful.helper"

ErrorPage.getInitialProps = async () => {
    const errorPageData = await getErrorPage()
    return errorPageData 
}

export default ErrorPage