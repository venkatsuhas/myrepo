import StannousPage from '@containers/StannousFlouridePage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getStannousPage } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const stannousPage = await getStannousPage({ locale: locales.french,slug:"dentifrice-au-fluorure-stanneux" })
    return stannousPage
}

export default FallbackPage(StannousPage)