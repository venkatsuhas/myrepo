import ArticlePage from "@containers/ArticlePage"
import FallbackPage from "@containers/FallbackPage"
import { getADPData, getADPSlug } from "@contentful/contentful.helper"
import { locales } from "@constants"

export const getStaticPaths = async () => {
    const paths = await getADPSlug({ locale: locales.french })
    return {
        paths: paths,
        fallback: process.env.CF_PREVIEW === "true" && process.env.BUILD_ENV === "preview",
    }
}

export const getStaticProps = async ({ params: { detailSlug: slug } }) => {
    const ADPData = await getADPData({ locale: locales.french, slug })
    return ADPData
}

export default FallbackPage(ArticlePage)
