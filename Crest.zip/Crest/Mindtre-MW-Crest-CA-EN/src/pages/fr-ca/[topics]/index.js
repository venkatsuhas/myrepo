import ArticleListingPage from "@containers/ArticleListingPage"
import FallbackPage from "@containers/FallbackPage"
import { getArticleListingData, getArticleListingSlug } from "@contentful/contentful.helper"
import { locales } from "@constants"

export const getStaticPaths = async () => {
    const paths = await getArticleListingSlug({ locale: locales.french, hasParent: false })
    return {
        paths: paths,
        fallback: process.env.CF_PREVIEW === "true" && process.env.BUILD_ENV === "preview",
    }
}

export const getStaticProps = async ({ params: {  topics: slug } }) => {
    const ArticleListingData = await getArticleListingData( { locale: locales.french, slug })
    return ArticleListingData
}

export default FallbackPage(ArticleListingPage)
