import ProductPage from '@containers/ProductPage'
import FallbackPage from '@containers/FallbackPage'
import { getPDPData, getPDPSlug } from '@contentful/contentful.helper'
import { locales } from '@constants'

export const getStaticPaths = async () => {
    const paths = await getPDPSlug({ locale: locales.french })
    return ({
        paths:paths,
        fallback: process.env.CF_PREVIEW === 'true' && process.env.BUILD_ENV === 'preview',
    })
}

export const getStaticProps = async ({ params: { detailSlug: slug,listingSlug } }) => {
    const PDPData = await getPDPData({ locale: locales.french, slug, listingSlug })
    return PDPData
}

export default FallbackPage(ProductPage)