import ProductListingPage from "@containers/ProductListingPage"
import FallbackPage from "@containers/FallbackPage"
import { getProductListingSlug, getProductListingData } from "@contentful/contentful.helper"
import { locales } from "@constants"

export const getStaticPaths = async () => {
    const paths = await getProductListingSlug({ locale: locales.french })
    return {
        paths: paths,
        fallback: process.env.CF_PREVIEW === "true" && process.env.BUILD_ENV === "preview",
    }
}

export const getStaticProps = async ({ params: { listingSlug: slug } }) => {
    const ProductListingData = await getProductListingData({ locale: locales.french, slug, topic: 'produits' })
    return ProductListingData
}

export default FallbackPage(ProductListingPage)
