import ProductListingPage from "@containers/ProductListingPage"
import FallbackPage from "@containers/FallbackPage"
import { getProductListingData } from "@contentful/contentful.helper"
import { locales } from "@constants"

export const getStaticProps = async () => {
    const ProductListingData = await getProductListingData({ locale: locales.french, slug: "produits" })
    return ProductListingData
}

export default FallbackPage(ProductListingPage)
