import ProductSafetyPage from '@containers/ProductSafetyPage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getProductSafetyPage } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const productSafetyPage = await getProductSafetyPage({ locale: locales.french,slug:"surete-du-produit" })
    return productSafetyPage
}

export default FallbackPage(ProductSafetyPage)
