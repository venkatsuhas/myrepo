import SustainabilityPage from '@containers/Sustainability'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getSustainabilityPage } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const SustainabilityPage = await getSustainabilityPage({ locale: locales.french,slug:"durabilite-des-soins-buccodentaires" })
    return SustainabilityPage
}

export default FallbackPage(SustainabilityPage)
