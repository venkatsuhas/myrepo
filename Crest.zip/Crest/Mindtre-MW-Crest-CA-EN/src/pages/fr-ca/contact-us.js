import ContactUsPage from '@containers/ContactUsPage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getContactUsData } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const ContactUsPage = await getContactUsData({ slug:"contact-us", locale: locales.french })
    return ContactUsPage
}

export default FallbackPage(ContactUsPage)
