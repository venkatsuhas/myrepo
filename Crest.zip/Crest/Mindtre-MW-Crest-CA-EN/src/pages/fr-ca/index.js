import HomePage from "@containers/HomePage"
import FallbackPage from "@containers/FallbackPage"
import { locales } from "@constants"
import { getHomePageData } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const homePageData = await getHomePageData({ locale: locales.french })
    return homePageData
}

export default FallbackPage(HomePage)
