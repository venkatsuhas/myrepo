import SearchPage from '@containers/SearchPage'
import FallbackPage from '@containers/FallbackPage'
import { locales } from '@constants'
import { getSearchPageData } from "@contentful/contentful.helper"

export const getStaticProps = async () => {
    const searchPageData = await getSearchPageData({ locale: locales.french })
    return searchPageData
}

export default FallbackPage(SearchPage)
