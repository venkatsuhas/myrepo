import { locales, pageTypes } from "@constants"

const urlHelper = ({ locale, pageType, slug, topicSlug, listingSlug, searchTerm }) => {
    if (pageType === pageTypes.pdpPage) {
        if (locale === locales.english) {
            return `/${locale?.toLowerCase()}/oral-care-products/${listingSlug?.toLowerCase()}/${slug}`
        } else {
            return `/${locale?.toLowerCase()}/produits/${listingSlug?.toLowerCase()}/${slug}`
        }
    } else if (pageType === pageTypes.adpPage) {
        return `/${locale?.toLowerCase()}/${topicSlug?.toLowerCase()}/${listingSlug?.toLowerCase()}/${slug}`
    } else if (pageType === pageTypes.alpPage) {
        return `/${locale?.toLowerCase()}/${topicSlug?.toLowerCase()}${listingSlug ? `/${listingSlug?.toLowerCase()}` : ""}`
    } else if (pageType === pageTypes.searchPage) {
        return `/${locale?.toLowerCase()}/search?term=${encodeURI(searchTerm)}`
    } else if (pageType === pageTypes.plpPage) {
        if (locale === locales.english) {
            return `/${locale?.toLowerCase()}/oral-care-products${slug ? `/${slug}` : ""}`
        } else {
            return `/${locale?.toLowerCase()}/produits${slug ? `/${slug}` : ""}`
        }
    } else if (pageType === pageTypes.faqPage) {
        if (locale === locales.english) {
            return `/${locale?.toLowerCase()}/oral-care-tips/faqs${slug ? `/${slug}` : ""}`
        } else {
            return `/${locale?.toLowerCase()}/conseils-pour-soins-buccodentaires/faqs${slug ? `/${slug}` : ""}`
        }
    } else {
        return null
    }
}

export default urlHelper
