const monthNames = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
]
const d = new Date()
const curr_date = d.getDate()
const curr_month = d.getMonth() //Months are zero based
const curr_year = d.getFullYear()

export const FormattedDate = locale =>
    curr_date.toLocaleString(locale, { minimumIntegerDigits: 2 }) +
  ' ' +
  monthNames[curr_month] +
  ', ' +
  curr_year