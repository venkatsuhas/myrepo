import { locales } from "@constants"
import queryHandler from "@contentful/contentful.adapter"
import { getMappedSearchData } from "@contentful/dataMapper/Algolia.mapper"

const dataFetcher = () =>
    new Promise((resolve, reject) => {
        Promise.all([
            queryHandler({
                content_type: "productContainer",
                limit: 500,
                depth: 10,
                locale: locales.english,
            }),
            queryHandler({
                content_type: "articleContainer",
                limit: 500,
                depth: 10,
                locale: locales.english,
            }),
            queryHandler({
                content_type: "productContainer",
                limit: 500,
                depth: 10,
                locale: locales.french,
            }),
            queryHandler({
                content_type: "articleContainer",
                limit: 500,
                depth: 10,
                locale: locales.french,
            }),
        ])
            .then(
                ([
                    productCollectionEN,
                    articleCollectionEN,
                    productCollectionFR,
                    articleCollectionFR,
                ]) => {
                    const mappedData = getMappedSearchData(
                        [...productCollectionEN.items, ...productCollectionFR.items],
                        [...articleCollectionEN.items, ...articleCollectionFR.items]
                    )
                    resolve(mappedData)
                }
            )
            .catch(reject)
    })

export default dataFetcher
