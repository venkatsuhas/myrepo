import { ApplicationInsights } from "@microsoft/applicationinsights-web"

const TelemetryService = () => {
    if (process.env.AZURE_INSTRUMENTATION_KEY) {
        const appInsights = new ApplicationInsights({
            config: {
                instrumentationKey: process.env.AZURE_INSTRUMENTATION_KEY,
                disableFetchTracking: false,
                loggingLevelConsole: 2,
                isCookieUseDisabled: true,
            },
        })
        appInsights.loadAppInsights()
        appInsights.addTelemetryInitializer((item) => {
            item.tags.push({ "ai.cloud.app": "ModernWeb" })
        })
        appInsights.trackPageView({})
        if (typeof window !== "undefined") {
            window.appInsights = appInsights
        }
    }
}

export default TelemetryService
