import fetch from "node-fetch"
import { locales } from "@constants"

const BV_LOADER_URL = process.env.BV_LOADER_URL,
    BV_ENCODING_KEY_EN_CA = process.env.BV_ENCODING_KEY_EN_CA,
    BV_ENCODING_KEY_FR_CA = process.env.BV_ENCODING_KEY_FR_CA

const convertLocale = (locale)=>locale.replace(/-/g,'_')

export const getReviews = ({
    productId,
    limit = 3,
    offset = 0,
    sortFilterValue = "IsFeatured:desc",
    locale = locales.english,
}) =>
{
    let bv_key = locale === locales.english ? BV_ENCODING_KEY_EN_CA : BV_ENCODING_KEY_FR_CA
    return new Promise((resolve, reject) =>

        fetch(
    `https://${BV_LOADER_URL}/data/reviews.json?apiversion=5.4&passkey=${bv_key}&Filter=ProductId:${productId}&Stats=Reviews&Locale=${convertLocale(locale)}&limit=${limit}&offset=${offset}&Sort=${sortFilterValue}`
        )
            .then((response) => response.json())
            .then((response) => {
                const data = {
                    total: response?.TotalResults || 0,
                    results: response?.Results?.map((result) => ({
                        id: result?.Id || "",
                        response: result?.ClientResponses[0]
                            ? {
                                response:
                            result?.ClientResponses[0]?.Response,
                                time: result?.ClientResponses[0]?.Date
                                    ? parseInt(
                                        (new Date().getTime() -
                                        new Date(
                                            result?.ClientResponses[0]?.Date
                                        ).getTime()) /
                                        (1000 * 3600 * 24)
                                    )
                                    : null,
                                name: result?.ClientResponses[0]?.Department||null,
                            }
                            : null,
                        rating: result?.Rating || 0,
                        time: result?.SubmissionTime
                            ? parseInt(
                                (new Date().getTime() -
                            new Date(
                                result?.SubmissionTime
                            ).getTime()) /
                              (1000 * 3600 * 24)
                            )
                            : null,
                        submissionTime: result?.SubmissionTime || null,
                        review: result?.ReviewText || null,
                        title: result?.Title || null,
                        name: result?.UserNickname || null,
                    })),
                }
                resolve(data)
            })
            .catch(reject)
    )
}

export const getRating = ({ productId, locale = locales.english }) =>
{
    let bv_key = locale === locales.english ? BV_ENCODING_KEY_EN_CA : BV_ENCODING_KEY_FR_CA
    return new Promise((resolve, reject) =>
        fetch(
    `https://${BV_LOADER_URL}/data/products.json?apiversion=5.4&passkey=${bv_key}&Filter=Id:${productId}&Locale=${convertLocale(locale)}&Include=Reviews&ExcludeFamily=true&Stats=Reviews&Limit=1&sort_Reviews=rating:desc`
        )
            .then((response) => response.json())
            .then((response) => {
                const data = response?.Results[0]?.ReviewStatistics
                if (data) {
                    resolve({
                        totalReviews: data?.TotalReviewCount || 0,
                        overallRating: data?.AverageOverallRating || 0,
                    })
                } else {
                    resolve({})
                }
            })
            .catch(reject)
    )
}

export const getRatings = ({ productIds, locale = locales.english }) =>
{
    let bv_key = locale === locales.english ? BV_ENCODING_KEY_EN_CA : BV_ENCODING_KEY_FR_CA
    return new Promise((resolve, reject) =>
        fetch(
    `https://${BV_LOADER_URL}/data/products.json?apiversion=5.4&passkey=${bv_key}&Filter=Id:${productIds.join(',')}&Locale=${convertLocale(locale)}&Include=Reviews&ExcludeFamily=true&Stats=Reviews&Limit=${productIds.length}&sort_Reviews=rating:desc`
        )
            .then((response) => response.json())
            .then((response) => {
                const data = response?.Results?.map(({ Id, ReviewStatistics })=>({ 
                    id: Id,
                    totalReviews: ReviewStatistics?.TotalReviewCount || 0,
                    overallRating: ReviewStatistics?.AverageOverallRating || 0,
                })).reduce((prevState, currentValue)=>({ ...prevState, [currentValue.id]: { totalReviews: currentValue.totalReviews, overallRating: currentValue.overallRating  } }),{})
                if (data) {
                    resolve(data)
                } else {
                    resolve({})
                }
            })
            .catch(reject)
    )
}
export function getPreview(reviewData) {
    let bv_key = reviewData.locale === locales.english ? BV_ENCODING_KEY_EN_CA : BV_ENCODING_KEY_FR_CA
    return new Promise((resolve, reject) => 
        fetch(`https://${BV_LOADER_URL}/data/submitreview.json?apiversion=5.4&passKey=${bv_key}&ProductId=${reviewData.productID}
&Action=preview
&rating=${reviewData.overallRating}
${reviewData.valueRating?`&rating_Value=${reviewData.valueRating}`:''}
${reviewData.qualityRating?`&rating_Quality=${reviewData.qualityRating}`:''}
&isrecommended=${reviewData.recommendProduct}
&title=${reviewData.reviewTitle}
&reviewtext=${reviewData.reviewBody}
&usernickname=${reviewData.nickname}
&contextdatavalue_Agemonth=${reviewData.dobMonth}
&contextdatavalue_Ageyear=${reviewData.dobYear}
&useremail=${reviewData.email}
&userlocation=${reviewData.location}
&agreedtotermsandconditions=${reviewData.termsAndCondition}
&locale=${reviewData.locale.replace('-','_')}
&hostedauthentication_authenticationemail=${reviewData.email}
&hostedauthentication_callbackurl=${reviewData.callBackURL}`,
        {  method: "POST" })
            .then((response) => response.json())
            .then(response => {
                console.info("response",response)
                resolve(response)
            })
            .catch(error => {
                console.info("error",error)
                reject(error)
            })
    )
}  

export function submitReviews(reviewData) {
    let bv_key = reviewData.locale === locales.english ? BV_ENCODING_KEY_EN_CA : BV_ENCODING_KEY_FR_CA
    return new Promise((resolve, reject) => 
        fetch(`https://${BV_LOADER_URL}/data/submitreview.json?apiversion=5.4&passKey=${bv_key}&ProductId=${reviewData.productID}
&Action=Submit
&rating=${reviewData.overallRating}
&reviewtext=${reviewData.reviewBody}
&contextdatavalue_Agemonth=${reviewData.dobMonth}
&contextdatavalue_Ageyear=${reviewData.dobYear}
&usernickname=${reviewData.nickname}
&useremail=${reviewData.email}
&agreedtotermsandconditions=${reviewData.termsAndCondition}
&hostedauthentication_authenticationemail=${reviewData.email}
&hostedauthentication_callbackurl=${reviewData.callBackURL}`
        ,{ method: "POST" })
            .then((response)=>response.json())
            .then(response => {
                console.info("response",response)
                resolve(response)
            })
            .catch(error => {
                console.info("error",error)
                reject(error)
            })
    )
}