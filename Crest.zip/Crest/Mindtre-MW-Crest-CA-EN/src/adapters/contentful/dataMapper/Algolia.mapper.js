import { pageTypes } from "@constants"
import { getImageData } from '@dataMapperHelper/image.helper'
import urlHelper from "@helpers/url.helpers"

const getMappedArticle = (entry) => ({
    objectID: entry?.sys?.id,
    locale: entry?.sys?.locale,
    articleName: entry?.fields?.articleName,
    articleCategory: entry?.fields?.articleCategory,
    url: urlHelper({
        locale: entry?.sys?.locale,
        pageType: pageTypes.adpPage,
        topicSlug: entry?.fields?.topicSlug,
        listingSlug: entry?.fields?.listingSlug,
        slug: entry?.fields?.slug,
    }),
    heroImage:
    (entry?.fields?.bannerImageSet?.fields?.smartphoneImage &&
        getImageData(entry?.fields?.bannerImageSet?.fields?.smartphoneImage)) ||
    null,
})

const getMappedProduct = (entry) => ({
    objectID: entry?.sys?.id,
    locale: entry?.sys?.locale,
    productName: entry?.fields?.productName,
    category: entry?.fields?.productMainCategory,
    facets: entry?.fields?.productFacets,
    description: entry?.fields?.description,
    slug: entry?.fields?.slug,
    url: urlHelper({
        locale: entry?.sys?.locale,
        pageType: pageTypes.pdpPage,
        slug: entry?.fields?.slug,
        listingSlug: entry?.fields?.productMainCategory?.toLowerCase()
    }),
    productHeroImageURL: entry?.fields?.heroImage?.fields?.file?.url,
    productHeroImage: entry?.fields?.heroImage && getImageData(entry?.fields?.heroImage)||null,
    priceSpiderId: entry?.fields?.priceSpiderId
})

export const getMappedSearchData = (productData, articleData) => ({
    products: productData?.filter(({ fields })=>fields?.content).map(({ fields })=>fields?.content).map(getMappedProduct),
    articles: articleData?.filter(({ fields })=>fields?.content).map(({ fields })=>fields?.content).map(getMappedArticle),
})
