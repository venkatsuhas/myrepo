import { locales, pageTypes } from "@constants"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"

export const getMappedSearchData = (entries) => {
    const searchPageData = {
        locale: locales.english,
        productFilterData: []
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        searchPageData.locale = entries?.items[0]?.sys?.locale
        searchPageData.productFilterData = firstItem?.searchPageFilter?.fields?.filters?.map(({ fields })=> ({ name: fields.name, options: fields.options }))||[]
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}
        return {
            props: {
                pageData: searchPageData,
                pageType: pageTypes.searchPage,
                breadcrumb,
                pageMetadata,
                locale: searchPageData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.searchPage,
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english,
            },
        }
    }
}