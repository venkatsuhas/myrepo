import { locales, pageTypes } from "@constants"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getImageData } from "@dataMapperHelper/image.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getRelatedProductData } from "@dataMapperHelper/relatedProduct.helper"
import urlHelper from "@helpers/url.helpers"

const getCategory = (category, isBasePath = true)=>({
    sys: category?.sys?.id || null,
    title: category?.fields?.categoryTitle,
    url: urlHelper({ locale: category?.sys?.locale||locales.english, pageType: pageTypes.plpPage, ...(isBasePath?{ slug: category?.fields?.slug }:{}) }),
})

export const getMappedProductListingData = (content, container, products) => {
    const productListingData = {
        locale: locales.english,
        bannerImage: {},
        title: null,
        subTitle: null,
        mainCategories: [],
        type: null,
        filters: [],
        products: [],
    }

    const firstContentEntry = content.items[0] && content.items[0].fields
    const firstContainerEntry =
        container.items &&
        container.items.filter(
            (container) =>
                container?.fields &&
                container?.fields?.categories &&
                container?.fields?.categories[0] &&
                container?.fields?.categories[0].fields?.type === firstContentEntry?.type
        )[0]?.fields

    if (firstContentEntry && firstContainerEntry) {
        productListingData.locale = container.items[0].sys.locale
        productListingData.title = firstContentEntry?.pageTitle || firstContentEntry?.title || null
        productListingData.subTitle = firstContentEntry?.subTitle || null
        productListingData.type = firstContentEntry?.type || null
        productListingData.bannerImage =
            (firstContentEntry?.bannerImage && {
                desktopImage:
                    (firstContentEntry?.bannerImage?.fields?.desktopImage && getImageData(firstContentEntry?.bannerImage?.fields?.desktopImage)) ||
                    null,
                smartphoneImage:
                    (firstContentEntry?.bannerImage?.fields?.smartphoneImage &&
                        getImageData(firstContentEntry?.bannerImage?.fields?.smartphoneImage)) ||
                    null,
            }) ||
            null
        productListingData.mainCategories = [...firstContainerEntry.categories.map((category)=>getCategory(category)),getCategory(firstContainerEntry.allCategories, false)]
        productListingData.filters =
            firstContainerEntry.filters?.fields?.filters?.map(({ fields }) => ({ name: fields.name, options: fields.options })) || []

        productListingData.products =
            products.items
                .map(({ fields }) => fields?.content)
                .filter((product) => {
                    if (product) {
                        const productFacets = [product.fields.productMainCategory, ...(product.fields.productFacets || [])]
                        return firstContentEntry.facets.some((filter) => productFacets.includes(filter))
                    } else {
                        return false
                    }
                }).sort((firstProduct,secondProduct)=>((firstProduct?.fields?.featuredRating||100)-(secondProduct?.fields?.featuredRating||100)))
                .map((product) => getRelatedProductData(product, productListingData.locale, true)) || []

        const breadcrumb = firstContentEntry?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstContentEntry?.pageMetadata && getPageMetadata(firstContentEntry?.pageMetadata) || {}

        return {
            props: {
                pageData: productListingData,
                pageType: pageTypes.plpPage,
                breadcrumb,
                pageMetadata,
                locale: productListingData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.plpPage,
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english,
            },
        }
    }
}

export const getMappedProductListingSlug = (entries) =>
    entries?.items
        ?.map(({ fields }) => fields?.categories)
        .flat()
        ?.filter((entry) => entry?.fields?.slug)
        .map((entry) => ({
            params: {
                listingSlug: entry?.fields?.slug,
            },
        })) || []
