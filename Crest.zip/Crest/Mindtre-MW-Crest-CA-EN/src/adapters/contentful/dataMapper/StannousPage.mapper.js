import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getFeatureCard } from "@dataMapperHelper/featureCard.helper"
import { getImageData } from "@dataMapperHelper/image.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getRelatedProductData } from "@dataMapperHelper/relatedProduct.helper"
import { locales, pageTypes } from "@constants"

export const getStannousPageData = (entries) => {
    const pageData = {
        benefitCards: [],
        innovationCard: [],
        dentalCards: [],
        productsCard: [],
        crestLogo: {},
    }
    const firstItem = entries?.items[0]?.fields
    if (firstItem) {
        pageData.locale = entries?.items[0].sys.locale || null
        pageData.pageTitle = firstItem.pageTitle || null
        pageData.pageSubTitle = firstItem.pageSubTitle || null
        pageData.benefitCards = firstItem?.benefitCards?.map((card) => (getFeatureCard(card)))
        pageData.innovationCardTitle = firstItem.innovationCardTitle || null
        pageData.crestLogo = (firstItem?.crestLogo?.fields && getImageData(firstItem?.crestLogo)) || null,
        pageData.innovationCard = firstItem?.innovationCard?.map((card) => (getFeatureCard(card)))
        pageData.dentalCardTitle = firstItem.dentalCardTitle || null
        pageData.dentalCardSubTitle = firstItem.dentalCardSubTitle || null
        pageData.dentalCards = firstItem?.dentalCards?.map((card) => (getFeatureCard(card)))
        pageData.productsCard = firstItem?.productsCard?.map((product) =>({
            title: product?.fields?.title || null,
            description: product?.fields?.description || null,
            product: { ...getRelatedProductData(product?.fields?.productCards, pageData.locale, true) },
        })) || []
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}
        return {
            props: {
                pageData: pageData,
                pageType: pageTypes.stannousPage,
                breadcrumb,
                pageMetadata,
                locale: pageData.locale,
            },
        }
    }
    else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.stannousPage,
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english,
            },
        }
    }
}
