import { locales, pageTypes } from "@constants"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getFeatureCard } from "@dataMapperHelper/featureCard.helper"

export const getSustainabilityPageData =(entries)=>{
    const pageData={
        featuresSection:{},
        videoCardUrl:"",
        ourVisionSection:{},
        healthCrisis:[],
        accessCard:{},
        oralCareEducation:{},
        sustainability:[],

    }
    const firstItem = entries?.items[0]?.fields
    if(firstItem){
        pageData.locale = entries?.items[0].sys.locale || null
        pageData.pageTitle = firstItem?.title || null
        pageData.ourVisionSection = firstItem?.ourVisionSection?.fields && (getFeatureCard(firstItem?.ourVisionSection))
        pageData.videoCardUrl = firstItem.videoCard?.fields?.url || null
        pageData.description = firstItem?.description || null
        pageData.featuresSection = { ...firstItem?.featuresSection?.fields }
        pageData.healthCrisis = firstItem?.healthCrisis?.map((item)=> item && ( getFeatureCard(item) ))
        pageData.guidelineSection = firstItem?.guidelineSection || null
        pageData.accessCard = firstItem?.accessCard?.fields && (getFeatureCard(firstItem?.accessCard))
        pageData.oralCareEducation = firstItem?.oralCareEducation?.fields && (getFeatureCard(firstItem?.oralCareEducation))
        pageData.sustainability = firstItem?.sustainability?.map((card)=>( getFeatureCard(card) ))
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}
        return {
            props:{
                pageData:pageData,
                breadcrumb,
                pageMetadata,
                locale:pageData.locale,
                pageType: pageTypes.sustainabilityPage,
            }
        }
    }
    else{
        return {
            props:{
                pageData:{},
                breadcrumb:[],
                pageMetadata:{},
                locale:locales.english,
                pageType: pageTypes.sustainabilityPage,
            }
        }
    }
}