import { locales, pageTypes, labels } from "@constants"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getImageData } from "@dataMapperHelper/image.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"

export const getMappedProductReviewData = (entries) => {
    const productData = {
        locale: locales.english,
        productName: null,
        heroImage: null,
        bazaarVoiceId: null,
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        productData.locale = entries?.items[0].sys.locale || locales.english
        productData.productName = firstItem.productName || null
        productData.heroImage =  firstItem.heroImage && getImageData(firstItem.heroImage) || null,
        productData.bazaarVoiceId = firstItem.bazaarvoiceId || null
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const lastElement = breadcrumb.length > 0 && breadcrumb.slice(-1)[0].url || {}
        breadcrumb.length > 0 && (breadcrumb.push({  
            sys: '',
            title: labels[productData.locale?.toLocaleLowerCase()]?.writeAReview||'',
            url: `${lastElement}/writereview`
        }))
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}
        if(pageMetadata && pageMetadata.canonicalUrl){
            pageMetadata.canonicalUrl = ''
        }

        return {
            props: {
                pageData: productData,
                pageType: pageTypes.reviewPage,
                breadcrumb,
                pageMetadata,
                locale: productData.locale
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.reviewPage,
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english
            },
        }
    }
}
