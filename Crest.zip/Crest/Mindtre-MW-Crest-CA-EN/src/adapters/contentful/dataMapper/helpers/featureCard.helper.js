import { getImageData } from "@dataMapperHelper/image.helper"

export const getFeatureCard = (card) => ({
    name:card?.fields?.name || null,
    title: card?.fields?.title || null,
    subTitle: card?.fields?.subTitle || null,
    sys: card?.sys?.id || null,
    description: card?.fields?.description || null,
    imageset: card?.fields?.imageSet && {
        desktopImage: getImageData(card?.fields?.imageSet?.fields?.desktopImage),
        smartphoneImage: getImageData(card?.fields?.imageSet?.fields?.smartphoneImage),
    } || null,
    image: (card?.fields?.image && getImageData(card?.fields?.image[0])) || null,
    href: card?.fields?.callToActions && card?.fields?.callToActions[0]?.fields?.url || null,
    linkText: card?.fields?.callToActions && card?.fields?.callToActions[0]?.fields?.title || null,
    cardLink: card?.fields?.cardLink || null,
    styles: card?.fields?.styles || null,
    videoUrl: card?.fields?.videoUrl || null,
    videoPlayIcon: card?.fields?.videoPlayIcon && {
        desktopImage: getImageData(card?.fields?.videoPlayIcon?.fields?.desktopImage),
        smartphoneImage: getImageData(card?.fields?.videoPlayIcon?.fields?.smartphoneImage),
    } || null,
    logo: card?.fields?.logo && {
        desktopImage: getImageData(card?.fields?.logo?.fields?.desktopImage),
        smartphoneImage: getImageData(card?.fields?.logo?.fields?.smartphoneImage),
    } || null,
})
