import { pageTypes } from "@constants"
import { getImageData } from "@dataMapperHelper/image.helper"
import urlHelper from '@helpers/url.helpers'

export const getRelatedArticleData = (article, locale) => article.sys && article.fields?.articleCategory ? ({
    sys: article.sys?.id || null,
    category: article.fields?.articleCategory || null,
    name: article.fields?.articleName || null,
    categoryBasedFeatured: false,
    href:urlHelper({
        locale,
        pageType: pageTypes.adpPage,
        topicSlug: article.fields?.topicSlug,
        listingSlug: article.fields?.listingSlug,
        slug: article.fields?.slug,
    }),
    image:
        (article?.fields?.heroImage &&
            getImageData(article?.fields?.heroImage)) ||
        null,
}): null