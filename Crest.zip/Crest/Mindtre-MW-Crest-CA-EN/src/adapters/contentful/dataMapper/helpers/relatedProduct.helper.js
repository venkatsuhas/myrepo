import { pageTypes } from "@constants"
import { getImageData } from "@dataMapperHelper/image.helper"
import urlHelper from "@helpers/url.helpers"

export const getRelatedProductData = (product, locale, needsRating = true) => product.sys && product.fields?.productMainCategory ? ({
    sys: product.sys?.id || null,
    title: product.fields?.productMainCategory || null,
    subTitle: product.fields?.productName || null,
    href: urlHelper({
        locale,
        pageType: pageTypes.pdpPage,
        slug: product?.fields?.slug,
        listingSlug: product?.fields?.listingSlug,
    }),
    image: (product?.fields?.heroImage && getImageData(product?.fields?.heroImage)) || null,
    isPopular: !!product?.fields?.isMostPopular,
    ...(needsRating ? { 
        bazaarVoiceId: product?.fields?.bazaarvoiceId || null, buyNowSKU: product?.fields?.priceSpiderId || null } : {}),
    productFacets: [product?.fields?.productMainCategory, ...(product.fields.productFacets || [])] || [],
    featuredRating: product?.fields?.featuredRating || 1
}) : null
