export const getPageMetadata = ({ fields }) => ({
    title: fields?.title||'',
    metaTitle: fields?.metaTitle||'',
    metaDescription: fields?.metaDescription||'',
    metaKeywords: fields?.metaKeywords||'',
    openGraphPageTitle: fields?.openGraphPageTitle||'',
    openGraphDescription: fields?.openGraphDescription||'',
    openGraphImage: fields?.openGraphImage?.fields?.file?.url||'',
    canonicalUrl: fields?.canonicalUrl||''
}) 
