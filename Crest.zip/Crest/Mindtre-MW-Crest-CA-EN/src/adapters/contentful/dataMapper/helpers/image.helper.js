export const extractImagePublicId = imageURL => imageURL?.replace(`//images.ctfassets.net/${process.env.CF_SPACE_ID}/`, '')

export const getImageData = (imageData) => imageData?.fields?.title && imageData?.fields?.file?.url ? ({
    sys: imageData?.sys?.id || null,
    url: extractImagePublicId(imageData?.fields?.file?.url) || null,
    altText: imageData?.fields?.title || null,
    height: imageData?.fields?.file?.details?.image?.height || 0,
    width: imageData?.fields?.file?.details?.image?.width || 0,
}):null