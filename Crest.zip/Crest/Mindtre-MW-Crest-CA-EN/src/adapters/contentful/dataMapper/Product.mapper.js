import { locales, pageTypes } from "@constants"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getImageData } from "@dataMapperHelper/image.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getRelatedArticleData } from "@dataMapperHelper/relatedArticle.helper"
import { getRelatedProductData } from "@dataMapperHelper/relatedProduct.helper"
import { getRating, getReviews } from '@adapters/bazaarvoice'

const getGalleryImageData = ({ fields: { productImages, variant } }) => ({
    variant,
    productImages: productImages.map(getImageData).filter(image=>image),
})

const getSubVariantData = ({
    fields: {
        variantName,
        mainVariant: isMainVariant,
        productImages,
        smartLabelId,
        buyNowId
    },
},fallbackImages) => ({
    variantName: variantName || null,
    isMainVariant: !!isMainVariant,
    productImages: productImages?.map(getGalleryImageData).filter(image=>image) || fallbackImages || [],
    smartLabelId: smartLabelId || null,
    buyNowId: buyNowId || null
})

const getMainVariantData = ({
    fields: {
        variantName,
        mainVariant: isMainVariant,
        subVariants,
        productImages,
        smartLabelId,
        buyNowId
    },
}, fallbackImages) =>
    subVariants && subVariants.length > 0
        ? {
            variantName: variantName|| null,
            isMainVariant: !!isMainVariant,
            subVariants: subVariants?.map((variant)=>getSubVariantData(variant,fallbackImages)),
        }
        : getSubVariantData({
            fields: {
                variantName,
                mainVariant: isMainVariant,
                productImages,
                smartLabelId,
                buyNowId
            },
        },fallbackImages)

export const getMappedProductData = async (entries) => {
    const productData = {
        locale: locales.english,
        name: null,
        mainCategory: null,
        productVariants: [],
        hasMainVariant: false,
        hasSubVariant: false,
        productImages:[],
        heroImage: null,
        description: null,
        productDetails: null,
        ourIngredients: null,
        smartLabelId: null,
        faq: null,
        bazaarVoiceId: null,
        buyNowId: null,
        relatedProducts: [],
        relatedArticles: [],
        relatedArticlesListing: null,
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        productData.locale = entries?.items[0].sys.locale || null
        productData.name = firstItem.productName || null
        productData.mainCategory = firstItem.productMainCategory || null
        productData.productImages = firstItem.productImages?.map(getGalleryImageData).filter(image=>image) || []
        productData.productVariants =
            firstItem.productVariants
                ?.map((variant) => {
                    if (
                        variant?.fields?.mainVariant &&
                        !productData.hasSubVariant
                    ) {
                        productData.hasMainVariant = true
                        return getMainVariantData(variant,productData.productImages)
                    } else if (!productData.hasMainVariant) {
                        productData.hasSubVariant = true
                        return getSubVariantData(variant,productData.productImages)
                    } else {
                        return null
                    }
                })
                .filter((variant) => variant) || []
        productData.productImages = ((!firstItem.productVariants || firstItem.productVariants.length === 0)&& firstItem.productImages?.map(getGalleryImageData).filter(image=>image)) || []
        productData.heroImage =  firstItem.heroImage && getImageData(firstItem.heroImage) || null,
        productData.description = firstItem.description || null
        productData.productDetails = firstItem.productDetails || null
        productData.smartLabelId = firstItem.smartLabelId || null
        productData.faq = firstItem.faq || null
        productData.bazaarVoiceId = firstItem.bazaarvoiceId || null
        productData.buyNowId = firstItem.priceSpiderId || null
        productData.relatedProducts =
            firstItem?.relatedProducts?.map((product) =>
                getRelatedProductData(product, productData.locale)
            ).filter(product=>product) || []
        productData.relatedArticles =
            firstItem?.relatedArticles?.map((article) =>
                getRelatedArticleData(article, productData.locale)
            ).filter(article=>article) || []
        productData.relatedArticlesListing = productData.relatedArticles && productData.relatedArticles.length > 0 && productData?.relatedArticles[0]?.href?.split('/').slice(0,-1).join('/') ||null
        
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}
        const ratingData = {
            aggregateRating:{
                ratingValue: 0,
                reviewCount: 0 
            },
            review:{
                author: '',
                date: '',
                reviewBody:'',
                name:'',
                rating: 0
            }
        }
        try{
            const aggregateRating = await getRating({ productId: productData.bazaarVoiceId, locale: productData.locale })
            ratingData.aggregateRating.ratingValue = aggregateRating?.overallRating||0
            ratingData.aggregateRating.reviewCount = aggregateRating?.totalReviews||0
            const reviewRating = await getReviews({ productId: productData.bazaarVoiceId, limit: 1, locale: productData.locale })
            ratingData.review ={
                author: reviewRating?.results[0]?.name||'Anonymous',
                date: reviewRating?.results[0]?.submissionTime||'',
                reviewBody: reviewRating?.results[0]?.review||'',
                name: reviewRating?.results[0]?.title||'',
                rating: reviewRating?.results[0]?.rating||1
            }
        }catch(error){
            ratingData.review.author = 'Anonymous'
        }

        const schemaData = {
            name: firstItem.productName || '',
            description: firstItem.description || '',
            image: (firstItem.heroImage && getImageData(firstItem.heroImage)?.url)?`//images.ctfassets.net/${process.env.CF_SPACE_ID}/${getImageData(firstItem.heroImage)?.url}`:'',
            sku: firstItem.smartLabelId?.padStart(14,'0')||'',
            ...ratingData
        }

        return {
            props: {
                pageData: productData,
                pageType: pageTypes.pdpPage,
                breadcrumb,
                pageMetadata,
                schemaData,
                locale: productData.locale
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.pdpPage,
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english
            },
        }
    }
}

export const getMappedProductSlug = (entries) => entries?.items?.map(({ fields })=>fields?.content)
    ?.filter((entry) => entry?.fields?.slug && entry?.fields?.listingSlug)
    .map((entry) => ({
        params: {
            listingSlug: entry?.fields?.listingSlug,
            detailSlug: entry?.fields?.slug,
        },
    })) || []
