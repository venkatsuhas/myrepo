import { locales, pageTypes } from "@constants"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"

export const getMappedReviewGuidelinesData = (entries) => {
    const reviewGuidelinesData = {
        locale: locales.english,
        cardData: {}
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        reviewGuidelinesData.locale = entries?.items[0]?.sys?.locale
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}
        reviewGuidelinesData.cardData = firstItem?.card?.fields || {}
        return {
            props: {
                pageData: reviewGuidelinesData,
                pageType: pageTypes.reviewGuidelinesPage,
                breadcrumb,
                pageMetadata,
                locale: reviewGuidelinesData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.reviewGuidelinesPage,
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english,
            },
        }
    }
}