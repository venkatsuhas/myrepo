import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getFeatureCard } from "@dataMapperHelper/featureCard.helper"
import { getImageData } from "@dataMapperHelper/image.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getRelatedProductData } from "@dataMapperHelper/relatedProduct.helper"
import { locales, pageTypes } from "@constants"

export const getWhiteningPageData = (entries) => {
    const pageData = {
        contentBlocks: [],
        productsCard: [],
        ReviewCards:{},
        
    }
    const firstItem = entries?.items[0]?.fields
    if (firstItem) {
        pageData.locale = entries?.items[0].sys.locale || null
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}
        pageData.locale = entries?.items[0].sys.locale || null
        const bannerFields = firstItem?.heroImageBlock?.fields

        pageData.heroImageBlock = {
            title: bannerFields?.title || null,
            imageset: bannerFields?.imageSet && {
                desktopImage: getImageData(bannerFields?.imageSet?.fields?.desktopImage),
                smartphoneImage: getImageData(bannerFields?.imageSet?.fields?.smartphoneImage),
            } || null,
            href: bannerFields?.callToActions[0]?.fields?.url || null,
            linkText: bannerFields?.callToActions[0]?.fields?.title || null,
            logo: bannerFields?.logo && {
                desktopImage: getImageData(bannerFields?.logo?.fields?.desktopImage),
                smartphoneImage: getImageData(bannerFields?.logo?.fields?.smartphoneImage),
            } || null,
        }
        pageData.contentBlocks = firstItem?.contentBlocks?.map((card) => (getFeatureCard(card)) || null)
        pageData.reviewCardTitle = firstItem?.reviewS.fields.title
        pageData.productsCard = firstItem?.productsCard?.map((product) =>({
            title: product?.fields?.title || null,
            description: product?.fields?.description || null,
            product: { ...getRelatedProductData(product?.fields?.productCards, pageData.locale, true) },
        })) || []
        pageData.ReviewCards = firstItem?.reviewS.fields.reviewCards.map((card) => (getFeatureCard(card))) || null
        const EmailFields=firstItem?.emailOption?.fields
        pageData.emailSignup={
            backgroundAsset: EmailFields?.backgroundAsset && {
                desktopImage: getImageData(EmailFields?.backgroundAsset?.fields?.desktopImage),
                smartphoneImage: getImageData(EmailFields?.backgroundAsset?.fields?.smartphoneImage),
            } || null,
            title:EmailFields?.title,
            subTitle:EmailFields?.subTitle,
            label:EmailFields?.label,
            emailOptionText:EmailFields?.emailOptionText,
            termsPrivacyPolicy:EmailFields?.termsPrivacyPolicy,
            button:EmailFields?.button,
            validationText1:EmailFields?.validationText1,
            validationText2:EmailFields?.validationText2 || null,
            maximumEmailLimit: EmailFields?.maximumEmailLimit || null,
            registrationSuccessMessage: EmailFields?.registrationSuccessMessage || null
        }
        return {
            props: {
                pageData: pageData,
                pageType: pageTypes.whiteningEmulsionsPage,
                breadcrumb,
                pageMetadata,
                locale: pageData.locale,
            },
        }
    }
    else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.whiteningEmulsionsPage,
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english,
            },
        }
    }
}
