import { getImageData } from "@dataMapperHelper/image.helper"
import { getMenuSlotData } from "./helpers/layout.helper"
import { getFeatureCard } from "@dataMapperHelper/featureCard.helper"

export const getMappedHeaderData = (entries) => {
    const headerData = {
        brandLogo: {},
        menuSlots: [],
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        headerData.locale = entries?.items[0].sys.locale || null
        headerData.brandLogo = getImageData(firstItem?.brandLogo) || null
        headerData.menuSlots = getMenuSlotData(firstItem?.menuSlots) || null
        return headerData
    } else {
        return {}
    }
}

export const getMappedFooterData = (entries) => {
    const footerData = {
        menuSlots: [],
        footerLinks: [],
        dentalCare: null,
        instaCard:{},
    }
    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {
        footerData.locale = entries?.items[0].sys.locale || null
        footerData.menuSlots = getMenuSlotData(firstItem?.menuSlots) || null
        footerData.footerLinks =
            (firstItem?.footerLinks &&
                firstItem?.footerLinks.map((footerLink) => ({
                    sys: footerLink?.sys?.id || null,
                    url: footerLink?.fields?.url || null,
                    title: footerLink?.fields?.title || null,
                }))) ||
            null
        footerData.dentalCare = firstItem?.dentalCare || null,
        footerData.instaCard = firstItem?.instagramCard && (getFeatureCard(firstItem?.instagramCard))
        return footerData
    } else {
        return {}
    }
}
