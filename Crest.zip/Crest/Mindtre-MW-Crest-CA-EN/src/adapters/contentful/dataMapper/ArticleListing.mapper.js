import { locales, pageTypes } from "@constants"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getImageData } from "@dataMapperHelper/image.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getRelatedArticleData } from "@dataMapperHelper/relatedArticle.helper"
import urlHelper from "@helpers/url.helpers"

const createFilter = (locale, title, collection)=>{
    const mainEntry = collection?.find((entry)=>entry?.fields?.title === title)
    const subEntries = collection?.filter((entry)=>entry?.fields?.title !== title)
    if(mainEntry){
        const data = {
            sys: mainEntry?.sys?.id || null, 
            title: mainEntry?.fields?.title || null,
            url: urlHelper({ locale, pageType: pageTypes.alpPage, topicSlug: mainEntry?.fields?.topics, listingSlug: mainEntry?.fields?.slug }),
            subEntries: subEntries.map((subEntry)=>({
                sys: subEntry?.sys?.id || null, 
                title: subEntry?.fields?.title || null,
                url: urlHelper({ locale, pageType: pageTypes.alpPage, topicSlug: subEntry?.fields?.topics, listingSlug: subEntry?.fields?.slug }),
            }))
        }
        return [data]
    }else{
        return []
    }

}

export const getMappedArticleListingData = (content, container, articles) => {
    const articleListingData = {
        locale: locales.english,
        title: null,
        subTitle: null,
        banner: null,
        filters: [],
        articles: [],
    }

    const firstContentEntry = content.items[0] && content.items[0].fields
    const firstContainerEntry = container.items[0] && container.items[0]?.fields
    
    if(firstContentEntry && firstContainerEntry && firstContainerEntry.allCategories){
        articleListingData.locale = container.items[0].sys.locale
        articleListingData.title = firstContentEntry?.pageTitle || firstContentEntry?.title || null
        articleListingData.subTitle = firstContentEntry?.subTitle || null
        articleListingData.banner = {
            desktopImage: firstContentEntry?.banner?.fields?.desktopImage && getImageData(firstContentEntry?.banner?.fields?.desktopImage)||null,
            smartphoneImage: firstContentEntry?.banner?.fields?.smartphoneImage && getImageData(firstContentEntry?.banner?.fields?.smartphoneImage)||null,
        } || null

        articleListingData.filters = [
            {
                sys:firstContainerEntry.allCategories?.sys?.id, 
                title: firstContainerEntry.viewAllTips,
                url: urlHelper({ locale: articleListingData.locale, pageType: pageTypes.alpPage, topicSlug: firstContainerEntry.allCategories?.fields?.slug })
            },
            ...(createFilter(articleListingData.locale, firstContainerEntry.conditionTitle, firstContainerEntry.conditions)),
            ...(createFilter(articleListingData.locale, firstContainerEntry.lifeStagesTitle, firstContainerEntry.lifeStages)),
        ]

        const featuredArticles = firstContentEntry?.featuredArticles?.map(({ sys })=>sys?.id)||[]

        articleListingData.articles = articles.items.map(({ fields })=>fields?.content).filter((article)=>
            (article && article.fields && article.fields.articleCategory 
            && firstContentEntry.articleCategory.indexOf(article.fields.articleCategory)!==-1)).map((article)=>{
            const data = getRelatedArticleData(article, articleListingData.locale)
            if(featuredArticles.indexOf(data.sys)!==-1){
                data.categoryBasedFeatured = true
            }
            return data
        }).sort((a,b)=>{
            if(b.categoryBasedFeatured && !a.categoryBasedFeatured){
                return 1
            }else if(a.categoryBasedFeatured && !b.categoryBasedFeatured){
                return -1
            }else{
                return 0
            }
        })||[]

        const breadcrumb = firstContentEntry?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstContentEntry?.pageMetadata && getPageMetadata(firstContentEntry?.pageMetadata) || {}

        return {
            props: {
                pageData: articleListingData,
                pageType: pageTypes.alpPage,
                breadcrumb,
                pageMetadata,
                locale: articleListingData.locale,
            },
        }
    }else{
        return {
            props: {
                pageData: {},
                pageType: pageTypes.alpPage,
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english,
            },
        }
    }
}

export const getMappedArticleListingSlugWithParent = (entries) =>{
    const entry = entries?.items[0] && entries?.items[0].fields
    const array = [...(entry?.conditions?.map((category)=>({
        params:{
            topics: category.fields.topics,
            listingSlug: category.fields.slug
        }
    }))||[]), ...(entry?.lifeStages?.map((category)=>({
        params:{
            topics: category.fields.topics,
            listingSlug: category.fields.slug
        }
    }))||[])]
    return array
}

export const getMappedArticleListingSlugWithoutParent = (entries) =>{
    const entry = entries?.items[0] && entries?.items[0]?.fields
    return entry && entry.allCategories ? [
        {
            params:{
                topics: entry.allCategories?.fields?.slug
            }
        }
    ]:[]
}
