import { locales, pageTypes } from "@constants"
import { getImageData } from "@dataMapperHelper/image.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getRelatedProductData } from "@dataMapperHelper/relatedProduct.helper"
import { getFeatureCard } from "@dataMapperHelper/featureCard.helper"

export const getHomepageData = (entries) => {
    const homeData = {
        banner:{},
        featureCards:[],
        productHeroSection:{},
        articleTopics:[],
        extraSmileCard:{},
        homeCategories:[],
        oralHygieneTips:{},
        featuredProductsCarousel:[],
        healthySmiles:{},
        testimonials:[],
    }
    const firstItem = entries?.items[0]?.fields
    if(firstItem){
        homeData.locale = entries?.items[0].sys.locale || null
        homeData.name = firstItem.name || null
        const bannerFields = firstItem?.banner?.fields
        homeData.banner = {
            title: bannerFields?.title || null,
            imageset: bannerFields?.imageSet && {
                desktopImage: getImageData(bannerFields?.imageSet?.fields?.desktopImage),
                smartphoneImage: getImageData(bannerFields?.imageSet?.fields?.smartphoneImage),
            } || null,
            href: bannerFields?.callToActions[0]?.fields?.url || null,
            linkText: bannerFields?.callToActions[0]?.fields?.title || null,
        }

        homeData.featureCards = firstItem?.featureCards?.map((item)=>(getFeatureCard(item)))

        homeData.extraSmileCard = firstItem?.extraSmileCard && (getFeatureCard(firstItem?.extraSmileCard))

        homeData.homeCategories = firstItem?.categories?.map((item)=>({
            imageset: item?.fields?.imageSet && {
                desktopImage: getImageData(item?.fields?.imageSet?.fields?.desktopImage),
                smartphoneImage: getImageData(item?.fields?.imageSet?.fields?.smartphoneImage),
            } || null,
            href: item?.fields?.link || null,
            linkText:item?.fields?.linkText || null,
        }))

        homeData.oralHygieneTips = firstItem?.oralHygieneTips && (getFeatureCard(firstItem?.oralHygieneTips))

        homeData.productHeroSection = firstItem?.productHeroSection && (getFeatureCard(firstItem?.productHeroSection))

        homeData.moreTopicsTitle = firstItem?.moreTopicsTitle
        homeData.articleTopics = firstItem?.articleTopics.map((topic)=>({ ...topic.fields }))
        homeData.featuredProductsCarousel =
        firstItem?.featuredProductsCarousel?.map((product) =>
            getRelatedProductData(product, homeData.locale, true)
        ) || []

        homeData.healthySmiles = firstItem?.healthySmiles && (getFeatureCard(firstItem?.healthySmiles))

        homeData.testimonials = firstItem?.testimonials?.map((item)=>(getFeatureCard(item)))
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}

        return {
            props: {
                pageData: homeData,
                pageType: pageTypes.homepage,
                pageMetadata,
                locale: homeData.locale,
            },
        }
    }
    else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.homepage,
                pageMetadata:{},
                locale: locales.english,
            },
        }
    }
}
