import { locales,pageTypes } from "@constants"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getFeatureCard } from "@dataMapperHelper/featureCard.helper"

export const getMappedOffersPageData =(entries)=>{

    const offersPageData ={
        locale: locales.english,
        featureCards:{},
      
    }

    const firstItem = entries?.items[0] && entries?.items[0]?.fields
    if (firstItem) {

        offersPageData.locale = entries?.items[0]?.sys?.locale
        offersPageData.title = firstItem?.title || null
        offersPageData.cardTitle = firstItem?.cardTitle || null
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}
        offersPageData.featureCards = firstItem?.card?.map((card) => (getFeatureCard(card))) || null
        return {
            props: {
                pageData: offersPageData,    
                pageType: pageTypes.offersPage,      
                breadcrumb,
                pageMetadata,
                locale: offersPageData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.offersPage, 
                breadcrumb:[],
                pageMetadata:{},
                locale: locales.english,
            },
        }
    }
}