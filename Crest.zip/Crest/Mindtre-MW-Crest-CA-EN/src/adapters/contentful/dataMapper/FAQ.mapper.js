import constants, { locales, pageTypes } from "@constants"
import urlHelper from "@helpers/url.helpers"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getFeatureCard } from "@dataMapperHelper/featureCard.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"
import { getRelatedArticleData } from "@dataMapperHelper/relatedArticle.helper"

export const getMappedFAQData = (entries, container) => {
    const faqPageData = {
        locale: "",
        bannerCard: {},
        accordionCollection: [],
        faqCategoryCollection: [],
        relatedArticles: [],
    }
    const firstEntry = entries?.items[0] && entries?.items[0]?.fields
    const firstContainer = container?.items[0] && container?.items[0]?.fields

    if (firstEntry && firstContainer) {
        faqPageData.locale = entries?.items[0].sys.locale || constants.english
        faqPageData.bannerCard = (firstEntry?.bannerCard && getFeatureCard(firstEntry?.bannerCard)) || {}
        faqPageData.accordionCollection = firstEntry?.accordion?.map((item) => ({ ...item.fields })) || []
        faqPageData.faqCategoryCollection =
            firstContainer?.categories
                .filter((entry) => entry?.fields?.slug)
                .map((item) => ({
                    title: item?.fields?.title || "",
                    url:
                        (item?.fields?.slug && urlHelper({ locale: faqPageData.locale, pageType: pageTypes.faqPage, slug: item?.fields?.slug })) ||
                        "",
                })) || []
        faqPageData.relatedArticles = firstEntry?.relatedArticles?.map((card) => getRelatedArticleData(card, faqPageData.locale)) || []
        const breadcrumb = firstEntry?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata = (firstEntry?.pageMetadata && getPageMetadata(firstEntry?.pageMetadata)) || {}

        return {
            props: {
                pageData: faqPageData,
                pageType: pageTypes.faqPage,
                breadcrumb,
                pageMetadata,
                locale: faqPageData.locale,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                pageType: pageTypes.faqPage,
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.english,
            },
        }
    }
}

export const getMappedFAQSlug = (entries) =>
    (entries?.items[0] &&
        entries?.items[0]?.fields?.categories
            ?.filter((entry) => entry?.fields?.slug)
            .map((entry) => ({
                params: {
                    endSlug: entry?.fields?.slug,
                },
            }))) ||
    []
