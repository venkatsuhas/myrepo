import { locales, pageTypes } from "@constants"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"

export const getMappedErrorPageData =(englishErrorData, frenchErrorData)=>{
    const errorPageData = {
        [locales.english]:{
            locale: locales.english,
            card: {}
        },
        [locales.french]:{
            locale: locales.french,
            card: {}
        }
    }

    const englishFirstData = englishErrorData?.items[0] && englishErrorData?.items[0]?.fields
    const frenchFirstData = frenchErrorData?.items[0] && frenchErrorData?.items[0]?.fields

    if (englishFirstData && frenchFirstData) {
        errorPageData[locales.english].locale = englishErrorData?.items[0]?.sys?.locale || locales.english
        errorPageData[locales.english].card = {
            title: englishFirstData?.card?.fields?.name || null,
            subTitle: englishFirstData?.card?.fields?.subTitle || null,
            href: englishFirstData?.card?.fields?.callToActions[0]?.fields?.url || null,
            linkText:  englishFirstData?.card?.fields?.callToActions[0]?.fields.title || null,
        }
        errorPageData[locales.french].locale = frenchErrorData?.items[0]?.sys?.locale || locales.french
        errorPageData[locales.french].card = {
            title: frenchFirstData?.card?.fields?.name || null,
            subTitle: frenchFirstData?.card?.fields?.subTitle || null,
            href: frenchFirstData?.card?.fields?.callToActions[0]?.fields?.url || null,
            linkText:  frenchFirstData?.card?.fields?.callToActions[0]?.fields.title || null,
        }
        const pageMetadata = englishFirstData?.pageMetadata && getPageMetadata(englishFirstData?.pageMetadata) || {}
        
        return {
            pageData: errorPageData,    
            pageType: pageTypes.errorPage,      
            pageMetadata,
            locale: locales.english,    
        }
    } else {
        return {
            pageData: {},
            pageType: pageTypes.errorPage, 
            pageMetadata:{},
            locale: locales.english,
        }
    }
}