import { getFeatureCard } from "@dataMapperHelper/featureCard.helper"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"

const { locales, pageTypes } = require("@constants")

export const getProductSafetyPageData =(entries)=>{
    const pageData ={
        bannerCard: {},
        linksCollection:[],
        fourStepsCard:{},
        highestStandard:{},
        stepsSection:[],
        videoCard:{},
        crestCards:[],
    }
    const firstItem = entries?.items[0]?.fields

    if(firstItem){
        pageData.locale = entries?.items[0].sys.locale || null
        pageData.bannerCard = firstItem?.bannerCard && (getFeatureCard(firstItem?.bannerCard)) || null
        pageData.linksCollection = firstItem?.linksSection?.map((item)=>({ ...item?.fields })) || []
        pageData.highestStandard = firstItem?.highestStandard && (getFeatureCard(firstItem?.highestStandard)) || null
        pageData.fourStepsCard  = firstItem?.fourStepsCard && (getFeatureCard(firstItem?.fourStepsCard)) || null
        pageData.stepsSection = firstItem?.stepsSection?.map((item)=>(getFeatureCard(item))) || []
        pageData.videoCard = firstItem?.videoCard && { ...firstItem?.videoCard?.fields } || null
        pageData.videoDescription = firstItem?.videoDescription || null
        pageData.crestCards = firstItem?.crestCards?.map((item)=>(getFeatureCard(item))) || []
        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb)||[]
        const pageMetadata = firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata) || {}

        return{
            props:{
                pageData:pageData,
                locale: pageData.locale,
                pageType: pageTypes.productSafetyPage,
                breadcrumb,
                pageMetadata,
            }
        }
    }
    else{
        return{
            props:{
                pageData:{},
                locale: locales.english,
                pageType: pageTypes.productSafetyPage,
                breadcrumb:[],
                pageMetadata:{},
            }
        } 
    }
}
