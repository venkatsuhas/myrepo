import { getMappedProductSlug, getMappedProductData } from "@contentful/dataMapper/Product.mapper"
import { getMappedProductReviewData } from "@contentful/dataMapper/ProductReview.mapper"
import { getMappedProductListingSlug, getMappedProductListingData } from "@contentful/dataMapper/ProductListing.mapper"
import { getMappedArticleSlug, getMappedArticleData } from "@contentful/dataMapper/Article.mapper"
import {
    getMappedArticleListingSlugWithoutParent,
    getMappedArticleListingSlugWithParent,
    getMappedArticleListingData,
} from "@contentful/dataMapper/ArticleListing.mapper"
import { getMappedHeaderData, getMappedFooterData } from "@contentful/dataMapper/Layout.mapper"
import { getMappedSearchData } from "@contentful/dataMapper/Search.mapper"
import { getHomepageData } from "@contentful/dataMapper/Homepage.mapper"
import { getStannousPageData } from "@contentful/dataMapper/StannousPage.mapper"
import { getSustainabilityPageData } from "@contentful/dataMapper/Sustainability.mapper"
import { getProductSafetyPageData } from "@contentful/dataMapper/ProductSafety.mapper"
import { getMappedSitemapData } from "@contentful/dataMapper/Sitemap.mapper"
import { getMappedContactUsData } from "@contentful/dataMapper/ContactUs.mapper"
import { getMappedReviewGuidelinesData } from "@contentful/dataMapper/ReviewGuidelines.mapper"
import { getMappedErrorPageData } from "@adapters/contentful/dataMapper/404.mapper"
import { getMappedOffersPageData } from "@adapters/contentful/dataMapper/Offers.mapper"
import { getMappedIngredientsData } from "@adapters/contentful/dataMapper/Ingredients.mapper"
import { getMappedFAQSlug, getMappedFAQData } from "@contentful/dataMapper/FAQ.mapper"
import { getWhiteningPageData } from "@contentful/dataMapper/WhiteningemulsionsData.mapper"
module.exports = {
    getMappedProductListingSlug,
    getMappedProductListingData,
    getMappedProductReviewData,
    getMappedArticleData,
    getMappedArticleSlug,
    getMappedProductData,
    getMappedProductSlug,
    getMappedArticleListingSlugWithoutParent,
    getMappedArticleListingSlugWithParent,
    getMappedArticleListingData,
    getMappedHeaderData,
    getMappedFooterData,
    getHomepageData,
    getMappedSearchData,
    getStannousPageData,
    getMappedSitemapData,
    getSustainabilityPageData,
    getMappedContactUsData,
    getProductSafetyPageData,
    getMappedReviewGuidelinesData,
    getMappedErrorPageData,
    getMappedOffersPageData,
    getMappedIngredientsData,
    getMappedFAQSlug,
    getMappedFAQData,
    getWhiteningPageData,
}
