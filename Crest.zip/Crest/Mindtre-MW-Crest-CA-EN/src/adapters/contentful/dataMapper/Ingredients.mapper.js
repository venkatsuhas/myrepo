import { locales, pageTypes } from "@constants"
import { getImageData } from "@dataMapperHelper/image.helper"
import { getBreadcrumb } from "@dataMapperHelper/breadcrumb.helper"
import { getPageMetadata } from "@dataMapperHelper/pageMetadata.helper"

export const getMappedIngredientsData = (entries) => {
    const ingredientsData = {
        bannerCard: {},
        firstCards: [],
        secondCards: [],
        bottomCards: [],
        firstTitle: null,
        secondTitle: null,
    }

    const firstItem = entries?.items[0] && entries?.items[0]?.fields

    if (firstItem) {
        ingredientsData.locale = entries?.items[0].sys.locale || null

        ingredientsData.bannerCard =
            (firstItem?.bannerCard && {
                sys: firstItem?.bannerCard?.sys?.id || null,
                title: firstItem?.bannerCard?.fields?.title || null,
                description: firstItem?.bannerCard?.fields?.description || null,
                imageSet:
                    (firstItem?.bannerCard?.fields?.imageSet && {
                        desktopImage: getImageData(firstItem?.bannerCard?.fields?.imageSet.fields?.desktopImage),
                        smartphoneImage: getImageData(firstItem?.bannerCard?.fields?.imageSet.fields?.smartphoneImage),
                    }) ||
                    null,
            }) ||
            null

        ingredientsData.bottomCards =
            (firstItem?.bottomCards &&
                firstItem?.bottomCards.map((bottomCard) => {
                    return {
                        sys: bottomCard?.sys?.id || null,
                        title: bottomCard?.fields?.title || null,
                        description: bottomCard?.fields?.description || null,
                        url: bottomCard?.fields?.callToActions[0]?.fields?.url || null,
                        image: (bottomCard?.fields?.image && getImageData(bottomCard?.fields?.image[0])) || null,
                    }
                })) ||
            null

        ingredientsData.firstTitle = firstItem?.firstSectionTitle || null
        ingredientsData.secondTitle = firstItem?.secondSectionTitle || null

        ingredientsData.firstCards =
            (firstItem?.firstSectionCards &&
                firstItem?.firstSectionCards.map((sectionCard) => {
                    return {
                        title: sectionCard?.fields?.title || null,
                        description: sectionCard?.fields?.description || null,
                        image: (sectionCard?.fields?.image && getImageData(sectionCard?.fields?.image[0])) || null,
                    }
                })) ||
            null

        ingredientsData.secondCards =
            (firstItem?.secondSectionCards &&
                firstItem?.secondSectionCards.map((sectionCard) => {
                    return {
                        description: sectionCard?.fields?.description || null,
                    }
                })) ||
            null

        const breadcrumb = firstItem?.breadcrumb?.map(getBreadcrumb) || []
        const pageMetadata = (firstItem?.pageMetadata && getPageMetadata(firstItem?.pageMetadata)) || {}

        return {
            props: {
                breadcrumb,
                pageMetadata,
                pageData: ingredientsData,
                locale: ingredientsData.locale,
                pageType: pageTypes.ingredientsPage,
            },
        }
    } else {
        return {
            props: {
                pageData: {},
                breadcrumb: [],
                pageMetadata: {},
                locale: locales.english,
                pageType: pageTypes.ingredientsPage,
            },
        }
    }
}
