import { locales } from "@constants"
import getContent from "@contentful/contentful.adapter"
import {
    getMappedProductData,
    getMappedProductSlug,
    getMappedProductReviewData,
    getMappedProductListingSlug,
    getMappedProductListingData,
    getMappedArticleData,
    getMappedArticleSlug,
    getMappedArticleListingData,
    getMappedArticleListingSlugWithoutParent,
    getMappedArticleListingSlugWithParent,
    getMappedSearchData,
    getMappedHeaderData,
    getMappedFooterData,
    getHomepageData,
    getStannousPageData,
    getSustainabilityPageData,
    getProductSafetyPageData,
    getMappedSitemapData,
    getMappedContactUsData,
    getMappedReviewGuidelinesData,
    getMappedErrorPageData,
    getMappedOffersPageData,
    getMappedIngredientsData,
    getMappedFAQSlug,
    getMappedFAQData,
    getWhiteningPageData,
} from "@contentful/dataMapper"

const getPromise = (queryOptions, mapperFunction) =>
    new Promise((resolve, reject) => {
        getContent(queryOptions)
            .then((entries) => {
                const mappedData = mapperFunction(entries)
                resolve(mappedData)
            })
            .catch(reject)
    })
const getFAQSlug = ({ locale }) => getPromise({ content_type: "faqContainer", locale }, getMappedFAQSlug)
const getFAQData = ({ slug, locale }) =>
    new Promise((resolve, reject) => {
        Promise.all([getContent({ content_type: "faqCategory", slug, locale }), getContent({ locale, content_type: "faqContainer" })])
            .then(([entries, container]) => {
                const mappedData = getMappedFAQData(entries, container)
                resolve(mappedData)
            })
            .catch(reject)
    })
const getPDPSlug = ({ locale }) => getPromise({ content_type: "productContainer", locale, limit: 500 }, getMappedProductSlug)
const getPDPData = ({ slug, listingSlug, locale }) => getPromise({ content_type: "product", slug, listingSlug, locale }, getMappedProductData)
const getProductReviewData = ({ slug, locale }) => getPromise({ content_type: "product", slug, locale }, getMappedProductReviewData)

const getProductListingSlug = ({ locale }) => getPromise({ content_type: "productCategoryContainer", locale }, getMappedProductListingSlug)
const getProductListingData = ({ slug, locale, topic }) =>
    new Promise((resolve, reject) => {
        Promise.all([
            getContent({ content_type: "productCategory", slug, locale, ...(topic ? { topic } : {} ) }),
            getContent({ content_type: "productCategoryContainer", locale }),
            getContent({
                locale,
                content_type: "productContainer",
                limit: 500,
            }),
        ])
            .then(([content, container, products]) => {
                const mappedData = getMappedProductListingData(content, container, products)
                resolve(mappedData)
            })
            .catch(reject)
    })

const getADPSlug = ({ locale }) => getPromise({ content_type: "articleContainer", locale, limit: 500 }, getMappedArticleSlug)
const getADPData = ({ slug, locale }) => getPromise({ content_type: "article", slug, locale }, getMappedArticleData)

const getArticleListingSlug = ({ locale, hasParent }) =>
    getPromise(
        { content_type: "articleCategoryContainer", locale },
        hasParent ? getMappedArticleListingSlugWithParent : getMappedArticleListingSlugWithoutParent
    )
const getArticleListingData = ({ locale, topics, slug }) =>
    new Promise((resolve, reject) => {
        Promise.all([
            getContent({ content_type: "articleCategory", ...(topics ? { topics } : {}), slug, locale }),
            getContent({ content_type: "articleCategoryContainer", locale }),
            getContent({
                locale,
                content_type: "articleContainer",
                limit: 500,
            }),
        ])
            .then(([content, container, articles]) => {
                const mappedData = getMappedArticleListingData(content, container, articles)
                resolve(mappedData)
            })
            .catch(reject)
    })

const getErrorPage = () =>  new Promise((resolve, reject) => {
    Promise.all([
        getContent({ content_type: "generalPage", pageType: "404", locale: locales.english }),
        getContent({ content_type: "generalPage", pageType: "404", locale: locales.french })
    ])
        .then(([englishData, frenchData]) => {
            const mappedData = getMappedErrorPageData(englishData, frenchData)
            resolve(mappedData)
        })
        .catch(reject)
})

const getHomePageData = ({ locale }) => getPromise({ content_type: "homepage", locale }, getHomepageData)
const getSearchPageData = ({ locale }) => getPromise({ content_type: "generalPage", locale, pageType: "Search" }, getMappedSearchData)
const getSustainabilityPage = ({ locale }) => getPromise({ content_type: "sustainabilityPage", locale }, getSustainabilityPageData)
const getContactUsData = ({ locale }) => getPromise({ content_type: "generalPage", locale, pageType: "Contact" }, getMappedContactUsData)
const getOffersPageData = ({ locale }) => getPromise({ content_type: "offersPage", locale }, getMappedOffersPageData)
const getReviewGuidelinesData = ({ locale }) =>
    getPromise({ content_type: "generalPage", locale, pageType: "ReviewGuidelines" }, getMappedReviewGuidelinesData)
const getStannousPage = ({ locale, slug }) => getPromise({ content_type: "stannousFlouridePage", slug, locale }, getStannousPageData)
const getProductSafetyPage = ({ locale, slug }) => getPromise({ content_type: "productSafetyPage", slug, locale }, getProductSafetyPageData)
const getHeaderData = ({ locale }) => getPromise({ content_type: "header", locale }, getMappedHeaderData)
const getFooterData = ({ locale }) => getPromise({ content_type: "footer", locale }, getMappedFooterData)
const getSitemapData = ({ locale }) => getPromise({ content_type: "sitemap", locale }, getMappedSitemapData)
const getIngredientsPageData = ({ locale }) => getPromise({ content_type: "ingredients", locale }, getMappedIngredientsData)
const getWhiteningemulsionsPage = ({ locale, slug }) => getPromise({ content_type: "whiteningEmulsionsPage", slug, locale }, getWhiteningPageData)
module.exports = {
    getPDPData,
    getPDPSlug,
    getProductReviewData,
    getProductListingSlug,
    getProductListingData,
    getADPData,
    getADPSlug,
    getArticleListingSlug,
    getArticleListingData,
    getSearchPageData,
    getHeaderData,
    getFooterData,
    getSitemapData,
    getHomePageData,
    getStannousPage,
    getSustainabilityPage,
    getProductSafetyPage,
    getContactUsData,
    getReviewGuidelinesData,
    getErrorPage,
    getOffersPageData,
    getIngredientsPageData,
    getFAQData,
    getFAQSlug,
    getWhiteningemulsionsPage,
}
