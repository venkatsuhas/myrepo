const { locales } = require('@constants')
module.exports = {
    url: {
        [locales.english]: "https://ca.crest.com/en-ca",
        [locales.french]: "https://ca.crest.com/fr-ca"
    },
    brandLogoURL: "https://res.cloudinary.com/mtree/Crest_CA_MW/3Hbn3Uxldw8nxXJC8knoe0/c85c91e6aff2f212a37fcb637fa1d291/crest-favIcon.png",
    sameAs: ["https://www.facebook.com/crest", "https://twitter.com/crest", "https://www.youtube.com/crest"]
}