import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { locales } from "@constants"

const FeatureCard = dynamic(() => import("@components/Card/FeatureCard"))
const Typography = dynamic(() => import("@components/Typography"))

const OffersPage = ({ locale, title, featureCards, cardTitle }) => {
    return (
        <div className='offerPageWrapper mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0'>
            <div>
                <h1 className='mx-auto text-left mdl:text-center text-28 mdl:text-34 leading-34 mdl:leading-40 font-neutrafaceDemi text-primary w-full mb-30'>{title}</h1>               
                <div className='offerFeatureCardSection mx-auto w-full mdl:w-10/12 mb-40 mdl:mb-80'>
                    <Typography content={cardTitle} className='mx-auto text-left mdl:text-center text-28 mdl:text-34 leading-34 mdl:leading-40 font-neutrafaceDemi text-primary w-full mb-30 mdl:mb-45' />
                    <div className='mx-auto w-full mdl:flex'>
                        {featureCards?.map((card, index) => (
                            <div key={index} className='featureCards w-full mdl:w-1/3 mdl:mx-15 mb-40 mdl:mb-0'>
                                <FeatureCard {...card} cardStyles={locale === locales.english ? 'offerFeatureCard' : 'frOffresncoupons'} />
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}

OffersPage.propTypes = {
    title: PropTypes.string,
    cardTitle: PropTypes.string,
    featureCards: PropTypes.object,
    locale:PropTypes.string
}

export default memo(OffersPage)
