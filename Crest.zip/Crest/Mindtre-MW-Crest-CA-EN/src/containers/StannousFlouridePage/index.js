import React, { memo } from "react"
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { locales } from "@constants"


const ProductCard = dynamic(() => import('@components/Card/ProductCard'))
const FeatureCard = dynamic(() => import("@components/Card/FeatureCard"))
const Typography = dynamic(() => import("@components/Typography"))
const Image = dynamic(() => import("@components/Image"))

const StannousPage = ({ locale, pageTitle, pageSubTitle, benefitCards, innovationCard, dentalCardTitle, dentalCardSubTitle, innovationCardTitle, dentalCards, productsCard, crestLogo }) => {
    return (
        <div className='w-full mt-25 mdl:mt-60'>
            <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0'>
                <div className='w-full mdl:w-8/12 mx-auto'>
                    <p className='mx-auto text-left mdl:text-center text-16 leading-40 text-accent font-neutrafaceBook uppercase mb-15'>{pageSubTitle}</p>
                    <Typography content={pageTitle} className='mx-auto text-left mdl:text-center text-28 mdl:text-34 leading-34 mdl:leading-40 font-neutrafaceDemi text-primary mdl:w-70p lg:w-55p mb-35 mdl:mb-50' />
                    <ul className='w-full mx-auto mdl:flex mdl:flex-wrap mb-80 mdl:mb-45'>
                        {benefitCards?.map((card, index) =>
                            <li key={index} className='w-full mdl:w-50p mb-40 mdl:mb-50 pl-25 mdl:px-30 list-none border-solid border-l-4 border-lightGreyBlue'>
                                <FeatureCard {...card} cardStyles='stannousBenefitCard' key={index} />
                            </li>
                        )}
                    </ul>
                </div>
            </div>
            <div className='w-full text-white border-solid border border-lightGray2  stannous-crestSection'>
                <div className='innovationSection'>
                    <div className=''>
                        <Image desktopClassName='max-w-150 text-center mx-auto pt-35 mdl:pt-50 pb-25 mdl:pb-15' smartphoneClassName='style.imgContainerSp' wrapperClassName='style.imgWrapper'
                            desktopImage={crestLogo} alt={crestLogo?.altText} />
                    </div>
                    <Typography content={innovationCardTitle} className='mx-auto px-20 lg:px-0 text-left mdl:text-center text-28 mdl:text-34 leading-34 mdl:leading-40 font-neutrafaceDemi mdl:w-50p lg:w-35p mb-40 mdl:mb-55' />
                    <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0'>
                        <ul className='mdl:flex mdl:flex-wrap mdl:w-10/12 mx-auto'>
                            {innovationCard?.map((card, index) =>
                                <li key={index} className='w-full mdl:w-25p list-none border-l-2 mdl:border-l-0 mdl:border-t-2 border-solid border-white relative'>
                                    <FeatureCard {...card} cardStyles={locale === locales.english ? 'stannousInnovationCard' : 'frStannousInnovationCard'} />
                                </li>
                            )}
                        </ul>
                    </div>
                </div>
                <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mt-100 mdl:mt-190 mdl:mb-60 stannous-dentalSection'>
                    <div className='mdl:w-10/12 mx-auto'>
                        <Typography content={dentalCardTitle} className='mx-auto w-full text-left mdl:text-center text-28 mdl:text-34 leading-34 mdl:leading-40 font-neutrafaceDemi mb-15' />
                        <Typography content={dentalCardSubTitle} className='mx-auto w-full text-left mdl:text-center text-20 leading-26 font-neutrafaceBook mb-60 mdl:mb-55 dentalCardSubTitle' />
                        <ul className='mdl:flex mdl:flex-wrap w-full mb-50 mdl:mb-0'>
                            {dentalCards?.map((card, index) =>
                                <li key={index} className='w-full mdl:w-4/12 mdl:px-20 lg:px-50 list-none '>
                                    <FeatureCard {...card} cardStyles='stannousDentalCard' key={index} />
                                </li>
                            )}
                        </ul>
                    </div>
                </div>
            </div>
            <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mdl:mb-60 stannous-productsCard'>
                <div className='w-full mdl:w-8/12 mx-auto mdl:flex justify-center'>
                    {productsCard?.map((card, index) => (
                        <div key={index} className='productWrapper w-full mdl:w-50p mb-70 mdl:mb-0  lg:mr-0'>
                            <div className='productDetails lg:pr-80'>
                                <Typography content={card?.title} className='w-full text-left text-primary text-28 mdl:text-34 leading-34 mdl:leading-40 font-neutrafaceDemi mb-15 mdl:mb-25' />
                                <Typography content={card?.description} className='text-20 leading-26 font-neutrafaceBook text-center w-full text-secondary  description' />
                            </div>
                            <ProductCard
                                key={card?.product.sys}
                                locale={locale}
                                {...card.product}
                                variant='stannousProductCard'
                            />
                        </div>
                    ))}
                </div>
            </div>

        </div>
    )
}

StannousPage.propTypes = {
    locale: PropTypes.string.isRequired,
    crestLogo: PropTypes.object,
    dentalCardTitle: PropTypes.string,
    dentalCardSubTitle: PropTypes.string,
    innovationCardTitle: PropTypes.string,
    pageSubTitle: PropTypes.string,
    pageTitle: PropTypes.string,
    innovationCard: PropTypes.array,
    benefitCards: PropTypes.array,
    dentalCards: PropTypes.array,
    productsCard: PropTypes.array,
}

export default memo(StannousPage)
