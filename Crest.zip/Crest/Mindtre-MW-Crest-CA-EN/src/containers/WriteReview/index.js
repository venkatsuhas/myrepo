import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"

const WriteReviewForm = dynamic(()=>import("@components/WriteReview/WriteReviewForm"))
const ReviewProduct = dynamic(()=>import('@components/WriteReview/ReviewProduct'))

const WriteReview= ({ locale, productName, heroImage, bazaarVoiceId }) => {
    return (
        <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mt-20'>
            <div className='w-full mdl:w-lgm mx-auto flex flex-col md:flex-row flex-wrap justify-center items-start'>
                <ReviewProduct heroImage={heroImage} productName={productName}/>
                <WriteReviewForm
                    locale={locale}
                    bazaarVoiceId={bazaarVoiceId}
                />
            </div>
        </div>
    )
}

WriteReview.propTypes = {
    locale: PropTypes.string.isRequired,
    bazaarVoiceId: PropTypes.string.isRequired,
    productName: PropTypes.string.isRequired,
    heroImage: PropTypes.shape({
        sys: PropTypes.string,
        url: PropTypes.string,
        altText: PropTypes.string,
        height: PropTypes.number,
        width: PropTypes.number,
    }),
}

export default memo(WriteReview)
