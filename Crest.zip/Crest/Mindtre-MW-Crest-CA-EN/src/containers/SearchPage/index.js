import React, { useState, useEffect, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import { labels as allLabels } from "@constants"
import searchHandler from "@adapters/algolia/searchHandler"
import useSearchPageReducer, { ACTIONS, TABS } from '@containers/SearchPage/SearchPage.reducer'

const Button = dynamic(()=>import("@components/Button"))
const FilterAccordion = dynamic(()=>import("@components/FilterAccordion"))
const Icon = dynamic(()=>import("@components/Icon"))
const ProductCard = dynamic(()=>import("@components/Card/ProductCard"))

const SearchPage = ({ locale, productFilterData }) => {
    const router = useRouter()
    const labels = allLabels[locale.toLowerCase()].searchPage
    const [searchTerm, setSearchTerm] = useState(null)
    const { state, dispatch } = useSearchPageReducer()

    useEffect(() => {
        dispatch({ type: ACTIONS.SET_ALL_FILTERS, value: productFilterData })
    }, [])

    useEffect(() => {
        if (router.asPath.match(/[^?]*\?term=([^&]+)/g)) {
            const term = decodeURI(router.asPath.replace(
                /[^?]*\?term=([^&]+)/g,
                (...node) => node[1]
            ))
            if (term) {
                setSearchTerm(term)
            }
        }
    }, [router.asPath])

    useEffect(() => {
        if (searchTerm) {
            searchHandler({ searchTerm, locale, type: "all", limit: 200 })
                .then(({ results }) => {
                    const products = results[0].hits.map((product) => ({
                        id: product.objectID,
                        productName: product.productName,
                        url: product.url,
                        productHeroImage: product.productHeroImage,
                        priceSpiderId: product.priceSpiderId,
                        facets: [
                            ...(product.facets || []),
                            product.category,
                        ],
                    }))
                    const articles = results[1].hits.map((article) => ({
                        id: article.objectID,
                        name: article.articleName,
                        category: article.articleCategory,
                        url: article.url,
                    }))
                    dispatch({ type: ACTIONS.SET_SEARCH_PRODUCTS, value: products })
                    dispatch({ type: ACTIONS.SET_SEARCH_ARTICLES, value: articles })
                })
                .catch((err) => {
                    console.error(err)
                })
        }
    }, [searchTerm])

    return (
        <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl'>
            <div className='text-28 leading-34 text-center font-neutrafaceDemi text-primary pt-30 pb-40 px-20 mdl:text-34 mdl:leading-40 mdl:pt-20'>
                {labels.resultCount
                    .replace(
                        "$count",
                        state.filteredProducts.length +
                        state.filteredArticles.length
                    )
                    .replace("$searchTerm", searchTerm)}
            </div>
            <div className='flex justify-center px-20 border-b border-lightestBorder'>
                <Button
                    onClick={() => dispatch({ type: ACTIONS.ALTER_ACTIVE_TAB, value: TABS.PRODUCT_TAB })}
                    className={`text-22 leading-30 px-20 pb-8 ${state.activeTab === TABS.PRODUCT_TAB ? 'border-b-2 border-accent font-neutrafaceDemi' : ''}`}>{`${labels.productsTitle}-${state.filteredProducts.length}`}</Button>
                <Button
                    onClick={() => dispatch({ type: ACTIONS.ALTER_ACTIVE_TAB, value: TABS.ARTICLE_TAB })}
                    className={`text-22 leading-30 px-20 pb-8 ${state.activeTab === TABS.ARTICLE_TAB ? 'border-b-2 border-accent font-neutrafaceDemi' : ''}`}>{`${labels.articlesTitle}-${state.filteredArticles.length}`}</Button>
            </div>
            <div>
                <div className={`${state.filteredProducts.length > 0 ? 'flex flex-wrap' : ''}  ${state.activeTab === TABS.PRODUCT_TAB ? "" : "hidden"}`}>
                    {state.filteredProducts.length > 0 && (<div className='w-full px-20 lg:px-0 mdl:w-3/12 mdl:pt-30 hidden mdl:block'>
                        <div className='py-10 flex justify-between mdl:px-0 text-20 leading-30 border-b border-lightestBorder'>
                            {labels.filtersTitle}
                            <Button onClick={() => dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })}>{labels.clearFilters}</Button>
                        </div>
                        {state.filterData.filter(filter => filter.options.filter(option => option.count).length).map((filter) => (
                            <FilterAccordion
                                key={filter?.name
                                    ?.toLowerCase()
                                    .replace(" ", "-")}
                                title={filter.name}
                                options={filter.options.map((option) => ({
                                    name: option.name,
                                    state: state.activeFilters.indexOf(option.name) !== -1,
                                    count: option.count
                                }))}
                                filterUpdate={(value) => dispatch({ type: ACTIONS.TOGGLE_ACTIVE_FILTER, value })}
                                variant='ProductListingPage'
                            />
                        ))}
                    </div>)}
                    {state.showMobileFilter && (
                        <div className={`${state.showMobileFilter ? "block px-20 bg-white mdl:hidden fixed z-100 w-full top-0 left-0 h-screen pb-80 overflow-y-auto animate-fromLeft" : "animate-toLeft"}`}>
                            <div className='w-full flex flex-row justify-between items-center pb-16 mb-15 border-b border-lightestBorder pt-30 text-20 leading-30 font-neutrafaceBook'>
                                {labels.filtersTitle}
                                <Button onClick={() => dispatch({ type: ACTIONS.TOGGLE_MOBILE_FILTER })}>
                                    <Icon className='closeIcon' name='Close' />
                                </Button>
                            </div>
                            {state.filterData.filter(filter => filter.options.filter(option => option.count).length).map((filter) => (
                                <FilterAccordion
                                    key={filter?.name
                                        ?.toLowerCase()
                                        .replace(" ", "-")}
                                    title={filter.name}
                                    options={filter.options.map((option) => ({
                                        name: option,
                                        state: state.activeFilters.indexOf(option) !== -1
                                    }))}
                                    filterUpdate={(value) => dispatch({ type: ACTIONS.TOGGLE_ACTIVE_FILTER, value })}
                                    variant='SearchResultAccor'
                                />
                            ))}
                        </div>
                    )}
                    {state.filteredProducts.length === 0 && <div className='px-20 text-22 leading-30 font-neutrafaceBook pt-80 pb-100 text-center text-primary'>{labels.noResults.replace("$searchTerm", searchTerm)}</div>}
                    {state.filteredProducts.length > 0 && (<div className='w-full mdl:w-9/12 mdl:pt-30'>
                        <div className='flex justify-between flex-row items-start mdl:hidden px-20 pt-30 pb-20 border-b border-lightestBorder'>
                            <p className='w-1/2 mdl:w-5/12 lg:w-7/12 font-neutrafaceBook text-22 leading-30 text-primary text-opacity-70'>{`${state.filteredProducts.length} ${labels.products}`}</p>
                            <Button
                                className='w-1/2 mdl:w-7/12 lg:w-5/12 flex flex-wrap flex-row justify-end items-start font-neutrafaceBook text-22 leading-30 text-primary'
                                onClick={() => dispatch({ type: ACTIONS.TOGGLE_MOBILE_FILTER })}>
                                {state.showMobileFilter ? labels.hideFilters : labels.showFilters}
                                <Icon className='icon ml-10 fill-current text-accent' name={state.showMobileFilter ? "FilterOpened" : "FilterClosed"} />
                            </Button>
                        </div>

                        <div className='flex flex-row flex-wrap pt-30 px-10'>
                            {state.filteredProducts.slice(0, state.productsToDisplay).map((product) => (
                                <ProductCard
                                    key={product.id}
                                    locale={locale}
                                    href={product.url}
                                    title={product.productName}
                                    image={product.productHeroImage}
                                    buyNowSKU={product.priceSpiderId}
                                    variant='searchPageCard'
                                />
                            ))}
                            {state.filteredProducts.length > 0 && state.productsToDisplay <
                                state.filteredProducts.length && (
                                <Button onClick={() => dispatch({ type: ACTIONS.LOAD_MORE })} className='w-full flex justify-center text-20 font-neutrafaceDemi text-darkBlue mt-50 mb-100 underline cursor-pointer'>
                                    {labels.loadMore}
                                </Button>
                            )}
                        </div>
                    </div>)}
                </div>
                <div className={` ${state.activeTab === TABS.ARTICLE_TAB ? "" : "hidden"}`}>
                    {state.searchResultsArticles.length === 0 && <div className='px-20 text-22 leading-30 font-neutrafaceBook pt-80 pb-100 text-center text-primary'>{labels.noResults.replace("$searchTerm", searchTerm)}</div>}
                    {state.searchResultsArticles.length > 0 && (<div className='px-20 mdl:px-0 pt-30 mdl:pt-60 mdl:w-8/12 mdl:mx-auto pb-45'>
                        {state.filteredArticles.slice(0, state.articlesToDisplay).map((article) => (
                            <div key={article.id} className='mb-35 mdl:mb-40'>
                                <Button href={article.url} className='font-neutrafaceDemi text-18 leading-24 text-primary mb-10 inline-block'>{article.name}</Button>
                            </div>
                        ))}

                        {state.searchResultsArticles.length > 0 && state.articlesToDisplay <
                            state.filteredArticles.length && (
                            <Button onClick={() => dispatch({ type: ACTIONS.LOAD_MORE })} className='w-full flex justify-center text-20 font-neutrafaceDemi text-darkBlue mt-50 mb-100 underline cursor-pointer'>
                                {labels.loadMore}
                            </Button>
                        )}
                    </div>
                    )}
                </div>
            </div>
        </div>
    )
}

SearchPage.propTypes = {
    locale: PropTypes.string.isRequired,
    productFilterData: PropTypes.arrayOf(
        PropTypes.shape({
            name: PropTypes.string,
            options: PropTypes.array,
        })
    ).isRequired,
}

export default memo(SearchPage)
