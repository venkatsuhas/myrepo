import { useReducer } from 'react'
import { productsPerPageSearch, articlesPerPageSearch } from "@constants"

export const ACTIONS = {
    SET_SEARCH_PRODUCTS:'SET_SEARCH_PRODUCTS',
    SET_SEARCH_ARTICLES:'SET_SEARCH_ARTICLES',
    ALTER_ACTIVE_TAB:'ALTER_ACTIVE_TAB',
    SET_ALL_FILTERS:'SET_ALL_FILTERS',
    TOGGLE_ACTIVE_FILTER:'TOGGLE_ACTIVE_FILTER',
    RESET_ACTIVE_FILTER:'RESET_ACTIVE_FILTER',
    TOGGLE_MOBILE_FILTER:'TOGGLE_MOBILE_FILTER',
    LOAD_MORE:'LOAD_MORE'
}

export const TABS = {
    PRODUCT_TAB:'PRODUCT_TAB',
    ARTICLE_TAB:'ARTICLE_TAB'
}

const useSearchPageReducer = () => {
    const initialState = {
        searchResultsProducts: [],
        searchResultsArticles: [],
        filteredProducts:[],
        filteredArticles:[],
        productsToDisplay: productsPerPageSearch,
        articlesToDisplay: articlesPerPageSearch,
        activeTab: TABS.PRODUCT_TAB,
        allFilters: [],
        activeFilters: [],
        filterData:[],
        showMobileFilter: false,
    }

    const getFilterWithCountData = (filter, computedFilterData, value)=>{
        return filter.map((filterSet)=>{
            if(value && filterSet.options.some((option)=>typeof option === 'object'?(option.name===value):(option === value))){
                return ({
                    name: filterSet.name,
                    options: filterSet.options.map((option)=>typeof option === 'object'?({
                        name: option.name,
                        count: computedFilterData[option.name] && computedFilterData[option.name] > option.count ? computedFilterData[option.name] : option.count
                    }):({
                        name: option,
                        count: computedFilterData[option]||0
                    }))
                })
            }else{
                return ({
                    name: filterSet.name,
                    options: filterSet.options.map((option)=>typeof option === 'object'?({
                        name: option.name,
                        count: computedFilterData[option.name]||0
                    }):({
                        name: option,
                        count: computedFilterData[option]||0
                    }))
                })
            }
        })
    }

    const generateFilterData = (activeFilters, state, value)=>{
        const filteredProducts = state.searchResultsProducts.filter((product) => {
            if (activeFilters.length > 0 && product.facets) {
                const optionSets = state.allFilters.map((filterSet)=>filterSet.options.filter((option)=>activeFilters.indexOf(option)!==-1)).filter((filterSet)=>filterSet.length)
                return optionSets.every((optionSet) => optionSet.some(filter => product.facets.includes(filter)))
            } else {
                return true
            }
        })
        const computedFilterData = filteredProducts.reduce((prevState, product)=>
            product.facets.reduce((prevObject,facet)=>({ ...prevObject, [facet]: prevObject[facet]? prevObject[facet] + 1 : 1 }),prevState)
        ,{})
        const filtersWithCount = getFilterWithCountData(state.filterData, computedFilterData, value )
        return { filteredProducts, filterData: filtersWithCount }
    }

    const toggleActiveFilterHandler = (state, value)=>{
        const activeFilters = state.activeFilters.indexOf(value) === -1 ? [...state.activeFilters, value] : state.activeFilters.filter(filter=>filter!==value) 
        const { filteredProducts, filterData } = generateFilterData(activeFilters, state, value)
        return { ...state, activeFilters, filterData, filteredProducts, productsToDisplay: productsPerPageSearch }
    } 
    
    const resetActiveFilterHandler = (state)=>{
        const activeFilters = []
        const { filteredProducts, filterData } = generateFilterData(activeFilters, state)
        return { ...state, activeFilters, filterData, filteredProducts, productsToDisplay: productsPerPageSearch  }
    } 

    const reducer = (state, action) => {
        switch (action.type) {
        case ACTIONS.SET_SEARCH_PRODUCTS:
            return { ...state, searchResultsProducts: [...action.value], filteredProducts: [...action.value], productsToDisplay: productsPerPageSearch, activeFilters:[], ...( state.allFilters ? generateFilterData([], { ...state, searchResultsProducts: [...action.value] }) :{}) }
        case ACTIONS.SET_SEARCH_ARTICLES:
            return { ...state, searchResultsArticles: [...action.value], filteredArticles: [...action.value], articlesToDisplay: articlesPerPageSearch }
        case ACTIONS.ALTER_ACTIVE_TAB:
            return { ...state, activeTab: action.value }
        case ACTIONS.SET_ALL_FILTERS:
            return { ...state, allFilters: [...action.value], filterData: getFilterWithCountData(action.value, {}) }
        case ACTIONS.TOGGLE_ACTIVE_FILTER:
            return toggleActiveFilterHandler(state, action.value)
        case ACTIONS.RESET_ACTIVE_FILTER:
            return resetActiveFilterHandler(state)
        case ACTIONS.TOGGLE_MOBILE_FILTER:
            return { ...state, showMobileFilter: !state.showMobileFilter }
        case ACTIONS.LOAD_MORE:
            if(state.activeTab === TABS.PRODUCT_TAB && state.productsToDisplay < state.filteredProducts.length){
                return { ...state, productsToDisplay: state.productsToDisplay + productsPerPageSearch <= state.filteredProducts.length ? state.productsToDisplay + productsPerPageSearch : state.filteredProducts.length }
            }else if(state.activeTab === TABS.ARTICLE_TAB && state.articlesToDisplay < state.filteredArticles.length){
                return { ...state, articlesToDisplay: state.articlesToDisplay + articlesPerPageSearch <= state.filteredArticles.length ? state.articlesToDisplay + articlesPerPageSearch : state.filteredArticles.length }
            }else{
                return state
            }
        default:
            return state
        }
    }
    
    const [state, dispatch] = useReducer(reducer, initialState)
    return { state, dispatch }
}

export default useSearchPageReducer
