import React, { useState, useEffect } from "react"
import PropTypes from "prop-types"
import dynamic from 'next/dynamic'
import { useRouter } from "next/router"
import { locales } from "@constants"

const Button = dynamic(() => import("@components/Button"))
const Typography = dynamic(() => import("@components/Typography"))

const ErrorPage = ({ [locales.english]: englishData, [locales.french]: frenchData }) => {
    const [card, setCard] = useState(englishData?.card || {})
    const router = useRouter()

    useEffect(()=>{
        if(router.asPath){
            const locale = router.asPath?.split('/')[1]
            if(locale === locales.french?.toLowerCase()){
                setCard(frenchData?.card || {})
            }
        }
    },[])

    return (
        <div>
            <div className='pt-216 pb-221 mdl:pt-190 mdl:pb-210 text-center w-full max-w-647 mx-auto px-20 mdl:px-0'>
                {card && card.title &&
                <Typography content={card.title} className='font-neutrafaceBold text-50 leading-50 mdl:text-80 mdl:leading-80 text-secondary mb-20 opacity-60'/>}
                {card && card.subTitle &&<Typography content={card.subTitle} className='font-neutrafaceBook text-24 leading-30 mdl:text-28 mdl:leading-34 text-secondary mb-30 mdl:mb-35' br_allowed={false}/>} 
                <Button className='font-neutrafaceDemi text-18 leading-24 uppercase bg-accent text-white rounded-25 h-46 w-335 flex justify-center items-center mx-auto' href={card.href}>
                    {card.linkText}
                </Button>
            </div>
        </div>
    )
}

ErrorPage.propTypes = {
    [locales.english]: PropTypes.object,
    [locales.french]: PropTypes.object,
}

export default ErrorPage
