import React, { useState, useEffect, useCallback, memo, Fragment } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import { labels as allLabels, pageTypes, articlesPerPageALP } from "@constants"

const Icon = dynamic(() => import("@components/Icon"))
const Button = dynamic(() => import("@components/Button"))
const ArticleCard = dynamic(() => import("@components/Card/ArticleCard"))
const Image = dynamic(() => import("@components/Image"))
const DropDown = dynamic(() => import("@components/DropDown"))
const FilterSmallScreenAlp = dynamic(() => import("@components/Filters/SmallScreenAlp"))

const ArticleListingPage = ({ locale, title, subTitle, banner, filters, articles }) => {
    const labels = allLabels[locale.toLowerCase()].articleListingPage
    const router = useRouter()

    const [next, setNext] = useState(articlesPerPageALP)
    const [articlesToShow, setArticlesToShow] = useState([])
    const [hideFilter, setHideFilter] = useState(true)
    const [sortBy, setSetSortBy] = useState(labels.sortBy.items[0].value)

    const getSortedArray = useCallback(
        (limit = next, sortOption = sortBy) => {
            switch (sortOption) {
            case "ascending":
                return articles
                    .map((article) => ({ ...article, categoryBasedFeatured: false }))
                    .sort((a, b) => a.name.localeCompare(b.name))
                    .slice(0, limit)
            case "descending":
                return articles
                    .map((article) => ({ ...article, categoryBasedFeatured: false }))
                    .sort((a, b) => -1 * a.name.localeCompare(b.name))
                    .slice(0, limit)
            case "featured":
                return articles
                    .sort((a, b) => {
                        if (b.categoryBasedFeatured && !a.categoryBasedFeatured) {
                            return 1
                        } else if (a.categoryBasedFeatured && !b.categoryBasedFeatured) {
                            return -1
                        } else {
                            return 0
                        }
                    })
                    .slice(0, limit)
            default:
                return articles.slice(0, limit)
            }
        },
        [articles, next, sortBy]
    )

    useEffect(() => {
        setArticlesToShow(getSortedArray(next, sortBy))
    }, [next, sortBy])

    useEffect(() => {
        setArticlesToShow([])
        setNext(articlesPerPageALP)
        setSetSortBy(labels.sortBy.items[0].value)
        setArticlesToShow(getSortedArray(articlesPerPageALP, labels.sortBy.items[0].value))
    }, [router.asPath])

    const showMoreArticles = useCallback(() => {
        setNext((prevNext) => {
            if (prevNext < articles.length) {
                if (prevNext + articlesPerPageALP <= articles.length) return prevNext + articlesPerPageALP
                else return articles.length
            }
        })
    }, [articles])

    const toggleFilterIconState = useCallback(() => {
        setHideFilter((prevState) => !prevState)
    }, [])

    const handleDropDown = useCallback((value) => {
        setSetSortBy(value)
    }, [])

    const handleDropDownUrl = useCallback(
        (value) => {
            router.push(value)
        },
        [router]
    )

    return (
        <div className='relative mdl:-top-55'>
            <div className='w-full relative flex flex-col justify-start mdl:justify-center items-center'>
                {banner && (
                    <Image
                        desktopClassName='hidden mdl:block'
                        smartphoneClassName='hidden'
                        wrapperClassName='w-full mdl:min-h-455'
                        desktopImage={banner.desktopImage}
                        smartphoneImage={banner.smartphoneImage}
                        alt={banner.desktopImage?.altText}
                    />
                )}
                <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mdl:absolute'>
                    {title && (
                        <h1 className='w-full mdl:w-5/12 font-neutrafaceDemi text-30 leading-40 mdl:text-54 mdl:leading-60 text-left text-primary mb-24 mdl:mb-30 relative px-20 mdl:px-0 mdl:left-auto mdl:top-auto mt-15 mdl:mt-0'>
                            {title}
                        </h1>
                    )}
                    {subTitle && (
                        <p className='w-full mdl:w-5/12 font-neutrafaceBook text-20 leading-26 mdl:text-22 mdl:leading-30 text-left text-primary mdl:text-secondary'>
                            {subTitle}
                        </p>
                    )}
                </div>
            </div>
            <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 flex flex-row justify-center items-start flex-wrap mdl:mt-60'>
                <div className='w-full mdl:w-3/12 text-left mdl:pr-15 lg:pr-60 hidden mdl:flex mdl:flex-col mdl:flex-wrap items-start justify-start'>
                    {filters.map((filter) => {
                        if (filter.subEntries && filter.subEntries.length) {
                            const isParentLink = router.asPath === filter.url
                            const isChildLink = filter.subEntries.map((subEntry) => subEntry.url).indexOf(router.asPath) !== -1
                            return (
                                <Fragment key={filter.sys}>
                                    <Button
                                        key={filter.sys}
                                        href={filter.url}
                                        gaClass='event_internal_link'
                                        gaLabel={filter.url}
                                        className={`w-full block font-neutrafaceBold text-18 leading-26 text-left py-20 mdl:pt-0 uppercase cursor-pointer ${
                                            isParentLink || isChildLink
                                                ? "text-accentDark mdl:pb-20 flex flex-row justify-start items-center"
                                                : "text-secondary mdl:pb-40"
                                        }`}>
                                        {isChildLink && (
                                            <Icon
                                                className='fill-none stroke-current stroke-2 text-accentDark w-20 h-20 transform rotate-90 mr-10'
                                                name='ChevronArrow'
                                            />
                                        )}
                                        {filter.title}
                                    </Button>

                                    <div
                                        key={`${filter.sys}-div`}
                                        className={
                                            isParentLink || isChildLink ? "pb-20 flex flex-col flex-wrap justify-start items-start" : "hidden"
                                        }>
                                        {filter.subEntries.map((subEntry) => (
                                            <Button
                                                key={subEntry.sys}
                                                href={subEntry.url}
                                                gaClass='event_internal_link'
                                                gaLabel={subEntry.url}
                                                className={`font-neutrafaceBook text-20 leading-24 text-secondary pb-20 flex flex-row justify-start items-center`}>
                                                <div
                                                    className={`w-18 h-18 border mr-18 rounded-full flex flex-wrap justify-center items-center flex-shrink-0 ${
                                                        router.asPath === subEntry.url ? "border-accentDark" : "border-lightGreyBlue"
                                                    }`}>
                                                    <span
                                                        className={`w-10 h-10 bg-accentDark rounded-full  ${
                                                            router.asPath === subEntry.url ? "block" : "hidden"
                                                        }`}></span>
                                                </div>
                                                {subEntry.title}
                                            </Button>
                                        ))}
                                    </div>
                                </Fragment>
                            )
                        } else {
                            return (
                                <Button
                                    key={filter.sys}
                                    href={filter.url}
                                    gaClass='event_internal_link'
                                    gaLabel={filter.url}
                                    className={`w-full block font-neutrafaceBold text-18 leading-26 text-left py-20 mdl:pt-0 mdl:pb-40 uppercase cursor-pointer ${
                                        router.asPath === filter.url ? "text-accentDark mdl:pb-20" : "text-secondary mdl:pb-40"
                                    }`}>
                                    {filter.title}
                                </Button>
                            )
                        }
                    })}
                </div>

                <div className='w-full mdl:w-9/12 mdl:pl-10'>
                    <div className='w-full flex flex-row justify-between items-start mb-40 mdl:mb-0 mt-50 mdl:mt-0'>
                        <div className='w-full flex flex-row justify-between  items-center mdl:items-start mdl:hidden'>
                            <DropDown
                                onSelect={handleDropDownUrl}
                                variant={pageTypes.alpPage}
                                defaultValue={
                                    filters.find(
                                        (filter) =>
                                            router.asPath === filter.url ||
                                            (filter?.subEntries && filter?.subEntries?.map((subEntry) => subEntry.url).indexOf(router.asPath) !== -1)
                                    )?.title
                                }
                                options={filters.map((filter) => ({ title: filter.title, value: filter.url }))}
                            />
                            <Button
                                gaClass='event_button_click'
                                className='font-neutrafaceBook text-22 leading-30 text-secondary mdl:mr-40 flex items-center justify-end'
                                onClick={toggleFilterIconState}>
                                {labels.filters}
                                <Icon className='icon ml-10 fill-current text-accent' name={hideFilter ? "FilterClosed" : "FilterOpened"} />
                            </Button>
                        </div>
                        {!hideFilter && (
                            <div
                                className={`${
                                    hideFilter ? "hidden" : "block px-20 bg-white mdl:hidden fixed z-100 w-full top-0 left-0 h-screen overflow-hidden"
                                }`}>
                                <div className='w-full flex flex-row justify-between items-center pt-37 pb-16 mb-15 border-b border-lightestBorder'>
                                    <p className='font-neutrafaceBook text-20 leading-30 text-secondary'>{labels.filters}</p>
                                    <Button gaClass='event_button_click' onClick={toggleFilterIconState}>
                                        <Icon className='closeIcon' name='Close' />
                                    </Button>
                                </div>
                                {
                                    <FilterSmallScreenAlp
                                        locale={locale}
                                        variant={pageTypes.alpPage}
                                        filter={filters.find(
                                            (filter) =>
                                                router.asPath === filter.url ||
                                                (filter?.subEntries &&
                                                    filter?.subEntries?.map((subEntry) => subEntry.url).indexOf(router.asPath) !== -1)
                                        )}
                                        sortBy={sortBy}
                                        handleDropDown={handleDropDown}
                                        toggleFilterIconState={toggleFilterIconState}
                                    />
                                }
                            </div>
                        )}
                    </div>
                    <div className='w-full flex flex-col-reverse mdl:flex-row flex-wrap justify-between items-start mdl:border-b mdl:border-lightGray mdl:pb-20 mb-30 mdl:mb-40'>
                        <div className='w-full mdl:w-1/2'>
                            <p className='font-neutrafaceBook text-22 leading-30 text-center mdl:text-left text-secondary'>
                                {labels.showingCount.replace("$count", articles.length)}
                            </p>
                        </div>
                        <div className='w-full mdl:w-1/2 hidden mdl:flex mdl:justify-end mdl:items-start mdl:flex-row'>
                            <p className='hidden mdl:block font-neutrafaceBook text-22 leading-30 text-left text-secondary pr-10'>
                                {labels.sortBy.title}
                            </p>

                            <DropDown
                                onSelect={handleDropDown}
                                variant={pageTypes.alpPage}
                                defaultValue={labels.sortBy.items[0].name}
                                options={labels.sortBy.items.map((item) => ({ title: item.name, value: item.value }))}
                            />
                        </div>
                    </div>

                    <div className='flex flex-row flex-wrap justify-start items-start w-full'>
                        {articlesToShow &&
                            articlesToShow.length > 0 &&
                            articlesToShow.map((article) => <ArticleCard key={article.sys} locale={locale} {...article} variant='alpArticlesCard' />)}
                    </div>

                    {next < articles.length && (
                        <Button
                            gaClass='event_button_click'
                            onClick={showMoreArticles}
                            className='flex flex-wrap flex-col mdl:flex-row justify-start items-center mx-auto mt-40'>
                            <p className='font-neutrafaceDemi text-20 leading-30 text-gradientDarkBlue mb-40 underline cursor-pointer'>
                                {labels.loadMore}
                            </p>
                        </Button>
                    )}
                </div>
            </div>
        </div>
    )
}

ArticleListingPage.propTypes = {
    locale: PropTypes.string.isRequired,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    banner: PropTypes.object,
    filters: PropTypes.array,
    articles: PropTypes.array,
}

export default memo(ArticleListingPage)
