import { useReducer } from 'react'
import { productsPerPagePLP } from "@constants"

export const ACTIONS = {
    SET_PRODUCTS:'SET_PRODUCTS',
    SET_ALL_FILTERS:'SET_ALL_FILTERS',
    TOGGLE_ACTIVE_FILTER:'TOGGLE_ACTIVE_FILTER',
    RESET_ACTIVE_FILTER:'RESET_ACTIVE_FILTER',
    TOGGLE_FILTER_BUTTON:'TOGGLE_FILTER_BUTTON',
    LOAD_MORE:'LOAD_MORE',
    SET_SORT_BY:'SET_SORT_BY'
}

const useProductListingPageReducer = () => {
    const initialState = {
        products: [],
        filteredProducts:[],
        productsToDisplay: productsPerPagePLP,
        allFilters: [],
        activeFilters: [],
        filterData:[],
        showFilter: false,
        sortBy: null
    }

    const getSortedProducts = (filteredProducts, sortOption) => {
        switch (sortOption) {
        case "ascending":
            return filteredProducts.sort((a, b) => a.subTitle.trim().localeCompare(b.subTitle.trim()))
        case "descending":
            return filteredProducts.sort((a, b) => (-1 * a.subTitle.trim().localeCompare(b.subTitle.trim())))
        case "featured":
            return filteredProducts.sort((a, b) => (a.featuredRating - b.featuredRating))
        default:
            return filteredProducts
        }
    }

    const getFilterWithCountData = (filter, computedFilterData, value)=>{
        return filter.map((filterSet)=>{
            if(value && filterSet.options.some((option)=>typeof option === 'object'?(option.name===value):(option === value))){
                return ({
                    name: filterSet.name,
                    options: filterSet.options.map((option)=>typeof option === 'object'?({
                        name: option.name,
                        count: computedFilterData[option.name] && computedFilterData[option.name] > option.count ? computedFilterData[option.name] : option.count
                    }):({
                        name: option,
                        count: computedFilterData[option]||0
                    }))
                })
            }else{
                return ({
                    name: filterSet.name,
                    options: filterSet.options.map((option)=>typeof option === 'object'?({
                        name: option.name,
                        count: computedFilterData[option.name]||0
                    }):({
                        name: option,
                        count: computedFilterData[option]||0
                    }))
                })
            }
        })
    }

    const generateFilterData = (activeFilters, state, value)=>{
        const filteredProducts = getSortedProducts(state.products.filter((product) => {
            if (activeFilters.length > 0 && product.productFacets) {
                const optionSets = state.allFilters.map((filterSet)=>filterSet.options.filter((option)=>activeFilters.indexOf(option)!==-1)).filter((filterSet)=>filterSet.length)
                return optionSets.every((optionSet) => optionSet.some(filter => product.productFacets.includes(filter)))
            } else if(!product.productFacets){
                return false
            } else {
                return true
            }
        }), state.sortBy)
        const computedFilterData = filteredProducts.reduce((prevState, product)=>
            product.productFacets ? product.productFacets.reduce((prevObject,facet)=>({ ...prevObject, [facet]: prevObject[facet]? prevObject[facet] + 1 : 1 }),prevState) : prevState
        ,{})
        const filtersWithCount = getFilterWithCountData(state.filterData, computedFilterData, value )
        return { filteredProducts, filterData: filtersWithCount }
    }

    const toggleActiveFilterHandler = (state, value)=>{
        const activeFilters = state.activeFilters.indexOf(value) === -1 ? [...state.activeFilters, value] : state.activeFilters.filter(filter=>filter!==value) 
        const { filteredProducts, filterData } = generateFilterData(activeFilters, state, value)
        return { ...state, activeFilters, filterData, filteredProducts, productsToDisplay: productsPerPagePLP }
    } 
    
    const resetActiveFilterHandler = (state)=>{
        const activeFilters = []
        const { filteredProducts, filterData } = generateFilterData(activeFilters, state)
        return { ...state, activeFilters, filterData, filteredProducts, productsToDisplay: productsPerPagePLP  }
    } 

    const reducer = (state, action) => {
        switch (action.type) {
        case ACTIONS.SET_PRODUCTS:
            return { ...state, products: [...action.value], filteredProducts: [...action.value], productsToDisplay: productsPerPagePLP, activeFilters:[], ...( state.allFilters ? generateFilterData([], { ...state, products: [...action.value] }) :{}) }
        case ACTIONS.SET_ALL_FILTERS:
            return { ...state, allFilters: [...action.value], filterData: getFilterWithCountData(action.value, {}) }
        case ACTIONS.TOGGLE_ACTIVE_FILTER:
            return toggleActiveFilterHandler(state, action.value)
        case ACTIONS.RESET_ACTIVE_FILTER:
            return resetActiveFilterHandler(state)
        case ACTIONS.TOGGLE_FILTER_BUTTON:
            return { ...state, showFilter: !state.showFilter }
        case ACTIONS.LOAD_MORE:
            return { ...state, productsToDisplay: state.productsToDisplay + productsPerPagePLP <= state.filteredProducts.length ? state.productsToDisplay + productsPerPagePLP : state.filteredProducts.length }
        case ACTIONS.SET_SORT_BY:
            return { ...state, sortBy: action.value, filteredProducts: getSortedProducts(state.filteredProducts, action.value) }
        default:
            return state
        }
    }
    
    const [state, dispatch] = useReducer(reducer, initialState)
    return { state, dispatch }
}

export default useProductListingPageReducer
