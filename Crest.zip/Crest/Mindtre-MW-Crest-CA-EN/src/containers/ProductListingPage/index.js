import React, { useEffect, useState, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import { labels as allLabels, pageTypes } from "@constants"
import useProductListingPageReducer, { ACTIONS } from "@containers/ProductListingPage/ProductLisitingPage.reducer"

const Icon = dynamic(() => import("@components/Icon"))
const Image = dynamic(() => import("@components/Image"))
const Button = dynamic(() => import("@components/Button"))
const DropDown = dynamic(() => import("@components/DropDown"))
const ProductCard = dynamic(() => import("@components/Card/ProductCard"))
const FilterLargeScreen = dynamic(() => import("@components/Filters/LargeScreen"))
const FilterSmallScreen = dynamic(() => import("@components/Filters/SmallScreen"))

const ProductListingPage = ({ locale, bannerImage, title, subTitle, mainCategories, filters, products, type }) => {
    const labels = allLabels[locale.toLowerCase()].productListingPage
    const router = useRouter()
    const [isScrollUp, setScrollUp] = useState(false)
    const { state, dispatch } = useProductListingPageReducer()

    useEffect(() => {
        dispatch({ type: ACTIONS.SET_SORT_BY, value: labels.sortBy.items[0].name })
    }, [])

    useEffect(() => {
        dispatch({ type: ACTIONS.SET_ALL_FILTERS, value: filters })
        dispatch({ type: ACTIONS.SET_PRODUCTS, value: products })
        dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })
    }, [router.asPath])

    useEffect(() => {
        if (!state.showFilter) {
            document.body.classList.remove("overflow-hidden")
            document.body.classList.remove("mdl:overflow-auto")
        } else {
            document.body.classList.add("overflow-hidden")
            document.body.classList.add("mdl:overflow-auto")
        }
        return () => {
            document.body.classList.remove("overflow-hidden")
            document.body.classList.remove("mdl:overflow-auto")
        }
    }, [state.showFilter])

    const handleScroll = useCallback(() => {
        if (document.getElementById("navBar") && document.getElementById("navBar").className) {
            const headerClassName = document.getElementById("navBar").className.split(" ")
            const isHeaderSticky = headerClassName[headerClassName.length - 1] === "header-sticky" ? true : false
            setScrollUp(isHeaderSticky)
        }
    }, [])

    useEffect(() => {
        if (window) {
            window.addEventListener("scroll", handleScroll)
        }
        return () => {
            window.removeEventListener("scroll", handleScroll)
        }
    }, [])

    return (
        <div className='mdl:relative mdl:-top-55'>
            <div className='w-full relative flex flex-col justify-start mdl:justify-center items-center'>
                {bannerImage && bannerImage.desktopImage && (
                    <Image
                        key={bannerImage.desktopImage.sys}
                        desktopClassName='hidden mdl:block'
                        smartphoneClassName='block mdl:hidden'
                        wrapperClassName='w-full min-h-155 mdl:min-h-455'
                        desktopImage={bannerImage.desktopImage}
                        smartphoneImage={bannerImage.smartphoneImage}
                        alt={bannerImage.desktopImage?.altText}
                    />
                )}
                <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mdl:absolute'>
                    {title && (
                        <h1 className='w-full mdl:w-5/12 font-neutrafaceDemi text-30 leading-40 mdl:text-54 mdl:leading-60 text-left text-primary mdl:mb-30 absolute mdl:relative px-20 mdl:px-0 top-30 left-0 mdl:left-auto mdl:top-auto'>
                            {title}
                        </h1>
                    )}
                    {subTitle && (
                        <p className='w-full mdl:w-5/12 font-neutrafaceBook text-20 leading-26 mdl:text-22 mdl:leading-30 text-left text-primary mdl:text-secondary mt-15 mdl:mt-0'>
                            {subTitle}
                        </p>
                    )}
                </div>
            </div>
            <div className='mx-auto w-full mdl:px-20 lg:px-0 lg:w-lg mxl:w-mxl xl:w-xl mdl:mt-60 flex flex-row flex-wrap justify-center items-start'>
                <div
                    className={`w-full mdl:w-3/12 text-left mdl:pr-15 lg:pr-60${
                        state.showFilter ? " block mdl:hidden mdl:animate-toLeft" : " hidden mdl:block animate-toLeft mdl:animate-none"
                    }`}>
                    <FilterLargeScreen
                        type={type}
                        locale={locale}
                        variant={pageTypes.plpPage}
                        mainCategories={mainCategories}
                        filters={state.filterData}
                        toggleFilter={(value) => dispatch({ type: ACTIONS.TOGGLE_ACTIVE_FILTER, value })}
                        activeFilters={state.activeFilters}
                        resetFilter={() => dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })}
                    />
                    <div
                        className={`${
                            !state.showFilter
                                ? "animate-toLeft mdl:hidden"
                                : "block px-20 bg-white mdl:hidden fixed z-100 w-full top-0 left-0 h-screen overflow-hidden animate-fromLeft"
                        }`}>
                        <FilterSmallScreen
                            locale={locale}
                            variant={pageTypes.plpPage}
                            filters={state.filterData}
                            toggleFilter={(value) => dispatch({ type: ACTIONS.TOGGLE_ACTIVE_FILTER, value })}
                            activeFilters={state.activeFilters}
                            resetFilter={() => dispatch({ type: ACTIONS.RESET_ACTIVE_FILTER })}
                            handleDropDown={(value) => dispatch({ type: ACTIONS.SET_SORT_BY, value })}
                            sortBy={state.sortBy}
                            toggleFilterIconState={() => dispatch({ type: ACTIONS.TOGGLE_FILTER_BUTTON })}
                        />
                    </div>
                </div>
                <div className='w-full mdl:w-9/12 mdl:pl-10 filter'>
                    <div className={`sticky mdl:static top-0 z-20 bg-white pt-30 ${isScrollUp ? "scrollUp" : "scrollDown"}`}>
                        <div
                            className={`w-full flex justify-between flex-row items-start mdl:border-b mdl:border-lightestBorder mdl:pb-20 px-20 lg:px-0 mb-30`}>
                            <p className='w-1/2 mdl:w-5/12 lg:w-6/12 font-neutrafaceBook text-22 leading-30 text-secondary'>
                                {`${state.filteredProducts.length} ${labels.products}`}
                            </p>
                            <div className='w-1/2 mdl:w-7/12 lg:w-6/12 flex flex-wrap flex-row justify-end items-start'>
                                <Button
                                    gaClass='event_button_click'
                                    className='w-full mdl:hidden font-neutrafaceBook text-22 leading-30 text-secondary mdl:mr-40 flex items-center justify-end'
                                    onClick={() => dispatch({ type: ACTIONS.TOGGLE_FILTER_BUTTON })}>
                                    {!state.showFilter ? labels.showFilters : labels.hideFilters}
                                    <Icon
                                        className='icon ml-10 fill-current text-accent'
                                        name={!state.showFilter ? "FilterClosed" : "FilterOpened"}
                                    />
                                </Button>
                                <Button
                                    gaClass='event_button_click'
                                    className='hidden mdl:w-max font-neutrafaceBook text-22 leading-30 text-secondary mdl:flex items-center justify-end mdl:mr-40'
                                    onClick={() => dispatch({ type: ACTIONS.TOGGLE_FILTER_BUTTON })}>
                                    {state.showFilter ? labels.showFilters : labels.hideFilters}
                                    <Icon className='icon ml-10 fill-current text-accent' name={state.showFilter ? "FilterClosed" : "FilterOpened"} />
                                </Button>
                                <div className='w-full mdl:w-max hidden mdl:flex mdl:justify-end mdl:items-start mdl:flex-row'>
                                    <p className='hidden mdl:block font-neutrafaceBook text-22 leading-30 text-left text-secondary pr-10'>
                                        {labels.sortBy.title}
                                    </p>
                                    <DropDown
                                        onSelect={(value) => dispatch({ type: ACTIONS.SET_SORT_BY, value })}
                                        variant={pageTypes.plpPage}
                                        defaultValue={labels.sortBy.items[0].name}
                                        options={labels.sortBy.items.map((item) => ({ title: item.name, value: item.value }))}
                                        resetOnPathChange={true}
                                    />
                                </div>
                            </div>
                        </div>

                        <div className='mdl:hidden mt-30 pb-16 border-b border-lightestBorder overflow-hidden'>
                            <ul className='w-full flex flex-grow flex-nowrap justify-start items-start overflow-x-scroll pr-15 no-scrollbar'>
                                {mainCategories?.length > 0 &&
                                    mainCategories?.map((category, index) => {
                                        return (
                                            <li key={index} className='pl-15 text-17 leading-24 font-neutrafaceBook text-secondary'>
                                                <Button
                                                    gaClass='event_internal_link'
                                                    gaLabel={category.url}
                                                    className={
                                                        decodeURI(router.asPath) === category.url
                                                            ? "active font-neutrafaceDemi border-b-2 border-accentDark block w-max"
                                                            : "block w-max"
                                                    }
                                                    href={category.url}>
                                                    {category.title}
                                                </Button>
                                            </li>
                                        )
                                    })}
                            </ul>
                        </div>
                    </div>
                    {state.activeFilters && state.activeFilters.length > 0 && (
                        <div className='mdl:hidden w-full flex flex-row flex-wrap justify-start items-center px-20'>
                            {state.activeFilters.map((filter, index) => (
                                <div
                                    key={`${filter}-${index}`}
                                    className='bg-lightGreyBlue rounded-full py-9 px-15 mr-10 mb-10 flex flex-row justify-between items-center'>
                                    <label className='font-neutrafaceBook text-18 leading-22 text-primary'>{filter}</label>
                                    <Button
                                        gaClass='event_button_click'
                                        onClick={() => dispatch({ type: ACTIONS.TOGGLE_ACTIVE_FILTER, value: filter })}>
                                        <Icon className='w-10 h-10 stroke-current stroke-2 text-secondary ml-15' name='Close' />
                                    </Button>
                                </div>
                            ))}
                        </div>
                    )}
                    <div className='w-full flex flex-wrap flex-row justify-start items-start h-full px-10 lg:px-0'>
                        {state.filteredProducts.length > 0 &&
                            state.filteredProducts.slice(0, state.productsToDisplay).map((product, index) => (
                                <div
                                    key={`${product.sys}-${index}`}
                                    className='w-1/2 mdl:w-4/12 mdl:px-15 mb-30 mdl:mb-65 h-full flex justify-center items-start'>
                                    <ProductCard locale={locale} {...product} variant={pageTypes.plpPage} />
                                </div>
                            ))}
                    </div>
                    {state.productsToDisplay < state.filteredProducts.length && (
                        <Button
                            gaClass='event_button_click'
                            onClick={() => dispatch({ type: ACTIONS.LOAD_MORE })}
                            className='flex flex-wrap flex-col mdl:flex-row justify-start items-center mx-auto'>
                            <p className='font-neutrafaceDemi text-20 leading-30 text-gradientDarkBlue mb-20 underline cursor-pointer'>
                                {labels.loadMore}
                            </p>
                        </Button>
                    )}
                </div>
            </div>
        </div>
    )
}

ProductListingPage.propTypes = {
    locale: PropTypes.string.isRequired,
    bannerImage: PropTypes.object.isRequired,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    mainCategories: PropTypes.array.isRequired,
    type: PropTypes.string.isRequired,
    filters: PropTypes.array.isRequired,
    products: PropTypes.array,
}

export default memo(ProductListingPage)
