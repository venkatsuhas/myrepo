import React, { useState, useEffect, useRef, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'
import { getRatings } from '@adapters/bazaarvoice'
import { labels as allLabels } from '@constants'

const Accordion = dynamic(() => import('@components/Accordion'))
const ArticleCard = dynamic(() => import('@components/Card/ArticleCard'))
const Button = dynamic(() => import('@components/Button'))
const BuyNowButton = dynamic(()=>import('@components/Button/BuyNowButton'))
const Carousel = dynamic(() => import('@components/Carousel'))
const DropDown = dynamic(() => import('@components/DropDown'))
const Image = dynamic(() => import('@components/Image'))
const ProductCard = dynamic(() => import('@components/Card/ProductCard'))
const ProductGallery = dynamic(()=>import('@components/ProductGallery'))
const Rating = dynamic(() => import('@components/Rating'))
const Review = dynamic(() => import('@components/Review'))
const SmartLabel = dynamic(() => import('@components/SmartLabel'))
const Typography = dynamic(() => import('@components/Typography'))
const AccordionStates = ["PRODUCT_DETAILS", "OUR_INGREDIENTS", "FAQS"]

const getVariantData = ({ productVariants, hasMainVariant, hasSubVariant, mainIndex, subIndex, productDetails })=>{
    if(hasMainVariant){
        if(productVariants[mainIndex].subVariants && productVariants[mainIndex].subVariants.length > 0)
            return productVariants[mainIndex].subVariants[subIndex]
        else
            return productVariants[mainIndex]
    }else if(hasSubVariant) {
        return productVariants[subIndex]
    }else{
        return productDetails
    }
}

const ProductPage = ({ locale, name, mainCategory, productVariants, hasMainVariant, hasSubVariant, productImages, heroImage, description, productDetails, smartLabelId, faq, bazaarVoiceId, buyNowId, relatedProducts, relatedArticles, relatedArticlesListing }) => {
    const [openAccordion, setOpenAccordion] = useState(AccordionStates[0])
    const [selectedVariant, setSelectedVariant] = useState({ mainIndex: 0, subIndex: 0, data: getVariantData({ productVariants, hasMainVariant, hasSubVariant, mainIndex: 0, subIndex: 0, productDetails: { productImages, smartLabelId, buyNowId } }) })
    const [bazaarVoiceData, setBazaarVoiceData] = useState({})
    const [resetValue, setResetValue] = useState(false)
    const [isSticky, setSticky] = useState(false)

    const reviewRef = useRef(null)
    const buyNowRef = useRef(null)
    const stickyRef = useRef(null)
    const router = useRouter()

    const handleScroll = useCallback(() => {
        if (
            reviewRef.current &&
            buyNowRef.current &&
            stickyRef.current
        ) {
            const reviewElement = reviewRef.current,
                buyNowElement = buyNowRef.current,
                stickyElement = stickyRef.current,
                availableHeight = window.screen.availHeight
            if((window.screen.availWidth < 1000 && (buyNowElement.getBoundingClientRect().bottom < 0 && 
            reviewElement.getBoundingClientRect().bottom - availableHeight > 0 ))
            ||(window.screen.availWidth > 1000 && (buyNowElement.getBoundingClientRect().bottom < 0 && 
            reviewElement.getBoundingClientRect().bottom - availableHeight + (1.75 * stickyElement.getBoundingClientRect().height) > 0 ))){
                setSticky(true)
            }else{
                setSticky(false)
            }
        }
    },[])

    useEffect(() => {
        document.addEventListener("scroll", handleScroll, false)
        return () => {
            document.removeEventListener("scroll", handleScroll, false)
        }
    }, [])

    useEffect(handleScroll,[openAccordion, handleScroll])

    const accordionClick = useCallback((value)=>{
        setOpenAccordion(prevState=>{
            if(prevState === value){
                return null
            }else{
                if(document.querySelector('#accordion-wrapper')){
                    document.querySelector('#accordion-wrapper').scrollIntoView({ behavior: "smooth" })
                }
                return value
            }

        })
    },[])

    const resetValueUpdate = useCallback(()=>{
        setResetValue(false)
    },[])

    useEffect(() => {

        window?.dataLayer?.push({
            event: "customEvent",
            GAeventCategory: "event_informational_action",
            GAeventAction: "event_view_product_detail_page",
            GAeventLabel: name,
            GAeventValue: name,
            GAeventNonInteraction: false
        })

        setSelectedVariant({ mainIndex: 0, subIndex: 0, data: getVariantData({ productVariants, hasMainVariant, hasSubVariant, mainIndex: 0, subIndex: 0, productDetails: { productImages, smartLabelId, buyNowId } }) })
        setResetValue(true)
        getRatings({ productIds: [bazaarVoiceId, ...relatedProducts.map((product)=>product.bazaarVoiceId).filter(id=>id)], locale  }).then(setBazaarVoiceData).catch(()=>setBazaarVoiceData({}))
    }, [router.asPath])

    const setMainVariant = useCallback((index)=>{
        setSelectedVariant(prevState=>({ ...prevState, mainIndex: index, subIndex: 0, data: getVariantData({ productVariants, hasMainVariant, hasSubVariant, mainIndex: index, subIndex: 0 }) }))
        setResetValue(true)
    },[])
    const setSubVariant = useCallback((index)=>setSelectedVariant(prevState=>({ ...prevState, subIndex: index, data: getVariantData({ productVariants, hasMainVariant, hasSubVariant, mainIndex: prevState.mainIndex, subIndex: index }) })),[])

    const labels = allLabels[locale.toLowerCase()]?.productPage || {}
    const commonLabels = allLabels[locale.toLowerCase()] || {}

    return (
        <div>
            <div className='flex flex-col md:flex-row flex-wrap justify-center items-start mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mt-10'>
                <div className='w-full mdl:w-lgm mx-auto flex flex-col md:flex-row flex-wrap justify-center items-start'>
                    <div className='w-full md:w-1/2 hidden md:block md:pr-10 mdl:pr-30'>
                        {selectedVariant?.data?.productImages && selectedVariant?.data?.productImages.length > 0 && <ProductGallery isMobile={false} productImages={selectedVariant?.data?.productImages} />}
                    </div>
                    <div className='w-full md:w-1/2 md:pl-10 mdl:pl-30'>
                        <h1 className='font-neutrafaceDemi text-primary text-28 leading-34 lg:text-34 lg:leading-40 text-left mb-10 lg:mb-15'>{name}</h1>
                        <h3 className='font-neutrafaceBook text-left text-secondary mdl:text-primary text-18 leading-24 lg:text-20 lg:leading-28 mb-16 lg:mb-30'>{mainCategory}</h3>
                        <div className='w-full flex flex-wrap flex-row items-center justify-start mb-60'>
                            <Button href={`#product-${bazaarVoiceId}-review`}>
                                <Rating className='' svgClassName='w-15 mr-3' productId={bazaarVoiceId} ratingValue={bazaarVoiceData[bazaarVoiceId]?.overallRating||0} constant='title' /> 
                            </Button>
                            <span className='font-neutrafaceBook text-16 text-secondary leading-22 pl-7'>{bazaarVoiceData[bazaarVoiceId]?.overallRating?.toFixed(1)||0}</span>
                            <span className='font-neutrafaceBook text-16 text-secondary leading-22 pl-18'>{labels?.ratings.replace('$count',bazaarVoiceData[bazaarVoiceId]?.totalReviews||0)}</span>
                        </div>
                        <div className='block md:hidden mb-30 mdl:mb-auto'>
                            {selectedVariant?.data?.productImages && selectedVariant?.data?.productImages.length > 0 && <ProductGallery isMobile={true} productImages={selectedVariant?.data?.productImages} />}
                        </div>
                        {(hasMainVariant && productVariants.length > 1) && (<div className='w-full mb-40 flex flex-wrap justify-start items-start'>
                            <label className='font-neutrafaceBook text-16 leading-22 text-left pr-16 mt-12 text-secondary'>{labels?.flavourLabel}</label>
                            <DropDown defaultValue={productVariants[0].variantName||''} onSelect={setMainVariant} 
                                options={productVariants.map(({ variantName },index)=>({ title: variantName, value: index }))}
                                variant='borderedDropdown'
                                gaClass='event_buy_now_choose_product'
                            />
                        </div>)}
                        {((hasMainVariant && productVariants[selectedVariant.mainIndex]?.subVariants && productVariants[selectedVariant.mainIndex].subVariants.length > 1 ) || (hasSubVariant && productVariants.length > 1)) && (<div className='w-full mb-40 flex flex-wrap justify-start items-start'>
                            <label className='font-neutrafaceBook text-16 leading-22 text-left pr-16 mt-12 text-secondary'>{labels?.variantLabel}</label>
                            <DropDown defaultValue={(hasMainVariant?productVariants[selectedVariant.mainIndex].subVariants[0].variantName:productVariants[0].variantName)||''} onSelect={setSubVariant} 
                                options={(hasMainVariant?productVariants[selectedVariant.mainIndex]?.subVariants:productVariants).map(({ variantName },index)=>({ title: variantName, value: index }))}
                                variant='borderedDropdown'
                                resetValue={resetValue}
                                resetValueComplete={resetValueUpdate}
                                gaClass='event_buy_now_choose_product'
                            />
                        </div>)}
                        <div ref={buyNowRef}>
                            <BuyNowButton locale={locale} sku={ selectedVariant?.data?.buyNowId ||buyNowId} />
                        </div>
                        <Typography className='text-left text-secondary text-18 leading-24 pb-10 pt-60' content={description} />
                        <div className='w-full flex-flex-wrap flex-col mt-31' id='accordion-wrapper'>
                            <Accordion open={openAccordion === AccordionStates[0]} title={labels?.productDetailTitle} toggleOpen={()=>{ accordionClick(AccordionStates[0]) }} variant='pdpPage' >
                                <Typography className='' content={productDetails} br_allowed={false} />
                            </Accordion>
                            {(selectedVariant?.data?.smartLabelId || smartLabelId) && (<Accordion open={openAccordion === AccordionStates[1]} title={labels?.ourIngredientsTitle} toggleOpen={()=>{ accordionClick(AccordionStates[1]) }} variant='pdpPage' >
                                {(selectedVariant?.data?.smartLabelId || smartLabelId) && <SmartLabel smartLabelID={selectedVariant?.data?.smartLabelId||smartLabelId} locale={locale}/>}
                            </Accordion>)}
                            {faq && (<Accordion open={openAccordion === AccordionStates[2]} title={labels?.faqTitle} toggleOpen={()=>{ accordionClick(AccordionStates[2]) }} variant='pdpPage' >
                                <Typography className='' content={faq} />
                            </Accordion>)}
                        </div>
                    </div>
                </div>
            </div>
            <div className='flex flex-col flex-wrap justify-center items-start mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0' ref={reviewRef}  id={`product-${bazaarVoiceId}-review`}>
                <div className='w-full mdl:w-lgm mx-auto'>
                    <div className='w-full border-lightBorder border px-20 lg:px-30 pt-16 lg:py-19 pb-30 mt-60 lg:mt-20 mb-30 lg:mb-40 flex flex-wrap justify-between items-center'>
                        <div className='w-full mdl:w-1/2'>
                            <div className='font-neutrafaceBook text-50 leading-56 lg:text-80 lg:leading-84 text-primary pb-20'>{bazaarVoiceData[bazaarVoiceId]?.overallRating?.toFixed(1)||0}</div>
                            <div className='flex flex-wrap justify-start items-center mb-30 mdl:mb-21'>
                                <Rating className='flex-wrap pb-5' svgClassName='w-21 h-20 lg:w-31 lg:h-28 mr-5' productId={bazaarVoiceId} ratingValue={bazaarVoiceData[bazaarVoiceId]?.overallRating||0} constant='reviewSection' /> 
                                <span className='font-neutrafaceBook text-18 leading-24 text-secondary md:pl-20'>{labels?.ratings.replace('$count',bazaarVoiceData[bazaarVoiceId]?.totalReviews||0)}</span>
                            </div>
                        </div>
                        <Button gaClass='event_product_review' gaLabel={name} className='block w-full md:w-max font-neutrafaceDemi text-18 leading-24 text-accent text-center md:px-62 pt-15 pb-11 border border-accentBorder rounded-full btn-plain cursor-pointer' href={`${router?.asPath}/writereview`}>{labels?.writeReviewLabel}</Button>
                    </div>
                    <Review locale={locale} productId={bazaarVoiceId} />
                </div>
                <div className={`w-full fixed bottom-0 left-0 h-72 py-10 bg-white z-50 shadow-lightGrey transform ${isSticky?'translate-y-1':'translate-y-100'} transition duration-700 ease-out`} ref={stickyRef}>
                    <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 flex flex-wrap items-center justify-center mdl:justify-between'>
                        <div className='flex-wrap items-center justify-start w-full mdl:w-7/12 hidden mdl:flex'>
                            {heroImage && <Image desktopClassName='w-full' wrapperClassName='w-45 h-52 pr-10' desktopImage={heroImage} alt={heroImage?.altText} layout='intrinsic' />}
                            <div className='block'>
                                <div className='font-bold text-primary'>{name}</div>
                                <div className='text-left text-secondary'>{mainCategory}</div>
                            </div>
                        </div>
                        <BuyNowButton locale={locale} sku={buyNowId} />
                    </div>
                </div>
            </div>
            {relatedProducts && relatedProducts.length > 0 && (
                <div className='w-full bg-lightBlueBg mb-40'>
                    <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 py-60'>
                        <h2 className='w-full font-neutrafaceDemi text-24 leading-30 mdl:text-34 mdl:leading-40 text-primary text-center mb-20 mdl:mb-30'>{labels.relatedProductsTitle}</h2>
                        <Carousel variant='productCard'>
                            {relatedProducts.map((product) => (
                                <ProductCard
                                    key={product.sys}
                                    locale={locale}
                                    {...product}
                                    rating={{ value: bazaarVoiceData[product.bazaarVoiceId]?.overallRating||0, count: bazaarVoiceData[product.bazaarVoiceId]?.totalReviews||0 }}
                                    variant='pdpProductCard'
                                />
                            ))}
                        </Carousel>
                    </div>
                </div>
            )}
            {relatedArticles && relatedArticles.length > 0 && (
                <div className='mx-auto w-full bg-white'>
                    <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 py-60'>
                        <h2 className='w-full font-neutrafaceDemi text-24 leading-30 mdl:text-34 mdl:leading-40 text-primary text-center mb-20 mdl:mb-30'>{commonLabels.relatedArticles}</h2>
                        <Carousel variant='articleCard'>
                            {relatedArticles.map((article) => (
                                <ArticleCard
                                    key={article.sys}
                                    locale={locale}
                                    {...article}
                                />
                            ))}
                        </Carousel>
                        <div className='flex justify-center'>
                            <Button
                                href={relatedArticlesListing}
                                gaClass='event_button_click'
                                gaLabel={commonLabels.viewMoreArticles}
                                className='btn-plain mt-40 px-40 py-10 relative uppercase text-18 text-accent border rounded-full border-accentBorder inline-flex items-center'>
                                {commonLabels.viewMoreArticles}
                            </Button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}

ProductPage.propTypes={
    locale: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    mainCategory: PropTypes.string.isRequired,
    productVariants: PropTypes.arrayOf(PropTypes.shape({
        variantName: PropTypes.string.isRequired,
        isMainVariant: PropTypes.bool.isRequired,
        subVariants: PropTypes.arrayOf(
            PropTypes.shape({
                variantName: PropTypes.string.isRequired,
                isMainVariant: PropTypes.bool.isRequired,
                productImages: PropTypes.arrayOf(
                    PropTypes.shape({
                        sys: PropTypes.string,
                        url: PropTypes.string,
                        altText: PropTypes.string,
                        height: PropTypes.number,
                        width: PropTypes.number,
                    })).isRequired,
                smartLabelId: PropTypes.string,
            })
        ),
        productImages: PropTypes.arrayOf(
            PropTypes.shape({
                sys: PropTypes.string,
                url: PropTypes.string,
                altText: PropTypes.string,
                height: PropTypes.number,
                width: PropTypes.number,
            })),
        smartLabelId: PropTypes.string,
        buyNowId: PropTypes.string,
        
    })).isRequired,
    hasMainVariant: PropTypes.bool.isRequired, 
    hasSubVariant: PropTypes.bool.isRequired,
    productImages: PropTypes.arrayOf(
        PropTypes.shape({
            sys: PropTypes.string,
            url: PropTypes.string,
            altText: PropTypes.string,
            height: PropTypes.number,
            width: PropTypes.number,
        })),
    heroImage: PropTypes.shape({
        sys: PropTypes.string,
        url: PropTypes.string,
        altText: PropTypes.string,
        height: PropTypes.number,
        width: PropTypes.number,
    }),
    description: PropTypes.string.isRequired,
    productDetails: PropTypes.string,
    smartLabelId: PropTypes.string,
    faq: PropTypes.string,
    bazaarVoiceId: PropTypes.string.isRequired,
    buyNowId: PropTypes.string.isRequired,
    relatedProducts: PropTypes.array,
    relatedArticles: PropTypes.array,
    relatedArticlesListing: PropTypes.string,
}

export default memo(ProductPage)
