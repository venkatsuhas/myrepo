import React, { memo, useState, useEffect } from "react"
import dynamic from "next/dynamic"
import PropTypes from "prop-types"
import { labels as allLabels } from "@constants"
import { getRatings } from "@adapters/bazaarvoice"

const Button = dynamic(() => import("@components/Button"))
const Carousel = dynamic(() => import("@components/Carousel"))
const FeatureCard = dynamic(() => import("@components/Card/FeatureCard"))
const Icon = dynamic(() => import("@components/Icon"))
const Image = dynamic(() => import("@components/Image"))
const ProductCard = dynamic(() => import("@components/Card/ProductCard"))
const Rating = dynamic(() => import("@components/Rating"))
const Typography = dynamic(() => import("@components/Typography"))

const HomePage = ({
    locale,
    banner,
    featureCards,
    articleTopics,
    moreTopicsTitle,
    extraSmileCard,
    oralHygieneTips,
    productHeroSection,
    featuredProductsCarousel,
    homeCategories,
    healthySmiles,
    testimonials,
}) => {
    const labels = allLabels[locale.toLowerCase()] || {}

    const [bazaarVoiceData, setBazaarVoiceData] = useState({})

    useEffect(() => {
        getRatings({
            productIds: [
                featuredProductsCarousel[0].bazaarVoiceId,
                ...featuredProductsCarousel.map((product) => product.bazaarVoiceId).filter((id) => id),
            ],
            locale,
        })
            .then(setBazaarVoiceData)
            .catch(() => setBazaarVoiceData({}))
    }, [])

    return (
        <div className=''>
            <div className='bannerSection w-full'>
                <FeatureCard {...banner} cardStyles='Homebanner' />
            </div>
            <div className='featureCardSection flex flex-wrap w-full mb-20 mdl:mb-70'>
                {featureCards?.map((card, index) => (
                    <div key={index} className='featureCards w-full mdl:w-4/12 relative'>
                        <FeatureCard {...card} cardStyles='HomefeatureCard' />
                    </div>
                ))}
            </div>
            <div className='extrasmiecard mx-auto lg:w-lg mxl:w-mxl xl:w-xl mb-55 mdl:mb-60'>
                <FeatureCard {...extraSmileCard} cardStyles='extrasmiecard' />
            </div>
            <div className='homeCategories pb-50 mdl:pb-90 mdl:mb-70'>
                <p className='text-36 leading-40 text-primary mb-33 px-16 text-center mdl:text-42 mdl:leading-46 mdl:mb-50'>
                    <span className='font-neutrafaceDemi block mdl:inline'>{labels.smile}</span>
                    <span className='font-neutrafaceBook block mdl:inline'>{labels.categoryTitle}</span>
                </p>
                <div className='catogories wrapper px-20 mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl flex flex-wrap lg:px-0'>
                    {homeCategories[0] && (
                        <div className='colWrapper w-full mdl:w-4/12 mdl:px-7'>
                            <FeatureCard {...homeCategories[0]} cardStyles='homeCategory' iconName='ChevronArrow' />
                        </div>
                    )}
                    {homeCategories.length > 1 && (
                        <div className='colWrpper w-full mdl:w-4/12 mdl:px-7'>
                            {homeCategories?.slice(1, 3)?.map((item, index) => (
                                <FeatureCard {...item} cardStyles='homeCategory' key={index} iconName='ChevronArrow' />
                            ))}
                        </div>
                    )}
                    {homeCategories.length > 2 && (
                        <div className='colWrpper w-full mdl:w-4/12 mdl:px-7'>
                            {homeCategories?.slice(3, 5)?.map((item, index) => (
                                <FeatureCard {...item} cardStyles='homeCategory' key={index} iconName='ChevronArrow' />
                            ))}
                        </div>
                    )}
                </div>
            </div>
            <div className='oralHygieneTipsSection mx-auto lg:w-lg mxl:w-mxl xl:w-xl'>
                <FeatureCard {...oralHygieneTips} cardStyles='oralHygieneTipsCard' />
            </div>
            <div className='moretopicsSection mb-35 mx-auto lg:w-lg mxl:w-mxl xl:w-xl mdl:flex mdl:flex-nowrap mdl:items-center mdl:mb-80'>
                <Typography
                    content={moreTopicsTitle}
                    className='text-24 px-20 lg:pl-0 leading-28 font-neutrafaceBook text-primary mb-26 mdl:mb-0 mdl:text-26 mdl:leading-36 mdl:font-neutrafaceDemi mdl:flex-shrink-0 mdl:pr-30'
                />
                <div className='links'>
                    <ul className='flex flex-row flex-nowrap flex-grow justify-start items-start overflow-x-scroll pr-15 no-scrollbar'>
                        {articleTopics?.map((topic, index) => (
                            <li key={index} className='flex-shrink-0'>
                                <a
                                    href={topic.url}
                                    data-action-detail={topic.title}
                                    className='px-35 py-14 font-neutrafaceBook text-gradientDarkBlue bg-lightestBlue ml-10 rounded-full text-18 leading-22 inline-block whitespace-no-wrap mdl:py-11 event_button_click'>
                                    {topic.title}
                                </a>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
            <div className='productHeroSection'>
                <FeatureCard {...productHeroSection} cardStyles='productHeroCard' />
            </div>
            <div className='featureProducts'>
                {featuredProductsCarousel.length > 0 && (
                    <div className='w-full'>
                        <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 pb-60 pt-38 mdl:pt-85 mdl:pb-94'>
                            <h2 className='w-full font-neutrafaceBook text-36 leading-38 mdl:text-42 mdl:leading-46 text-primary text-center mb-31 mdl:mb-45'>
                                {labels.featureProducts}
                            </h2>
                            <Carousel variant='HomeProductCard'>
                                {featuredProductsCarousel.map((product, index) => (
                                    <ProductCard
                                        key={product.sys}
                                        locale={locale}
                                        {...product}
                                        rating={{
                                            value: bazaarVoiceData[product.bazaarVoiceId]?.overallRating || 0,
                                            count: bazaarVoiceData[product.bazaarVoiceId]?.totalReviews || 0,
                                        }}
                                        isPopular={index === 0}
                                        variant='homeFeatureProductCard'
                                    />
                                ))}
                            </Carousel>
                        </div>
                    </div>
                )}
            </div>
            <div className='healthySmiles mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl lg:relative lg:pb-80 lg:mb-110'>
                <div className='healthySmileImageset lg:w-10/12'>
                    <FeatureCard imageset={healthySmiles.imageset} cardStyles='helthyImgCard' />
                </div>
                <div className='healthySmilesDetails mx-20 bg-gradientlightBlue px-18 transform -translate-y-60 pb-35 lg:absolute lg:-bottom-80 lg:w-37p lg:pt-120 lg:pr-30 lg:pb-120 lg:pl-40 lg:right-0 lg:m-0 '>
                    <div className='titleSection lg:flex lg:mb-60'>
                        <div className='icon w-95 h-95 mx-auto border-4 border-white rounded-full transform -translate-y-50 -mb-30 lg:translate-y-0 lg:mb-0 lg:flex-shrink-0 lg:mx-0'>
                            <Image
                                desktopClassName={"imgContainerDt"}
                                smartphoneClassName={"imgContainerSp"}
                                wrapperClassName={"imgWrapper"}
                                desktopImage={healthySmiles.image}
                                alt={healthySmiles.altText}
                            />
                        </div>
                        <div className='smileTitle mb-18 lg:mb-0'>
                            {labels?.smilesTitle?.map((item, index) => (
                                <Typography
                                    content={item}
                                    className='smileTitleText text-30 leading-30 uppercase font-neutrafaceBold text-center lg:text-left lg:pl-20'
                                    key={index}
                                />
                            ))}
                        </div>
                    </div>
                    <FeatureCard
                        description={healthySmiles.description}
                        cardStyles='helthyDescCard'
                        linkText={healthySmiles.linkText}
                        href={healthySmiles.href}
                    />
                </div>
            </div>
            <div className='productSection mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl'>
                {testimonials.length > 0 && (
                    <div className='mb-50 px-20 lg:px-0 mdl:mb-100'>
                        <h2 className=''>
                            <Typography
                                content={labels.testimonialHeading}
                                className='text-36 leading-40 font-neutrafaceDemi text-primary mb-20 text-center mdl:text-42 mdl:leading-46 mdl:mb-16'
                            />
                            <Typography
                                content={labels.testimonialSubHeading}
                                className='prodSecDesc text-22 leading-24 font-neutrafaceBook text-center mb-20 mdl:text-26 text-secondary mdl:mb-48'
                            />
                        </h2>
                        <Carousel variant='TestimonialCarousel'>
                            {testimonials?.map((card, index) => (
                                <div
                                    className='homeFeatureProductCard w-full mdl:w-4/12 px-8 flex-grow-0 flex-shrink-0 scroll-snap-center mdl:flex mdl:flex-col'
                                    key={index}>
                                    <div className='mdl:mb-31'>
                                        <Image desktopClassName='' smartphoneClassName='' desktopImage={card.image} alt={card.image.altText} />
                                    </div>
                                    <div className='testimonialDetails bg-darkBlue bg-opacity-10 pt-17 pl-26 pr-20 pb-24 mdl:pl-20 mdl:pb-20 min-h-360 mdl:min-h-450 lg:min-h-380 mxl:min-h-340 relative'>
                                        <Rating className='mb-32' svgClassName='ratingIcon w-14 h-14 mr-6' ratingValue={5} />
                                        {card.title && (
                                            <Typography
                                                content={card.title}
                                                className='text-22 leading-24 font-neutrafaceDemi text-primary mb-13 mdl:text-26 mdl:mb-23'
                                            />
                                        )}
                                        {card.description && (
                                            <Typography
                                                content={card.description}
                                                className='testimonialDesc text-18 leading-22 font-neutrafaceBook text-primary mdl:text-20 mdl:leading-26'
                                            />
                                        )}
                                        {card.linkText && card.href && (
                                            <Button
                                                href={card.href}
                                                gaClass='event_button_click'
                                                gaLabel={card.linkText}
                                                className='absolute left-26 bottom-24 text-18 leading-26 pr-10 mxl:pr-0 underline font-neutrafaceDemi text-gradientDarkBlue mt-74 mdl:mt-60 mdl:text-22 mdl:leading-28'>
                                                <span className=''>{card.linkText} </span>
                                                <span className='inline-block w-17 ml-5 transform -rotate-90'>
                                                    <Icon className='w-full fill-none stroke-current stroke-2 ' name='ChevronArrow' />
                                                </span>
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </Carousel>
                    </div>
                )}
            </div>
        </div>
    )
}

HomePage.propTypes = {
    locale: PropTypes.string.isRequired,
    moreTopicsTitle: PropTypes.string.isRequired,
    banner: PropTypes.object,
    featureCards: PropTypes.array,
    articleTopics: PropTypes.array,
    productHeroSection: PropTypes.object,
    homeCategories: PropTypes.array,
    testimonials: PropTypes.array,
    featuredProductsCarousel: PropTypes.array,
    extraSmileCard: PropTypes.object,
    oralHygieneTips: PropTypes.object,
    healthySmiles: PropTypes.object,
}

export default memo(HomePage)
