import React, { useRef, useEffect, useState, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import { labels as allLabels } from "@constants"
import { generateId } from "@helpers/generateId.helper"

const Button = dynamic(() => import("@components/Button"))
const FeatureCard = dynamic(() => import("@components/Card/FeatureCard"))
const Typography = dynamic(() => import("@components/Typography"))

const SustainabilityPage = ({
    locale,
    pageTitle,
    ourVisionSection,
    videoCardUrl,
    description,
    healthCrisis,
    guidelineSection,
    featuresSection,
    accessCard,
    oralCareEducation,
    sustainability,
}) => {
    const accessRef = useRef(null)
    const oralCareEducationRef = useRef(null)
    const sustainabilityRef = useRef(null)
    const sectionRef = useRef(null)
    const [isScrollUp, setScrollUp] = useState(false)

    const sectionRefs = [
        { section: accessCard.name, ref: accessRef, id: generateId(accessCard.name) },
        { section: oralCareEducation.name, ref: oralCareEducationRef, id: generateId(oralCareEducation.name) },
        { section: sustainability[0].name, ref: sustainabilityRef, id: generateId(sustainability[0].name) },
    ]

    const router = useRouter()
    const labels = allLabels[locale.toLowerCase()] || {}
    const [visibleSection, setVisibleSection] = useState(sectionRefs[0].section)

    const handleScroll = useCallback(() => {
        const selected = sectionRefs.find(({ ref }) => {
            const element = ref.current
            const section = sectionRef.current
            if (element && section) {
                const { bottom: elementBottom } = element.getBoundingClientRect()
                const { bottom: sectionBottom } = section.getBoundingClientRect()
                return isScrollUp ? elementBottom > sectionBottom : elementBottom - 20 > sectionBottom
            } else {
                return false
            }
        })

        if (selected) {
            setVisibleSection(selected.section)
        }

        if (document.getElementById("navBar") && document.getElementById("navBar").className) {
            const headerClassName = document.getElementById("navBar").className.split(" ")
            const isHeaderSticky = headerClassName[headerClassName.length - 1] === "header-sticky" ? true : false
            setScrollUp(isHeaderSticky)
        }
    }, [isScrollUp])

    useEffect(() => {
        window.addEventListener("scroll", handleScroll)
        return () => {
            window.removeEventListener("scroll", handleScroll)
        }
    }, [])

    useEffect(() => {
        if (router.asPath.match(/#(.*)/)) {
            const componentId = router.asPath.match(/#(.*)/)[0]
            const selected = sectionRefs.find(({ id }) => componentId === `#${id}`)
            if (selected) {
                setVisibleSection(selected.section)
                selected.ref.current.scrollIntoView({ behaviour: "smooth" })
            }
        }
    }, [router.asPath])

    return (
        <div className='mt-40 mdl:mt-50 sustainabilityContainer'>
            <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0'>
                <div className='mx-auto w-full mdl:w-8/12'>
                    <h1
                      
                        className='mx-auto text-left mdl:text-center text-28 mdl:text-34 leading-34 mdl:leading-40 font-neutrafaceDemi text-primary w-full mb-30'
                    >{pageTitle} </h1>
                    <div className='ourVisionSection'>
                        {ourVisionSection && <FeatureCard {...ourVisionSection} cardStyles='sustainabilityOurVisionSection' />}
                    </div>
                </div>
            </div>

            <div className='videoSection mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl text-center'>
                <div className='mx-auto w-full mdl:w-8/12'>
                    {videoCardUrl && (
                        <iframe
                            width='100%'
                            height='180'
                            src={videoCardUrl}
                            title='YouTube video player'
                            frameBorder='0'
                            allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture'
                            allowFullScreen
                            className=' w-full h-210 mdl:w-full lg:w-720 mdl:px-20 lg:px-0 md:h-405 mx-auto'
                        />
                    )}
                    <div className='videoDescription mt-40 mb-60 mdl:mb-100 w-full text-left mdl:text-center text-20 leading-26 font-neutrafaceBook text-secondary px-20 lg:px-0'>
                        <Typography content={description} className='' />
                    </div>
                </div>
            </div>

            <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 healthCrisisSection-wrapper'>
                <div className='mx-auto w-full mdl:w-8/12'>
                    <div className='healthCrisisSection mb-25 mdl:mb-40'>
                        <Typography
                            content={labels.healthCrisisTitle}
                            className='text-left text-24 mdl:text-30 leading-30 mdl:leading-36 font-neutrafaceDemi text-primary w-full mb-30 mdl:mb-55'
                        />
                        <div className='w-full mdl:flex flex-wrap'>
                            {healthCrisis.length > 0 &&
                                healthCrisis?.map((item) => <FeatureCard key={item.sys} {...item} cardStyles='sustainabilityhealthCrisisSection' />)}
                        </div>
                    </div>
                    <div>
                        <Typography
                            content={featuresSection?.title}
                            className='text-left text-24 mdl:text-30 leading-30 mdl:leading-36 font-neutrafaceDemi text-primary w-full mb-20 mdl:mb-25'
                        />
                        <p className='text-20 leading-26 font-neutrafaceBook text-left w-full text-secondary mb-60'>{featuresSection?.description}</p>
                    </div>
                    <div>
                        <div
                            className={`featuresSection flex mdl:block overflow-auto mdl:overflow-visible -mx-20 mdl:mx-0 text-center sticky top-20 z-10 ${isScrollUp ? "scrollUp" : "scrollDown"
                                }`} ref={sectionRef}>
                            <div className='buttonsSection text-center'>
                                <Button
                                    href={`#${sectionRefs[0].id}`}
                                    className={`header_link ${visibleSection === sectionRefs[0].section ? "selected" : ""}`}
                                    anchor>
                                    {accessCard.name}
                                </Button>
                                <Button
                                    href={`#${sectionRefs[1].id}`}
                                    className={`header_link ${visibleSection === sectionRefs[1].section ? "selected" : ""}`}
                                    anchor>
                                    {oralCareEducation.name}
                                </Button>
                                <Button
                                    href={`#${sectionRefs[2].id}`}
                                    className={`header_link ${visibleSection === sectionRefs[2].section ? "selected" : ""}`}
                                    anchor>
                                    {sustainability[0].name}
                                </Button>
                            </div>
                        </div>
                        {accessCard && (
                            <div className='mb-30 mdl:mb-60 mt-45 mdl:mt-100 accessSection' id={generateId(accessCard.name)} ref={accessRef}>
                                <FeatureCard {...accessCard} cardStyles='sustainabilityAccessSection' />
                            </div>
                        )}
                        {oralCareEducation && (
                            <div className='mb-30 mdl:mb-60 oralCareSection' id={generateId(oralCareEducation.name)} ref={oralCareEducationRef}>
                                <FeatureCard {...oralCareEducation} cardStyles='sustainabilityOralCareSection' />
                            </div>
                        )}
                        {sustainability?.length > 0 && (
                            <div className='sustainabilityWrapper' id={generateId(sustainability[0].name)} ref={sustainabilityRef}>
                                {sustainability.map((card) => (
                                    <FeatureCard key={card.sys} {...card} cardStyles={card.styles} />
                                ))}
                            </div>
                        )}
                    </div>
                    <div className='guidelineSection'>
                        <Typography
                            content={guidelineSection}
                            className='text-20 leading-26 font-neutrafaceBook text-left mdl:text-center w-full text-secondary mdl:w-11/12 mx-auto mb-80 mdl:mb-100 '
                        />
                    </div>
                </div>
            </div>
        </div>
    )
}

SustainabilityPage.propTypes = {
    locale: PropTypes.string.isRequired,
    pageTitle: PropTypes.string,
    videoCardUrl: PropTypes.string,
    featuresSection: PropTypes.object,
    ourVisionSection: PropTypes.object,
    accessCard: PropTypes.object,
    oralCareEducation: PropTypes.object,
    healthCrisis: PropTypes.array,
    sustainability: PropTypes.array,
    description: PropTypes.string,
    guidelineSection: PropTypes.string,
}

export default memo(SustainabilityPage)
