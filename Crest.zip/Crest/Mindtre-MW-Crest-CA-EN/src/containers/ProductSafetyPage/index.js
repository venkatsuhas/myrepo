import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { labels as allLabels } from "@constants"

const Button = dynamic(() => import("@components/Button"))
const FeatureCard = dynamic(() => import("@components/Card/FeatureCard"))
const Typography = dynamic(() => import("@components/Typography"))

const ProductSafetyPage = ({ locale, bannerCard, linksCollection, fourStepsCard, highestStandard, stepsSection, videoCard, crestCards }) => {
    const labels = allLabels[locale.toLowerCase()].productSafetyPage || {}
    return (
        <div className='pageWrapper mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl'>
            <div className='max-w-824 mx-auto'>
                <div className='bannersection'>
                    <Typography
                        content={bannerCard.title}
                        className='bannerTitle text-28 leading-34 mdl:text-34 mdl:leading-40 text-left mdl:text-center font-bold p-20 mdl:px-0 mdl:pb-40'
                    />
                    <FeatureCard {...bannerCard} cardStyles={bannerCard.styles} />
                </div>
                <div className='px-20 mdl:px-0'>
                    <div className='linksSection flex flex-col pt-40 mdl:py-40'>
                        {linksCollection?.map((item, index) => (
                            <li key={index} className='list-disc text-20 leading-28 text-accentDark py-10'>
                                <Button href={item?.url} className='underline'>
                                    {item?.title}
                                </Button>
                            </li>
                        ))}
                    </div>
                    <div className='highestStandardSection' id='sect1'>
                        <FeatureCard {...highestStandard} cardStyles={highestStandard.styles} />
                    </div>
                    <div className='fourStepsCardSection' id='sect2'>
                        <FeatureCard {...fourStepsCard} cardStyles={fourStepsCard.styles} />
                    </div>
                    <div className='stepsSection'>
                        {stepsSection?.map((item) => (
                            <FeatureCard {...item} cardStyles={item.styles} key={item.sys} />
                        ))}
                    </div>
                    {videoCard && (
                        <div className='psvideo max-w-720 mx-auto pt-20 mdl:pt-40' id='sect3'>
                            <p className='videoCardTitle font-neutrafaceDemi text-primary text-24 leading-24 lg:text-34 lg:leading-40 text-left mdl:text-center mb-10 lg:mb-15 mdl:px-30'>
                                {videoCard?.title}
                            </p>
                            <iframe
                                width='100%'
                                height='406px'
                                src={videoCard?.url}
                                title={videoCard?.title}
                                frameBorder='0'
                                allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture'
                                allowFullScreen
                                className='test'
                            />
                        </div>
                    )}
                </div>
            </div>

            <div className='crestCardsSection py-60 mdl:py-80 px-20 mdl:px-0'>
                <p className='font-neutrafaceDemi text-primary text-24 leading-34 lg:text-34 lg:leading-40 text-left mb-10 lg:mb-20 mdl:px-20'>
                    {labels.whyCrest}
                </p>
                <div className='flex flex-col mdl:flex-row'>
                    {crestCards?.map((item) => (
                        <FeatureCard key={item.sys} {...item} cardStyles={item?.styles} />
                    ))}
                </div>
            </div>
        </div>
    )
}

ProductSafetyPage.propTypes = {
    locale: PropTypes.string.isRequired,
    videoCard: PropTypes.object,
    bannerCard: PropTypes.object,
    fourStepsCard: PropTypes.object,
    accessCard: PropTypes.object,
    highestStandard: PropTypes.object,
    linksCollection: PropTypes.array,
    stepsSection: PropTypes.array,
    crestCards: PropTypes.array,
}

export default memo(ProductSafetyPage)
