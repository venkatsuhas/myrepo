import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"

const Typography = dynamic(() => import("@components/Typography"))

const ReviewGuidelinesPage = ({ cardData }) => {
    return (
        <div className='adp mx-auto px-20 mdl:px-0 w-full lg:w-lg mxl:w-mxl xl:w-xl mb-90 '>
            <div className='w-full'>
                {cardData.title && (
                    <h1 className='text-16 leading-40 uppercase font-neutrafaceBook text-accent mt-30'>
                        {cardData.title}
                    </h1>
                )}
            </div>
            <div className='w-full'>
                {cardData.subTitle && (
                    <h2 className='text-28 leading-34 font-neutrafaceDemi text-primary mb-20 mdl:text-34 mdl:leading-40'>
                        {cardData.subTitle}
                    </h2>
                )}
            </div>
            <div className='cardDesc mb-20 text-20 leading-26 font-neutrafaceBook text-secondary'>
                {cardData.description && <Typography content={cardData.description}  />}
            </div>
        </div>
    )
}

ReviewGuidelinesPage.propTypes = {
    cardData: PropTypes.object,
}

export default memo(ReviewGuidelinesPage)
