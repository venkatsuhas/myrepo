import React, { useState, useEffect, useRef, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { labels as allLabels } from "@constants"
import { generateId } from "@helpers/generateId.helper"

const ArticleCard = dynamic(() => import("@components/Card/ArticleCard"))
const Button = dynamic(() => import("@components/Button"))
const Carousel = dynamic(() => import("@components/Carousel"))
const Image = dynamic(() => import("@components/Image"))
const ProductCard = dynamic(() => import("@components/Card/ProductCard"))
const IconButton = dynamic(() => import("@components/IconButton"))
const Typography = dynamic(() => import("@components/Typography"))

const ArticlePage = ({
    locale,
    category,
    name,
    bannerImage,
    descriptionCard,
    cardsCollection,
    indentedCard,
    recommendedProducts,
    discoverMoreCard,
    videoCard,
    relatedArticles,
    listingPageURL,
    articleURL,
}) => {
    const [isSticky, setSticky] = useState(false)
    const [copiedToClipboard, setCopiedToClipboard] = useState(false)
    const labels = allLabels[locale.toLowerCase()]

    const contentRef = useRef(null)
    const stickyRef = useRef(null)

    const handleScroll = useCallback(() => {
        if (contentRef.current && stickyRef.current) {
            const contentElement = contentRef.current,
                stickyElement = stickyRef.current
            if (
                contentElement.getBoundingClientRect().top <= stickyElement.getBoundingClientRect().top &&
                contentElement.getBoundingClientRect().bottom >= stickyElement.getBoundingClientRect().bottom
            ) {
                setSticky(true)
            } else {
                setSticky(false)
            }
        }
    }, [])

    const copyToClipboard = useCallback(() => {
        setCopiedToClipboard(true)
        setTimeout(setCopiedToClipboard, 2000, false)
    }, [])

    useEffect(() => {

        window?.dataLayer?.push({
            event: "customEvent",
            GAeventCategory: "event_informational_action",
            GAeventAction: "event_view_article_page",
            GAeventLabel: name,
            GAeventValue: name,
            GAeventNonInteraction: false
        })

        document.addEventListener("scroll", handleScroll, false)
        return () => {
            document.removeEventListener("scroll", handleScroll, false)
        }
    }, [])

    return (
        <div className='adp'>
            <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl'>
                <div className='lg:w-10/12 lg:mx-auto'>
                    <Button href={listingPageURL}>
                        <p className='text-16 leading-40 uppercase font-neutrafaceBook text-accent px-20 mt-30 lg:px-0'>{category}</p>
                    </Button>
                    <h1 className='text-28 leading-34 font-neutrafaceDemi text-primary px-20 mb-20 lg:px-0 mdl:text-34 mdl:leading-40'>{name}</h1>
                    {bannerImage && bannerImage.desktopImage && (
                        <div className=''>
                            <Image
                                key={bannerImage.desktopImage.sys}
                                desktopClassName='hidden mdl:block'
                                smartphoneClassName='block mdl:hidden'
                                wrapperClassName='w-full'
                                desktopImage={bannerImage.desktopImage}
                                smartphoneImage={bannerImage.smartphoneImage}
                                alt={bannerImage.desktopImage?.altText}
                            />
                        </div>
                    )}
                </div>
                <div className='sideBarSec mdl:mx-auto lg:ml-auto mdl:w-full lg:w-11/12 px-20 pt-30 mdl:pt-40 mdl:px-0 mdl:flex mdl:flex-wrap lg:mr-0 lg:px-0'>
                    <IconButton
                        variant='adpSocial'
                        articleName={name}
                        articleURL={articleURL}
                        copyToClipboard={copyToClipboard}
                        copiedToClipboard={copiedToClipboard}
                        locale={locale}
                        gaClass='event_share'
                    />
                    <div className='mdl:w-8/12 lg:w-9/12' ref={contentRef}>
                        <div className='mdl:w-9/12'>
                            {descriptionCard && (
                                <div>
                                    {descriptionCard.title && <h2>{descriptionCard.title}</h2>}
                                    {descriptionCard.description && (
                                        <Typography
                                            content={descriptionCard.description}
                                            className='cardDesc mb-20 text-20 leading-26 font-neutrafaceBook text-secondary'
                                        />
                                    )}
                                    {descriptionCard.image && (
                                        <Image
                                            key={descriptionCard.image.sys}
                                            desktopClassName=''
                                            smartphoneClassName=''
                                            wrapperClassName='w-full '
                                            desktopImage={bannerImage.desktopImage}
                                            smartphoneImage={bannerImage.smartphoneImage}
                                            alt={bannerImage.desktopImage?.altText}
                                        />
                                    )}
                                </div>
                            )}
                            {recommendedProducts.length > 0 && (
                                <div className='recomendedWrap flex flex-wrap px-20 pt-20 pb-25 lg:pb-15 border border-borderColor mb-40 lg:mb-57 lg:mt-20'>
                                    <h4 className='text-24 leading-30 font-neutrafaceDemi text-primary mb-20 text-left w-full lg:text-28 lg:leading-36'>
                                        {labels.weRecommend}
                                    </h4>
                                    {recommendedProducts.map((product) => (
                                        <ProductCard key={product.sys} locale={locale} {...product} variant='adpWeRecommend' />
                                    ))}
                                </div>
                            )}

                            {cardsCollection.length > 0 &&
                                cardsCollection.map((card) => (
                                    <div key={card.sys} className=''>
                                        {card.type === "videoCard" ? (
                                            <div className='videoWrap mb-100'>
                                                <h2
                                                    className='text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36'
                                                    id={generateId(card?.title)}>
                                                    {card?.title}
                                                </h2>
                                                <iframe
                                                    width='100%'
                                                    height='180'
                                                    src={card?.url}
                                                    title='YouTube video player'
                                                    frameBorder='0'
                                                    allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture'
                                                    allowFullScreen
                                                    className='test'
                                                />
                                            </div>
                                        ) : (
                                            <div>
                                                {card.title && (
                                                    <h2
                                                        className='text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36'
                                                        id={generateId(card?.title)}>
                                                        {card.title}
                                                    </h2>
                                                )}
                                                {card.description && (
                                                    <Typography
                                                        content={card.description}
                                                        className='cardDesc mb-20 text-20 leading-26 font-neutrafaceBook text-secondary'
                                                    />
                                                )}
                                                {card.image && (
                                                    <div className='mb-40'>
                                                        <Image
                                                            key={card.image.sys}
                                                            desktopClassName=''
                                                            wrapperClassName='w-full'
                                                            desktopImage={card.image}
                                                            alt={card.image?.altText}
                                                        />
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            {indentedCard && indentedCard.description && (
                                <Typography
                                    content={indentedCard.description}
                                    className='pl-24 border-l-4 border-lightGreyBlue mb-40 lg:mb-60 mt-40 text-20 leading-26 font-neutrafaceBook text-secondary'
                                />
                            )}
                            {videoCard && (
                                <div className='videoWrap mb-100'>
                                    <h2
                                        className='text-24 leading-30 font-neutrafaceDemi text-primary mb-20 lg:text-30 lg:leading-36'
                                        id={generateId(videoCard?.title)}>
                                        {videoCard?.title}
                                    </h2>
                                    <iframe
                                        width='100%'
                                        height='180'
                                        src={videoCard?.url}
                                        title='YouTube video player'
                                        frameBorder='0'
                                        allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture'
                                        allowFullScreen
                                        className='test'
                                    />
                                </div>
                            )}
                        </div>
                    </div>
                    <div
                        className={`hidden fixed bottom-10 right-30 mdl:w-3/12 lg:w-2/12 mdl:block transform transition duration-500 ease-out ${
                            isSticky ? "visible" : "invisible"
                        }`}
                        ref={stickyRef}>
                        {discoverMoreCard && (
                            <div className='w-200 mxl:w-250'>
                                <h4 className='text-24 leading-30 font-neutrafaceDemi mb-20 text-accentDark'>{labels.discoverMore}</h4>
                                <Button href={discoverMoreCard.href}>
                                    {discoverMoreCard.image && (
                                        <div className='mb-15'>
                                            <Image
                                                desktopClassName=''
                                                smartphoneClassName=''
                                                wrapperClassName='w-full'
                                                desktopImage={discoverMoreCard.image}
                                                alt={discoverMoreCard.image?.altText}
                                            />
                                        </div>
                                    )}
                                    {discoverMoreCard.description && (
                                        <Typography
                                            content={discoverMoreCard.description}
                                            className='text-18 leading-24 font-neutrafaceBook text-secondary'
                                        />
                                    )}
                                </Button>
                            </div>
                        )}
                    </div>
                </div>
                {relatedArticles.length > 0 && (
                    <div className='mb-90 px-20 lg:px-0'>
                        <h2 className='text-24 leading-30 font-neutrafaceDemi mb-20 text-center lg:text-34 lg:leading-40'>
                            {labels.relatedArticles}
                        </h2>
                        <Carousel variant='articleCard'>
                            {relatedArticles.map((article) => (
                                <ArticleCard key={article.sys} locale={locale} {...article} />
                            ))}
                        </Carousel>
                        <div className='flex justify-center'>
                            <Button
                                href={listingPageURL}
                                gaClass='event_button_click'
                                gaLabel={labels.viewMoreArticles}
                                className='btn-plain mt-40 px-40 py-10 relative font-neutrafaceDemi uppercase text-18 text-accent border rounded-full border-accentBorder inline-flex items-center'>
                                {labels.viewMoreArticles}
                            </Button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}

ArticlePage.propTypes = {
    locale: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    category: PropTypes.string.isRequired,
    bannerImage: PropTypes.object,
    descriptionCard: PropTypes.object,
    cardsCollection: PropTypes.array,
    recommendedProducts: PropTypes.array,
    discoverMoreCard: PropTypes.object,
    relatedArticles: PropTypes.array,
    videoCard: PropTypes.object,
    indentedCard: PropTypes.object,
    listingPageURL: PropTypes.string,
    articleURL: PropTypes.string,
}

export default memo(ArticlePage)
