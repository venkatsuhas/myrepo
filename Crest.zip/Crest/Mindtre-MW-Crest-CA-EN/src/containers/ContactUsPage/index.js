import React, { memo } from "react"
import PropTypes from "prop-types"
const ContactUsPage = ({ gcr }) => {
    return(
        <div className='pageWrapper'>
            <div>
                <iframe className='contactus mx-auto mt-50 mb-100' title='Contact us' src={gcr} />
            </div>
        </div>
    )
}

ContactUsPage.propTypes ={    
    gcr: PropTypes.string, 
}

export default memo(ContactUsPage)
