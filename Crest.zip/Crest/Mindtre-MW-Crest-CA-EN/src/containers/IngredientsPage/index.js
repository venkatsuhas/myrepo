import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { labels as allLabels } from "@constants"
import { generateId } from "@helpers/generateId.helper"

const Button = dynamic(() => import("@components/Button"))
const Image = dynamic(() => import("@components/Image"))
const Typography = dynamic(() => import("@components/Typography"))

const IngredientsPage = ({ locale, bannerCard, bottomCards, firstTitle, secondTitle, firstCards, secondCards }) => {
    const labels = allLabels[locale.toLowerCase()]?.ingredientsPage || {}
    return (
        <div className='pageWrapper mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl'>
            <div className='max-w-824 mx-auto'>
                <div>
                    {bannerCard && (
                        <div>
                            <div className='bannerTitle font-neutrafaceDemi text-28 leading-34 mdl:text-34 mdl:leading-40 text-left mdl:text-center font-normal p-20 pr-0 mdl:px-0 mdl:pb-40 max-w-250 mdl:max-w-full'>
                                {bannerCard.title && <h1>{bannerCard.title}</h1>}
                            </div>
                            {bannerCard.imageSet && (
                                <Image
                                    desktopClassName='hidden mdl:block'
                                    smartphoneClassName='block mdl:hidden'
                                    wrapperClassName='w-full '
                                    desktopImage={bannerCard.imageSet.desktopImage}
                                    alt={bannerCard?.imageSet?.desktopImage?.altText}
                                    smartphoneImage={bannerCard.imageSet.smartphoneImage}
                                />
                            )}
                            <div className='px-20 mdl:px-0'>
                                {bannerCard.description && (
                                    <Typography content={bannerCard.description} className='linksSection flex flex-col pt-40 mdl:py-40' />
                                )}
                            </div>
                        </div>
                    )}
                </div>
                <div className='px-20 mdl:px-0 py-20 mt-45 mdl:mt-0'>
                    {firstCards && firstCards.length > 0 && (
                        <div className='tpIngredients aLink'>
                            <div className='font-neutrafaceDemi text-primary text-32 leading-40 lg:text-40 lg:leading-36 text-left mb-10 lg:mb-15'>
                                <h2
                                    id={generateId(firstTitle)}>
                                    {firstTitle}
                                </h2>
                            </div>
                            {firstCards.map((card) => {
                                return (
                                    <ul key={card.sys}>
                                        <li>
                                            <div className='flex flex-row items-start borderBottomset'>
                                                <div className='w-3/12 mdl:w-50p flex flex-col mdl:flex-row items-center pt-40 pb-50 text-center mdl:text-left'>
                                                    {card.image && (
                                                        <div className='w-75 mdl:w-105'>
                                                            <Image
                                                                desktopClassName=''
                                                                wrapperClassName='w-full'
                                                                desktopImage={card.image}
                                                                alt={card.image?.altText}
                                                            />
                                                        </div>
                                                    )}
                                                    <div className='font-neutrafaceBook mdl:ml-36 text-16 leading-26 mdl:text-20 mdl:leading-26 pt-8 mdl:pt-0'>
                                                        {card.title && <Typography content={card.title} br_allowed={false} />}
                                                    </div>
                                                </div>
                                                <div className='ml-20 mdl:ml-0 w-9/12 mdl:w-50p text-20 leading-26 font-neutrafaceBook text-left pt-40 pb-50'>
                                                    {card.description && <Typography content={card.description} />}
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                )
                            })}
                        </div>
                    )}
                </div>
                <div>
                    {secondCards && secondCards.length > 0 && (
                        <div className='aLink pt-30 pb-50 px-20 mdl:px-0'>
                            <div className='font-neutrafaceDemi text-primary text-32 leading-40 mdl:mb-37 mdl:text-40 lg:leading-36 text-left mb-0 lg:mb-30'>
                                <h2
                                    id={generateId(secondTitle)}>
                                    {secondTitle}
                                </h2>
                            </div>
                            {secondCards.map((card) => {
                                return (
                                    <div key={card.sys} className='text-20 leading-26 font-neutrafaceBook text-left w-full'>
                                        {card.description && <Typography content={card.description} />}
                                    </div>
                                )
                            })}
                        </div>
                    )}
                </div>
            </div>
            <div>
                {bottomCards && bottomCards.length > 0 && (
                    <div className='crestCardsSection pb-25 pt-50 mdl:py-80 px-20 mdl:px-45'>
                        <Typography
                            content={labels.whyCrest}
                            className='font-neutrafaceDemi text-primary text-24 leading-34 lg:text-34 lg:leading-40 text-left mb-10 lg:mb-20 mdl:px-20'
                        />
                        <div className='flex flex-col mdl:flex-row'>
                            {bottomCards.map((card) => {
                                return (
                                    <div
                                        key={card.sys}
                                        className='whyCrestCard flex flex-col items-center w-full mx-0 mdl:w-50p mdl:mx-15 pb-40 mdl:pb-0 mdl:overflow-hidden'>
                                        <div className='imgWrapper w-full'>
                                            <Image
                                                desktopClassName=''
                                                wrapperClassName='w-full'
                                                desktopImage={card.image}
                                                alt={card.image?.altText}
                                            />
                                        </div>
                                        <div className='contentWrapper w-full'>
                                            <div className='contentContainer whyCrestContent'>
                                                {card.title && (
                                                    <h3 className='font-neutrafaceDemi text-primary mdl:text-white text-28 leading-34 lg:text-30 lg:leading-36 text-left pt-20 pb-15 mdl:pt-30 mdl:pb-35 m-0'>
                                                        {card.title}
                                                    </h3>
                                                )}
                                                {card.description && (
                                                    <Typography
                                                        content={card.description}
                                                        className='text-18 leading-24 font-neutrafaceBook text-left w-full description'
                                                    />
                                                )}
                                                {card.url && (
                                                    <Button
                                                        href={card.url}
                                                        gaClass='event_button_click'
                                                        gaLabel={labels.learnMore}
                                                        className='articleLink bg-accent py-12 px-30 uppercase mt-40 text-white text-18 min-w-172 h-46 rounded-26 inline-block'>
                                                        {labels.learnMore}
                                                    </Button>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}

IngredientsPage.propTypes = {
    locale: PropTypes.string,
    bannerCard: PropTypes.object,
    firstCards: PropTypes.array,
    bottomCards: PropTypes.array,
    secondCards: PropTypes.array,
    firstTitle: PropTypes.string,
    secondTitle: PropTypes.string,
}

export default memo(IngredientsPage)
