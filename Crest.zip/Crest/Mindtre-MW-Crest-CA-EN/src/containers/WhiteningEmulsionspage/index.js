import React, { memo } from "react"
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import Emailsign from "@components/Emailsign"

const ProductCard = dynamic(() => import('@components/Card/ProductCard'))
const FeatureCard = dynamic(() => import("@components/Card/FeatureCard"))
const Typography = dynamic(() => import("@components/Typography"))


 const whiteningEmulsionspage = ({heroImageBlock,contentBlocks,productsCard,locale,reviewCardTitle,ReviewCards,emailSignup}) => {
    return (
        <div>
           <div className='bannerSection w-full'>
                <FeatureCard {...heroImageBlock} cardStyles='whiteningEmulsionsbanner' />
            </div>
            <div className={contentBlocks?.styles}>
                {contentBlocks?.map((card, index) =>
                    <FeatureCard {...card} cardStyles={card.styles} key={index} />        
                )}
            </div>
            <div id="productsection" className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mdl:mb-60 sm:mt-60 mdl:mt-60 stannous-productsCard'>
                <div className='w-full mdl:w-full mx-auto mdl:flex justify-center'>
                    {productsCard?.map((card, index) => (
                        <div key={index} className='productWrapper w-full mdl:w-50p mb-70 mdl:mb-0  lg:mr-0'>
                            <ProductCard
                                key={card?.product.sys}
                                locale={locale}
                                {...card.product}
                                variant='emulsionsProductCard'
                            />
                            <div className='productDetails lg:pr-80'>
                                <Typography content={card?.title} className='w-full text-left text-primary text-28 mdl:text-34 leading-34 mdl:leading-40 font-neutrafaceDemi mb-15 mdl:mb-25' />
                                <Typography content={card?.description} className='text-20 leading-26 font-neutrafaceBook text-center w-full text-secondary  description' />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            <div className='mdl:h-40 sm:h-100 bg-aquaMarinebg' >
                <Typography content={reviewCardTitle} className='mx-auto text-cyanBlue text-left mdl:w-450 sm:text-center mdl:text-center text-28 mdl:text-34 mdl:leading-50 font-neutrafaceBold sm:text-36 text-primary w-full mb-40 pt-40 mdl:mb-45' />
                <div className='mx-auto w-full mdl:flex'>
                    {
                        ReviewCards?.map((card, index) => (
                            <div key={index} className='featureCards w-full mdl:w-1/3 mdl:mx-15 mb-40 mdl:mb-0'>
                                    <FeatureCard {...card} cardStyles='reviewCard' />
                            </div>
                        ))
                    }
                </div>
            </div>
            <div>
                <Emailsign {...emailSignup} locale={locale} />
            </div>
        </div>
    )
}

whiteningEmulsionspage.propTypes = {
    locale: PropTypes.string.isRequired,
    heroImageBlock: PropTypes.object,
    contentBlocks: PropTypes.array,
    reviewCardTitle: PropTypes.string,
    productsCard: PropTypes.array,
    ReviewCards:PropTypes.array
}

export default memo(whiteningEmulsionspage)
