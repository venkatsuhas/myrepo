import React, { useState, useEffect, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import { labels as allLabels } from "@constants"

const Accordion = dynamic(() => import("@components/Accordion"))
const ArticleCard = dynamic(() => import("@components/Card/ArticleCard"))
const Button = dynamic(() => import("@components/Button"))
const FeatureCard = dynamic(() => import("@components/Card/FeatureCard"))
const Typography = dynamic(() => import("@components/Typography"))

const FAQPage = (props) => {
    const { locale, bannerCard, accordionCollection, relatedArticles, faqCategoryCollection } = props
    const commonLabels = allLabels[locale.toLowerCase()] || {}
    const [openAccordion, setOpenAccordion] = useState(null)
    const router = useRouter()

    const toggleAccordion = useCallback((index) => {
        setOpenAccordion((prevState)=>prevState === index ? null : index)
    },[])
    
    useEffect(() => {
        setOpenAccordion(null)
    }, [router.asPath])
    
    return (
        <div className='faqPageWrapper w-full mdl:relative mdl:-top-55'>
            <FeatureCard {...bannerCard} cardStyles='faqHomebanner' />
            <div className='faqAccordianWrapper mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mdl:flex mb-90 mdl:mb-100'>
                <div className='faqCategorySection w-full mdl:w-3/12'>
                    <h3 className='hidden mdl:block text-18 leading 26 text-accentDark font-neutrafaceBold uppercase mb-30 '>
                        {commonLabels.faqCategory}
                    </h3>
                    <div className='flex mdl:grid -mx-20 mdl:mx-0 whitespace-nowrap overflow-auto mdl:overflow-visible text-17 leading-17 mdl:text-20 mdl:leading-24 text-secondary font-neutrafaceBook mb-30 mdl:mb-0 faqCategorySection-item no-scrollbar'>
                        {faqCategoryCollection?.map((item, index) => (
                            <Button key={index} href={item?.url} className={router.asPath === item?.url ? "buttonActive" : null}>
                                {item?.title}
                            </Button>
                        ))}
                    </div>
                </div>
                <div className='faqAccordianSection w-full mdl:w-9/12 mdl:ml-4p'>
                    {accordionCollection?.map((accordion, index) => (
                        <Accordion
                            key={index}
                            open={openAccordion === index}
                            title={accordion.title}
                            toggleOpen={() => toggleAccordion(index)}
                            variant='faqAccord'>
                            <Typography content={accordion.description} />
                        </Accordion>
                    ))}
                    {relatedArticles && relatedArticles.length > 0 && (
                        <div className='faqRelatedArticle mdl:ml-30 mt-50 mdl:mt-30'>
                            <h2 className='hidden mdl:block text-24 leading-32 text-secondary font-neutrafaceDemi mb-15'>{commonLabels.relatedArticles}</h2>
                            <div className='mdl:flex w-full'>{relatedArticles.map((article) => (
                                <ArticleCard
                                    key={article.sys}
                                    locale={locale}
                                    {...article}
                                    href={null}
                                    variant='faqArticlesCard'
                                />
                            ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

FAQPage.propTypes = {
    locale: PropTypes.string.isRequired,
    bannerCard: PropTypes.object,
    accordionCollection: PropTypes.array,
    relatedArticles: PropTypes.array,
    faqCategoryCollection: PropTypes.array,
}

export default memo(FAQPage)
