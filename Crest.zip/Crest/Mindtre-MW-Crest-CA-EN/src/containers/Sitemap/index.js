import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"

const Button = dynamic(() => import("@components/Button"))

const Sitemap = ({ title, products, aboutUs, tips, contactUs }) => {
    return (
        <div className='px-20 mx-auto mb-100 w-full lg:w-lg mxl:w-mxl xl:w-xl lg:px-0'>
            {title && (
                <h1 className='text-28 leading-34 font-neutrafaceDemi text-primary mt-25 mb-15 mdl:text-40 mdl:leading-38 mdl:mt-40 mdl:mb-40 mdl:font-neutrafaceBold'>
                    {title}
                </h1>
            )}
            <div className='flex flex-wrap'>
                <div className='mdl:w-6/12'>
                    {products && (
                        <div className='mb-20 mdl:mb-0'>
                            {products.title && (
                                <h2 className='text-22 leading-32 font-neutrafaceBold text-accent mb-8 mdl:mb-15 mdl:text-24 mdl:leading-32'>
                                    {products.title}
                                </h2>
                            )}
                            <ul>
                                {products.items &&
                                    products.items.length > 0 &&
                                    products.items.map((item) => {
                                        return (
                                            <li key={item.sys} className='pl-10'>
                                                <Button
                                                    href={item.link}
                                                    gaClass='event_internal_link'
                                                    gaLabel={item.title}
                                                    className='text-20 leading-30 font-neutrafaceBold text-accent mb-15 mdl:mb-20 inline-block mdl:text-22 mdl:leading-30'>
                                                    <h3>{item.title}</h3>
                                                </Button>
                                            </li>
                                        )
                                    })}
                            </ul>
                        </div>
                    )}
                    <div className=''>
                        {aboutUs && (
                            <div className='mb-20'>
                                {aboutUs.title && (
                                    <h2 className='text-22 leading-32 font-neutrafaceBold text-accent mb-8 mdl:mb-15 mdl:text-24 mdl:leading-32'>
                                        {aboutUs.title}
                                    </h2>
                                )}
                                <ul>
                                    {aboutUs.items &&
                                        aboutUs.items.length > 0 &&
                                        aboutUs.items.map((item) => {
                                            return (
                                                <li key={item.sys} className='pl-20'>
                                                    <Button
                                                        href={item.link}
                                                        gaClass='event_internal_link'
                                                        gaLabel={item.title}
                                                        className='text-18 leading-26 font-neutrafaceBook text-accent mb-10 mdl:mb-8 inline-block mdl:text-20 mdl:leading-26'>
                                                        {item.title}
                                                    </Button>
                                                </li>
                                            )
                                        })}
                                </ul>
                            </div>
                        )}
                        {contactUs && (
                            <div>
                                {contactUs.title && contactUs.url && (
                                    <Button href={contactUs.url} gaClass='event_internal_link' gaLabel={contactUs.title}>
                                        <h2 className='text-22 leading-32 font-neutrafaceBold text-accent mb-35 mdl:mb-40 mdl:text-24 mdl:leading-32'>
                                            {contactUs.title}
                                        </h2>
                                    </Button>
                                )}
                            </div>
                        )}
                    </div>
                </div>
                <div className='mdl:w-6/12'>
                    {tips && (
                        <div className='mdl:mb-20'>
                            {tips.title && (
                                <h2 className='text-22 leading-32 font-neutrafaceBold text-accent mb-8 mdl:mb-15 mdl:text-24 mdl:leading-32'>
                                    {tips.title}
                                </h2>
                            )}
                            {tips.items &&
                                tips.items.length > 0 &&
                                tips.items.map((tipsItem) => {
                                    return (
                                        <div key={tipsItem.sys} className='pl-10 mb-5 mdl:mb-20'>
                                            {tipsItem.title && (
                                                <h3 className='text-20 leading-30 font-neutrafaceBold mb-10 mdl:mb-16 text-accent mdl:text-22 mdl:leading-30'>
                                                    {tipsItem.title}
                                                </h3>
                                            )}
                                            <ul>
                                                {tipsItem.subMenu &&
                                                    tipsItem.subMenu.length > 0 &&
                                                    tipsItem.subMenu.map((subMenuItem) => {
                                                        return (
                                                            <li key={subMenuItem.sys}>
                                                                <Button
                                                                    href={subMenuItem.link}
                                                                    gaClass='event_internal_link'
                                                                    gaLabel={subMenuItem.title}
                                                                    className='text-18 leading-26 font-neutrafaceBook text-accent mb-10 pl-10 mdl:mb-8 inline-block mdl:text-20'>
                                                                    {subMenuItem.title}
                                                                </Button>
                                                            </li>
                                                        )
                                                    })}
                                            </ul>
                                        </div>
                                    )
                                })}
                        </div>
                    )}
                    <div className='hidden '>
                        {aboutUs && (
                            <div className='mb-20'>
                                {aboutUs.title && (
                                    <h2 className='text-22 leading-32 font-neutrafaceBold text-accent mb-20 mdl:leading-30'>{aboutUs.title}</h2>
                                )}
                                <ul className='pl-10 mdl:pl-0'>
                                    {aboutUs.items &&
                                        aboutUs.items.length > 0 &&
                                        aboutUs.items.map((item) => {
                                            return (
                                                <li key={item.sys}>
                                                    <Button
                                                        href={item.link}
                                                        gaClass='event_internal_link'
                                                        gaLabel={item.title}
                                                        className='text-18 leading-26 font-neutrafaceBook text-accent mb-19 inline-block mdl:text-20 mdl:leading-26'>
                                                        {item.title}
                                                    </Button>
                                                </li>
                                            )
                                        })}
                                </ul>
                            </div>
                        )}
                        {contactUs && (
                            <div>
                                {contactUs.title && contactUs.url && (
                                    <Button href={contactUs.url} gaClass='event_internal_link' gaLabel={contactUs.title}>
                                        <h2 className='text-22 leading-32 font-neutrafaceBold text-accent mb-40 mdl:text-24 mdl:leading-32'>
                                            {contactUs.title}
                                        </h2>
                                    </Button>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    )
}

Sitemap.propTypes = {
    tips: PropTypes.object,
    title: PropTypes.string,
    locale: PropTypes.string,
    aboutUs: PropTypes.object,
    products: PropTypes.object,
    contactUs: PropTypes.object,
}

export default memo(Sitemap)
