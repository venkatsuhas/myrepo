import React from "react"
import { shallow } from "enzyme"
import Icon from '@components/Icon'

describe('Icon Component', ()=>{
    it('Should render Icon component with no name',()=>{
        const wrapper=shallow(<Icon name={''}/>)
        expect(wrapper).toBeTruthy()
    })
    it('Should render Icon component with valid name',()=>{
        const wrapper=shallow(<Icon name='SmartLabelIcon' className='' />)
        expect(wrapper).toBeTruthy()
    })
    it('Should render Icon component with invalid name',()=>{
        const wrapper=shallow(<Icon name='abc' className='' />)
        expect(wrapper).toBeTruthy()
    })

})
