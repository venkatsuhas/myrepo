import React, { memo } from 'react'
import PropTypes from 'prop-types'
import Icons from '@icons'

const Icon = ({ name, className }) => {
    if (!name) return <span>Icon not found</span>
    const SelectedIcon = Icons[name] ? Icons[name] : null
    if(SelectedIcon)
        return SelectedIcon(className)
    else
        return null
}

Icon.propTypes = {
    name: PropTypes.string.isRequired,
    className: PropTypes.string
}

export default memo(Icon)
