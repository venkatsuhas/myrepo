import React from "react"
import { shallow } from "enzyme"
import { locales } from "@constants"
import SmartLabel from '@components/SmartLabel'

describe('SmartLabel Component', ()=>{
    it('Should render Smart Label component',()=>{
        const wrapper=shallow(<SmartLabel locale={locales.english} smartLabelID='123456789' />)
        expect(wrapper).toBeTruthy()
    })
})
