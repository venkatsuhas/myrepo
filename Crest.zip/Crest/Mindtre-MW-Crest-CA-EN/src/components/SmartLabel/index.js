import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { labels } from '@constants'

const Button = dynamic(()=>import('@components/Button'))
const Icon = dynamic(()=>import('@components/Icon'))

const SmartLabel = ({ smartLabelID, locale }) => (
    <Button className='mt-5 py-10 border-light border-lightGreyBlue rounded-full flex w-max justify-between items-center px-10' href={`https://smartlabel.pg.com/${locale.toLowerCase()}/${smartLabelID}.html`}>
        <Icon className='border-r-light border-lightGreyBlue px-10 w-125' name='SmartLabelIcon'/>
        <span className='text-secondary text-14 leading-24 px-10 no-underline'>
            {labels[locale.toLowerCase()]?.smartLabelText}
        </span>
    </Button>
)

SmartLabel.propTypes = {
    smartLabelID: PropTypes.string.isRequired,
    locale: PropTypes.string.isRequired,
}

export default memo(SmartLabel)
