import React, { useState, useEffect, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import { labels as allLabels } from "@constants"

const Button = dynamic(() => import("@components/Button"))
const Accordion = dynamic(() => import("@components/Accordion"))

const FilterSmallScreen = ({ locale, variant, filter, handleDropDown, sortBy, toggleFilterIconState }) => {
    const router = useRouter()
    const labels = allLabels[locale.toLowerCase()].articleListingPage
    const [openAccordion, setOpenAccordion] = useState({
        sortBy: true,
        category: true,
    })
    const [localSortBy, setLocalSortBy] = useState(sortBy)
    const [category, setCategory] = useState(null)

    const toggleAccordion = useCallback((selectedCategory) => {
        setOpenAccordion((prevState) => ({
            ...prevState,
            [selectedCategory]: !prevState[selectedCategory],
        }))
    }, [])

    useEffect(() => {
        setCategory(router.asPath)
    }, [router.asPath])

    const applyFilters = useCallback(() => {
        handleDropDown(localSortBy)
        router.push(category)
        toggleFilterIconState()
    }, [category, handleDropDown, localSortBy, router, toggleFilterIconState])

    const generateID = useCallback((text1, text2) => `${text1.replace(/[^A-Za-z0-9-]/, "-")}-${text2.replace(/[^A-Za-z0-9-]/, "-")}-mobile`, [])

    return (
        <div>
            <div className='w-full h-screen pb-150 overflow-y-scroll no-scrollbar'>
                <Accordion open={openAccordion.sortBy} title={labels.sortBy.title} toggleOpen={() => toggleAccordion("sortBy")} variant={variant}>
                    <ul className='w-full'>
                        {labels.sortBy.items.map((item, index) => {
                            return (
                                <li key={index} className='flex flex-wrap justify-start items-center mb-20 cursor-pointer'>
                                    <input
                                        type='radio'
                                        id={generateID(labels.sortBy.title, item.name)}
                                        name={labels.sortBy.title}
                                        value={item.name}
                                        checked={localSortBy === item.value}
                                        onChange={() => setLocalSortBy(item.value)}
                                        className='pl-10 border border-accentBorder w-18 h-18 cursor-pointer text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0 focus:outline-none'
                                    />
                                    <label
                                        htmlFor={generateID(labels.sortBy.title, item.name)}
                                        className='font-neutrafaceBook text-20 leading-24 mdl:leading-30 text-secondary pl-10'>
                                        {item.name}
                                    </label>
                                </li>
                            )
                        })}
                    </ul>
                </Accordion>

                {filter && filter.subEntries && filter.subEntries.length > 0 && (
                    <Accordion open={openAccordion.category} title={filter.title} toggleOpen={() => toggleAccordion("category")} variant={variant}>
                        <ul className='w-full'>
                            {filter.subEntries.map((option, index) => (
                                <li key={index} className='flex flex-nowrap justify-start items-center mb-15 cursor-pointer'>
                                    <input
                                        type='radio'
                                        id={generateID(filter.title, option.title)}
                                        name={filter.title}
                                        title={option.title}
                                        value={option.url}
                                        checked={category === option.url}
                                        onChange={() => setCategory(option.url)}
                                        className='pl-10 border border-accentBorder w-18 h-18 cursor-pointer text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0 focus:outline-none'
                                    />
                                    <label
                                        htmlFor={generateID(filter.title, option.title)}
                                        className='font-neutrafaceBook text-20 leading-24 mdl:leading-30 text-secondary pl-10'>
                                        {option.title}
                                    </label>
                                </li>
                            ))}
                        </ul>
                    </Accordion>
                )}
                <div className='flex flex-wrap flex-row justify-end py-10 bg-white border-t border-lightestBorder w-full fixed bottom-0 left-0 px-20 z-50'>
                    <Button
                        gaClass='event_button_click'
                        className='text-16 leading-24 text-white font-neutrafaceDemi uppercase px-30 py-12 btn-filled rounded-full cursor-pointer'
                        onClick={applyFilters}>
                        {labels.applyFilter}
                    </Button>
                </div>
            </div>
        </div>
    )
}

FilterSmallScreen.propTypes = {
    locale: PropTypes.string,
    variant: PropTypes.string,
    filter: PropTypes.object,
    resetFilter: PropTypes.func,
    toggleFilter: PropTypes.func,
    activeFilters: PropTypes.array,
    handleDropDown: PropTypes.func,
    sortBy: PropTypes.string,
    toggleFilterIconState: PropTypes.func,
}

export default memo(FilterSmallScreen)
