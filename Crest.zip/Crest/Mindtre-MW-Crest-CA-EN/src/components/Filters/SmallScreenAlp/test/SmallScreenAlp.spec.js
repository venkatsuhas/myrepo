import React from "react"
import { shallow } from "enzyme"
import FilterSmallScreenAlp from "@components/Filters/SmallScreenAlp"

jest.mock("next/router", () => ({
    useRouter() {
        return {
            route: "/",
            pathname: "",
            query: "",
            asPath: "",
        }
    },
}))

describe("FilterSmallScreenAlp Component", () => {
    it("Should render FilterSmallScreenAlp component", () => {
        const props = {
            locale: "en-ca",
            variant: "header",
            sortBy: "A to Z",
            handleDropDown: jest.fn(),
            toggleFilterIconState: jest.fn(),
            filter: { title: "Crest", subEntries: [{ title: "Crest", url: "/" }] },
        }

        const wrapper = shallow(<FilterSmallScreenAlp {...props} />)
        expect(wrapper).toBeTruthy()
    })
    it("Should render DropDown component", () => {
        const props = {
            locale: "fr-ca",
            variant: "header",
            sortBy: "Z to A",
            handleDropDown: jest.fn(),
            toggleFilterIconState: jest.fn(),
            filter: { title: "Crest", subEntries: [{ title: "Crest", url: "/" }] },
        }

        const wrapper = shallow(<FilterSmallScreenAlp {...props} />)
        expect(wrapper).toBeTruthy()
    })
})
