import React, { useState, useEffect, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { labels as allLabels } from "@constants"

const Button = dynamic(() => import("@components/Button"))
const Accordion = dynamic(() => import("@components/Accordion"))
const FilterAccordion = dynamic(() => import("@components/FilterAccordion"))
const Icon = dynamic(() => import("@components/Icon"))

const FilterSmallScreen = ({ locale, variant, filters, toggleFilter, activeFilters, resetFilter, sortBy, handleDropDown, toggleFilterIconState }) => {
    const [openAccordion, setOpenAccordion] = useState(true)
    const [localActiveFilters, setLocalActiveFilters] = useState([...activeFilters])
    const [localSortBy, setLocalSortBy] = useState(sortBy)

    const toggleAccordion = useCallback(() => {
        setOpenAccordion((prevState) => !prevState)
    }, [])

    useEffect(() => {
        setLocalActiveFilters(activeFilters)
        setLocalSortBy(sortBy)
    }, [activeFilters, sortBy])

    const labels = allLabels[locale.toLowerCase()]?.productListingPage || {}

    const toggleLocalFilter = useCallback(
        (value) => {
            toggleFilter(value)
            setLocalActiveFilters((prevLocalActiveFilters) => {
                if (prevLocalActiveFilters.indexOf(value) === -1) {
                    return [...prevLocalActiveFilters, value]
                } else {
                    return prevLocalActiveFilters.filter((entry) => entry !== value)
                }
            })
        },
        [toggleFilter]
    )

    const resetFilters = useCallback(() => {
        resetFilter()
        toggleFilterIconState()
    }, [resetFilter, toggleFilterIconState])

    const closeFilters = useCallback(() => {
        localActiveFilters.map(toggleFilter)
        toggleFilterIconState()
    }, [localActiveFilters, toggleFilter, toggleFilterIconState])

    const applyFilters = useCallback(() => {
        handleDropDown(localSortBy)
        toggleFilterIconState()
    }, [handleDropDown, localSortBy, toggleFilterIconState])

    return (
        <>
            <div className='w-full flex flex-row justify-between items-center pt-37 pb-16 mb-15 border-b border-lightestBorder'>
                <p className='font-neutrafaceBook text-20 leading-30 text-secondary'>{labels.filters}</p>
                <Button gaClass='event_button_click' onClick={closeFilters}>
                    <Icon className='closeIcon' name='Close' />
                </Button>
            </div>
            <div>
                <div className='w-full h-screen pb-150 overflow-y-scroll no-scrollbar'>
                    <Accordion open={openAccordion} title={labels.sortBy.title} toggleOpen={toggleAccordion} variant={variant}>
                        <ul className='w-full'>
                            {labels.sortBy.items.map((item, index) => {
                                return (
                                    <li key={index} className='flex flex-wrap justify-start items-center mb-20 cursor-pointer'>
                                        <input
                                            type='radio'
                                            name={`${labels.sortBy.title}-radio`}
                                            value={item.value}
                                            checked={item.value === localSortBy}
                                            onChange={() => setLocalSortBy(item.value)}
                                            className='pl-10 border border-accentBorder w-18 h-18 cursor-pointer text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0'
                                        />
                                        <label className='font-neutrafaceBook text-20 leading-24 mdl:leading-30 text-secondary pl-10'>
                                            {item.name}
                                        </label>
                                    </li>
                                )
                            })}
                        </ul>
                    </Accordion>
                    {filters &&
                        filters
                            .filter((filter) => filter.options.filter((option) => option.count).length)
                            .map((filter) => (
                                <FilterAccordion
                                    key={filter?.name?.toLowerCase().replace(" ", "-")}
                                    title={filter.name}
                                    options={filter.options.map((option) => ({
                                        name: option.name,
                                        state: localActiveFilters.indexOf(option.name) !== -1,
                                        count: option.count,
                                    }))}
                                    variant={variant}
                                    filterUpdate={toggleLocalFilter}
                                    constant='SmallScreen'
                                />
                            ))}
                    <div className='flex flex-wrap flex-row justify-between py-10 bg-white border-t border-lightestBorder w-full fixed bottom-0 left-0 px-15 z-50'>
                        <Button
                            gaClass='event_button_click'
                            className='text-16 leading-24 text-accent font-neutrafaceDemi uppercase px-20 py-12 btn-plain rounded-full cursor-pointer'
                            onClick={() => resetFilters()}>
                            {labels.resetFilters}
                        </Button>
                        <Button
                            gaClass='event_button_click'
                            className='text-16 leading-24 text-white font-neutrafaceDemi uppercase px-20 py-12 btn-filled rounded-full cursor-pointer'
                            onClick={() => applyFilters()}>
                            {labels.applyFilter}
                        </Button>
                    </div>
                </div>
            </div>
        </>
    )
}

FilterSmallScreen.propTypes = {
    locale: PropTypes.string,
    variant: PropTypes.string,
    filters: PropTypes.array,
    resetFilter: PropTypes.func,
    toggleFilter: PropTypes.func,
    activeFilters: PropTypes.array,
    sortBy: PropTypes.string,
    handleDropDown: PropTypes.func,
    toggleFilterIconState: PropTypes.func,
}

export default memo(FilterSmallScreen)
