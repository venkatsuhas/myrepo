import React from "react"
import { shallow } from "enzyme"
import FilterSmallScreen from "@components/Filters/SmallScreen"

// jest.mock("react", () => ({
//     ...jest.requireActual("react"),
//     useState: jest.fn(),
//     useEffect: jest.fn(),
// }))

describe("FilterSmallScreen Component", () => {
    it("Should render FilterSmallScreen component", () => {
        // const setState = jest.fn()
        const props = {
            locale: "en-ca",
            variant: "ProductListingPage",
            filters: [
                { name: "Crest", options: [{ name: "Crest", count: 1 }] },
                { name: "Crest", options: [{ name: "Crest", count: 1 }] },
            ],
            resetFilter: jest.fn(),
            toggleFilter: jest.fn(),
            activeFilters: ["Crest", "Always"],
            sortBy: "A to Z",
            handleDropDown: jest.fn(),
            toggleFilterIconState: jest.fn(),
        }

        // const mockState = {
        //     openAccordion: true,
        //     localActiveFilters: ["Crest", "Always"],
        //     localSortBy: "A to Z",
        // }
        // useStateMock.mockImplementation(() => [mockState, setState])

        // useEffectMock.mockImplementationOnce((func) => func())

        const wrapper = shallow(<FilterSmallScreen {...props} />)
        expect(wrapper).toBeTruthy()
    })
    it("Should render FilterSmallScreen component", () => {
        // const setState = jest.fn()
        const props = {
            locale: "fr-ca",
            variant: "header",
            filters: [
                { name: "Crest", options: [{ name: "Crest", count: 1 }] },
                { name: "Crest", options: [{ name: "Crest", count: 1 }] },
            ],
            resetFilter: jest.fn(),
            toggleFilter: jest.fn(),
            activeFilters: ["Crest", "Always"],
            sortBy: "Z to A",
            handleDropDown: jest.fn(),
            toggleFilterIconState: jest.fn(),
        }

        // const mockState = {
        //     openAccordion: false,
        //     localActiveFilters: ["Crest", "Always"],
        //     localSortBy: "A to Z",
        // }
        // useStateMock.mockImplementation(() => [mockState, setState])

        // useEffectMock.mockImplementationOnce((func) => func())

        const wrapper = shallow(<FilterSmallScreen {...props} />)
        expect(wrapper).toBeTruthy()
    })
})
