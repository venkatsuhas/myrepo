import React from "react"
import { shallow } from "enzyme"
import FilterLargeScreen from "@components/Filters/LargeScreen"

jest.mock("next/router", () => ({
    useRouter() {
        return {
            route: "/",
            pathname: "",
            query: "",
            asPath: "",
        }
    },
}))

describe("FilterLargeScreen Component", () => {
    it("Should render FilterLargeScreen component", () => {
        const props = {
            type: "Category",
            locale: "en-ca",
            variant: "ProductListingPage",
            filters: [
                { name: "Crest", options: [{ name: "Crest", count: 1 }] },
                { name: "Crest", options: [{ name: "Crest", count: 1 }] },
            ],
            mainCategories: [
                { url: "/", title: "Crest" },
                { url: "/", title: "Crest" },
            ],
            resetFilter: jest.fn(),
            toggleFilter: jest.fn(),
            activeFilters: ["Crest", "Always"],
        }

        const wrapper = shallow(<FilterLargeScreen {...props} />)
        expect(wrapper).toBeTruthy()
    })
    it("Should render FilterLargeScreen component", () => {
        const props = {
            type: "Solution",
            locale: "fr-ca",
            variant: "header",
            filters: [
                { name: "Crest", options: [{ name: "Crest", count: 1 }] },
                { name: "Crest", options: [{ name: "Crest", count: 1 }] },
            ],
            mainCategories: [
                { url: "/", title: "Crest" },
                { url: "/", title: "Crest" },
            ],
            resetFilter: jest.fn(),
            toggleFilter: jest.fn(),
            activeFilters: ["Crest", "Always"],
        }

        const wrapper = shallow(<FilterLargeScreen {...props} />)
        expect(wrapper).toBeTruthy()
    })
})
