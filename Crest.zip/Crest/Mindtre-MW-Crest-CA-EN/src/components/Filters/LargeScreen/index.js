import React, { useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import { labels as allLabels } from "@constants"

const Button = dynamic(() => import("@components/Button"))
const FilterAccordion = dynamic(() => import("@components/FilterAccordion"))

const FilterLargeScreen = ({ type, locale, variant, mainCategories, filters, toggleFilter, activeFilters, resetFilter }) => {
    const labels = allLabels[locale.toLowerCase()]?.productListingPage || {}
    const router = useRouter()
    const resetFilters = useCallback(() => {
        if (typeof resetFilter === "function") resetFilter()
    }, [resetFilter])

    return (
        <div className='hidden mdl:block'>
            <ul className='border-lightestBorder border mdl:pt-30 mdl:pb-5 mdl:px-20 mdl:mb-30 rounded-md'>
                <p className='uppercase w-full font-neutrafaceBold text-18 leading-26 text-accentDark mb-30'>{labels.browseByLabels[type]}</p>
                {mainCategories?.length > 0 &&
                    mainCategories?.map((category, index) => {
                        return (
                            <li key={index} className='text-20 leading-24 mb-20'>
                                <Button
                                    className={
                                        decodeURI(router.asPath) === category.url
                                            ? "font-neutrafaceBold text-primary"
                                            : "font-neutrafaceBook text-secondary"
                                    }
                                    href={category.url}
                                    gaClass='event_internal_link'
                                    gaLabel={category.url}>
                                    {category.title}
                                </Button>
                            </li>
                        )
                    })}
            </ul>
            <div className='w-full'>
                <div className='flex flex-wrap flex-row justify-between items-center  pb-10 mb-40 border-b border-lightestBorder'>
                    <p className='font-neutrafaceBook text-20 leading-30 text-secondary'>{labels.filters}</p>
                    <Button
                        className='font-neutrafaceBook text-20 leading-30 text-secondary text-opacity-70'
                        gaClass='event_button_click'
                        onClick={resetFilters}>
                        {labels.resetFilters}
                    </Button>
                </div>
                {filters &&
                    filters
                        .filter((filter) => filter.options.filter((option) => option.count).length)
                        .map((filter) => (
                            <FilterAccordion
                                key={filter?.name?.toLowerCase().replace(" ", "-")}
                                title={filter.name}
                                options={filter.options.map((option) => ({
                                    name: option.name,
                                    state: activeFilters.indexOf(option.name) !== -1,
                                    count: option.count,
                                }))}
                                variant={variant}
                                filterUpdate={toggleFilter}
                                constant='LargeScreen'
                            />
                        ))}
            </div>
        </div>
    )
}

FilterLargeScreen.propTypes = {
    type: PropTypes.string,
    locale: PropTypes.string,
    variant: PropTypes.string,
    filters: PropTypes.array,
    mainCategories: PropTypes.array,
    resetFilter: PropTypes.func,
    toggleFilter: PropTypes.func,
    activeFilters: PropTypes.array,
}

export default memo(FilterLargeScreen)
