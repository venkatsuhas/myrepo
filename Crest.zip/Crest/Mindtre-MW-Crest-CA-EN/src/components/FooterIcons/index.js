import React, { memo } from "react"
import dynamic from "next/dynamic"

const IconButton = dynamic(() => import("@components/IconButton"))

const FooterIcons = () => {
    return (
        <div className='footerSocialIcon'>
            <div>
                <IconButton variant='footerSocial' gaClass='event_socialmedia_exit' />
            </div>
            <div className='footerLabel'>
                <IconButton variant='footerLabels' gaClass='event_outbound_link' />
            </div>
        </div>
    )
}

export default memo(FooterIcons)
