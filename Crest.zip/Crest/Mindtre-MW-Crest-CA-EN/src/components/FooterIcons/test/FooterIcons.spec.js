import React from "react"
import { shallow } from "enzyme"
import FooterIcons from "../index"

describe("FooterIcons component", () => {
    let wrapper
    jest.mock("@components/IconButton/index")
    beforeEach(() => {
        window.scrollTo = jest.fn()
        wrapper = shallow(<FooterIcons />)
        expect(wrapper).toBeTruthy()
    })

    it('should render FooterIcons component', () => {
        expect(wrapper).toBeTruthy()
    })
})
