import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { allIcons, allIconLinks, labels } from "@constants"

const Button = dynamic(() => import("@components/Button"))
const Icon = dynamic(() => import("@components/Icon"))

export const getButton = ({ iconName, articleName, articleURL, copyToClipboard, copiedToClipboard, locale, gaClass }) => {
    const props = { href: allIconLinks[iconName] }
    switch (iconName && iconName.toLowerCase()) {
    case "facebookicon":
        props.href = `https://facebook.com/sharer/sharer.php?u=${process.env.DOMAIN}${articleURL}`
        break
    case "linkicon":
        props.href = null
        props.onClick = () => {
            navigator.clipboard.writeText(`${process.env.DOMAIN}${articleURL}`)
            if (typeof copyToClipboard === "function") copyToClipboard()
        }
        break
    case "twittericon":
        props.href = `http://twitter.com/share?text=${articleName}&url=${process.env.DOMAIN}${articleURL}`
        break
    default:
        break
    }

    return (
        <>
            {iconName && iconName.toLowerCase() === "linkicon" && (
                <div
                    className={`${
                        copiedToClipboard ? "block" : "hidden"
                    } clipText absolute left-35 whitespace-nowrap bg-darkBlue text-white p-5 inline-flex w-90 right-auto rounded-3 top-50p transform -translate-y-2/4 lg:-left-30 lg:-top-25 `}>
                    {labels[locale?.toLowerCase()]?.linkCopied}
                </div>
            )}
            <Button {...{ ...props, anchor: !props.href }} gaClass={gaClass} gaLabel={props.href||iconName} name={iconName}>
                <span className='sr-only'>{iconName}</span>
                <Icon name={iconName} className='' />
            </Button>
        </>
    )
}

const IconButton = ({ variant, articleName, articleURL, copyToClipboard, copiedToClipboard, locale, gaClass }) => {
    return (
        <div className='socialWrap flex items-center mb-30 mdl:w-1/12 mdl:flex-nowrap mdl:content-start'>
            {Object.keys(allIcons[variant]).map((key, index) => (
                <div key={index} className='icon pr-20 last:pr-0 mdl:w-full mdl:pr-0 mdl:pb-20 relative'>
                    {getButton({ iconName : allIcons[variant][key], articleName, articleURL, copyToClipboard, copiedToClipboard, locale, gaClass })}
                </div>
            ))}
        </div>
    )
}

IconButton.propTypes = {
    variant: PropTypes.string,
    articleName: PropTypes.string,
    articleURL: PropTypes.string,
    copyToClipboard: PropTypes.func,
    copiedToClipboard: PropTypes.bool,
    locale: PropTypes.string,
    gaClass: PropTypes.string,
}

IconButton.defaultprops = {
    variant: '',
    articleName:'',
    locale:'',
    gaClass:'',
    articleURL:'',
}
export default memo(IconButton)
