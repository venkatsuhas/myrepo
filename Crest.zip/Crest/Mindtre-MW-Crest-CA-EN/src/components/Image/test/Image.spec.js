import React from "react"
import { shallow } from "enzyme"
import Image from "../index"

describe('Button Component', () => {
    it('Should render Imageset with priority', () => {
        const props={
            desktopClassName: "imgContainer min-h-150 mxl:min-h-250",  
            smartphoneClassName: "imgContainer min-h-150 mxl:min-h-250",  
            wrapperClassName: "w-full",
            desktopImage: {
                sys: 'LebCY3LHEwM03PJHbWgaa',
                url: 'LebCY3LHEwM03PJHbWgaa/52b040eef248285e54fdbc9aac7cd726/1_The_Best_Mouthwash_for_Gingivitis_and_Gum_Disease_2x.jpg',
                altText: '1 The Best Mouthwash for Gingivitis and Gum Disease@2x',
                height: 924,
                width: 960
            }, 
            smartphoneImage: {
                sys: 'LebCY3LHEwM03PJHbWgaa',
                url: 'LebCY3LHEwM03PJHbWgaa/52b040eef248285e54fdbc9aac7cd726/1_The_Best_Mouthwash_for_Gingivitis_and_Gum_Disease_2x.jpg',
                altText: '1 The Best Mouthwash for Gingivitis and Gum Disease@2x',
                height: 924,
                width: 960
            },
            priority: true,
        }
        const wrapper = shallow(<Image {...props}  alt={''} />)
        expect(wrapper).toBeTruthy()
    })

    it('Should render Imageset with priority', () => {
        const props={
            desktopClassName: "imgContainer min-h-150 mxl:min-h-250",  
            smartphoneClassName: "imgContainer min-h-150 mxl:min-h-250",  
            wrapperClassName: "w-full",
            desktopImage: {
                sys: 'LebCY3LHEwM03PJHbWgaa',
                url: 'LebCY3LHEwM03PJHbWgaa/52b040eef248285e54fdbc9aac7cd726/1_The_Best_Mouthwash_for_Gingivitis_and_Gum_Disease_2x.jpg',
                altText: '1 The Best Mouthwash for Gingivitis and Gum Disease@2x',
                height: 924,
                width: 960
            }, 
            smartphoneImage: {
                sys: 'LebCY3LHEwM03PJHbWgaa',
                url: 'LebCY3LHEwM03PJHbWgaa/52b040eef248285e54fdbc9aac7cd726/1_The_Best_Mouthwash_for_Gingivitis_and_Gum_Disease_2x.jpg',
                altText: '1 The Best Mouthwash for Gingivitis and Gum Disease@2x',
                height: 924,
                width: 960
            },
            layout: 'fixed',
            priority: true,
        }
        const wrapper = shallow(<Image {...props}  alt={''} />)
        expect(wrapper).toBeTruthy()
    })

    it('Should render Imageset without priority', () => {
        const props={
            desktopClassName: "imgContainer min-h-150 mxl:min-h-250",  
            smartphoneClassName: "imgContainer min-h-150 mxl:min-h-250",  
            wrapperClassName: "w-full",
            desktopImage: {
                sys: 'LebCY3LHEwM03PJHbWgaa',
                url: 'LebCY3LHEwM03PJHbWgaa/52b040eef248285e54fdbc9aac7cd726/1_The_Best_Mouthwash_for_Gingivitis_and_Gum_Disease_2x.jpg',
                altText: '1 The Best Mouthwash for Gingivitis and Gum Disease@2x',
                height: 924,
                width: 960
            }, 
            smartphoneImage: {
                sys: 'LebCY3LHEwM03PJHbWgaa',
                url: 'LebCY3LHEwM03PJHbWgaa/52b040eef248285e54fdbc9aac7cd726/1_The_Best_Mouthwash_for_Gingivitis_and_Gum_Disease_2x.jpg',
                altText: '1 The Best Mouthwash for Gingivitis and Gum Disease@2x',
                height: 924,
                width: 960
            },
        }
        const wrapper = shallow(<Image {...props}  alt={''} />)
        expect(wrapper).toBeTruthy()
    })

})
