import React from "react"
import { shallow } from "enzyme"
import Button from '@components/Button'

describe('Button Component', ()=>{
    it('Should render Button component with external URL',()=>{
        const props={
            href:"www.pg.com",
            className:'',
            target:'_blank'
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
    })
    
    it('Should render Button component with external URL without target',()=>{
        const props={
            href:"www.pg.com",
            className:''
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
    })

    it('Should render Button component with internal URL',()=>{
        const props={
            href:"/",
            className:'',
            gaClass: 'test',
            target:'_blank'
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
    })
    
    it('Should render Button component with hash path and element found',()=>{
        Object.defineProperty(global.document, 'querySelector', { value: jest.fn().mockImplementation((hash)=>hash==='#test'?({ scrollIntoView: jest.fn() }):null) })
        const props={
            href:"#test",
            className:''
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
        wrapper.prop('onClick')({ preventDefault: jest.fn() })
    })

    it('Should render Button component with hash path and element not found',()=>{
        const props={
            href:"#notTest",
            className: 'class',
            gaClass: 'test'
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
        wrapper.prop('onClick')({ preventDefault: jest.fn() })
    })

    it('Should render Button component with hash path and anchor prop',()=>{
        const props={
            href:"#test",
            className:'',
            anchor: true
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
    })
    
    it('Should render Button component without URL',()=>{
        const props={
            className:'',
            target:'_blank'
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
    })

    it('Should render Button component without URL and null type',()=>{
        const props={
            className:'',
            target:'_blank',
            type:null
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
    })
    
    it('Should render Button component with role',()=>{
        const props={
            className:'',
            target:'_blank',
            role:'button'
        }
        const wrapper=shallow(<Button {...props}>Hi</Button>)
        expect(wrapper).toBeTruthy()
    })

})
