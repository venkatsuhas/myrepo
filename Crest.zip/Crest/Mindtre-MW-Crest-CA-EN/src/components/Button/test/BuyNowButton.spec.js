import React from "react"
import { shallow } from "enzyme"
import BuyNowButton from "@components/Button/BuyNowButton"

jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useContext: jest.fn().mockImplementation(()=>({ openBuyNow: jest.fn() })),
}))

describe("Buy Now Button component with shallow render", () => {
    let wrapper
    const props = {
        className:
            "text-18",
        sku: "",
        locale: "en-ca",
    }

    beforeEach(() => {
        wrapper = shallow(<BuyNowButton {...props} />)
    })

    it("should render", () => {
        expect(wrapper).toBeTruthy()
        wrapper.prop('onClick')()
    })
})
