import React, { useContext, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { labels } from '@constants'

import BuyNowContext from '@components/BuyNow/BuyNowContext'

const Button = dynamic(()=>import('@components/Button'))

const BuyNowButton = ({ className, sku, locale }) => {
    const whereToBuy = labels[locale.toLowerCase()]?.whereToBuy
    const { openBuyNow } = useContext(BuyNowContext)
    
    return (
        <Button gaClass='event_buy_now' gaLabel={sku} className={className} onClick={()=>openBuyNow(sku)}>{whereToBuy}</Button>
    )
}

BuyNowButton.propTypes = {
    className: PropTypes.string,
    sku: PropTypes.string.isRequired,
    locale: PropTypes.string.isRequired,
}

BuyNowButton.defaultProps = {
    className:'font-neutrafaceDemi text-18 leading-24 px-78 lg:px-62 pt-15 pb-11 mdl:pt-19 mdl:pb-15 bg-accent text-white uppercase rounded-full cursor-pointer btn-filled'
}

export default memo(BuyNowButton)
