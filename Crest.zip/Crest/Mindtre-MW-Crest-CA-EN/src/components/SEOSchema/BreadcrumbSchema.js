import React, { memo } from "react"
import PropTypes from "prop-types"
import Head from "next/head"

const BreadcrumbSchema = ({ breadcrumb }) => (
    <Head>
        <script
            type='application/ld+json'
            dangerouslySetInnerHTML={{
                __html: `{
                    "@context":"https://schema.org",
                    "@type": "BreadcrumbList",
                    "itemListElement": ${JSON.stringify(
                    breadcrumb.map((breadcrumbEntry, key) => ({
                        "@type": "ListItem",
                        position: key + 1,
                        name: breadcrumbEntry.title,
                        item: process.env.DOMAIN + breadcrumbEntry.url,
                    }))
                )}
                }`,
            }}
        />
    </Head>
)

BreadcrumbSchema.propTypes = {
    breadcrumb: PropTypes.arrayOf(
        PropTypes.shape({
            sys: PropTypes.string,
            title: PropTypes.string,
            url: PropTypes.string,
        })
    ),
}

export default memo(BreadcrumbSchema)
