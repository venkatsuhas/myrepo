import React, { memo } from "react"
import PropTypes from "prop-types"
import Head from "next/head"

const HomepageSchema = ({ locale }) => (
    <Head>
        <script
            type='application/ld+json'
            dangerouslySetInnerHTML={{
                __html: `{
        "@context":"https://schema.org",
        "@type": "WebSite",
        "name":"Crest",
        "url":"${process.env.DOMAIN}/${locale?.toLowerCase()}",
        "potentialAction":{"@type":"SearchAction","target":"${
            process.env.DOMAIN
        }/${locale?.toLowerCase()}/search?term={search_term}",
        "query-input":"required name=search_term"}}`,
            }}
        />
    </Head>
)

HomepageSchema.propTypes = {
    locale: PropTypes.string.isRequired,
}

export default memo(HomepageSchema)
