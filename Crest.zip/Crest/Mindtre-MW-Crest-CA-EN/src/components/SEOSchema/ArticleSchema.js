import React, { memo } from "react"
import PropTypes from "prop-types"
import Head from "next/head"
import SEOConstants from "@constants/SEOConstants"

const ArticleSchema = ({ locale, schemaData }) => (
    <Head>
        <script
            type='application/ld+json'
            dangerouslySetInnerHTML={{
                __html: `{
            "@context":"https://schema.org",
            "@type": "Article",
            "author": "Crest Canada – P&G",
            "dateCreated": "${schemaData?.created}",
            "dateModified": "${schemaData?.published}",
            "datePublished": "${schemaData?.published}",
            "mainEntityOfPage":{
                "@type":"WebPage",
                "@id":"${process.env.DOMAIN}${schemaData?.url}"
            },
            "headline": "${schemaData?.name || ""}",
            "image": {
                "@type": "ImageObject",
                "url": "${schemaData?.banner || ""}"
            },
            "publisher": {
                    "@type": "Organization",
                    "name": "Crest",
                    "url": "${SEOConstants.url[locale]}",
                    "logo": {
                    "@type": "ImageObject",
                    "url": "${SEOConstants.brandLogoURL}"
                    }
                },
                "description": "${schemaData?.description || ""}"
            }
        }`,
            }}
        />
    </Head>
)

ArticleSchema.propTypes = {
    locale: PropTypes.string.isRequired,
    schemaData: PropTypes.object.isRequired,
}

export default memo(ArticleSchema)
