import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { pageTypes } from '@constants'

const ArticleSchema = dynamic(()=>import('@components/SEOSchema/ArticleSchema'))
const BreadcrumbSchema = dynamic(()=>import('@components/SEOSchema/BreadcrumbSchema'))
const HomepageSchema = dynamic(()=>import('@components/SEOSchema/HomepageSchema'))
const OrganizationSchema = dynamic(()=>import('@components/SEOSchema/OrganizationSchema'))
const ProductSchema = dynamic(()=>import('@components/SEOSchema/ProductSchema'))

const SEOSchema = ({ pageType, locale, breadcrumb, schemaData }) => (
    <>
        {(pageType === pageTypes.homepage) && <HomepageSchema locale={locale} />  }
        {(pageType === pageTypes.homepage) && <OrganizationSchema locale={locale} />  }
        {(pageType === pageTypes.adpPage) && <ArticleSchema locale={locale} schemaData={schemaData}/>}
        {(pageType === pageTypes.pdpPage) && <ProductSchema schemaData={schemaData}/>}
        {breadcrumb && breadcrumb.length > 0 && <BreadcrumbSchema breadcrumb={breadcrumb} />}
    </>
)

SEOSchema.propTypes = {
    pageType: PropTypes.string.isRequired,
    locale: PropTypes.string.isRequired,
    breadcrumb: PropTypes.arrayOf(
        PropTypes.shape({
            sys: PropTypes.string,
            title: PropTypes.string,
            url: PropTypes.string,
        })
    ),
    schemaData: PropTypes.object,
}

export default memo(SEOSchema)
