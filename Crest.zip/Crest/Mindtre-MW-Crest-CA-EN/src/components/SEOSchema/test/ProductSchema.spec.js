import React from 'react'
import { shallow } from 'enzyme'
import ProductSchema from '@components/SEOSchema/ProductSchema'

describe('ProductSchema component', () => {
    let wrapper
    let props = {
        schemaData: {
            name:'',
            description:'',
            image: '',
            sku: '',
            aggregateRating:{
                ratingValue:'',
                reviewCount:''
            },
            review:{
                author:'',
                date:'',
                reviewBody:'',
                name:'',
                rating:''
            }
        }
    }
    beforeEach(() => {
        wrapper = shallow(<ProductSchema {...props} />)
    })
    it('should render', () => {
        expect(wrapper).toBeTruthy()
    })
})
