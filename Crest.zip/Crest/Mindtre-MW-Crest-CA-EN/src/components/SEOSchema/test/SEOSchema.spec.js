import React from 'react'
import { shallow } from 'enzyme'
import { pageTypes } from '@constants'
import SEOSchema from '@components/SEOSchema'

describe('SEOSchema component', () => {
    let wrapper
    
    it('should render for ADP', () => {
        let props = {
            pageType: pageTypes.adpPage
        }
        wrapper = shallow(<SEOSchema {...props} />)
        expect(wrapper).toBeTruthy()
    })
    it('should render for PDP', () => {
        let props = {
            pageType: pageTypes.pdpPage
        }
        wrapper = shallow(<SEOSchema {...props} />)
        expect(wrapper).toBeTruthy()
    })
    it('should render for Homepage', () => {
        let props = {
            pageType: pageTypes.homepage
        }
        wrapper = shallow(<SEOSchema {...props} />)
        expect(wrapper).toBeTruthy()
    })
    it('should render when breadcrumb is present', () => {
        let props = {
            breadcrumb: [{
                title: '',
                url: ''
            }]
        }
        wrapper = shallow(<SEOSchema {...props} />)
        expect(wrapper).toBeTruthy()
    })
})
