import React from 'react'
import { shallow } from 'enzyme'
import ArticleSchema from '@components/SEOSchema/ArticleSchema'

describe('ArticleSchema component', () => {
    let wrapper
    let props = {
        locale:'en-ca',
        schemaData: {
            created: '',
            published: '',
            name:'',
            banner:'',
            description:''
        }
    }
    beforeEach(() => {
        wrapper = shallow(<ArticleSchema {...props} />)
    })
    it('should render', () => {
        expect(wrapper).toBeTruthy()
    })
})
