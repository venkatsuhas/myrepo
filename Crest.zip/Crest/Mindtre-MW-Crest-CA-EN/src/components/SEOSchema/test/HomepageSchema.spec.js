import React from 'react'
import { shallow } from 'enzyme'
import HomepageSchema from '@components/SEOSchema/HomepageSchema'

describe('HomepageSchema component', () => {
    let wrapper
    let props = {
        locale:'en-ca'
    }
    beforeEach(() => {
        wrapper = shallow(<HomepageSchema {...props} />)
    })
    it('should render', () => {
        expect(wrapper).toBeTruthy()
    })
})
