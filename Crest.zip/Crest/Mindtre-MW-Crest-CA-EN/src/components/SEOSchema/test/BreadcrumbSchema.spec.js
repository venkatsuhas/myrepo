import React from 'react'
import { shallow } from 'enzyme'
import BreadcrumbSchema from '@components/SEOSchema/BreadcrumbSchema'

describe('BreadcrumbSchema component', () => {
    let wrapper
    let props = {
        breadcrumb: [{
            title: '',
            url: ''
        }]
    }
    beforeEach(() => {
        wrapper = shallow(<BreadcrumbSchema {...props} />)
    })
    it('should render', () => {
        expect(wrapper).toBeTruthy()
    })
})
