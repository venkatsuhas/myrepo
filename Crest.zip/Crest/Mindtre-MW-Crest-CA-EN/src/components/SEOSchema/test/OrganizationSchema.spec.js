import React from 'react'
import { shallow } from 'enzyme'
import OrganizationSchema from '@components/SEOSchema/OrganizationSchema'

describe('OrganizationSchema component', () => {
    let wrapper
    let props = {
        locale:'en-ca'
    }
    beforeEach(() => {
        wrapper = shallow(<OrganizationSchema {...props} />)
    })
    it('should render', () => {
        expect(wrapper).toBeTruthy()
    })
})
