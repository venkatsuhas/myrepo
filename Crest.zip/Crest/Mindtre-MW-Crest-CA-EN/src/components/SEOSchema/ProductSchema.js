import React, { memo } from "react"
import PropTypes from "prop-types"
import Head from "next/head"

const ProductSchema = ({ schemaData }) => (
    <Head>
        <script
            type='application/ld+json'
            dangerouslySetInnerHTML={{
                __html: `{
            "@context":"https://schema.org",
            "@type": "IndividualProduct",
            "brand": {
                "@type": "Brand",
                "name": "Crest"
            },
            "name": "${schemaData?.name}",
            "description": "${schemaData?.description || ""}",
            "image": "${schemaData?.image || ""}",
            "sku": "${schemaData?.sku}",
            "gtin14": "${schemaData?.sku}",
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "${schemaData?.aggregateRating?.ratingValue || 0}",
                "reviewCount": "${schemaData?.aggregateRating?.reviewCount || 0}"
            },
            "review": [
                {
                    "@type": "Review",
                    "author": "${schemaData?.review?.author || "Anonymous"}",
                    "datePublished": "${schemaData?.review?.date}",
                    "reviewBody": ${JSON.stringify(
                    schemaData?.review?.reviewBody || ""
                )},
                    "name": ${JSON.stringify(schemaData?.review?.name || "")},
                    "reviewRating": {
                        "@type": "Rating",
                        "bestRating": "5",
                        "ratingValue": "${schemaData?.review?.rating || 1}",
                        "worstRating": "1"
                    }
                }
            ]
        }`,
            }}
        />
    </Head>
)

ProductSchema.propTypes = {
    schemaData: PropTypes.object.isRequired,
}

export default memo(ProductSchema)
