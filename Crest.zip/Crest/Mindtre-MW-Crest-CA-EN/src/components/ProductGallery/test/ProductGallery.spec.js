import React from "react"
import { shallow } from "enzyme"
import ProductGallery from "../index"

const  productImages = [
    {
        variant: '2X1',
        productImages: [{ 
            sys: '2fCiG0ZNFKLd2lQ8K9anR',
            url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
            altText: 'about Us image',
            height: 318,
            width: 361
        },   
        { 
            sys: '2fCiG0ZNFKLd2lQ8K9anR1',
            url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
            altText: 'about Us image',
            height: 318,
            width: 361
        }]
    },  
    { variant: '1X1',
        productImages: [{ 
            sys: '2fCiG0ZNFKLd2lQ8K9anR2',
            url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
            altText: 'about Us image',
            height: 318,
            width: 361
        },   
        { 
            sys: '2fCiG0ZNFKLd2lQ8K9anR3',
            url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
            altText: 'about Us image',
            height: 318,
            width: 361
        }]
    }, 
    { 
        productImages: [{ 
            sys: '2fCiG0ZNFKLd2lQ8K9anR4',
            url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
            altText: 'about Us image',
            height: 318,
            width: 361
        },   
        { 
            sys: '2fCiG0ZNFKLd2lQ8K9anR5',
            url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
            altText: 'about Us image',
            height: 318,
            width: 361
        }]
    }   
]

describe("ProductGallery component", () => {
    let wrapper

    it('should render for desktop', () => {
        const props={
            productImages,
            isMobile:false
        }
        wrapper = shallow(<ProductGallery {...props}/>)
        expect(wrapper).toBeTruthy()
    })

    it('should render for mobile', () => {
        const props={
            productImages,
            isMobile: true
        }
        wrapper = shallow(<ProductGallery {...props}/>)
        expect(wrapper).toBeTruthy()
    })
})
