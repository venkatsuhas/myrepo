import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"

const Carousel = dynamic(() => import("@components/Carousel"))
const Image = dynamic(() => import("@components/Image"))

const ProductGallery = ({ productImages, isMobile }) => isMobile ? (
    <Carousel variant='productGallery'>
        {productImages
            .map((entry) => entry.productImages)
            .reduce(
                (prevValue, currentValue) => [
                    ...prevValue,
                    ...currentValue,
                ],
                []
            )
            .map((image) => (
                <Image
                    key={image.sys}
                    desktopClassName=''
                    wrapperClassName='w-full flex-grow-0 flex-shrink-0 scroll-snap-center px-10 mdl:px-0'
                    desktopImage={image}
                    alt={image?.altText}
                />
            ))}
    </Carousel>
) : <div>
    {productImages
        .map((entry,index)=>{
            if(entry.variant === '1X1')
                return (<div className='' key={`${entry.productImages[0]&&entry.productImages[0].sys}-${index}`}>
                    {entry.productImages.map((image) => (
                        <Image
                            key={image.sys}
                            desktopClassName=''
                            wrapperClassName='w-full mb-15'
                            desktopImage={image}
                            alt={image?.altText}
                        />
                    ))}
                </div>)
            else if(entry.variant === '2X1')
                return (<div className='flex flex-nowrap mb-15' key={`${entry.productImages[0]&&entry.productImages[0].sys}-${index}`}>
                    {entry.productImages.map((image) => (
                        <Image
                            key={image.sys}
                            desktopClassName=''
                            wrapperClassName='w-1/2 pl-7 first:pl-0 first:pr-7'
                            desktopImage={image}
                            alt={image?.altText}
                        />
                    ))}
                </div>)
            else
                return null
        })}
</div>

ProductGallery.propTypes = {
    productImages: PropTypes.arrayOf(
        PropTypes.shape({
            variant: PropTypes.string.isRequired,
            productImages: PropTypes.arrayOf(
                PropTypes.shape({
                    sys: PropTypes.string,
                    url: PropTypes.string,
                    altText: PropTypes.string,
                    height: PropTypes.number,
                    width: PropTypes.number,
                })
            ).isRequired,
        })
    ).isRequired,
    isMobile: PropTypes.bool,
}

ProductGallery.defaultProps = {
    isMobile: true,
}

export default memo(ProductGallery)
