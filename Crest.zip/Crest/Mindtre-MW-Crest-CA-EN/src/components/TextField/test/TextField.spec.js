import React from 'react'
import { shallow } from 'enzyme'
import TextField from '@components/TextField'

describe('TextField Component', () => {
    let wrapper

    beforeEach(() => {
        wrapper = shallow(<TextField />)
    })

    afterEach(() => {
        wrapper.unmount()
    })

    it('should render', () => {
        expect(wrapper.find("div")).toBeTruthy()
    })

    it('should render singleLineText', () => {
        wrapper.setProps({ multiRow: false })
        expect(wrapper.exists('input')).toBeTruthy()
    })

    it('should render multiLineText', () => {
        wrapper.setProps({ multiRow: true })
        expect(wrapper.exists('textarea')).toBeTruthy()
    })
})
