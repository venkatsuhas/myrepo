import React, { memo } from 'react'
import classNames from 'classnames'
import PropTypes from 'prop-types'

const TextField = ({
    required,
    className,
    labelId,
    labelText,
    multiRow,
    readonly,
    rows,
    cols,
    ...other
}) => multiRow ? (
    <>
        <label htmlFor={labelId}>
            {/* To be hidden to normal user and visible to screen readers */}
            <span className='sr-only'>{labelText}</span>
        </label>
        <textarea
            id={labelId}
            className={classNames(className)}
            {...other}
            rows={rows}
            cols={cols}
        />
    </>
) : (
    <>
        <label htmlFor={labelId}>
            {/* To be hidden to normal user and visible to screen readers */}
            <span className='sr-only'>{labelText}</span>
        </label>
        <input
            id={labelId}
            autoComplete='off'
            className={classNames(className)}
            required={required}
            readOnly={readonly}
            {...other}
        />
    </>
)

TextField.propTypes = {
    className: PropTypes.string,
    labelId: PropTypes.string,
    labelText: PropTypes.string,
    component: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
    required: PropTypes.bool,
    multiRow: PropTypes.bool,
    readonly: PropTypes.bool,
    rows: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    cols: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
}

TextField.defaultProps = {
    component: 'div',
    required: false,
    multiRow: false,
    className: '',
}

export default memo(TextField)
