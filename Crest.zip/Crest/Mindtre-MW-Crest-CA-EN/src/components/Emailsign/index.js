import React, { memo, useState, useEffect } from "react"
import PropTypes from 'prop-types'
import Typography from "@components/Typography"
import Image from "@components/Image"
import Modal from 'react-modal'
import { locales } from "@constants"

const Emailsign = ({ title,subTitle,label,emailOptionText,termsPrivacyPolicy,button,validationText1,validationText2,maximumEmailLimit,registrationSuccessMessage, backgroundAsset, locale })=>{
    
    const [Optin, setOptin] = useState(311)
    const [emailAddress, setEmailAddress] = useState("")
    const campaignBaseURL = process.env.GCS_BASE_URL || ''
    const getCampaignSlug = process.env.GCS_CAMPAIGN_SLUG || ''    
    const postRegistrationSlug = process.env.GCS_REGISTRATION_SLUG || ''
    const gcsAccessToken = process.env.GCS_ACCESS_TOKEN || ''
    const gcsCampaignID = process.env.GCS_CAMPAIGN_ID || 175
    const [gcsSuccess, setGcsSuccess] = useState(false)    
    const [checkedValue, setCheckedValue] = useState(false)
    const [checkedStatus, setCheckedStatus] = useState(false)

    const gcsCampaignURL = `${campaignBaseURL}${getCampaignSlug}?campaignId=${gcsCampaignID}&locale=${locale}`
    const gcsCampaignRegistration = campaignBaseURL + postRegistrationSlug

    const [emailAddressStatus, setEmailAddressStatus] = useState(false)
    const [existEmailLimit, setExistEmailLimit] = useState(false)

    const validateEmail = (email) => {
        return String(email)
            .toLowerCase()
            .match(
                /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            )
    }

    let handleOnChange = (e) =>{
        e.preventDefault()
        if(validateEmail(e.target.value)) {
            setEmailAddress(e.target.value)  
            setEmailAddressStatus(false)         
        } else {
            setEmailAddress(e.target.value)            
        }
    }

    let handleOnChecked = () => {
        if(checkedValue) {
            setCheckedValue(false)
        } else {
            setCheckedValue(true)
            setCheckedStatus(false)
        }
    }

    function closeModal() {
        setGcsSuccess(false)
    }

    useEffect(() => {
        fetch(gcsCampaignURL, {
            headers: {
                "access_token": gcsAccessToken
            } })
            .then(async (response) => {
                if (response.status === 201 || response.status === 200) {
                    let responseData = await response.json()
                    let optIns = responseData?.optIns && responseData.optIns.shift()
                    setOptin(optIns?.optInId)
                }                
            })
    }, [])    

    function validationCheck() {
        let status = ''
        status = validationEmail()
        if(checkedValue) {
            setCheckedStatus(false)
            status = true
        } else {
            setCheckedStatus(true)
            status = false
        }
        return status        
    }

    function validationEmail() {
        let status = ""
        if(emailAddress !== "" && validateEmail(emailAddress)) {
            setEmailAddressStatus(false)            
            status =  true
        } else {
            setEmailAddressStatus(true)            
            status = false
        }
        return status
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        setExistEmailLimit(false)
        if(validationCheck()) {
            if(validationEmail()) {
                let messageRequestBody = {
                    "campaign": {
                        "campaignId": parseInt(gcsCampaignID),
                        "locale": locale
                    },
                    "consumer": {
                        "emailAddress": emailAddress
                    },
                    "order": {
                        "optIns": `${Optin}:1`
                    }
                }
                fetch(gcsCampaignRegistration, {
                    method: 'POST',
                    headers: {
                        "Content-Type": "application/json",
                        "access_token": gcsAccessToken
                    },
                    body: JSON.stringify(messageRequestBody)
                })
                    .then(async (response) => {
                        if (response.status === 201 || response.status === 200) {
                            let responseData = await response.json()
                            if(responseData.code === "SUCCESS") {
                                setGcsSuccess(true)
                                setEmailAddress("")
                                setCheckedValue("")
                            }
                        } else {
                            let responseData = await response.json()
                            if(responseData.error.code === "EXCEED_EMAIL_LIMIT") {
                                setExistEmailLimit(true)                    
                            }
                            setGcsSuccess(false)
                        }
                    }).catch(() => {
                        setGcsSuccess(false)
                    })
            }
        }
    }

    return(
        <div className='w-full relative'>
            {backgroundAsset && (
                <Image
                    desktopClassName='dt imgContainer hidden mdl:block signIn'
                    smartphoneClassName= {locale == locales.french ? 'sp imgContainer fr-emailsign-banner mdl:hidden sm:h-60':'sp imgContainer emailsign-banner mdl:hidden sm:h-54'}
                    wrapperClassName='imgWrapper'
                    desktopImage={backgroundAsset.desktopImage}
                    smartphoneImage={backgroundAsset.smartphoneImage}
                    alt={backgroundAsset.altText}
                />
            )}
            <form  onSubmit={handleSubmit} noValidate>
                <div className='absolute left-150 mdl:w-full sm:left-0 mdl:top-15 lg:w-full md:top-110 sm:top-10 text-white sm:px-15'>
                    <Typography content={title} className='title mx-auto mdl:w-full sm:text-center mdl:text-center sm:text-36 text-28 mdl:text-50 mdl:leading-50 font-neutrafaceDemi text-white w-full mb-40 pt-40 mdl:mb-45' />
                    <Typography content={subTitle} className='subTitle mx-auto mdl:w-50p sm:text-center mdl:text-center sm:text-22  mdl:text-2xl mdl:leading-50 font-neutrafaceDemi text-white w-full mb-40 mdl:mb-45' />
                    <div className='w-50p sm:w-full mx-auto text-center'>                    
                        <div>
                            <span className='lg:pr-30 sm:text-25 md:mr-20 '>{label}</span>
                            <input
                                className='w-300 h-38'
                                type='email'
                                name='email'
                                style={{ color:"black" }}
                                value={emailAddress}
                                onChange={(e) => handleOnChange(e)}
                            />
                        </div>
                        {emailAddressStatus && <p className={ locale == locales.french ? 'lg:ml-200 md:ml-110 text-red-600' :'lg:ml-140 md:ml-110 text-red-600'}>{validationText1}</p>}
                        <div className='flex mt-10 md:justify-center md:items-center lg:items-center mdl:justify-center'>
                            <input
                                type='checkbox'
                                className={locale==locales.french ? "lg:relative lg:top-10 lg:m-0 md:mb-28 mdl:mb-0 sm:mt-13" :"lg:relative lg:top-10 md:mb-3  lg:m-0 sm:mt-13"}
                                checked={checkedValue}
                                value={checkedValue}
                                onChange={() => handleOnChecked()}
                            />
                            <span className='ml-5 lg:mt-25 sm:mt-10' dangerouslySetInnerHTML={{ __html: emailOptionText }} />
                        </div>
                        
                        {checkedStatus && <p className='lg:text-center text-red-600'>{validationText2}</p>}
                    
                    </div>
                    <div className='w-50p sm:w-full text-base mx-auto leading-30 text-center mt-30' dangerouslySetInnerHTML={{ __html: termsPrivacyPolicy }}/>
                    <div className='w-50p flex mx-auto'>
                        <button type='submit'
                            className='px-36 mt-10 py-16 mdl:px-30 lg:mt-30 mdl:py-12 sm:mt-10 mdl:mt-20 text-18 mdl:text-20 leading-18 mdl:leading-20 font-neutrafaceDemi text-gradientDarkBlue bg-white rounded-full inline-block uppercase min-w-184 text-center mx-auto'> 
                            {button}  
                        </button>
                    </div>
                    {existEmailLimit && <p className='text-red-600 text-center mx-10'>{maximumEmailLimit}</p>}
                </div>  
            </form>       
            {gcsSuccess &&  <Modal
                isOpen={gcsSuccess}
                onRequestClose={closeModal}  
                className='pop-up-wrapper'           
            >          
                <button className='float-right' onClick={closeModal}>X</button>
                <p className='text-center mx-20'>{registrationSuccessMessage}</p>
            </Modal>}   
        </div>
    )
    
}

Emailsign.propTypes = {
    title:PropTypes.string,
    subTitle:PropTypes.string,
    label:PropTypes.string,
    emailOptionText:PropTypes.string,
    termsPrivacyPolicy:PropTypes.string,
    button:PropTypes.string,
    validationText1:PropTypes.string,
    validationText2:PropTypes.string,
    backgroundasset:PropTypes.object,
    maximumEmailLimit:PropTypes.string,
    registrationSuccessMessage:PropTypes.string,
    backgroundAsset:PropTypes.object,
    locale:PropTypes.object,
}

export default memo(Emailsign)