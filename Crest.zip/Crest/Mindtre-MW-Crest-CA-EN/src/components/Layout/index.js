import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { adChoiceLabel, labels } from "@constants"

const Header = dynamic(()=>import("@components/Header"))
const Footer = dynamic(()=>import("@components/Footer"))
const Button = dynamic(()=>import("@components/Button"))
const Icon = dynamic(()=>import("@components/Icon"))

const Layout = ({ children, headerData, footerData }) => (
    <>
        <Button className='sr-only focus:not-sr-only' href='#main'>Skip to Content</Button>
        <Header {...headerData} />
        <main id='main'>
            {children}
            <div className='fixed right-20 bottom-20 z-100'>
                <div className='border-secondary border rounded-5 z-100 bg-white p-5'>
                    <Button href={labels[headerData?.locale?.toLowerCase()]?.adChoiceURL}>
                        <span className='pr-3'>{adChoiceLabel}</span>
                        <Icon name='AdChoicesIcon' className='h-14 inline-block' />
                    </Button>
                </div>
            </div>
        </main>
        <Footer {...footerData} />
    </>
)

Layout.propTypes = {
    children: PropTypes.node.isRequired,
    headerData: PropTypes.shape({
        locale: PropTypes.string.isRequired,
    }).isRequired,
    footerData: PropTypes.shape({
        locale: PropTypes.string.isRequired,
    }).isRequired,
}

export default memo(Layout)
