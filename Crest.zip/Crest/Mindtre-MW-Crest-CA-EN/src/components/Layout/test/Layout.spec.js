import React from 'react'
import { shallow } from 'enzyme'
import Layout from '../index'
import BreadcrumbSchema from '@components/SEOSchema/BreadcrumbSchema'

describe('Layout component', () => {
    let wrapper
    const props = {
        children: {},
        headerData: {},
        footerData: {},
        breadcrumb: [{
            title: 'toothpaste',
            url: 'solutions/toothpaste'
        }]  ,
        pageType:"",
        slug:""
    }

    it("should render", () => {
        const wrapper = shallow(<Layout {...props} />)
        expect(wrapper).toBeTruthy()
    })
    it('render breadcrumb seo',()=>{
        let props={
        
            breadcrumb: [{
                title: 'abc',
                url: 'aa/bb'
            }]
            ,
        }
        wrapper = shallow(<BreadcrumbSchema {...props} locale={"en-ca"}/>)
        expect(wrapper).toBeTruthy()
    })
    it('should render successfully', () => {
        expect(wrapper).toBeTruthy()
    })
})