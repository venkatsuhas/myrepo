import React from 'react'
import { shallow } from 'enzyme'
import PageMetadata from '@components/PageMetadata'

describe('PageMetadata component', () => {
    let wrapper
    const defaultProps = {
        title: 'Title',
        metaTitle: 'My Page',
        metaDescription: 'My Page Description',
        metaKeywords: 'My Page',
        canonicalUrl: 'Canonical URL',
        openGraphPageTitle: 'Open Graph Title',
        openGraphDescription: 'Open Graph Description',
        openGraphImage: 'Open Graph Image'
    }
    beforeEach(() => {
        wrapper = shallow(<PageMetadata {...defaultProps} />)
    })

    it('should render', () => {
        expect(wrapper).toBeTruthy()
    })

})
