import React, { memo } from 'react'
import PropTypes from 'prop-types'
import Head from 'next/head'

const PageMetadata = ({
    title,
    metaTitle,
    metaKeywords,
    metaDescription,
    canonicalUrl,
    openGraphPageTitle,
    openGraphDescription,
    openGraphImage
}) => (
    <Head>
        {title && <title>{title}</title>}
        {metaTitle && <meta name='title' content={metaTitle} />}
        {metaDescription && <meta name='description' content={metaDescription} />}
        {metaKeywords && <meta name='keywords' content={metaKeywords} />}
        {openGraphImage && <meta name='image' content={openGraphImage} />}
        {openGraphPageTitle && <meta property='og:title' content={openGraphPageTitle} />}
        {openGraphDescription && (
            <meta property='og:description' content={openGraphDescription} />
        )}
        {openGraphImage && <meta property='og:image' content={openGraphImage} />}
        {canonicalUrl && <link rel='canonical' href={process.env.DOMAIN + canonicalUrl} />}
    </Head>
)
PageMetadata.propTypes = {
    title: PropTypes.string.isRequired,
    metaTitle: PropTypes.string,
    metaDescription: PropTypes.string,
    metaKeywords: PropTypes.string,
    openGraphPageTitle: PropTypes.string,
    openGraphDescription: PropTypes.string,
    openGraphImage: PropTypes.string,
    canonicalUrl: PropTypes.string.isRequired,
}

PageMetadata.defaultProps = {
    metaTitle: '',
    metaDescription: '',
    metaKeywords: '',
    openGraphPageTitle: '',
    openGraphDescription: '',
    openGraphImage: '',
}

export default memo(PageMetadata)
