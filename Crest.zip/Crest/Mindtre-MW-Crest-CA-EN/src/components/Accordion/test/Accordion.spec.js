import React from "react"
import { shallow } from "enzyme"
import Accordion from '@components/Accordion'

describe('Accordion Component', ()=>{
    it('Should render Accordion component with open as false',()=>{
        const props={ 
            title: 'Title',
            open: false,
            toggleOpen: jest.fn() 
        }
        const wrapper=shallow(<Accordion {...props}>Hi</Accordion>)
        expect(wrapper).toBeTruthy()
    })

    it('Should render Accordion component with open as true',()=>{
        const props={ 
            title: 'Title',
            open: true,
            toggleOpen: jest.fn() 
        }
        const wrapper=shallow(<Accordion {...props}>Hi</Accordion>)
        expect(wrapper).toBeTruthy()
    })
})
