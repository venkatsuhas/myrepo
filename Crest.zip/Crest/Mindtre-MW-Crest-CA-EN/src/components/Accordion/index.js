import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import styles from "@components/Accordion/Accordion.tw-style"

const Button = dynamic(() => import("@components/Button"))
const Icon = dynamic(() => import("@components/Icon"))

const Accordion = ({ title, children: body, open, toggleOpen, variant }) => {
    const style = styles[variant]
    return (
        <div className={style.wrapper}>
            <Button className={`${style.titleWrapper} ${open ? 'openAccor' : 'closeAccor'} `} gaClass='event_button_click' gaLabel={title} component='div' onClick={toggleOpen} role='button' onKeyPress={toggleOpen}>
                <div className={style.title}>{title}</div>
                <Icon className='arwIcon icon w-20' name={open ? style.openStateArrow : style.closeStateArrow} />
            </Button>
            <div className={open ? style.childOpen : style.childClose}>{body}</div>
        </div>
    )
}

Accordion.propTypes = {
    title: PropTypes.string.isRequired,
    children: PropTypes.node.isRequired,
    open: PropTypes.bool.isRequired,
    toggleOpen: PropTypes.func.isRequired,
    variant: PropTypes.string,
}

Accordion.defaultProps = {
    variant: "default",
}

export default memo(Accordion)
