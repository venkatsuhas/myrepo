import React, { useState as useStateMock, useEffect as useEffectMock } from 'react'
import { shallow } from 'enzyme'
import Review from '@components/Review'
import { getReviews as getReviewsMock } from '@adapters/bazaarvoice'

jest.mock('@adapters/bazaarvoice', () => ({
    ...jest.requireActual("@adapters/bazaarvoice"),
    getReviews: jest.fn(),
}))

jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useEffect: jest.fn(),
}))

describe('Review component', () => {
    let wrapper
    
    it('should render Review component for en-ca', () => {
        const props = {
            locale:'en-ca',
            productId:'1234'
        }
        getReviewsMock.mockImplementation(()=>{
            return Promise.resolve({ results: [{ id: 4 },{ id: 5 },{ id: 6 }], total: 8 })
        })
        const mockState = {
            reviews: [{ id:1 },{ id:2 },{
                id: 3,
                response:{}
            }],
            limit: 3,
            totalReviews: 8,
            sortOption: 'abc',
            fetchData: true
        }
        useStateMock.mockImplementation(() => [mockState,jest.fn().mockImplementation((callback)=>{
            if(typeof callback === 'function')
                callback(mockState)
            else
                return {}
        })])
        useEffectMock.mockImplementation(async (func) => {
            await func()
        })
        wrapper = shallow(<Review {...props} />)
        expect(wrapper).toBeTruthy()
        wrapper.find('[gaClass="event_view_more_details"]').prop('onClick')()
        wrapper.find('[onSelect]').prop('onSelect')("ascending")
    })

    it('should render Review component for en-ca', () => {
        const props = {
            locale:'en-ca',
            productId:'1234'
        }
        getReviewsMock.mockImplementation(()=>{
            return Promise.resolve({})
        })
        const mockState = {
            reviews: [{ id:1 },{ id:2 },{
                id: 3,
                response:{}
            }],
            limit: 3,
            totalReviews: 8,
            sortOption: 'abc',
            fetchData: true
        }
        useStateMock.mockImplementation(() => [mockState,jest.fn().mockImplementation((callback)=>{
            if(typeof callback === 'function')
                callback(mockState)
            else
                return {}
        })])
        useEffectMock.mockImplementation(async (func) => {
            await func()
        })
        wrapper = shallow(<Review {...props} />)
        expect(wrapper).toBeTruthy()
        wrapper.find('[gaClass="event_view_more_details"]').prop('onClick')()
        wrapper.find('[onSelect]').prop('onSelect')("ascending")
    })

    it('should render Review component for en-ca', () => {
        const props = {
            locale:'en-ca',
            productId:'1234'
        }
        getReviewsMock.mockImplementation(()=>{
            return Promise.resolve({ results: [{ id: 4 },{ id: 5 },{ id: 6 }], total: 8 })
        })
        const mockState = {
            reviews: [{ id:1 },{ id:2 },{
                id: 3,
                response:{}
            }],
            limit: 3,
            totalReviews: 8,
            sortOption: 'abc',
            fetchData: false
        }
        useStateMock.mockImplementation(() => [mockState,jest.fn().mockImplementation((callback)=>{
            if(typeof callback === 'function')
                callback()
        })])
        useEffectMock.mockImplementation(async (func) => {
            await func()
        })
        wrapper = shallow(<Review {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it('should render Review component for en-ca with App Insights', () => {
        const props = {
            locale:'en-ca',
            productId:'1234'
        }
        getReviewsMock.mockImplementation(()=>new Promise((resolve, reject)=>reject(true)))
        const mockState = {
            reviews: [],
            limit: 3,
            totalReviews: 0,
            sortOption: 'abc',
            fetchData: true
        }
        window.appInsights = { 
            trackException: jest.fn()
        }
        useStateMock.mockImplementation(() => [mockState,jest.fn()])
        useEffectMock.mockImplementation((func) => func())
        wrapper = shallow(<Review {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it('should render Review component for en-ca without App Insights', () => {
        const props = {
            locale:'en-ca',
            productId:'1234'
        }
        getReviewsMock.mockImplementation(()=>new Promise((resolve, reject)=>reject(true)))
        const mockState = {
            reviews: [],
            limit: 3,
            totalReviews: 0,
            sortOption: 'abc',
            fetchData: true
        }
        window.appInsights = null
        useStateMock.mockImplementation(() => [mockState,jest.fn()])
        useEffectMock.mockImplementation((func) => func())
        wrapper = shallow(<Review {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it('should render Review component for en-us', () => {
        const props = {
            locale:'en-us',
            productId:'1234'
        }
        wrapper = shallow(<Review {...props} />)
        expect(wrapper).toBeTruthy()
    })
})