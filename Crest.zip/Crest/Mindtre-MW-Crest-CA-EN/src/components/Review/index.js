import React, { useState, useEffect, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { getReviews } from '@adapters/bazaarvoice'
import { labels as allLabels } from '@constants'

const Button = dynamic(()=>import('@components/Button'))
const DropDown = dynamic(()=>import('@components/DropDown'))
const Rating = dynamic(()=>import('@components/Rating'))

const Review = ({ locale, productId }) => {
    const labels = allLabels[locale.toLowerCase()]?.productPage || {}
    const sortOptions = allLabels[locale.toLowerCase()]?.sortOptions || {}
    const [state, setState] = useState({
        reviews: [],
        limit: 3,
        totalReviews: 0,
        sortOption: sortOptions[0]?.value,
        fetchData: true
    })
    
    const fetchMoreData = () => {
        getReviews({ productId, limit: state.limit, locale, offset: state.reviews.length, sortFilterValue: state.sortOption }).then((response)=>{
            setState((prevState)=>({ ...prevState, fetchData: false, reviews: [...prevState.reviews, ...(response?.results||[])], totalReviews: response?.total||0 }))
        }).catch((error)=>{
            if(typeof window !== 'undefined' && window.appInsights){
                window.appInsights.trackException({ exception: error })
            }
        })
    }

    const setFetchData = ()=>setState((prevState)=>({ ...prevState, fetchData: true }))

    const updateSort = (value)=>{
        setState(prevState=>({ ...prevState, fetchData: true, reviews: [], sortOption: value  }))
    }

    useEffect(() => {
        if(state.fetchData){
            fetchMoreData()
        }
    }, [state.fetchData])

    return (
        <div className='w-full'>
            <div className='flex flex-row items-center'>
                <p className='font-neutrafaceBook text-22 leading-30 text-left text-secondary pr-10'>{labels?.sortByLabel}</p>
                <DropDown defaultValue={sortOptions[0]?.title} onSelect={updateSort} options={sortOptions} 
                    variant='plainDropdown'
                />
            </div>
            <div className='w-full pt-10'>
                {state.reviews.length> 0 && state.reviews.map((review)=>(
                    <div key={review?.id}  className='w-full py-40 mdl:py-50 border-lightestBorder first:border-t-0 border-t'>
                        <div className='w-full flex flex-wrap justify-between items-start flex-col mdl:flex-row'>
                            <div className='w-full mdl:w-4/12 flex flex-row mdl:flex-col justify-between items-start mb-30 mdl:mb-0'>
                                <div className='font-neutrafaceBook text-18 leading-24 text-left text-primary mdl:mb-15'>{review?.name}</div>
                                <div className='font-neutrafaceBook text-18 leading-24 text-left text-secondary'>{labels.daysLabel.replace('$noDays',review?.time)}</div>
                            </div>
                            <div className='w-full mdl:w-8/12'>
                                <Rating className='w-full' svgClassName='w-18 mr-3' productId={productId} constant={review.id} ratingValue={review?.rating} />
                                <div className='w-full my-25 font-neutrafaceDemi text-20 leading-24 text-left text-primary'>{review.title}</div>
                                <div className='w-full font-neutrafaceBook text-18 leading-24 text-left text-secondary'>{review.review}</div>
                            </div>
                        </div>
                        {review.response && (
                            <div className='w-full mt-40 mdl:mt-60 pl-20 mdl:pl-40'>
                                <div  className='w-full font-neutrafaceDemi text-18 leading-24 text-left text-accentDark'>{`Response from crest-en_us:`}</div>
                                <div  className='w-full font-neutrafaceDemi text-20 leading-24 text-left text-primary'>{review.response.name}<span className='pl-30 font-neutrafaceBook text-18 leading-24 text-left text-secondary'>{`${review.response?.time}${labels.daysLabel}`}</span></div>
                                <div  className='w-full font-neutrafaceBook text-18 leading-24 text-left text-secondary'>{review.response.response}</div>
                            </div>
                        )}
                    </div>
                ))}
            </div>
            {state.reviews.length < state.totalReviews ? <Button gaClass='event_view_more_details' onClick={setFetchData} className='w-max mx-auto block text-center font-neutrafaceDemi text-20 leading-26 text-gradientDarkBlue mb-80 underline cursor-pointer'>{labels.moreReviewsLabel}</Button> : null }
        </div>
    )
}

Review.propTypes = {
    locale: PropTypes.string.isRequired,
    productId: PropTypes.string.isRequired,
}

export default memo(Review)
