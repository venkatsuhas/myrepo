import React, { useState, useMemo, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { svgNameSpace } from '@constants'

const Button = dynamic(()=>import('@components/Button'))

const RatingButton = ({ variant, updateValue, value }) => {
    const buttons = useMemo(()=>Array(5)
        .fill(1)
        .map((element, index) => index + element),[])

    const [state, setState] = useState({ hover: 0, selected: value })
    return (
        <div className='flex'>
            {buttons.map(item => (
                <Button
                    key={item}
                    onClick={() => {
                        setState({ ...state, selected: item })
                        updateValue(item)
                    }}
                    onMouseOver={() => setState({ ...state, hover: item })}
                    onFocus={() => setState({ ...state, hover: item })}
                    onMouseOut={() => setState({ ...state, hover: 0 })}
                    onBlur={() => setState({ ...state, hover: 0 })}
                >
                    {(variant === "star") && (
                        <svg className='w-35 h-35 mr-14' xmlns={svgNameSpace} viewBox='0 0 30.094 28.804'>
                            <path
                                d='M14.874,1,11.2,8.449l-8.218,1.2a1.8,1.8,0,0,0-1,3.071l5.946,5.794L6.526,26.7a1.8,1.8,0,0,0,2.61,1.9l7.352-3.864,7.352,3.864a1.8,1.8,0,0,0,2.61-1.9l-1.406-8.185,5.946-5.794a1.8,1.8,0,0,0-1-3.071l-8.218-1.2L18.1,1a1.8,1.8,0,0,0-3.229,0Z'
                                transform='translate(-1.441 0.001)'
                                fill={
                                    state.hover >= item ||
                                    state.selected >= item
                                        ? "#0c457c"
                                        : "#c8d8f4"
                                }
                            />
                        </svg>
                    )}
                    {(variant === "button") &&(
                        <span className={`font-neutrafaceBook text-30 leading-30 text-center border-lightGreyBlue w-40 h-40 mr-10 flex justify-center items-center ${
                            state.hover >= item ||
                            state.selected >= item
                                ? "bg-accentDark text-white border-0"
                                : "bg-transparent border text-primary"
                        }`}>{item}</span>
                    )}
                </Button>
            ))}
        </div>
    )
}

RatingButton.propTypes = {
    variant: PropTypes.oneOf(['star','button']).isRequired,
    updateValue: PropTypes.func.isRequired,
    value: PropTypes.number.isRequired
}

export default memo(RatingButton)
