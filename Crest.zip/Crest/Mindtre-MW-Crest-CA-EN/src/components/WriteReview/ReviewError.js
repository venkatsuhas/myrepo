import React, { memo, useCallback } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { labels as allLabels } from "@constants/writeAReview"

const Button = dynamic(()=>import("@components/Button"))

const ReviewError = ({ onReviewErrorClose, locale, ageError }) => {
    const labels = allLabels[locale.toLowerCase()]
    
    const closeClick = useCallback(() => {
        onReviewErrorClose()
    },[onReviewErrorClose])

    return (
        <div className='w-full h-screen fixed top-0 left-0 flex flex-wrap flex-row justify-center items-center bg-black bg-opacity-80 z-100'>
            <div className='bg-white py-50 px-20 w-full mdl:w-1/2 relative'>
                <div className='w-full text-center'>
                    <span className='font-neutrafaceBold text-22 leading-24 text-primary w-full'>
                        {ageError?'':labels.reviewSorry}
                    </span>
                    <Button
                        className='absolute top-0 right-20'
                        onClick={closeClick}
                    >
                        <span className='closespan font-neutrafaceBook text-secondary text-50 leading-tight'>{`×`}</span>
                    </Button>
                </div>

                <div className='w-full text-center mt-15'>
                    <p className='font-neutrafaceBook text-18 leading-24 text-secondary'>
                        {ageError?labels.ageError:labels.reviewSorryContent}
                    </p>
                    <div className='w-full text-center mt-30'>
                        <Button
                            data-pgaction-redirection='0'
                            className='btn btn-plain font-neutrafaceDemi text-18 leading-24 text-accent uppercase rounded-full px-80 border border-accentBorder pt-19 pb-15 block w-max mx-auto'
                            onClick={closeClick}
                        >
                            {labels.reviewContinueButton}
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    )
}

ReviewError.propTypes = {
    onReviewErrorClose: PropTypes.func.isRequired,
    locale: PropTypes.string.isRequired,
    ageError: PropTypes.bool.isRequired,
}

export default memo(ReviewError)
