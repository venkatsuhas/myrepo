import React, { useEffect as useEffectMock } from 'react'
import { shallow } from 'enzyme'
import WriteReviewForm from '../WriteReviewForm'
import reducerMock from '@components/WriteReview/WriteReview.reducer'
import { labels as allLabels } from "@constants/writeAReview"
import { getPreview as getPreviewMock, submitReviews as submitReviewsMock } from "@adapters/bazaarvoice"

jest.mock('@components/WriteReview/WriteReview.reducer', () => ({
    __esModule: true,
    default: jest.fn(),
    ACTIONS: {}
}))

jest.mock('@adapters/bazaarvoice', () => ({
    __esModule: true,
    getPreview: jest.fn(),
    submitReviews: jest.fn()
}))

jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useEffect: jest.fn(),
}))

jest.mock("next/router", () => ({
    ...jest.requireActual("next/router"),
    useRouter: jest.fn().mockImplementation(()=>({ asPath: "/en-ca/oral-care-products/product/writereview", replace: jest.fn() })),
}))

describe('WriteReviewForm component', () => {
    let wrapper
    
    it('should render WriteReviewForm component with no errors', () => {
        let props = {
            locale:'en-ca',
            bazaarVoiceId:'1234'
        }
        const label = allLabels['en-ca']
        const mockState = {
            overallRating: 0,
            overallRatingError: null,
            valueRating: 0,
            qualityRating: 0,
            recommendProduct: label.reviewNo,
            recommendProductError: null,
            reviewTitle: null,
            reviewTitleError: null,
            reviewBody: null,
            reviewBodyError: null,
            nickname: null,
            nicknameError: null,
            nicknameTaken: null,
            dobMonth: 0,
            dobMonthError: null,
            dobYear: 0,
            dobYearError: null,
            email: null,
            emailError: null,
            location: null,
            locationError: null,
            termsAndCondition: false,
            termsAndConditionError: null,
            anyError: null,
            canPreview: true,
            setSubmit: false,
            ageError: false,
            thankyou:false,
            sorry:false,
            serverError: false,
            success: false,
            failure: false
        }
        reducerMock.mockImplementation(()=>({ state: mockState, dispatch: jest.fn() }))
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function')
                output()
        })
        
        getPreviewMock.mockImplementation(()=>new Promise((resolve)=>resolve(true)))
        submitReviewsMock.mockImplementation(()=>new Promise((resolve)=>resolve(true)))
        wrapper = shallow(<WriteReviewForm {...props} />)
        expect(wrapper).toBeTruthy()
        wrapper.find('#tAndC').prop('onBlur')({ target: { value: '' } })
        wrapper.find('[variant="star"]').prop('updateValue')()
        wrapper.find('[variant="button"]').forEach((button)=>{
            button.prop('updateValue')()
        })
        wrapper.find('[type="text"]').forEach((textField)=>{
            textField.prop('onBlur')({ target: { value: '' } })
        })
        wrapper.find('[variant="WriteAReviewMonthDP"]').forEach((dropDown)=>{
            dropDown.prop('onSelect')()
        })
        wrapper.find('[onClick]').forEach((buttonComp)=>{
            buttonComp.prop('onClick')()
        })
    })

    it('should render WriteReviewForm component with no errors and submit error', () => {
        let props = {
            locale:'en-ca',
            bazaarVoiceId:'1234'
        }
        const label = allLabels['en-ca']
        const mockState = {
            overallRating: 0,
            overallRatingError: null,
            valueRating: 0,
            qualityRating: 0,
            recommendProduct: label.reviewNo,
            recommendProductError: null,
            reviewTitle: null,
            reviewTitleError: null,
            reviewBody: null,
            reviewBodyError: null,
            nickname: null,
            nicknameError: null,
            nicknameTaken: null,
            dobMonth: 0,
            dobMonthError: null,
            dobYear: 0,
            dobYearError: null,
            email: null,
            emailError: null,
            location: null,
            locationError: null,
            termsAndCondition: false,
            termsAndConditionError: null,
            anyError: null,
            canPreview: true,
            setSubmit: false,
            ageError: false,
            thankyou:false,
            sorry:false,
            serverError: false,
            success: false,
            failure: false
        }
        reducerMock.mockImplementation(()=>({ state: mockState, dispatch: jest.fn() }))
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function')
                output()
        })
        
        getPreviewMock.mockImplementation(()=>new Promise((resolve,reject)=>reject(true)))
        submitReviewsMock.mockImplementation(()=>new Promise((resolve,reject)=>reject(true)))
        wrapper = shallow(<WriteReviewForm {...props} />)
        expect(wrapper).toBeTruthy()
        wrapper.find('#tAndC').prop('onBlur')({ target: { value: '' } })
        wrapper.find('[variant="star"]').prop('updateValue')()
        wrapper.find('[variant="button"]').forEach((button)=>{
            button.prop('updateValue')()
        })
        wrapper.find('[type="text"]').forEach((textField)=>{
            textField.prop('onBlur')({ target: { value: '' } })
        })
        wrapper.find('[variant="WriteAReviewMonthDP"]').forEach((dropDown)=>{
            dropDown.prop('onSelect')()
        })
        wrapper.find('[onClick]').forEach((buttonComp)=>{
            buttonComp.prop('onClick')()
        })
    })

    it('should render WriteReviewForm component with no errors', () => {
        let props = {
            locale:'en-ca',
            bazaarVoiceId:'1234'
        }
        const label = allLabels['en-ca']
        const mockState = {
            overallRating: 0,
            overallRatingError: null,
            valueRating: 0,
            qualityRating: 0,
            recommendProduct: label.reviewYes,
            recommendProductError: null,
            reviewTitle: null,
            reviewTitleError: null,
            reviewBody: null,
            reviewBodyError: null,
            nickname: null,
            nicknameError: null,
            nicknameTaken: null,
            dobMonth: 0,
            dobMonthError: null,
            dobYear: 0,
            dobYearError: null,
            email: null,
            emailError: null,
            location: null,
            locationError: null,
            termsAndCondition: false,
            termsAndConditionError: null,
            anyError: null,
            canPreview: true,
            setSubmit: false,
            ageError: false,
            thankyou:false,
            sorry:false,
            serverError: false,
            success: false,
            failure: false
        }
        reducerMock.mockImplementation(()=>({ state: mockState, dispatch: jest.fn() }))
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function')
                output()
        })
        getPreviewMock.mockImplementation(()=>new Promise((resolve)=>resolve(true)))
        submitReviewsMock.mockImplementation(()=>new Promise((resolve)=>resolve(true)))
        wrapper = shallow(<WriteReviewForm {...props} />)
        expect(wrapper).toBeTruthy()
    })
    
    it('should render WriteReviewForm component with all validation errors', () => {
        let props = {
            locale:'en-ca',
            bazaarVoiceId:'1234'
        }
        const mockState = {
            overallRating: 0,
            overallRatingError: true,
            valueRating: 0,
            qualityRating: 0,
            recommendProduct: null,
            recommendProductError: true,
            reviewTitle: null,
            reviewTitleError: true,
            reviewBody: null,
            reviewBodyError: true,
            nickname: null,
            nicknameError: true,
            nicknameTaken: true,
            dobMonth: 0,
            dobMonthError: true,
            dobYear: 0,
            dobYearError: true,
            email: null,
            emailError: true,
            location: null,
            locationError: true,
            termsAndCondition: false,
            termsAndConditionError: true,
            anyError: true,
            canPreview: false,
            setSubmit: false,
            ageError: false,
            thankyou:false,
            sorry:false,
            serverError: false,
            success: false,
            failure: false
        }
        reducerMock.mockImplementation(()=>({ state: mockState, dispatch: jest.fn() }))
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function')
                output()
        })
        document.body.classList.add('overflow-hidden')
        wrapper = shallow(<WriteReviewForm {...props} />)
        expect(wrapper).toBeTruthy()
    })
    
    it('should render WriteReviewForm component with Thank You Screen', () => {
        let props = {
            locale:'en-ca',
            bazaarVoiceId:'1234'
        }
        const label = allLabels['en-ca']
        const mockState = {
            overallRating: 0,
            overallRatingError: null,
            valueRating: 0,
            qualityRating: 0,
            recommendProduct: label.reviewNo,
            recommendProductError: null,
            reviewTitle: null,
            reviewTitleError: null,
            reviewBody: null,
            reviewBodyError: null,
            nickname: null,
            nicknameError: null,
            nicknameTaken: null,
            dobMonth: 1,
            dobMonthError: null,
            dobYear: 2020,
            dobYearError: null,
            email: null,
            emailError: null,
            location: null,
            locationError: null,
            termsAndCondition: false,
            termsAndConditionError: null,
            anyError: null,
            canPreview: true,
            setSubmit: false,
            ageError: false,
            thankyou:true,
            sorry:false,
            serverError: false,
            success: false,
            failure: false
        }
        reducerMock.mockImplementation(()=>({ state: mockState, dispatch: jest.fn() }))
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function')
                output()
        })
        wrapper = shallow(<WriteReviewForm {...props} />)
        expect(wrapper).toBeTruthy()
    })
    
    it('should render WriteReviewForm component with Error Screen', () => {
        let props = {
            locale:'en-ca',
            bazaarVoiceId:'1234'
        }
        const mockState = {
            overallRating: 0,
            overallRatingError: true,
            valueRating: 0,
            qualityRating: 0,
            recommendProduct: null,
            recommendProductError: true,
            reviewTitle: null,
            reviewTitleError: true,
            reviewBody: null,
            reviewBodyError: true,
            nickname: null,
            nicknameError: true,
            nicknameTaken: true,
            dobMonth: 0,
            dobMonthError: true,
            dobYear: 0,
            dobYearError: true,
            email: null,
            emailError: true,
            location: null,
            locationError: true,
            termsAndCondition: false,
            termsAndConditionError: true,
            anyError: true,
            canPreview: false,
            setSubmit: false,
            ageError: false,
            thankyou:false,
            sorry:true,
            serverError: false,
            success: false,
            failure: false
        }
        reducerMock.mockImplementation(()=>({ state: mockState, dispatch: jest.fn() }))
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function')
                output()
        })
        wrapper = shallow(<WriteReviewForm {...props} />)
        expect(wrapper).toBeTruthy()
        wrapper.find('[onReviewErrorClose]').prop('onReviewErrorClose')()
    })
    
    it('should render WriteReviewForm component with Age Error Screen', () => {
        let props = {
            locale:'en-ca',
            bazaarVoiceId:'1234'
        }
        const mockState = {
            overallRating: 0,
            overallRatingError: true,
            valueRating: 0,
            qualityRating: 0,
            recommendProduct: null,
            recommendProductError: true,
            reviewTitle: null,
            reviewTitleError: true,
            reviewBody: null,
            reviewBodyError: true,
            nickname: null,
            nicknameError: true,
            nicknameTaken: true,
            dobMonth: 0,
            dobMonthError: true,
            dobYear: 0,
            dobYearError: true,
            email: null,
            emailError: true,
            location: null,
            locationError: true,
            termsAndCondition: false,
            termsAndConditionError: true,
            anyError: true,
            canPreview: false,
            setSubmit: false,
            ageError: true,
            thankyou:false,
            sorry:false,
            serverError: false,
            success: false,
            failure: false
        }
        reducerMock.mockImplementation(()=>({ state: mockState, dispatch: jest.fn() }))
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function')
                output()
        })
        wrapper = shallow(<WriteReviewForm {...props} />)
        expect(wrapper).toBeTruthy()
        wrapper.find('[onReviewErrorClose]').prop('onReviewErrorClose')()
    })
    
    it('should render WriteReviewForm component with Age Error from Local Storage', () => {
        let props = {
            locale:'en-ca',
            bazaarVoiceId:'1234'
        }
        const mockState = {
            overallRating: 0,
            overallRatingError: true,
            valueRating: 0,
            qualityRating: 0,
            recommendProduct: null,
            recommendProductError: true,
            reviewTitle: null,
            reviewTitleError: true,
            reviewBody: null,
            reviewBodyError: true,
            nickname: null,
            nicknameError: true,
            nicknameTaken: true,
            dobMonth: 0,
            dobMonthError: true,
            dobYear: 0,
            dobYearError: true,
            email: null,
            emailError: true,
            location: null,
            locationError: true,
            termsAndCondition: false,
            termsAndConditionError: true,
            anyError: false,
            canPreview: true,
            setSubmit: false,
            ageError: true,
            thankyou:false,
            sorry:false,
            serverError: false,
            success: false,
            failure: false
        }
        const today = new Date()
        const tomorrow = new Date(today)
        tomorrow.setDate(tomorrow.getDate() + 1)
        window.localStorage.setItem(
            "WRITE_REVIEW_AGE_RESTRICTION",
            JSON.stringify({ time: tomorrow })
        )
        reducerMock.mockImplementation(()=>({ state: mockState, dispatch: jest.fn() }))
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function')
                output()
        })
        wrapper = shallow(<WriteReviewForm {...props} />)
        expect(wrapper).toBeTruthy()
        wrapper.find('[onReviewErrorClose]').prop('onReviewErrorClose')()
    })
})