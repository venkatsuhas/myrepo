import React from 'react'
import { shallow } from 'enzyme'

import ReviewError from '../ReviewError'

describe('ReviewProduct component', () => {
    let wrapper

    it('should render for Age Error', () => {
        let props = {
            locale:"en-ca",
            ageError:true,
            onReviewErrorClose:jest.fn()
        }
        wrapper = shallow(<ReviewError {...props} />)
        expect(wrapper).toBeTruthy()
        wrapper.find('.btn').prop('onClick')()
    })
    
    it('should render for Other Errors', () => {
        let props = {
            locale:"en-ca",
            ageError:false,
            onReviewErrorClose:jest.fn()
        }
        wrapper = shallow(<ReviewError {...props} />)
        expect(wrapper).toBeTruthy()
    })
})