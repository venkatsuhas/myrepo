import React from 'react'
import { shallow } from 'enzyme'

import ReviewProduct from '../ReviewProduct'
describe('ReviewProduct component', () => {
    let wrapper
    let props = {
        heroImage: {
            altText: 'qwer',
            urel: '/abc' 
        },
        productName:'test'
    }
    beforeEach(() => {
        wrapper = shallow(<ReviewProduct {...props} />)
    })
    it('should render', () => {
        expect(wrapper).toBeTruthy()
    })
})