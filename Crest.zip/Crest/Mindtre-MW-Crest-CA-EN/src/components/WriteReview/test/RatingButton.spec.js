import React from 'react'
import { shallow } from 'enzyme'

import RatingButton from '../RatingButton'
describe('RatingButton component', () => {
    let wrapper

    it('should render RatingButton for star variant', () => {
        let props = {
            value:0,
            variant:'star',
            updateValue: jest.fn()
        }
        wrapper = shallow(<RatingButton {...props} />)
        expect(wrapper).toBeTruthy()
        expect(wrapper.find('[onClick]').length).toBe(5)
        const firstButton = wrapper.find('[onClick]').at(0)
        firstButton.prop('onClick')()
        firstButton.prop('onMouseOver')()
        firstButton.prop('onFocus')()
        firstButton.prop('onMouseOut')()
        firstButton.prop('onBlur')()
    })

    it('should render RatingButton for button variant', () => {
        let props = {
            value:0,
            variant:'button'
        }
        wrapper = shallow(<RatingButton {...props} />)
        expect(wrapper).toBeTruthy()
    })
    
    it('should render RatingButton for star variant', () => {
        let props = {
            value:3,
            variant:'star'
        }
        wrapper = shallow(<RatingButton {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it('should render RatingButton for button variant', () => {
        let props = {
            value:3,
            variant:'button'
        }
        wrapper = shallow(<RatingButton {...props} />)
        expect(wrapper).toBeTruthy()
    })
})