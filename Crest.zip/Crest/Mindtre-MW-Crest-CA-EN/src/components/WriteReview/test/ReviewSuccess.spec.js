import React from 'react'
import { shallow } from 'enzyme'

import ReviewSuccess from '../ReviewSuccess'

describe('ReviewProduct component', () => {
    let wrapper

    let props = {
        locale:"en-ca",
        url:"/en-ca/oral-care-tips/toothpaste"
    }

    beforeEach(() => {
        wrapper = shallow(<ReviewSuccess {...props} />)
    })
    it('should render', () => {
        expect(wrapper).toBeTruthy()
    })
})