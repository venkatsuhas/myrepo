import { useReducer } from 'react'

export const ACTIONS = {
    OVERALL_RATING:'OVERALL_RATING',
    VALUE_RATING:'VALUE_RATING',
    QUALITY_RATING:'QUALITY_RATING',
    RECOMMEND_PRODUCT:'RECOMMEND_PRODUCT',
    REVIEW_TITLE:'REVIEW_TITLE',
    REVIEW_BODY:'REVIEW_BODY',
    NICKNAME: 'NICKNAME',
    DOB_MONTH:'DOB_MONTH',
    DOB_YEAR:'DOB_YEAR',
    EMAIL:'EMAIL',
    LOCATION:'LOCATION',
    T_AND_C:'T_AND_C',
    VALIDATE_ALL:'VALIDATE_ALL',
    SET_SUBMIT:'SET_SUBMIT',
    THANK_YOU:'THANK_YOU',
    SET_ERROR:'SET_ERROR',
    SET_PREVIEW:'SET_PREVIEW',
    SET_AGE_RESTRICTION:'SET_AGE_RESTRICTION'
}

const useWriteReviewReducer = () => {
    const initialState = {
        overallRating: 0,
        overallRatingError: null,
        valueRating: 0,
        qualityRating: 0,
        recommendProduct: null,
        recommendProductError: null,
        reviewTitle: null,
        reviewTitleError: null,
        reviewBody: null,
        reviewBodyError: null,
        nickname: null,
        nicknameError: null,
        nicknameTaken: null,
        dobMonth: 0,
        dobMonthError: null,
        dobYear: 0,
        dobYearError: null,
        email: null,
        emailError: null,
        location: null,
        locationError: null,
        termsAndCondition: false,
        termsAndConditionError: null,
        anyError: null,
        canPreview: false,
        setSubmit: false,
        ageError: false,
        thankyou:false,
        sorry:false,
        serverError: false,
        success: false,
        failure: false
    }

    const reducer = (state, action) => {
        let newState = { ...state }
        switch (action.type) {
        case ACTIONS.OVERALL_RATING:
            return { ...state, overallRating: action.value, overallRatingError: null }
        case ACTIONS.VALUE_RATING:
            return { ...state, valueRating: action.value }
        case ACTIONS.QUALITY_RATING:
            return { ...state, qualityRating: action.value }
        case ACTIONS.RECOMMEND_PRODUCT:
            return { ...state, recommendProduct: action.value, recommendProductError: null }
        case ACTIONS.REVIEW_TITLE:
            return { ...state, reviewTitle: action.value, reviewTitleError: action.value === null || !(action.value.length && action.value.length <= 50) }
        case ACTIONS.REVIEW_BODY:
            return { ...state, reviewBody: action.value, reviewBodyError: action.value === null || action.value.length < 50 }
        case ACTIONS.NICKNAME:
            return { ...state, nickname: action.value, nicknameError: action.value === null || !(action.value.length && action.value.match(/^[a-z0-9 ]+$/gi)) }
        case ACTIONS.DOB_MONTH:
            return { ...state, dobMonth: action.value, dobMonthError: null }
        case ACTIONS.DOB_YEAR:
            return { ...state, dobYear: action.value, dobYearError: null }
        case ACTIONS.EMAIL:
            return { ...state, email: action.value, emailError: action.value === null || !(action.value.length && action.value.match(/^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/g)) }
        case ACTIONS.LOCATION:
            return { ...state, location: action.value, locationError: action.value === null || !action.value.length }
        case ACTIONS.T_AND_C:
            return { ...state, termsAndCondition: action.value, termsAndConditionError: !action.value }
        case ACTIONS.THANK_YOU:
            return { ...state, thankyou: action.value }
        case ACTIONS.SET_ERROR:
            return { ...state, sorry: action.value, canPreview: action.value }    
        case ACTIONS.SET_PREVIEW:
            return { ...state, canPreview: action.value }  
        case ACTIONS.SET_AGE_RESTRICTION:
            return { ...state, ageError:action.value }      
        case ACTIONS.VALIDATE_ALL:
            newState = { ...state,
                overallRatingError: state.overallRating === 0,
                recommendProductError: !state.recommendProduct,
                reviewTitleError: state.reviewTitle === null || !(state.reviewTitle.length && state.reviewTitle.length <= 50),
                reviewBodyError: state.reviewBody === null || state.reviewBody.length < 50,
                nicknameError: state.nickname === null || !(state.nickname.length && state.nickname.match(/^[a-z0-9 ]+$/gi)),
                dobMonthError: state.dobMonth === 0,
                dobYearError: state.dobYear === 0,
                emailError: state.email === null ||!(state.email.length && state.email.match(/^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/g)),
                locationError: state.location === null || !state.location.length,
                termsAndConditionAcceptError: !state.termsAndConditionAcceptError
            }
            return { ...newState, anyError: newState.overallRatingError || 
                newState.recommendProductError ||
                newState.reviewTitleError ||
                newState.reviewBodyError ||
                newState.nicknameError ||
                newState.dobMonthError ||
                newState.dobYearError ||
                newState.emailError||
                newState.locationError ||
                newState.termsAndConditionAcceptError,
            canPreview: !(newState.overallRatingError || 
                    newState.recommendProductError ||
                    newState.reviewTitleError ||
                    newState.reviewBodyError ||
                    newState.nicknameError ||
                    newState.dobMonthError ||
                    newState.dobYearError ||
                    newState.emailError||
                    newState.locationError ||
                    newState.termsAndConditionAcceptError)
            }
        case ACTIONS.SET_SUBMIT:
            return { ...state, setSubmit: true }

        default:
            return state
        }
    }
    
    const [state, dispatch] = useReducer(reducer, initialState)
    return { state, dispatch }
}

export default useWriteReviewReducer
