import React, { useEffect, useCallback, useMemo, memo } from "react"
import PropTypes from "prop-types"
import { useRouter } from "next/router"
import dynamic from "next/dynamic"
import { FormattedDate } from "@helpers/dateHelper"
import { getPreview, submitReviews } from "@adapters/bazaarvoice"
import useWriteReviewReducer, {
    ACTIONS,
} from "@components/WriteReview/WriteReview.reducer"
import { labels as allLabels } from "@constants/writeAReview"

const Button = dynamic(()=> import("@components/Button"))
const TextField = dynamic(()=> import("@components/TextField"))
const RatingButton = dynamic(()=> import("@components/WriteReview/RatingButton"))
const Icon = dynamic(()=> import("@components/Icon"))
const DropDown = dynamic(()=> import("@components/DropDown"))
const Typography = dynamic(()=> import("@components/Typography"))
const ReviewSuccess = dynamic(() =>
    import("@components/WriteReview/ReviewSuccess")
)
const Rating = dynamic(() => import("@components/Rating"))
const ReviewError = dynamic(() =>
    import("@components/WriteReview/ReviewError")
)

const WriteReviewForm = ({ locale, bazaarVoiceId }) => {
    const router = useRouter()
    const currentYear = useMemo(()=>Number(new Date().getUTCFullYear()),[])
    const months = useMemo(()=>Array(12)
        .fill(1)
        .map((item, index) => ({ title: `${index + item}`, value: index + item })),[])
    const years = useMemo(()=>Array(120)
        .fill(1)
        .map((item, index) => ({
            title: `${currentYear - index}`,
            value: currentYear - index,
        })),[])

    const { state, dispatch } = useWriteReviewReducer()
    const labels = allLabels[locale.toLowerCase()]

    const cancelHandler = useCallback(() => {
        router.replace(router.asPath.replace("/writereview", ""))
    },[])

    const handlePreview = useCallback(() => {
        dispatch({ type: ACTIONS.VALIDATE_ALL })
        dispatch({ type: ACTIONS.SET_PREVIEW, value: true })
    },[])

    const handleSubmit = useCallback(() => {
        const reviewData = {
            locale,
            productID: bazaarVoiceId,
            overallRating: state.overallRating,
            valueRating: state.valueRating,
            qualityRating: state.qualityRating,
            recommendProduct: state.recommendProduct,
            reviewTitle: state.reviewTitle,
            reviewBody: state.reviewBody,
            nickname: state.nickname,
            dobMonth: state.dobMonth,
            dobYear: state.dobYear,
            email: state.email,
            location: state.location,
            termsAndCondition: state.termsAndCondition,
            callBackURL: `https://ca.crest.com/${locale.toLowerCase()}`,
        }
        submitReviews(reviewData)
            .then(() => {
                dispatch({
                    type: ACTIONS.THANK_YOU,
                    value: true,
                })
            })
            .catch(() => {
                dispatch({
                    type: ACTIONS.SET_ERROR,
                    value: true,
                })
            })
    },[])

    const closeClick = useCallback(() => {
        dispatch({
            type: ACTIONS.SET_PREVIEW,
            value: false,
        })
    },[])

    const onReviewErrorClose = useCallback(() => {
        dispatch({
            type: ACTIONS.SET_ERROR,
            value: false,
        })
        dispatch({
            type: ACTIONS.SET_AGE_RESTRICTION,
            value: false,
        })
    },[])

    useEffect(()=>{
        if(window.localStorage.getItem("WRITE_REVIEW_AGE_RESTRICTION") &&
        new Date() -
            new Date(
                JSON.parse(
                    window.localStorage.getItem(
                        "WRITE_REVIEW_AGE_RESTRICTION"
                    )
                ).time
            ) <
            0){
            dispatch({
                type: ACTIONS.SET_AGE_RESTRICTION,
                value: true,
            })
        }
    },[])

    useEffect(()=>{
        if((state.canPreview || state.error || state.ageError)&&!document.body.classList.contains('overflow-hidden')){
            document.body.classList.add('overflow-hidden')
        }else if(!(state.canPreview || state.error || state.ageError) && document.body.classList.contains('overflow-hidden')){
            document.body.classList.remove('overflow-hidden')
        }
        return ()=>{
            if(document.body.classList.contains('overflow-hidden'))
                document.body.classList.remove('overflow-hidden')
        }
    },[state.canPreview, state.error, state.ageError])

    useEffect(() => {
        if (state.canPreview) {
            if (
                window.localStorage.getItem("WRITE_REVIEW_AGE_RESTRICTION") &&
                new Date() -
                    new Date(
                        JSON.parse(
                            window.localStorage.getItem(
                                "WRITE_REVIEW_AGE_RESTRICTION"
                            )
                        ).time
                    ) <
                    0
            ) {
                dispatch({
                    type: ACTIONS.SET_AGE_RESTRICTION,
                    value: true,
                })
            } else {
                const curDate = new Date()
                const userDate = new Date()

                userDate.setDate(curDate.getDate())
                userDate.setMonth(state.dobMonth - 1)
                userDate.setFullYear(state.dobYear)

                if (
                    (curDate.getTime() - userDate.getTime()) /
                        (1000 * 60 * 60 * 24 * 365) >=
                    18
                ) {
                    const reviewData = {
                        locale,
                        productID: bazaarVoiceId,
                        overallRating: state.overallRating,
                        valueRating: state.valueRating,
                        qualityRating: state.qualityRating,
                        recommendProduct: state.recommendProduct,
                        reviewTitle: state.reviewTitle,
                        reviewBody: state.reviewBody,
                        nickname: state.nickname,
                        dobMonth: state.dobMonth,
                        dobYear: state.dobYear,
                        email: state.email,
                        location: state.location,
                        termsAndCondition: state.termsAndCondition,
                        callBackURL: `https://ca.crest.com/${locale.toLowerCase()}`,
                    }
                    getPreview(reviewData).then(() => {
                        return
                    }).catch(() => {
                        dispatch({
                            type: ACTIONS.SET_ERROR,
                            value: true,
                        })
                    })
                } else {
                    const today = new Date()
                    const tomorrow = new Date(today)
                    tomorrow.setDate(tomorrow.getDate() + 1)
                    dispatch({
                        type: ACTIONS.SET_AGE_RESTRICTION,
                        value: true,
                    })
                    window.localStorage.setItem(
                        "WRITE_REVIEW_AGE_RESTRICTION",
                        JSON.stringify({ time: tomorrow })
                    )
                }
            }
        }
    }, [state.canPreview])

    return (
        <div className='w-full md:w-7/12 md:pl-30 lg:pl-45 flex flex-col flex-wrap justify-start items-start mt-50 md:mt-0'>
            <div className='w-full'>
                <h2 className='w-full font-neutrafaceDemi text-24 mdl:text-30 mdl:leading-36 leading-30 text-primary text-left'>
                    {labels.ratingSectionTitle}
                </h2>
                <div className='w-full my-30 mdl:mt-20'>
                    <p className='font-neutrafaceDemi text-20 mdl:text-24 mdl:leading-30 leading-26 text-primary text-left mb-15'>
                        {labels.overallRating}
                    </p>
                    <RatingButton
                        variant='star'
                        updateValue={(value) =>
                            dispatch({ type: ACTIONS.OVERALL_RATING, value })
                        }
                        value={state.overallRating}
                    />
                </div>
                {state.overallRatingError ? (
                    <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                        {labels.overallRatingError}
                    </span>
                ) : null}

                <div className='w-full'>
                    <span className='font-neutrafaceDemi text-20 mdl:text-24 mdl:leading-30 leading-26 text-primary text-left mb-16'>
                        {labels.value}
                    </span>
                    <RatingButton
                        variant='button'
                        updateValue={(value) =>
                            dispatch({ type: ACTIONS.VALUE_RATING, value })
                        }
                        value={state.valueRating}
                    />
                </div>

                <div className='w-full mt-30'>
                    <span className='font-neutrafaceDemi text-20 mdl:text-24 mdl:leading-30 leading-26 text-primary text-left mb-16'>
                        {labels.quality}
                    </span>
                    <RatingButton
                        variant='button'
                        updateValue={(value) =>
                            dispatch({ type: ACTIONS.QUALITY_RATING, value })
                        }
                        value={state.qualityRating}
                    />
                </div>

                <div className='w-full my-40 mdl:my-30 pb-40 mdl:pb-30 border-b border-lightestBorder'>
                    <p className='font-neutrafaceBook text-18 leading-24 mdl:text-20 mdl:leading-26 text-secondary text-left mb-15'>
                        {labels.recommendProduct}
                    </p>
                    <div className='w-full flex flex-wrap flex-row justify-start items-start'>
                        <Button
                            onClick={() =>
                                dispatch({
                                    type: ACTIONS.RECOMMEND_PRODUCT,
                                    value: labels.reviewYes,
                                })
                            }
                        >
                            <Icon
                                className={`w-24 h-24 fill-current mr-10 ${
                                    state.recommendProduct === labels.reviewYes
                                        ? "text-accentDark stroke-2 stroke-current"
                                        : "text-primary"
                                }`}
                                name='ThumbsUpIcon'
                            />
                        </Button>
                        <Button
                            onClick={() =>
                                dispatch({
                                    type: ACTIONS.RECOMMEND_PRODUCT,
                                    value: labels.reviewNo,
                                })
                            }
                        >
                            <Icon
                                className={`w-24 h-24 fill-current ml-10 mt-8 ${
                                    state.recommendProduct === labels.reviewNo
                                        ? "text-accentDark stroke-2 stroke-current"
                                        : "text-primary"
                                }`}
                                name='ThumbsDownIcon'
                            />
                        </Button>
                    </div>
                </div>
                {state.recommendProductError ? (
                    <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                        {labels.recommendProductError}
                    </span>
                ) : null}
            </div>
            <div className='w-full'>
                <h2 className='w-full font-neutrafaceDemi text-24 mdl:text-30 mdl:leading-36 leading-30 text-primary text-left'>
                    {labels.reviewSectionTitle}
                </h2>

                <div className='w-full mt-20'>
                    <p className='font-neutrafaceBook text-20 leading-26 text-secondary text-left mb-10'>
                        {labels.reviewTitle}
                    </p>
                    <TextField
                        className='w-full h-46 border border-lightGreyBlue px-15 py-13 placeholder-secondary placeholder-opacity-50 rounded-md text-secondary font-neutrafaceBook text-20 leading-26'
                        type='text'
                        multiRow={false}
                        labelText={labels.reviewTitle}
                        placeholder={labels.reviewTitlePlaceHolder}
                        onBlur={(event) =>
                            dispatch({
                                type: ACTIONS.REVIEW_TITLE,
                                value: event.target.value,
                            })
                        }
                    />
                </div>
                {state.reviewTitleError ? (
                    <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                        {labels.reviewTitleError}
                    </span>
                ) : null}

                <div className='w-full mt-20 mb-40 mdl:mb-30 pb-40 mdl:pb-30 border-b border-lightestBorder'>
                    <div className='w-full'>
                        <p className='font-neutrafaceBook text-20 leading-26 text-secondary text-left mb-10'>
                            {labels.reviewBody}
                        </p>
                        <TextField
                            className='w-full h-200 border border-lightGreyBlue px-15 py-13 placeholder-secondary placeholder-opacity-50 rounded-md text-secondary font-neutrafaceBook text-20 leading-26'
                            type='text'
                            multiRow={true}
                            rows={5}
                            labelText={labels.reviewBody}
                            onBlur={(event) =>
                                dispatch({
                                    type: ACTIONS.REVIEW_BODY,
                                    value: event.target.value,
                                })
                            }
                        />
                    </div>
                    {state.reviewBodyError ? (
                        <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                            {labels.reviewBodyError}
                        </span>
                    ) : null}
                </div>
            </div>
            <div className='w-full'>
                <h2 className='w-full font-neutrafaceDemi text-24 mdl:text-30 mdl:leading-36 leading-30 text-primary text-left'>
                    {labels.userInformationSection}
                </h2>

                <div className='w-full mt-20'>
                    <p className='font-neutrafaceBook text-20 leading-26 text-secondary text-left mb-10'>
                        {labels.nickname}
                    </p>
                    <TextField
                        className='w-full h-46 border border-lightGreyBlue px-15 py-13 placeholder-secondary placeholder-opacity-50 rounded-md text-secondary font-neutrafaceBook text-20 leading-26'
                        type='text'
                        multiRow={false}
                        labelText={labels.nickname}
                        onBlur={(event) =>
                            dispatch({
                                type: ACTIONS.NICKNAME,
                                value: event.target.value,
                            })
                        }
                    />
                </div>
                {state.nicknameError ? (
                    <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                        {labels.nicknameError}
                    </span>
                ) : null}

                <div className='w-full mt-20 flex flex-wrap flex-row justify-between items-start'>
                    <p className='w-full font-neutrafaceBook text-20 leading-26 text-secondary text-left mb-10'>
                        {labels.dateOfBirth}
                    </p>
                    <div className='w-1/2 pr-5 mdl:pr-8'>
                        <DropDown
                            defaultValue={labels.dateOfBirthMonth}
                            variant='WriteAReviewMonthDP'
                            options={months}
                            onSelect={(value) =>
                                dispatch({ type: ACTIONS.DOB_MONTH, value })
                            }
                        />
                        {state.dobMonthError ? (
                            <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                                {labels.dateOfBirthMonthError}
                            </span>
                        ) : null}
                    </div>
                    <div className='w-1/2 pl-5 mdl:pl-8'>
                        <DropDown
                            defaultValue={labels.dateOfBirthYear}
                            variant='WriteAReviewMonthDP'
                            options={years}
                            onSelect={(value) =>
                                dispatch({ type: ACTIONS.DOB_YEAR, value })
                            }
                        />
                        {state.dobYearError ? (
                            <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                                {labels.dateOfBirthYearError}
                            </span>
                        ) : null}
                    </div>
                </div>

                <div className='w-full mt-20'>
                    <p className='font-neutrafaceBook text-20 leading-26 text-secondary text-left mb-10'>
                        {labels.email}
                    </p>
                    <TextField
                        className='w-full h-46 border border-lightGreyBlue px-15 py-13 placeholder-secondary placeholder-opacity-50 rounded-md text-secondary font-neutrafaceBook text-20 leading-26'
                        type='text'
                        multiRow={false}
                        labelText={labels.email}
                        onBlur={(event) =>
                            dispatch({
                                type: ACTIONS.EMAIL,
                                value: event.target.value,
                            })
                        }
                    />
                </div>
                {state.emailError ? (
                    <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                        {labels.emailError}
                    </span>
                ) : null}

                <div className='w-full mt-20'>
                    <p className='font-neutrafaceBook text-20 leading-26 text-secondary text-left mb-10'>
                        {labels.location}
                    </p>
                    <TextField
                        className='w-full h-46 border border-lightGreyBlue px-15 py-13 placeholder-secondary placeholder-opacity-50 rounded-md text-secondary font-neutrafaceBook text-20 leading-26'
                        type='text'
                        multiRow={false}
                        labelText={labels.location}
                        onBlur={(event) =>
                            dispatch({
                                type: ACTIONS.LOCATION,
                                value: event.target.value,
                            })
                        }
                    />
                </div>
                {state.locationError ? (
                    <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                        {labels.locationError}
                    </span>
                ) : null}

                <div>
                    <div className='w-full flex flex-nowrap justify-start items-start mt-40'>
                        <input
                            type='checkbox'
                            id={"tAndC"}
                            defaultChecked={state.termsAndCondition}
                            onBlur={(event) =>
                                dispatch({
                                    type: ACTIONS.T_AND_C,
                                    value: event.target.checked,
                                })
                            }
                            className='border border-accentBorder rounded-5 w-20 h-20 cursor-pointer text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0 focus:outline-none'
                        />
                        <label
                            htmlFor={"tAndC"}
                            className='font-neutrafaceBook text-16 leading-22 text-secondary pl-24'
                        >
                            <Typography
                                className='text-secondary cursor-pointer termCondition'
                                content={labels.tAndC}
                            />
                        </label>
                    </div>
                    {state.termsAndConditionError ? (
                        <span className='w-full font-neutrafaceBook text-16 leading-26 text-left text-darkRed mt-8'>
                            {labels.tAndCError}
                        </span>
                    ) : null}
                </div>
                
                {!state.ageError && (<div className='w-full flex flex-wrap flex-row justify-between items-start mt-60 mb-80'>
                    <div className='w-full mdl:w-1/2 mdl:pr-10 flex justify-start mb-10 mdl:mb-0'>
                        <Button
                            gaLabel={bazaarVoiceId}
                            gaClass='event_product_review_view'
                            className='block font-neutrafaceDemi text-18 leading-24 w-full px-90 text-white btn-filled rounded-full pt-19 pb-15 uppercase mxl:w-min'
                            onClick={handlePreview}
                        >
                            {labels.preview}
                        </Button>
                    </div>
                    <div className='w-full mdl:w-1/2 mdl:pl-10 flex justify-start'>
                        <Button
                            gaLabel={bazaarVoiceId}
                            gaClass='event_cancel_review'
                            className='font-neutrafaceDemi text-18 leading-24 text-accent block px-90 w-full btn-plain rounded-full pt-19 pb-15 uppercase mxl:w-min'
                            onClick={cancelHandler}
                        >
                            {labels.cancel}
                        </Button>
                    </div>

                    <div className='w-full flex flex-wrap justify-center mdl:justify-start items-start flex-row mt-40'>
                        <label
                            htmlFor={"termsAndConds"}
                            className='font-neutrafaceBook text-16 leading-22 text-accent pr-8 underline'
                        >
                            <Typography
                                className='text-accent cursor-pointer'
                                content={labels.termsAndConds}
                            />
                        </label>
                        {"|"}
                        <a
                            href={`/${locale.toLowerCase()}/review-guidelines`}
                            className='font-neutrafaceBook text-16 leading-22 text-accent pl-8 underline'
                        >
                            <Typography
                                className='text-accent cursor-pointer'
                                content={labels.ReviewGuidelines}
                            />
                        </a>
                    </div>
                </div>)}
            </div>
            {state.canPreview && !state.ageError && !state.sorry && (
                <div
                    className={
                        state.thankyou || state.sorry
                            ? "hidden"
                            : "show h-screen w-full bg-black bg-opacity-80 fixed top-0 left-0 flex flex-row flex-wrap justify-center items-center px-20"
                    }
                >
                    <div className='bg-white px-20 py-60 w-full lg:w-lg mxl:w-mxl xl:w-xl  relative'>
                        <div className='w-full'>
                            <Button
                                className='absolute top-0 right-20'
                                onClick={closeClick}
                            >
                                <span className='closespan font-neutrafaceBook text-secondary text-50 leading-tight'>{`×`}</span>
                            </Button>
                        </div>

                        <div className='w-full'>
                            <div className='w-full flex flex-wrap justify-center items-start flex-col mdl:flex-row'>
                                <div className='w-full mdl:w-3/12 flex flex-row mdl:flex-col justify-between items-start mb-30 mdl:mb-0 break-words'>
                                    <div className='font-neutrafaceBook text-18 leading-24 text-left text-primary mdl:mb-15'>
                                        {state.nickname}
                                    </div>
                                    <div className='font-neutrafaceBook text-18 leading-24 text-left text-secondary'>
                                        {FormattedDate(locale.toLowerCase())}
                                    </div>
                                </div>
                                <div className='w-full mdl:w-7/12 break-words'>
                                    <div className='w-full'>
                                        <Rating
                                            className='flex-wrap'
                                            svgClassName='w-18 h-17 mr-5'
                                            productId={bazaarVoiceId}
                                            ratingValue={
                                                state.overallRating || 0
                                            }
                                            constant='reviewSection'
                                        />
                                    </div>
                                    <div className='w-full my-25 font-neutrafaceDemi text-20 leading-24 text-left text-primary capitalize'>
                                        {state.reviewTitle}
                                    </div>
                                    <div className='w-full font-neutrafaceBook text-18 leading-24 text-left text-secondary'>
                                        {state.reviewBody}
                                    </div>
                                    <div className='w-full my-20 font-neutrafaceBook text-18 leading-24 text-left text-secondary'>
                                        {state.recommendProduct ===
                                        labels.reviewYes ? (
                                                <span id='recommend'>
                                                    {labels.yesRecommend}
                                                </span>
                                            ) : (
                                                <span id='notRecommend'>
                                                    {labels.notRecommend}
                                                </span>
                                            )}
                                    </div>
                                    <div className='mt-30 w-full mx-auto text-center mdl:text-left'>
                                        <Button
                                            onClick={closeClick}
                                            gaClass='event_button_click'
                                            className='btn btn-plain font-neutrafaceDemi text-18 leading-24 text-accent uppercase rounded-full px-110 border border-accentBorder pt-19 pb-15 mb-20 mdl:mb-0'
                                        >
                                            {labels.reviewEditButton}
                                        </Button>
                                        <Button
                                            onClick={handleSubmit}
                                            gaLabel={labels.reviewSubmitButton}
                                            gaClass='event_submit_review'
                                            className='btn btn-filled font-neutrafaceDemi text-18 leading-24 text-white uppercase rounded-full px-98 pt-19 pb-15 mdl:ml-20'
                                        >
                                            {labels.reviewSubmitButton}
                                        </Button>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
            )}
            {state.thankyou ? (
                <ReviewSuccess
                    url={router.asPath.replace("/writereview", "")}
                    locale={locale}
                />
            ) : null}

            {(state.sorry || state.ageError) && (
                <ReviewError onReviewErrorClose={state.ageError?cancelHandler:onReviewErrorClose} locale={locale} ageError={state.ageError} />
            )}
        </div>
    )
}

WriteReviewForm.propTypes = {
    locale: PropTypes.string.isRequired,
    bazaarVoiceId: PropTypes.string.isRequired,
}

export default memo(WriteReviewForm)
