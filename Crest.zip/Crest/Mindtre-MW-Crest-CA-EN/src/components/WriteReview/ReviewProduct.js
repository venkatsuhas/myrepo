import React, { memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'

const Image = dynamic(() => import('@components/Image'))

export const ReviewProduct = ({ heroImage, productName }) => (
    <div className='w-full md:w-5/12'>
        <div className='w-full flex flex-row mdl:flex-col flex-wrap mdl:sticky top-0'>
            <div className='w-4/12 md:w-full'>
                {heroImage && <Image desktopClassName='imgContainer min-h-100 mxl:min-h-310' wrapperClassName='w-full' desktopImage={heroImage} alt={heroImage?.altText} layout='intrinsic' />}
            </div>
            <h1 className='w-8/12 md:w-full pl-18 mdl:pl-0 font-neutrafaceDemi text-20 leading-20 mdl:text-34 mdl:leading-40 text-left text-primary mdl:mt-30'>
                {productName} 
            </h1>
        </div>
    </div>
)

ReviewProduct.propTypes = {
    heroImage: PropTypes.object,
    productName: PropTypes.string,
}

export default memo(ReviewProduct)
