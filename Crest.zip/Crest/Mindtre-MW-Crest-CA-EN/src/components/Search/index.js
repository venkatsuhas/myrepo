import React, { useState, useEffect, useRef, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"
import { labels as allLabels, pageTypes } from "@constants"
import searchHandler from "@adapters/algolia/searchHandler"
import urlHelper from "@helpers/url.helpers"

const Button = dynamic(() => import("@components/Button"))
const Icon = dynamic(() => import("@components/Icon"))
const ProductCard = dynamic(() => import("@components/Card/ProductCard"))
const TextField = dynamic(() => import("@components/TextField"))

const Search = ({ locale, closeHandler }) => {
    const router = useRouter()
    const labels = allLabels[locale.toLowerCase()]
    const [inputText, setInputText] = useState("")
    const [results, setResults] = useState([])
    const debounceTimer = useRef(null)

    useEffect(() => {
        document.body.classList.add("overflow-hidden")
        const url = router.asPath
        if (url.match(/[^?]*\?term=([^&]+)/g)) setInputText(decodeURI(url.replace(/[^?]*\?term=([^&]+)/g, (...node) => node[1])))
        return () => {
            document.body.classList.remove("overflow-hidden")
        }
    }, [])

    const updateSearchTerm = useCallback(() => {
        searchHandler({
            searchTerm: inputText,
            locale,
            limit: 3,
            type: "product",
        })
            .then(({ hits }) => {
                setResults(
                    hits.map((entry) => ({
                        id: entry.objectID,
                        productName: entry.productName,
                        url: entry.url,
                        productHeroImage: entry.productHeroImage,
                        priceSpiderId: entry.priceSpiderId,
                    }))
                )
            })
            .catch((err) => {
                console.error(err)
            })
        clearTimeout(debounceTimer.current)
        debounceTimer.current = null
    }, [inputText, locale])

    useEffect(() => {
        if (inputText) {
            if (!debounceTimer.current) {
                debounceTimer.current = setTimeout(updateSearchTerm, 500)
            }
        }
    }, [inputText])

    const inputHandler = useCallback((event) => {
        setInputText(event.target.value)
    }, [])

    const formSubmitHandler = useCallback(
        (event) => {
            event.preventDefault()
            window?.dataLayer?.push({
                event: "customEvent",
                GAeventCategory: "event_informational_action",
                GAeventAction: "event_search",
                GAeventLabel: inputText,
                GAeventValue: inputText,
                GAeventNonInteraction: false
            })    
            closeHandler()
            if (!router.asPath.includes("search")) {
                router.prefetch(
                    urlHelper({
                        locale,
                        pageType: pageTypes.searchPage,
                        searchTerm: inputText,
                    })
                )
            }
            router.push(
                urlHelper({
                    locale,
                    pageType: pageTypes.searchPage,
                    searchTerm: inputText,
                })
            )
        },
        [closeHandler, inputText, locale, router]
    )

    const clearInput = useCallback(() => {
        setInputText("")
        setResults([])
    }, [])

    return (
        <div className='backdrop fixed z-50 overflow-y-auto inset-0 bg-overlaybg flex items-center'>
            <div className='search-modal bg-white fixed top-0 left-0 w-full overflow-hidden py-30 menuDropdown_animate'>
                <div className='px-20 mx-auto w-full flex flex-col-reverse lg:w-lg mxl:w-mxl xl:w-xl relative lg:px-0'>
                    <form onSubmit={formSubmitHandler} className='searchformWrapper w-full mdl:w-6/12 mdl:mx-auto'>
                        <div className={"relative "}>
                            <Icon name='Search' className='iconSearch absolute pr-12 pb-2 left-14 transform -translate-y-1/2 top-1/2 border-0 w-30' />
                            <TextField
                                className={
                                    "search-box pt-14 pr-70 pb-11 pl-55 text-20 leading-26 font-neutrafaceBook w-full bg-lightGray bg-opacity-30 text-secondary"
                                }
                                placeholder={labels.searchHere}
                                name='search'
                                labelId='search-box'
                                labelText='Search Here'
                                defaultValue={inputText}
                                value={inputText}
                                onInput={inputHandler}
                            />
                            <Button
                                gaClass='event_button_click'
                                onClick={clearInput}
                                className='clearText absolute transform -translate-y-1/2 top-1/2 text-14 font-neutrafaceBook right-20 leading-24'>
                                {labels.clear}
                            </Button>
                        </div>
                    </form>
                    <Button
                        gaClass='event_button_click'
                        onClick={closeHandler}
                        className='w-15 mr-16 ml-auto mdl:absolute mdl:float-none mdl:transform mdl:-translate-y-1/2 mdl:top-1/2 mdl:text-14 mdl:font-neutrafaceBook mdl:right-20'>
                        <Icon name='Close' className='searchClose w-15 mb-24 mdl:mb-0 mdl:w-20' />
                    </Button>
                </div>
                {results && results.length > 0 && (
                    <div className='autoSearch'>
                        <div className=' flex flex-wrap py-30 justify-center overflow-y-auto mx-auto px-20 lg:w-lg mxl:w-mxl xl:w-xl relative lg:px-0'>
                            <div className='flex flex-row flex-wrap mdl:w-8/12 mdl:mx-auto '>
                                {results.map((product) => (
                                    <ProductCard
                                        key={product.id}
                                        locale={locale}
                                        title={product.productName}
                                        image={product.productHeroImage}
                                        buyNowSKU={product.priceSpiderId}
                                        href={product.url}
                                        onClick={closeHandler}
                                        variant='searchRecomandCard'
                                    />
                                ))}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}

Search.propTypes = {
    locale: PropTypes.string.isRequired,
    closeHandler: PropTypes.func.isRequired,
}

export default memo(Search)
