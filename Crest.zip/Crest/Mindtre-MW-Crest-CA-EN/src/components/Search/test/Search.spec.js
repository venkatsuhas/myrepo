import React, { useState as useStateMock, useEffect as useEffectMock } from 'react'
import { shallow } from 'enzyme'
import Search from '@components/Search'

jest.mock('@adapters/algolia/searchHandler', () => ({
    ...jest.requireActual("@adapters/algolia/searchHandler"),
    default: jest.fn(),
}))

jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useEffect: jest.fn(),
}))

jest.mock("next/router", () => ({
    ...jest.requireActual("next/router"),
    useRouter: jest.fn().mockImplementation(()=>({ asPath: "/en-ca/oral-care-products#product?type=all" }))
}))

describe('Search component', () => {
    let wrapper
    
    it('should render Search component', () => {
        const props = {
            locale:'en-ca',
            closeHandler:jest.fn(),
        }
        useStateMock.mockImplementationOnce(() => ['',jest.fn()])
        useStateMock.mockImplementationOnce(() => [[{ id: 1 }, { id: 2 }, { id: 3 }],jest.fn()])
        
        useEffectMock.mockImplementation(async (func) => {
            await func()
        })
        wrapper = shallow(<Search {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it('should render Search component', () => {
        const setInputText = jest.fn()
        const props = {
            locale:'en-ca',
            closeHandler:jest.fn(),
        }
        const mockState = {
            setInputText:'aa'
        }
        useStateMock.mockImplementation(() => [mockState, setInputText])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
        wrapper = shallow(<Search {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it('should render Search component', () => {
        const setResults = jest.fn()
        const props = {
            locale:'en-ca',
            closeHandler:jest.fn(),
        }
        const mockState = {
            setResults:[]
        }
        useStateMock.mockImplementation(() => [mockState, setResults])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
        wrapper = shallow(<Search {...props} />)
        expect(wrapper).toBeTruthy()
    })
})