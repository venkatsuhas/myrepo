import React, { memo, Fragment } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { labels as allLabels } from "@constants"
import styles from "@components/Card/ProductCard-tw-styles"

const Button = dynamic(() => import("@components/Button"))
const BuyNowButton = dynamic(() => import("@components/Button/BuyNowButton"))
const Image = dynamic(() => import("@components/Image"))
const Rating = dynamic(() => import("@components/Rating"))

const ProductCard = ({
    locale,
    title,
    subTitle,
    href,
    image,
    rating,
    buyNowSKU,
    isPopular,
    variant,
    onClick,
    isThumbnails,
    productFacets,
}) => {

    const labels = allLabels[locale.toLowerCase()] || {}
    const style = styles[variant] || styles.default
    const Component = href ? Button : Fragment
    return (
        <div className={style.cardWrapper}>
            <div className={style.cardContainer}>
                <Component {...{ ...(href ? { href, className: style.linkWrap, gaClass:'event_internal_link', gaLabel:href } : {}), ...(onClick ? { onClick } : {}) }}>
                    {isPopular && (
                        <span className={style.cardTag}>{labels.mostPopular}</span>
                    )}
                    {isThumbnails && (
                        <div className={style.thumbnailsFacet}>{productFacets}</div>
                    )}
                    {image && (
                        <Image
                            key={image.sys}
                            desktopClassName={style.imgContainer}
                            wrapperClassName={style.imgWrapper}
                            desktopImage={image}
                            alt={image?.altText}
                        />
                    )}
                    <div className={style.contentWrapper}>
                        {title && (
                            <div className={style.cardCategory}>{title}</div>
                        )}
                        {subTitle && (
                            <div className={style.title}>{subTitle}</div>
                        )}

                        {rating && (
                            <div className={style.ratingContainer}>
                                <Rating
                                    className={style.ratingIconContainer}
                                    svgClassName={style.ratingIcon}
                                    productId={buyNowSKU}
                                    ratingValue={rating.value}
                                />
                                <span className={style.ratingCount}>
                                    {rating.count}
                                </span>
                            </div>
                        )}
                    </div>
                </Component>
                {buyNowSKU && (
                    <BuyNowButton className={style.buyNow} locale={locale} sku={buyNowSKU} />
                )}
            </div>

        </div>
    )
}

ProductCard.propTypes = {
    href: PropTypes.string,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    image: PropTypes.object,
    locale: PropTypes.string,
    rating: PropTypes.shape({
        value: PropTypes.number.isRequired,
        count: PropTypes.number.isRequired,
    }),
    buyNowSKU: PropTypes.string,
    isPopular: PropTypes.bool,
    variant: PropTypes.string.isRequired,
    onClick: PropTypes.func,
    isThumbnails: PropTypes.bool,
    productFacets: PropTypes.arrayOf(PropTypes.string),
}
ProductCard.defaultProps = {
    isThumbnails: false,
}
export default memo(ProductCard)
