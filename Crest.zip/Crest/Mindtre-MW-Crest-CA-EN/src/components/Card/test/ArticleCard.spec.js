import React from "react"
import { shallow } from "enzyme"
import ArticleCard from "../ArticleCard"

describe("ArticleCard component", () => {
    let wrapper
    let props = {
        locale: "en-ca",
        href: "aa/bb/cc",
        image: {
            altText: "Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches",
            height: 250,
            sys: "EK9wrqNPOtvmE2EytxSek",
            url: "EK9wrqNPOtvmE2EytxSek/255f06666ed624facf6524912be9bd4b/Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches.jpg",
        },
        name: "name",
        category: true,
        variant: "alpArticlesCard",
        categoryBasedFeatured: true,
    }

    beforeEach(() => {
        wrapper = shallow(<ArticleCard {...props} title={"Card"} locale={"en-ca"} />)
        expect(wrapper).toBeTruthy()
    })

    it(`should render if the style is ArticleCard component`, () => {
        expect(wrapper).toBeTruthy()
    })

    it("should render ProductCard component without style", () => {
        wrapper.setProps({
            locale: "",
            href: null,
            variant: null,
            category: false,
            categoryBasedFeatured: false,
        })
        expect(wrapper.html()).not.toBe(null)
    })
})
