import React from "react"
import { shallow } from "enzyme"
import ProductCard from "../ProductCard"

describe("ProductCard component", () => {
    let wrapper
    const props = {
        locale: "en-ca",
        title: "name",
        subTitle: "name",
        href: "aa/bb/cc",

        image: {
            altText: "Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches",
            height: 250,
            sys: "EK9wrqNPOtvmE2EytxSek",
            url: "EK9wrqNPOtvmE2EytxSek/255f06666ed624facf6524912be9bd4b/Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches.jpg",
        },
        buyNowSKU: "056100080350",
        isPopular: true,
        variant: "ProductListingPage",
        isThumbnails: true,
        productFacets: [],
        rating: "1",
        onClick: jest.fn(),
    }

    beforeEach(() => {
        wrapper = shallow(<ProductCard {...props} title={"Card"} />)
        expect(wrapper).toBeTruthy()
    })

    it(`should render ProductCard component`, () => {
        expect(wrapper).toBeTruthy()
    })

    it("should render ProductCard component without style", () => {
        wrapper.setProps({
            locale: "",
            href: null,
            variant: null,
            onClick: null,
        })
        expect(wrapper.html()).not.toBe(null)
    })
})
