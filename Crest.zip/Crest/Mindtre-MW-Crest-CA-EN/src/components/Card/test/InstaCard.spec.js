import React from "react"
import { shallow } from "enzyme"
import InstaCard from "../InstaCard"

describe("insta card component", () => {
    let wrapper
    let props = [
        {
            cardSytles:"cardSytles",
            instaCard:{
                cardLink: "https://www.instagram.com/crest/?hl=en",
                description: "#BringOnTheSmiles",
                href: 'aa/bb/cc',
                image:{
                    altText: "Instagram",
                    height: 32,
                    sys: "7ItJ23JHpRB8iQHf04eh6a",
                    url: "7ItJ23JHpRB8iQHf04eh6a/0be2105b6fbfc66acfac51a7be67e4c1/Instagram.svg",
                    width: 32,
                },
                imageSet:{
                    desktopImage: {
                        sys: '4AMAKGqs3Q9S4hl9IT5kxl', 
                        url: '4AMAKGqs3Q9S4hl9IT5kxl/fb5cf6bbfabf1bf7ffc914117a1ab172/d-social-instagram.png', 
                        altText: 'd-social-instagram', 
                        height: 403, 
                        width: 959
                    },
                    smartphoneImage: {
                        sys: '3sVjEtomGfKVyV8o1fBGEu', 
                        url: '3sVjEtomGfKVyV8o1fBGEu/586cd05e555ca339a28d0a69',
                    }
                },
                linkText: "Enabling healthier oral care habits",
                name: "#BringOnTheSmiles",
                styles: "styles",
                subTitle: "Enabling healthier oral care habits",
                sys: "5hzxpDIAdYkwunPTAQp9tG",
                title: "#BringOnTheSmiles"

            }
        }
       
    ]

    beforeEach(() => {
        wrapper = shallow(<InstaCard {...props[0]} title={"Card"}  />)
        expect(wrapper).toBeTruthy()
    })

    props.forEach((prop) => {
        it(`should render if the style is ${prop.styles ? prop.styles : "default"}`, () => {
            const component = shallow(<InstaCard {...prop}  />)
            expect(component).toBeTruthy()
        })
    })
})
