import React from "react"
import { shallow } from "enzyme"
import FeatureCard from "../FeatureCard"

describe("FeatureCard component", () => {
    let wrapper
    let props = [
        {
            cardStyles:"cardStyles",
            href:"aa/bb/cc",
            imageset:{
                desktopImage:{
                    altText: "Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches",
                    height: 250,
                    sys: "EK9wrqNPOtvmE2EytxSek",
                    url: "EK9wrqNPOtvmE2EytxSek/255f06666ed624facf6524912be9bd4b/Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches.jpg",
                },
                smartPhoneImage:{
                    altText: "Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches",
                    height: 250,
                    sys: "EK9wrqNPOtvmE2EytxSek",
                    url: "EK9wrqNPOtvmE2EytxSek/255f06666ed624facf6524912be9bd4b/Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches.jpg",
                },
            },
            image:{
                altText: "Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches",
                height: 250,
                sys: "EK9wrqNPOtvmE2EytxSek",
                url: "EK9wrqNPOtvmE2EytxSek/255f06666ed624facf6524912be9bd4b/Est-ce-a-cause-de-la-leucoplasie-que-vous-avez-les-gencives-blanches.jpg",
            },

            title:"name",
            subTitle:"name",
            description:" Going the Extra Smile ",
            linkText:" Going the Extra Smile ",
            iconName:" Going the Extra Smile ",
        }
       
    ]

    beforeEach(() => {
        wrapper = shallow(<FeatureCard {...props[0]} title={"Card"}  />)
        expect(wrapper).toBeTruthy()
    })

    props.forEach((prop) => {
        it(`should render if the style is ${prop.cardStyles ? prop.cardStyles : "default"}`, () => {
            const component = shallow(<FeatureCard {...prop}  />)
            expect(component).toBeTruthy()
        })
    })
})
