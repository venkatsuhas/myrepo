import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import Modal from 'react-modal'
import styles from "@components/Card/FeatureCard-tw-styles"

const Icon = dynamic(() => import("@components/Icon"))
const Image = dynamic(() => import("@components/Image"))
const Button = dynamic(() => import("@components/Button"))
const Typography = dynamic(() => import("@components/Typography"))

const FeatureCard = ({ cardStyles, href, imageset, image, title, subTitle, description, linkText, iconName, videoUrl, videoPlayIcon, logo }) => {
    const style = styles[cardStyles] || styles?.default
    const [modalIsOpen, setIsOpen] = React.useState(false)

    function openModal() {
        setIsOpen(true)
    }

    function closeModal() {
        setIsOpen(false)
    }

    return (
        <div className={style.cardWrapper}>
            {imageset && (
                <Image
                    desktopClassName={style.imgContainerDt}
                    smartphoneClassName={style.imgContainerSp}
                    wrapperClassName={style.imgWrapper}
                    desktopImage={imageset.desktopImage}
                    smartphoneImage={imageset.smartphoneImage}
                    alt={imageset.altText}
                />
            )}
            {image && (
                <Image
                    desktopClassName={style.imgContainerDt}
                    smartphoneClassName={style.imgContainerSp}
                    wrapperClassName={style.imgWrapper}
                    desktopImage={image}
                    alt={imageset?.altText}
                />
            )}

            <div className={style.contentWrapper}>
                <div className={style.contentContainer}>
                    {logo && <div>
                        <Image
                            desktopClassName={style?.logoStyle}
                            smartphoneClassName={"w-100"}
                            desktopImage={logo.desktopImage}
                            smartphoneImage={logo.smartphoneImage}
                            alt={logo.altText}
                        />
                    </div>}
                    {title && <Typography content={title} className={style.title} />}
                    {subTitle && <Typography content={subTitle} className={style.subTitle} />}
                    {description && <Typography content={description} className={style.description} />}
                    {href && linkText && (
                        <Button gaClass='event_button_click' gaLabel={linkText} href={href} className={style.articleLink}>
                            {linkText}
                            {iconName && (
                                <span className={style.icon}>
                                    <Icon className='w-full' name={iconName} />
                                </span>
                            )}
                        </Button>
                    )}
                    {videoUrl && videoPlayIcon && (
                        <div onClick={openModal}
                            role='button'
                            tabIndex={0}
                            onKeyPress={openModal}
                        >
                            <Image
                                desktopClassName={style.playLogo}
                                smartphoneClassName={style.imgVideoPlayIconSp}
                                wrapperClassName={""}
                                desktopImage={videoPlayIcon.desktopImage}
                                smartphoneImage={videoPlayIcon.smartphoneImage}
                                alt={videoPlayIcon.altText}                                
                            />
                        </div>
                    )}
                    {videoUrl && <Modal
                        isOpen={modalIsOpen}
                        onRequestClose={closeModal}  
                        className={style.videoStyles}             
                    >          
                        <iframe className=' w-full lg:h-500 mdl:h-400 md:h-215 sm:h-160 lg:mt-10p ' src={videoUrl} title='video'/>
                        <button className='pop-close-icon  ' onClick={closeModal}>X</button>
                    </Modal>}
                </div>
            </div>
        </div>
    )
}

FeatureCard.propTypes = {
    href: PropTypes.string,
    image: PropTypes.object,
    imageset: PropTypes.object,
    linkText: PropTypes.string,
    title: PropTypes.string,
    subTitle: PropTypes.string,
    description: PropTypes.string,
    cardStyles: PropTypes.string,
    iconName: PropTypes.string,
    videoUrl: PropTypes.string,
    logo:{
        desktopImage:PropTypes.object,
        smartphoneImage:PropTypes.object,
        altText:PropTypes.string
    },
    videoPlayIcon:{
        desktopImage:PropTypes.object,
        smartphoneImage:PropTypes.object,
        altText:PropTypes.string
    }
}
FeatureCard.defaultProps = {
    iconName: "",
    href: "",
    linkText: "",
    title: "",
    subTitle: "",
    description: "",
    cardStyles: "",
}
export default memo(FeatureCard)
