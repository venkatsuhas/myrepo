import React, { memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import styles from "@components/Card/InstaCard-tw-styles"

const FeatureCard = dynamic(() => import("@components/Card/FeatureCard"))
const Button = dynamic(() => import("@components/Button"))

const InstaCard = ({ instaCard, cardStyles }) => {
    const style = styles[cardStyles] || styles.default
    return (
        <div className={style.cardWrapper}>
            <div className={style.instaDetails}>
                <FeatureCard image={instaCard.image} title={instaCard.title} subTitle={instaCard.subTitle} cardStyles='instaImagecard' />
            </div>
            <div className={style.imageSet}>
                <Button href={instaCard.cardLink} gaClass='event_socialmedia_exit' gaLabel={instaCard.cardLink} target='_blank'>
                    <FeatureCard imageset={instaCard.imageset} cardStyles='instaImageGalcard' />
                </Button>
            </div>
        </div>
    )
}

InstaCard.propTypes = {
    instaCard: PropTypes.object,
    cardStyles: PropTypes.string,
}

InstaCard.defaultProps = {
    cardStyles: "",
    instaCard: {},
}
export default memo(InstaCard)
