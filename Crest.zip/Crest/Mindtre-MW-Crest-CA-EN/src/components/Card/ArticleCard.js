import React, { memo, Fragment } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { labels as allLabels } from "@constants"
import styles from "@components/Card/ArticleCard-tw-styles"

const Image = dynamic(() => import("@components/Image"))
const Button = dynamic(() => import("@components/Button"))

const ArticleCard = ({ locale, href, image, name, category, categoryBasedFeatured, variant }) => {
    const labels = allLabels[locale.toLowerCase()] || {}
    const style = variant ? styles[variant] : styles.relatedArticles
    const Component = href ? Button : Fragment
    return (
        <div className={`${style.cardWrapper} ${categoryBasedFeatured ? style.featuredWrapper : style.notFeaturedWrapper}`}>
            <Component {...(href ? { href, className: style.linkWrap, gaClass:'event_internal_link', gaLabel:href } : {})}>
                <div className={style.imgContainer}>
                    {image && (
                        <Image
                            key={image.sys}
                            desktopClassName={style.imgContainer}
                            wrapperClassName={style.imgWrapper}
                            desktopImage={image}
                            alt={image.altText}
                        />
                    )}
                </div>
                {category && <div className={style.cardCategory}>{category}</div>}
                {name && <div className={style.title}>{name}</div>}
            </Component>
            {href && (
                <Button href={href} gaClass='event_internal_link' gaLabel={labels.readArticle} className={style.articleLink}>
                    {labels.readArticle}
                </Button>
            )}
        </div>
    )
}

ArticleCard.propTypes = {
    locale: PropTypes.string,
    href: PropTypes.string,
    image: PropTypes.object,
    name: PropTypes.string,
    sys: PropTypes.string,
    category: PropTypes.string,
    categoryBasedFeatured: PropTypes.bool,
    variant: PropTypes.string,
}

export default memo(ArticleCard)
