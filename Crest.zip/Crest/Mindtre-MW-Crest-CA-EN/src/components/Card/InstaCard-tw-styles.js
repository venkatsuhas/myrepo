module.exports = {
    default: {
        cardWrapper:'instaCard mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl mdl:flex mdl:flex-wrap mdl:items-center mdl:mb-100 mdl:p-45',
        instaDetails:'instaDetails mdl:w-3/12',
        imageSet:'imageset mdl:w-9/12'
    },
    productSafetyInstaCard: {
        cardWrapper:'instaCard mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl mdl:flex mdl:flex-wrap mdl:items-center mdl:mb-100 mdl:p-45',
        instaDetails:'instaDetails mdl:w-3/12',
        imageSet:'imageset mdl:w-9/12'
    },
    homepageInstaCard:{
        cardWrapper:'instaCard mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl mdl:flex mdl:flex-wrap mdl:items-center mdl:mb-100',
        instaDetails:'instaDetails mdl:w-4/12 lg:w-3/12 mdl:relative mdl:z-1',
        imageSet:'imageset mdl:w-8/12 lg:w-9/12'
    },
    productpageInstaCard: {
        cardWrapper:'instaCard mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl mdl:flex mdl:flex-wrap mdl:items-center mdl:mb-100 mdl:p-45',
        instaDetails:'instaDetails mdl:w-3/12',
        imageSet:'imageset mdl:w-9/12'
    },
}