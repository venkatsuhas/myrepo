import React, { useState, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"

const Accordion = dynamic(() => import("@components/Accordion"))

const FilterAccordion = ({ title, options, filterUpdate, variant, constant }) => {
    const [openAccordion, setOpenAccordion] = useState(true)

    const toggleAccordion = useCallback(() => {
        setOpenAccordion((prevState) => !prevState)
    },[])

    const handleChange = useCallback((value) => {
        if (typeof filterUpdate === "function") {
            filterUpdate(value)
        }
    },[])

    const generateID = useCallback((text1,text2)=>`${text1.replace(/[^A-Za-z0-9-]/,'-')}-${text2.replace(/[^A-Za-z0-9-]/,'-')}-${constant}`, [constant])

    return (
        <div>
            <Accordion open={openAccordion} title={title} toggleOpen={toggleAccordion} variant={variant}>
                {options && options.length > 0 && (
                    <ul className='w-full'>
                        {options.filter(option=>option.count).map((option, index) => (
                            <li key={index} className='flex flex-wrap justify-start items-center mb-15 cursor-pointer'>
                                <input
                                    type='checkbox'
                                    name={title}
                                    id={generateID(title, option.name)}
                                    value={option.name}
                                    checked={option.state}
                                    onChange={() => handleChange(option.name)}
                                    className='pl-10 border border-accentBorder rounded-3 w-18 h-18 cursor-pointer text-accentDark checked:bg-accentDark checked:border-accentDark checked:outline-none checked:ring-0 focus:bg-transparent focus:border-accentDark focus:outline-none focus:ring-0 focus:outline-none'
                                />
                                <label htmlFor={generateID(title, option.name)} className='font-neutrafaceBook text-20 leading-24 mdl:leading-30 text-secondary pl-10'>
                                    {`${option.name}${option.count?' ('+option.count+')':''}`}
                                </label>
                            </li>
                        ))}
                    </ul>
                )}
            </Accordion>
        </div>
    )
}

FilterAccordion.propTypes = {
    title: PropTypes.string,
    options: PropTypes.array,
    variant: PropTypes.string,
    filterUpdate: PropTypes.func,
    constant: PropTypes.string,
}

FilterAccordion.defaultProps={
    constant: 'default'
}

export default memo(FilterAccordion)
