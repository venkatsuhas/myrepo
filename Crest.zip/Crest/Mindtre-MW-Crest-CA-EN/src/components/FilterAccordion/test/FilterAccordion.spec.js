import React from "react"
import { shallow } from "enzyme"
import FilterAccordion from "@components/FilterAccordion"

describe("FilterAccordion Component", () => {
    let wrapper
    beforeEach(() => {
        window.scrollTo = jest.fn()
    })
    
    it("should render", () => {
        const props = {
            title: "Filter",
            options: [
                {
                    name: "Filter",
                    state: true,
                    count: 10,
                },
                {
                    name: "Filter",
                    state: false,
                    count: 15,
                },
            ],
            filterUpdate: jest.fn(),
            constant: "LargeScreen",
            variant: "ProductListingPage",
        }
        wrapper = shallow(<FilterAccordion {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it("should render without counts", () => {
        const props = {
            title: "Filter",
            options: [
                {
                    name: "Filter",
                    state: true,
                },
                {
                    name: "Filter",
                    state: false,
                },
            ],
            filterUpdate: jest.fn(),
            constant: "LargeScreen",
            variant: "ProductListingPage",
        }
        wrapper = shallow(<FilterAccordion {...props} />)
        expect(wrapper).toBeTruthy()
    })
})
