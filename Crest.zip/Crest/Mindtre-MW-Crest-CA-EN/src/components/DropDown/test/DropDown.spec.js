import React, { useState as useStateMock, useEffect as useEffectMock } from "react"
import { shallow } from "enzyme"
import DropDown from "@components/DropDown"

jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useEffect: jest.fn(),
    useRef: jest.fn(),
}))

jest.mock("next/router", () => ({
    useRouter() {
        return {
            route: "/",
            pathname: "",
            query: "",
            asPath: "",
        }
    },
}))

describe("DropDown Component", () => {
    it("Should render DropDown component", () => {
        const setState = jest.fn()
        const props = {
            onSelect: jest.fn(),
            defaultValue: "articleCard",
            options: [
                {
                    title: "title",
                    value: "value",
                },
                {
                    title: "title",
                    value: "value",
                },
            ],
            variant: "ProductListingPage",
            resetOnPathChange: false,
        }

        const mockState = {
            state:{
                dropDownOpen: false,
                dropDownValue: 3,
            }
            
        }
        useStateMock.mockImplementation(() => [mockState.state, setState])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
        const wrapper = shallow(<DropDown {...props} />)
        expect(wrapper).toBeTruthy()
    })
    it("Should render DropDown component", () => {
        const setOutsideClick = jest.fn()
        const props = {
            onSelect: jest.fn(),
            defaultValue: "articleCard",
            options: [
                {
                    title: "title",
                    value: "value",
                },
                {
                    title: "title",
                    value: "value",
                },
            ],
            variant: "ProductListingPage",
            resetOnPathChange: true,
        }
        const mockState = {
            outsideClick: false,
            childrenPerPage: 1,
        }
        useStateMock.mockImplementation(() => [mockState, setOutsideClick])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
        const wrapper = shallow(<DropDown {...props} />)
        expect(wrapper).toBeTruthy()
        
    })
})
