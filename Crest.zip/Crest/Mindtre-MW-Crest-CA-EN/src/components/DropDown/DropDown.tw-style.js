module.exports = {
    default:{
        wrapper: 'font-neutrafaceBook text-16 leading-22 text-left',
        titleContainer:'font-neutrafaceBook text-16 leading-22 text-left border-lightGreyBlue border pl-20 pr-15 py-12 w-139',
        title:'flex justify-between w-full items-center text-left',
        dpIconContainer: '',
        dpIcon:'w-9 fill-current text-lightGreyBlue',
        dpItems:'flex flex-col flex-wrap border-lightGreyBlue border border-t-0 px-6 absolute z-10 w-139 bg-white',
        dpItem:'font-neutrafaceBook text-16 leading-22 text-left border-lightGreyBlue border-t first:border-t-0 pl-14 pr-9 py-12',
        dropDownIcon:'DropDownArrow'
    },
    borderedDropdown:{
        wrapper: 'font-neutrafaceBook text-16 leading-22 text-left',
        titleContainer:'font-neutrafaceBook text-16 leading-22 text-left border-lightGreyBlue border pl-20 pr-15 py-12 w-max rounded-md',
        title:'flex justify-between w-full items-center text-left text-secondary',
        dpIconContainer: 'pl-10',
        dpIcon:'w-9 fill-current text-lightGreyBlue',
        dpItems:'flex flex-col flex-wrap border-lightGreyBlue border border-t-0 px-6 pr-30 absolute z-10 w-max bg-white shadow-lightestGrey rounded-b-md',
        dpItem:'font-neutrafaceBook text-16 leading-22 text-left pl-14 pr-9 py-12 text-secondary',
        dropDownIcon:'DropDownArrow'
    },
    ProductListingPage:{
        wrapper: 'font-neutrafaceBook text-16 leading-22 text-left hidden mdl:flex justify-end relative',
        titleContainer:'font-neutrafaceBook text-22 leading-30 text-left',
        title:'flex justify-between w-full items-center text-left text-secondary',
        dpIconContainer: 'pl-15',
        dpIcon:'w-9 fill-current text-accent',
        dpItems:'flex flex-col flex-wrap border-lightGreyBlue border px-15 pt-5 absolute z-10 bg-white top-40 w-max shadow-lightestGrey',
        dpItem:'font-neutrafaceBook text-16 leading-22 text-left text-secondary py-15',
        dropDownIcon:'ChevronArrowDown'
    },
    plainDropdown:{
        wrapper: 'relative',
        titleContainer:'titleContainer pl-10 pr-15',
        title:'title font-neutrafaceBook text-18 leading-24 text-primary text-left flex justify-start items-baseline',
        dpIconContainer:'pl-5',
        dpIcon:'dpIcon w-10 fill-current text-secondary',
        dpItems:'dpItems flex flex-col flex-wrap border-lightGreyBlue border px-15 pt-5 absolute z-20 bg-white top-40 w-max shadow-lightestGrey',
        dpItem:'dpItem font-neutrafaceBook text-18 leading-24 text-primary text-left py-12',
        dropDownIcon:'DropDownArrow'
    },
    countryDropdown:{
        wrapper: 'relative',
        titleContainer:'titleContainer',
        title:'title font-neutrafaceBook text-16 leading-20 text-lightWhite text-left flex justify-start items-baseline',
        dpIconContainer:'pl-5',
        dpIcon:'dpIcon w-10 fill-current text-secondary',
        dpItems:'dpItems flex flex-col flex-wrap px-6 absolute z-10 bg-white',
        dpItem:'dpItem font-neutrafaceBook text-18 leading-24 text-primary text-left py-12',
        dropDownIcon:'DropDownArrow'
    },
    ArticleListingPage:{
        wrapper: 'text-left w-210 mdl:w-auto mdl:flex mdl:justify-end mdl:relative',
        titleContainer:'border-lightGreyBlue border px-20 py-12 mdl:p-0 mdl:border-0 rounded-md',
        title:'flex justify-between w-full items-center text-left font-neutrafaceBook text-22 leading-30 text-secondary',
        dpIconContainer: 'block pl-10 mdl:pl-15',
        dpIcon:'w-9 fill-current text-lightGreyBlue mdl:text-accent',
        dpItems:'flex flex-col flex-wrap border-lightGreyBlue border border-t-0 mdl:border mdl:px-15 mdl:pl-5 absolute z-10 mdl:top-40 bg-white w-175 mdl:w-max mdl:shadow-lightestGrey',
        dpItem:'font-neutrafaceBook text-22 leading-30 text-secondary px-20 py-12',
        dropDownIcon:'ChevronArrowDown'
    },
    WriteAReviewMonthDP:{
        wrapper: 'w-full relative',
        titleContainer:'border-lightGreyBlue border px-15 h-46 rounded-md flex items-center w-full',
        title:'flex justify-between w-full items-center text-left font-neutrafaceDemi text-20 leading-26 text-secondary',
        dpIconContainer: 'block ml-10 mdl:ml-15',
        dpIcon:'w-15 fill-current text-accent',
        dpItems:'w-full flex flex-col flex-nowrap border-lightGreyBlue border border-t-0 mdl:border mdl:px-15 absolute z-10 mdl:top-46 bg-white mdl:shadow-lightestGrey h-300 overflow-y-scroll',
        dpItem:'font-neutrafaceBook text-20 leading-26 text-secondary px-20 py-12 w-full',
        dropDownIcon:'ChevronArrowDown'
    },
}
