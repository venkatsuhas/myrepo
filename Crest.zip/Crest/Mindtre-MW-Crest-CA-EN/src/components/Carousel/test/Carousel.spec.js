import React, { useState as useStateMock, useEffect as useEffectMock } from "react"
import { shallow } from "enzyme"
import Carousel from "@components/Carousel"

jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useEffect: jest.fn(),
   
}))

describe("Carousel Component", () => {
    it("Should render Carousel component", () => {
        const setChildrenPerPage = jest.fn()
        const props = {
            callBack: jest.fn(),
            variant: "articleCard",
           
        }
        const mockState = {
            childrenPerPage: 1,
        }
        useStateMock.mockImplementation(() => [mockState.childrenPerPage, setChildrenPerPage])
        useEffectMock.mockImplementationOnce((func) => func())
        const wrapper = shallow(
            <Carousel {...props}>
                <div></div>
            </Carousel>
        )
      
        expect(wrapper).toBeTruthy()
    })

    it("Should render Carousel component", () => {
        const setCarouselState = jest.fn()
        const props = {
        
            callBack: jest.fn(),
            variant: "articleCard",
        }
        const mockState = {
            carouselState: 0,
            childrenPerPage: 1,
        }
        useStateMock.mockImplementation(() => [mockState.carouselState, setCarouselState])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
     
        const wrapper = shallow(
            <Carousel {...props}>
                <div></div>
            </Carousel>
        )    
        expect(wrapper).toBeTruthy()
    })
})
