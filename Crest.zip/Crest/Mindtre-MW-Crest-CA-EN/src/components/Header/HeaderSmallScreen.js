import React, { useState, useEffect, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"

const Button = dynamic(() => import("@components/Button"))
const Accordion = dynamic(() => import("@components/Accordion"))

const HeaderSmallScreen = ({ menuSlots, toggleMenu }) => {
    const [openAccordion, setOpenAccordion] = useState(null)

    const accordionClick = useCallback((value) => {
        setOpenAccordion((prevOpenAccordion) => {
            if (prevOpenAccordion === value) {
                return null
            } else {
                return value
            }
        })
    }, [])

    useEffect(() => {
        document.body.classList.add("overflow-hidden")
        return () => {
            document.body.classList.remove("overflow-hidden")
        }
    }, [])

    return (
        <div>
            {menuSlots?.length > 0 && (
                <div className='headeraccorWrap'>
                    {menuSlots.map((menuSlot) => {
                        return (
                            <div key={menuSlot.sys}>
                                {menuSlot.menuItems && menuSlot.menuItems.length > 0 ? (
                                    <Accordion
                                        key={menuSlot.sys}
                                        open={openAccordion === menuSlot?.title}
                                        title={menuSlot?.title}
                                        toggleOpen={() => {
                                            accordionClick(menuSlot?.title)
                                        }}
                                        variant='header'>
                                        <div>
                                            {menuSlot.viewAllLinkText && (
                                                <Button
                                                    href={menuSlot?.viewAllLink || null}
                                                    gaClass='event_menu_click'
                                                    gaLabel={menuSlot.viewAllLinkText}
                                                    onClick={toggleMenu}
                                                    className='text-18 leading-22 font-neutrafaceDemi text-secondary mb-20 flex mt-10'>
                                                    {menuSlot.viewAllLinkText}
                                                </Button>
                                            )}
                                            {menuSlot.menuItems &&
                                                menuSlot.menuItems.map((menuItem) => (
                                                    <div key={menuItem.sys}>
                                                        <p className='text-18 leading-22 font-neutrafaceDemi text-secondary mb-20'>
                                                            {menuItem.title}
                                                        </p>
                                                        <div className='mb-30'>
                                                            {menuItem &&
                                                                menuItem.subMenu &&
                                                                menuItem.subMenu.length > 0 &&
                                                                menuItem.subMenu.map(({ title, link, sys }) => (
                                                                    <div
                                                                        key={sys}
                                                                        className='text-18 pl-30 leading-40 font-neutrafaceBook text-secondary'>
                                                                        <Button
                                                                            href={link}
                                                                            gaClass='event_menu_click'
                                                                            gaLabel={title}
                                                                            onClick={toggleMenu}>
                                                                            {title}
                                                                        </Button>
                                                                    </div>
                                                                ))}
                                                        </div>
                                                    </div>
                                                ))}
                                        </div>
                                    </Accordion>
                                ) : (
                                    <Button
                                        href={menuSlot?.viewAllLink || null}
                                        gaClass='event_menu_click'
                                        gaLabel={menuSlot.title}
                                        onClick={toggleMenu}
                                        className='flex px-20 py-20'>
                                        {menuSlot.title}
                                    </Button>
                                )}
                            </div>
                        )
                    })}
                </div>
            )}
        </div>
    )
}
HeaderSmallScreen.propTypes = {
    menuSlots: PropTypes.array,
    toggleMenu: PropTypes.func.isRequired,
}

HeaderSmallScreen.defaultProps = {
    locale:'',
    styles:'',
    menuSlots:[],

}

export default memo(HeaderSmallScreen)
