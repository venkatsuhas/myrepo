import React,{ useState as useStateMock, useEffect as useEffectMock,  useRef as useRefMock  }  from "react"
import { shallow } from "enzyme"
import Header from "@components/Header/index"
jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useRef: jest.fn(),
    useEffect: jest.fn(),
}))

describe("Header component", () => {
    const setModalOpen = jest.fn()
    const setOpenAccordion = jest.fn()
    const setIsSearch = jest.fn()
    const changeSelectedIndex = jest.fn()
    let wrapper
    let props = [
        {
            brandLogo: {
                sys: 'lJLfpjuMu8YcWsQxnRkh3',
                url: 'lJLfpjuMu8YcWsQxnRkh3/19071636bb2ef3500d8e41c756629fa8/d_crest_logo_original.png',
                altText: 'Header Brand Logo',
                height: 100,
                width: 208
            },
            locale:"en-ca",
            menuSlots: [
                {
                    sys: '1I5eZObbbyChn7tOL2C7Vb',
                    title: 'SHOP PRODUCTS',
                    viewAllLink: '/',
                    viewAllLinkText: 'View All',
                    menuItems: [
                        {
                            sys: '6DkqIqwUuDd6xupVoBuoTQ',
                            link: '/en-ca/oral-care-products/toothpaste',
                            title: 'Toothpaste',
                            subMenu: null
                        },
                        {
                            sys: '73wBJ0rz0zUE7hfPKdrrfl',
                            link: '/en-ca/oral-care-products/mouthwash',
                            title: 'Mouthwash',
                            subMenu: null
                        },
                    ],
                    menuImage: { 
                        sys: '2fCiG0ZNFKLd2lQ8K9anR',
                        url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
                        altText: 'about Us image',
                        height: 318,
                        width: 361
                    }
                },
                {
                    sys: 'cc0fhOZ1nTVxjrq0qz0r5',
                    title: 'ORAL CARE TIPS',
                    viewAllLink: '/en-ca/oral-care-tips',
                    viewAllLinkText: 'View All',
                    menuItems: [
                        {
                            sys: '6DkqIqwUuDd6xupVoBuoTQ',
                            link: '/en-ca/oral-care-products/toothpaste',
                            title: 'Toothpaste',
                            subMenu: null
                        },
                        {
                            sys: '73wBJ0rz0zUE7hfPKdrrfl',
                            link: '/en-ca/oral-care-products/mouthwash',
                            title: 'Mouthwash',
                            subMenu: null
                        },
                    ],
                    menuImage: null
                },
  
            ],

        }
       
    ]

    Object.defineProperty(global.document, 'getElementById', { value: jest.fn().mockImplementation((type,callback)=>{ 
        if(typeof callback === 'function'){
            callback({ target: "ref" })
        }
    }) 
    })
   
    const mockState = {
        openAccordion: false,
        // modalOpen: false,
    }
    useStateMock.mockImplementation(() => [mockState.openAccordion, setOpenAccordion])
    useEffectMock.mockImplementation((func) => {
        const output = func()
        if(typeof output === 'function'){
            output()
        }
    })

    const mockkState = {
        modalOpen: false,
    }
    useStateMock.mockImplementation(() => [mockkState, setModalOpen])
    useEffectMock.mockImplementationOnce((func) => func())

    beforeEach(() => {
        wrapper = shallow(<Header {...props[0]} title={"Card"} locale={"en-ca"} />)
        expect(wrapper).toBeTruthy()
    })

    props.forEach((prop) => {
        it(`should render if the style is ${prop.styles ? prop.styles : "default"}`, () => {
            const component = shallow(<Header {...prop} locale={""} />)
            expect(component).toBeTruthy()
        })
    })

    it('should render Header Selector', () => {
        const mockState = {
            isSearch: false,
        }
        
        useStateMock.mockImplementation(() => [mockState.isSearch, setIsSearch])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
    })

    it('should render Header Selector - useref', () => {
        const mockState = {
            selMenuIndex: false,
        }

        let props = [
            {
                brandLogo: {
                    sys: 'lJLfpjuMu8YcWsQxnRkh3',
                    url: 'lJLfpjuMu8YcWsQxnRkh3/19071636bb2ef3500d8e41c756629fa8/d_crest_logo_original.png',
                    altText: 'Header Brand Logo',
                    height: 100,
                    width: 208
                },
                locale:"en-ca",
                menuSlots: [
                    {
                        sys: '1I5eZObbbyChn7tOL2C7Vb',
                        title: 'SHOP PRODUCTS',
                        viewAllLink: '/',
                        viewAllLinkText: 'View All',
                        menuItems: [
                            {
                                sys: '6DkqIqwUuDd6xupVoBuoTQ',
                                link: '/en-ca/oral-care-products/toothpaste',
                                title: 'Toothpaste',
                                subMenu: null
                            },
                            {
                                sys: '73wBJ0rz0zUE7hfPKdrrfl',
                                link: '/en-ca/oral-care-products/mouthwash',
                                title: 'Mouthwash',
                                subMenu: null
                            },
                        ],
                        menuImage: { 
                            sys: '2fCiG0ZNFKLd2lQ8K9anR',
                            url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
                            altText: 'about Us image',
                            height: 318,
                            width: 361
                        }
                    },
                    {
                        sys: 'cc0fhOZ1nTVxjrq0qz0r5',
                        title: 'ORAL CARE TIPS',
                        viewAllLink: '/en-ca/oral-care-tips',
                        viewAllLinkText: 'View All',
                        menuItems: [
                            {
                                sys: '6DkqIqwUuDd6xupVoBuoTQ',
                                link: '/en-ca/oral-care-products/toothpaste',
                                title: 'Toothpaste',
                                subMenu: null
                            },
                            {
                                sys: '73wBJ0rz0zUE7hfPKdrrfl',
                                link: '/en-ca/oral-care-products/mouthwash',
                                title: 'Mouthwash',
                                subMenu: null
                            },
                        ],
                        menuImage: null
                    },
      
                ],
    
            }
           
        ]
        
        useStateMock.mockImplementation(() => [mockState.selMenuIndex, changeSelectedIndex])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
        
        useRefMock.mockImplementation(()=>({ current: 'ref' }))
        wrapper = shallow(<Header {...props}  />)
        expect(wrapper).toBeTruthy()
    })
    props.forEach((prop) => {
        it(`should render if the style is ${prop.styles ? prop.styles : "default"}`, () => {
            const component = shallow(<Header {...prop}  />)
            expect(component).toBeTruthy()
        })
    })

})