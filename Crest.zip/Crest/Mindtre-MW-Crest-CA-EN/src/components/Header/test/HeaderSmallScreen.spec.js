import React,{ useState as useStateMock, useEffect as useEffectMock }  from "react"
import { shallow } from "enzyme"
import HeaderSmallScreen from "@components/Header/HeaderSmallScreen"
jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useEffect: jest.fn(),
}))

describe("HeaderSmallScreen component", () => {
    const setOpenAccordion = jest.fn()
    let wrapper
    let props = [
        {
            toggleMenu:jest.fn(),
            brandLogo: {
                sys: 'lJLfpjuMu8YcWsQxnRkh3',
                url: 'lJLfpjuMu8YcWsQxnRkh3/19071636bb2ef3500d8e41c756629fa8/d_crest_logo_original.png',
                altText: 'Header Brand Logo',
                height: 100,
                width: 208
            },
            locale:"en-ca",
            menuSlots: [
                {
                    sys: '1I5eZObbbyChn7tOL2C7Vb',
                    title: 'SHOP PRODUCTS',
                    viewAllLink: '/',
                    viewAllLinkText: 'View All',
                    menuItems: [
                        {
                            sys: '6DkqIqwUuDd6xupVoBuoTQ',
                            link: '/en-ca/oral-care-products/toothpaste',
                            title: 'Toothpaste',
                            subMenu: null
                        },
                        {
                            sys: '73wBJ0rz0zUE7hfPKdrrfl',
                            link: '/en-ca/oral-care-products/mouthwash',
                            title: 'Mouthwash',
                            subMenu: null
                        },
                    ],
                    menuImage: { 
                        sys: '2fCiG0ZNFKLd2lQ8K9anR',
                        url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
                        altText: 'about Us image',
                        height: 318,
                        width: 361
                    }
                },
                {
                    sys: 'cc0fhOZ1nTVxjrq0qz0r5',
                    title: 'ORAL CARE TIPS',
                    viewAllLink: '/en-ca/oral-care-tips',
                    viewAllLinkText: 'View All',
                    menuItems: [
                        {
                            sys: '6DkqIqwUuDd6xupVoBuoTQ',
                            link: '/en-ca/oral-care-products/toothpaste',
                            title: 'Toothpaste',
                            subMenu: null
                        },
                        {
                            sys: '73wBJ0rz0zUE7hfPKdrrfl',
                            link: '/en-ca/oral-care-products/mouthwash',
                            title: 'Mouthwash',
                            subMenu: null
                        },
                    ],
                    menuImage: null
                },
            
            ],

        }
       
    ]
    const mockState = {
        openAccordion: false,
     
    }
    useStateMock.mockImplementation(() => [mockState, setOpenAccordion])
    useEffectMock.mockImplementationOnce((func) => func())

    beforeEach(() => {
        window.scrollTo = jest.fn()
        wrapper = shallow(<HeaderSmallScreen {...props[0]} title={"Card"} locale={"en-ca"} />)
        expect(wrapper).toBeTruthy()
    })

    props.forEach((prop) => {
        it(`should render if the style is ${prop.styles ? prop.styles : "default"}`, () => {
            const component = shallow(<HeaderSmallScreen {...prop} locale={""} />)
            expect(component).toBeTruthy()
        })
    })
})
