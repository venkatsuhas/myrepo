import React, { useEffect, useState, useRef, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"

const Button = dynamic(() => import("@components/Button"))
const Icon = dynamic(() => import("@components/Icon"))
const Image = dynamic(() => import("@components/Image"))
const Search = dynamic(() => import("@components/Search"))
const HeaderSmallScreen = dynamic(() => import("@components/Header/HeaderSmallScreen"))

const Header = ({ brandLogo, menuSlots, locale }) => {
    const [isSearch, setIsSearch] = useState(false)
    const [isMenuOpen, setIsMenuOpen] = useState(false)
    const [isSticky, setStickyStatus] = useState(false)
    const [selMenuIndex, changeSelectedIndex] = useState(null)
    const indexRef = useRef(selMenuIndex)

    const toggleMenu = useCallback(() => {
        setIsMenuOpen((prevIsMenuOpen) => !prevIsMenuOpen)
    }, [])

    const handleEnter = useCallback((menuIndex) => {
        indexRef.current = menuIndex
        changeSelectedIndex(menuIndex)
        const element = document.getElementById("navBar")
        element.classList.add("menuEntered")
    }, [])

    const handleLeave = useCallback(() => {
        changeSelectedIndex(null)
        const element = document.getElementById("navBar")
        element.classList.remove("menuEntered")
        if (window.scrollY > 0) {
            element.classList.add("menuEntered")
        }
    }, [])

    const searchHandler = useCallback(() => {
        setIsSearch((prevIsSearch) => !prevIsSearch)
    }, [])

    const scrollHandler = useCallback(() => {
        if (typeof window !== "undefined") {
            const currentScroll = window.pageYOffset
            const scrollDirection = (currentScroll > 0 && currentScroll - window.lastScrollPosition >= 0) || currentScroll === 0 ? "down" : "up"
            window.lastScrollPosition = currentScroll
            setStickyStatus(scrollDirection === "down" ? false : true)
        }
    }, [])

    useEffect(() => {
        if (typeof window !== undefined) {
            window.lastScrollPosition = 0
            window.addEventListener("scroll", scrollHandler)
        }
        return () => {
            window.removeEventListener("scroll", scrollHandler)
        }
    }, [])

    return (
        <header>
            <div id='navBar' className={`mdl:bg-darkBlue relative ${isSticky ? "header-sticky" : "header-non-sticky"}`}>
                <div className='flex justify-between bg-darkBlue mdl:bg-transparent h-55 mx-auto w-full px-20 lg:w-lg mxl:w-mxl xl:w-xl lg:px-0 mdl:h-72 items-center'>
                    <div className={`mdl:hidden h-24 ${isMenuOpen ? "menuOpen" : "menuClose"}`}>
                        <Button onClick={toggleMenu} gaClass='event_menu_click' gaLabel='Menu' className='relative' name='Hamburger'>
                            <span className='sr-only'>Hamburger</span>
                            <div className='hamburger w-20 h-20' id='hamburger-1'>
                                <span className='line'></span>
                                <span className='line'></span>
                                <span className='line'></span>
                            </div>
                        </Button>
                    </div>
                    {brandLogo && (
                        <Button href={`/${locale?.toLowerCase()}`} gaClass='event_image_click' gaLabel='Home' onClick={handleLeave} className=''>
                            <div>
                                <Image
                                    key={brandLogo.sys}
                                    desktopClassName=''
                                    wrapperClassName='w-93 mdl:w-150 mdl:mr-42'
                                    desktopImage={brandLogo}
                                    alt={brandLogo?.altText}
                                    priority={true}
                                />
                            </div>
                        </Button>
                    )}
                    <div className='hidden mdl:w-7/12 mdl:flex h-full items-center'>
                        {menuSlots?.length > 0 &&
                            menuSlots.map((menuSlot, menuIndex) => {
                                return (
                                    <div
                                        key={menuSlot.sys}
                                        onMouseOver={() => handleEnter(menuIndex)}
                                        onFocus={() => handleEnter(menuIndex)}
                                        onMouseLeave={handleLeave}
                                        onKeyDown={() => null}
                                        role='presentation'
                                        className={"h-full flex items-center"}>
                                        <Button
                                            onClick={handleLeave}
                                            gaLabel={menuSlot.title}
                                            gaClass='event_menu_click'
                                            href={menuSlot?.viewAllLink || null}
                                            className='pr-40 text-16 leading-22 uppercase font-neutrafaceBook text-white mdl:text-center lg:text-left'>
                                            {menuSlot.title}
                                        </Button>
                                        {selMenuIndex === menuIndex && menuSlot.menuItems && menuSlot.menuItems.length > 0 && (
                                            <div className='subMenu w-full absolute left-0 mdl:top-66 pt-20 bg-white z-10'>
                                                <div className='relative'>
                                                    <div className='subMenuWrap flex mx-auto w-full px-20 lg:w-lg mxl:w-mxl xl:w-xl lg:px-0 lg:min-h-400'>
                                                        {menuSlot.viewAllLinkText && (
                                                            <div className='w-full mdl:w-3/12'>
                                                                <Button
                                                                    onClick={handleLeave}
                                                                    gaClass='event_menu_click'
                                                                    gaLabel={menuSlot.viewAllLinkText}
                                                                    href={menuSlot?.viewAllLink || null}
                                                                    className='text-18 leading-22 uppercase font-neutrafaceBold mdl:pt-50 mdl:inline-flex'>
                                                                    {menuSlot.viewAllLinkText}
                                                                </Button>
                                                            </div>
                                                        )}
                                                        <div className='flex mdl:w-6/12 mdl:pt-50'>
                                                            {menuSlot.menuItems &&
                                                                menuSlot.menuItems.map((menuItem) => (
                                                                    <div
                                                                        key={menuItem.sys}
                                                                        className={
                                                                            menuIndex === menuSlots?.length - 1
                                                                                ? "aboutmenu"
                                                                                : "categoryMenu mdl:w-4/12 mdl:px-15"
                                                                        }>
                                                                        {menuItem.title && (
                                                                            <p className='text-18 leading-30 font-neutrafaceDemi text-secondary mb-20'>
                                                                                {menuItem.title}
                                                                            </p>
                                                                        )}
                                                                        <div>
                                                                            {menuItem &&
                                                                                menuItem.subMenu &&
                                                                                menuItem.subMenu.length > 0 &&
                                                                                menuItem.subMenu.map(({ title, link, sys }) => (
                                                                                    <div key={sys}>
                                                                                        <Button
                                                                                            href={link}
                                                                                            onClick={handleLeave}
                                                                                            gaClass='event_menu_click'
                                                                                            gaLabel={title}
                                                                                            className='text-18 leading-30 font-neutrafaceBook text-secondary mb-12 inline-flex'>
                                                                                            {title}
                                                                                        </Button>
                                                                                    </div>
                                                                                ))}
                                                                        </div>
                                                                    </div>
                                                                ))}
                                                        </div>
                                                        {menuSlot.menuImage && (
                                                            <div className='mdl:w-250 lg:w-350 mdl:absolute mdl:right-0 mdl:bottom-0'>
                                                                <Image
                                                                    key={menuSlot.menuImage.sys}
                                                                    desktopClassName=''
                                                                    wrapperClassName='mdl:w-250 lg:w-350'
                                                                    desktopImage={menuSlot.menuImage}
                                                                    alt={menuSlot.menuImage?.altText}
                                                                    priority={true}
                                                                />
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )
                            })}
                    </div>
                    <div className='searchWrap mdl:w-3/12 flex mdl:pl-25 mdl:justify-end'>
                        <Button onClick={searchHandler} gaClass='event_search' gaLabel='Search' name='Search'>
                            <span className='sr-only'>Search</span>
                            <Icon name={"Search"} className='searchMenuIcon' />
                        </Button>
                        {isSearch && <Search locale={locale} closeHandler={searchHandler} />}
                    </div>
                </div>
                {isMenuOpen && (
                    <div className='absolute pt-10 top-55 z-30 bg-white w-full mdl:hidden'>
                        <HeaderSmallScreen menuSlots={menuSlots} toggleMenu={toggleMenu} />
                    </div>
                )}
            </div>
            <div className={isSticky ? "h-55 mdl:h-72" : "hidden"}></div>
        </header>
    )
}

Header.propTypes = {
    locale: PropTypes.string,
    menuSlots: PropTypes.array,
    brandLogo: PropTypes.object,
}

Header.defaultProps = {
    locale:'',
    styles:'',
    menuSlots:[],
    brandLogo:{}
}

export default memo(Header)
