import React from "react"
import { shallow } from "enzyme"
import Breadcrumb from '@components/Breadcrumb'

jest.mock("next/router", () => ({
    ...jest.requireActual("next/router"),
    useRouter: jest.fn().mockImplementation(()=>({ asPath: "/en-ca/oral-care-products#product?type=all" }))
}))

describe("Breadcrumb Component", () => {
    it("should render for Breadcrumb", () => {
        const defaultProps = {
            breadcrumb: [
                {
                    sys: "home",
                    url: "/en-ca",
                    title: "Home"
                },
                {
                    sys: "products",
                    url: "/en-ca/oral-care-products",
                    title: "Products",
                }
            ]
        }
        const wrapper = shallow(<Breadcrumb {...defaultProps} />)
        expect(wrapper).toBeTruthy()
    })
})