import React, { useMemo, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { useRouter } from "next/router"

const Button = dynamic(()=>import("@components/Button"))
const Icon = dynamic(()=>import("@components/Icon"))

const Breadcrumb = ({ breadcrumb: breadcrumbs }) => {
    const router = useRouter()
    const currentPath = useMemo(()=>decodeURI(router?.asPath?.replace(/(.*)\?.*/g,(...node)=>node[1]).replace(/(.*)#.*/g,(...node)=>node[1])), [router?.asPath])
    
    return (
        <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl px-20 lg:px-0 mdl:z-1 mdl:relative'>
            <ul className='flex flex-row flex-wrap justify-start items-center py-15'>
                {breadcrumbs.map((breadcrumb, index) => {
                    const Component =
                        currentPath !== breadcrumb.url ? Button : "p"
                    const props =
                        currentPath !== breadcrumb.url
                            ? {
                                href: breadcrumb.url,
                                title: breadcrumb.title,
                                gaClass: "event_internal_link",
                                "data-action-detail": breadcrumb.title,
                                "data-pgaction-redirection": "0",
                            }
                            : {}
                    return (<li className='flex items-center justify-start' key={breadcrumb.sys}>
                        <Component
                            {...props}
                            itemProp='name'
                            className={`font-neutrafaceBook text-14 leading-20 text-primary capitalize block ${currentPath !== breadcrumb.url ? "text-opacity-100" : "text-opacity-80"}`}
                        >
                            {breadcrumb.title}
                        </Component>
                        {currentPath !== breadcrumb.url && (
                            <Icon
                                name='ChevronArrow'
                                className='w-10 h-10 inline-block mx-11 transform -rotate-90 fill-none stroke-current stroke-2'
                            />
                        )}
                        <meta itemProp='position' content={index + 1} />
                    </li>
                    )
                })}
            </ul>
        </div>
    )
}

Breadcrumb.propTypes = {
    breadcrumb: PropTypes.arrayOf(
        PropTypes.shape({
            sys: PropTypes.string,
            title: PropTypes.string,
            url: PropTypes.string,
        })
    ),
}

export default memo(Breadcrumb)
