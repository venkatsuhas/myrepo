import React,{ useState as useStateMock, useEffect as useEffectMock }  from "react"
import { shallow } from "enzyme"
import Footer from "../index"
jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useEffect: jest.fn(),
}))

describe("CategoryCard component", () => {
    const setModalOpen = jest.fn()
    const setOpenAccordion = jest.fn()
    let wrapper
    let props = [
        {
            menuSlots: [
                {
                    sys: '1I5eZObbbyChn7tOL2C7Vb',
                    title: 'SHOP PRODUCTS',
                    viewAllLink: '/',
                    viewAllLinkText: 'View All',
                    menuItems: [
                        {
                            sys: '6DkqIqwUuDd6xupVoBuoTQ',
                            link: '/en-ca/oral-care-products/toothpaste',
                            title: 'Toothpaste',
                            subMenu: null
                        },
                        {
                            sys: '73wBJ0rz0zUE7hfPKdrrfl',
                            link: '/en-ca/oral-care-products/mouthwash',
                            title: 'Mouthwash',
                            subMenu: null
                        },
                    ],
                    menuImage: { 
                        sys: '2fCiG0ZNFKLd2lQ8K9anR',
                        url: '2fCiG0ZNFKLd2lQ8K9anR/ff4a1c932cc79c7672cd124032ee2ea4/nav-aboutus.png',
                        altText: 'about Us image',
                        height: 318,
                        width: 361
                    }
                },
                {
                    sys: 'cc0fhOZ1nTVxjrq0qz0r5',
                    title: 'ORAL CARE TIPS',
                    viewAllLink: '/en-ca/oral-care-tips',
                    viewAllLinkText: 'View All',
                    menuItems: [
                        {
                            sys: '6DkqIqwUuDd6xupVoBuoTQ',
                            link: '/en-ca/oral-care-products/toothpaste',
                            title: 'Toothpaste',
                            subMenu: null
                        },
                        {
                            sys: '73wBJ0rz0zUE7hfPKdrrfl',
                            link: '/en-ca/oral-care-products/mouthwash',
                            title: 'Mouthwash',
                            subMenu: null
                        },
                    ],
                    menuImage: null
                },
  
            ],
            footerLinks: [
                {
                    sys: '7Hv1PWfGoycXD2njtvxcy7',
                    url: 'https://privacypolicy.pg.com/en/',
                    title: 'Privacy'
                },
                {
                    sys: '3CPLRXM4UuBv8vOTX327IS',
                    url: 'https://privacypolicy.pg.com/en/#CCPA',
                    title: 'CA Privacy'
                },
                {
                    sys: '6yo760MoycowgnyEYl9HV7',
                    url: 'https://termsandconditions.pg.com/en-us/',
                    title: 'T&C'
                },
                {
                    sys: '1RGk3quKwd7ofZOgHClYpP',
                    url: '/en-ca/sitemap',
                    title: 'Sitemap'
                }
            ],
            dentalCare:' DENTAL PROFESSIONAL? [Visit dentalcare.com](https://www.dentalcare.com/en-us)',
            locale:'en-ca',
            instaCard:{
                name: '#BringOnTheSmiles',
                title: '#BringOnTheSmiles',
                subTitle: 'Enabling healthier oral care habits',
                sys: '5hzxpDIAdYkwunPTAQp9tG',
                description: null,
                imageset: {
                    desktopImage: {
                        sys: '4AMAKGqs3Q9S4hl9IT5kxl',
                        url: '4AMAKGqs3Q9S4hl9IT5kxl/fb5cf6bbfabf1bf7ffc914117a1ab172/d-social-instagram.png',
                        altText: 'd-social-instagram',
                        height: 403,
                        width: 959
                    },
                    smartphoneImage: {
                        sys: '3sVjEtomGfKVyV8o1fBGEu',
                        url: '3sVjEtomGfKVyV8o1fBGEu/586cd05e555ca339a28d0a69a001dd67/m-social-instagram.jpg',
                        altText: 'm-social-instagram',
                        height: 1208,
                        width: 750
                    }
                },
                image: {
                    sys: '7ItJ23JHpRB8iQHf04eh6a',
                    url: '7ItJ23JHpRB8iQHf04eh6a/0be2105b6fbfc66acfac51a7be67e4c1/Instagram.svg',
                    altText: 'Instagram',
                    height: 32,
                    width: 32
                },
                href: null,
                linkText: null,
                cardLink: 'https://www.instagram.com/crest',
                styles: null
            }

        }
       
    ]
    const mockState = {
        openAccordion: true,
        // modalOpen: false,
    }
    useStateMock.mockImplementation(() => [mockState, setOpenAccordion])
    useEffectMock.mockImplementationOnce((func) => func())

    const mockkState = {
        modalOpen: true,
    }
    useStateMock.mockImplementation(() => [mockkState, setModalOpen])
    useEffectMock.mockImplementationOnce((func) => func())

    beforeEach(() => {
        wrapper = shallow(<Footer {...props[0]} title={"Card"} locale={"en-ca"} />)
        expect(wrapper).toBeTruthy()
    })

    props.forEach((prop) => {
        it(`should render if the style is ${prop.styles ? prop.styles : "default"}`, () => {
            const component = shallow(<Footer {...prop} locale={""} />)
            expect(component).toBeTruthy()
        })
    })
})
