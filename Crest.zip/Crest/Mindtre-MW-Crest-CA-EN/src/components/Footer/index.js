import React, { useState, useCallback, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { copyRight, siteCountries } from "@constants"

const Accordion = dynamic(() => import("@components/Accordion"))
const Button = dynamic(() => import("@components/Button"))
const CountrySelector = dynamic(() => import("@components/CountrySelector"))
const FooterIcons = dynamic(() => import("@components/FooterIcons"))
const Icon = dynamic(() => import("@components/Icon"))
const InstaCard = dynamic(() => import("@components/Card/InstaCard"))
const Typography = dynamic(() => import("@components/Typography"))

const Footer = ({ menuSlots, footerLinks, dentalCare, locale, instaCard }) => {
    const [openAccordion, setOpenAccordion] = useState(null)
    const [modalOpen, setModalOpen] = useState(false)

    const accordionClick = useCallback((value) => {
        setOpenAccordion((prevOpenAccordion) => {
            if (prevOpenAccordion === value) {
                return null
            } else {
                return value
            }
        })
    }, [])

    const openModal = useCallback(() => {
        setModalOpen(true)
    }, [])

    const closeModal = useCallback(() => {
        setModalOpen(false)
    }, [])

    return (
        <div className='footerwrapper'>
            {instaCard && <InstaCard instaCard={instaCard} cardStyles='homepageInstaCard' />}
            <footer className='footer pt-20 mdl:pt-80 pb-30 px-0 mdl:px-20'>
                <div className='mx-auto w-full lg:w-lg mxl:w-mxl xl:w-xl'>
                    <div className='flex flex-wrap'>
                        <div className='hidden mdl:w-9/12 mdl:flex mdl:flex-wrap'>
                            {menuSlots?.length > 0 &&
                                menuSlots.map((menuSlot) => {
                                    return (
                                        <div key={menuSlot.sys} className='mdl:w-3/12 mdl:pr-30'>
                                            <h4 className='text-18 leading-22 uppercase font-neutrafaceBold mb-28 text-lightWhite'>
                                                {menuSlot.title}
                                            </h4>
                                            <ul>
                                                {menuSlot.menuItems &&
                                                    menuSlot.menuItems.length > 0 &&
                                                    menuSlot.menuItems.map((menuItem) => (
                                                        <li key={menuItem.sys} className='mb-23'>
                                                            <Button
                                                                href={menuItem.link || null}
                                                                gaClass='event_internal_link'
                                                                gaLabel={menuItem.title || null}
                                                                className='text-lightWhite text-18 leading-22 font-neutrafaceBook '>
                                                                {menuItem.title}
                                                            </Button>
                                                        </li>
                                                    ))}
                                                {menuSlot.viewAllLink && (
                                                    <li>
                                                        <Button
                                                            gaClass='event_internal_link'
                                                            gaLabel={menuSlot?.viewAllLink || null}
                                                            href={menuSlot?.viewAllLink || null}
                                                            className='text-lightWhite text-18 leading-22 font-neutrafaceBook '>
                                                            {menuSlot?.viewAllLinkText || null}
                                                        </Button>
                                                    </li>
                                                )}
                                            </ul>
                                        </div>
                                    )
                                })}
                        </div>
                        <div className='w-full mdl:hidden mb-50'>
                            {menuSlots?.length > 0 &&
                                menuSlots.map((menuSlot) => {
                                    return (
                                        <div key={menuSlot.sys} className='border-b border-dotsBlue mx-20 '>
                                            {menuSlot.menuItems && menuSlot.menuItems.length > 0 ? (
                                                <Accordion
                                                    key={menuSlot.sys}
                                                    open={openAccordion === menuSlot?.title}
                                                    title={menuSlot?.title}
                                                    toggleOpen={() => {
                                                        accordionClick(menuSlot?.title)
                                                    }}
                                                    variant='footer'>
                                                    <ul className='footerItem mb-30 mt-14 mdl:mt-0'>
                                                        {menuSlot.menuItems &&
                                                            menuSlot.menuItems.length > 0 &&
                                                            menuSlot.menuItems.map((menuItem) => (
                                                                <li key={menuItem.sys} className='linkItem mb-23'>
                                                                    <Button
                                                                        href={menuItem.link || null}
                                                                        gaClass='event_internal_link'
                                                                        gaLabel={menuItem.title}
                                                                        className='text-lightWhite text-18 leading-22 font-neutrafaceBook tracking-normal'>
                                                                        {menuItem.title}
                                                                    </Button>
                                                                </li>
                                                            ))}
                                                        {menuSlot.viewAllLink && (
                                                            <li className='linkItem mb-23'>
                                                                <Button
                                                                    href={menuSlot?.viewAllLink || null}
                                                                    gaClass='event_internal_link'
                                                                    gaLabel={menuSlot?.viewAllLink}
                                                                    className='text-lightWhite'>
                                                                    {menuSlot?.viewAllLinkText || null}
                                                                </Button>
                                                            </li>
                                                        )}
                                                    </ul>
                                                </Accordion>
                                            ) : (
                                                <Button href={menuSlot?.viewAllLink || null} gaClass='event_internal_link' gaLabel={menuSlot.title}>
                                                    {menuSlot.title}
                                                </Button>
                                            )}
                                        </div>
                                    )
                                })}
                        </div>
                        <div className='w-full mdl:w-3/12'>
                            <FooterIcons />
                        </div>
                    </div>
                    <Typography
                        component='div'
                        content={dentalCare}
                        className='dentalCare text-18 leading-22 font-neutrafaceBook mb-54 text-lightWhite text-center mdl:flex mdl:justify-center mdl:mb-52 event_outbound_link'
                    />
                    <div className='mdl:flex'>
                        <div className='mdl:w-9/12 mdl:flex mdl:flex-wrap'>
                            <div className='countrySelector mb-30 px-20 mdl:pl-0 mdl:pr-30 mdl:mb-0 text-lightWhite text-16 leading-20 font-neutrafaceBook'>
                                <Button gaClass='event_button_click' gaLabel={siteCountries[locale?.toLowerCase()]} className='flex' onClick={openModal}>
                                    {siteCountries[locale?.toLowerCase()]}
                                    <Icon className='w-10 h-auto ml-5 mt-6 fill-current text-lightGreyBlue' name='DropDownArrow' />
                                </Button>
                            </div>
                            <div className='flex flex-wrap px-20 mdl:-mx-7 mb-30 mdl:w-auto mdl:px-0 mdl:mb-0'>
                                {footerLinks &&
                                    footerLinks.length > 0 &&
                                    footerLinks.map((footerLink) => (
                                        <div
                                            key={footerLink.sys}
                                            className='w-6/12 text-lightWhite mdl:px-7 mb-20 text-16 leading-20 font-neutrafaceBook mdl:w-auto mdl:pl-0 mdl:pr-30 mdl:mb-0'>
                                            <Button href={footerLink.url}>{footerLink.title}</Button>
                                        </div>
                                    ))}
                            </div>
                        </div>
                        <Typography
                            content={copyRight}
                            className='copyright px-20 text-lightWhite text-center text-16 leading-20 font-neutrafaceBook mdl:w-3/12 mdl:text-right mdl:px-0'
                        />
                    </div>
                </div>
                {modalOpen && <CountrySelector locale={locale} isOpen={modalOpen} closeModal={closeModal} />}
            </footer>
        </div>
    )
}

Footer.propTypes = {
    locale: PropTypes.string,
    menuSlots: PropTypes.array,
    dentalCare: PropTypes.string,
    footerLinks: PropTypes.array,
    instaCard: PropTypes.object,
}

Footer.defaultProps = {
    locale:'',
    menuSlots:[],
    dentalCare:'',
    footerLinks:[],
    instaCard:{}
}

export default memo(Footer)
