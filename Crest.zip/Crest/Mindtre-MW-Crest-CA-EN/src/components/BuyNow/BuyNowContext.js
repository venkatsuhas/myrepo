import { createContext } from 'react'

const BuyNowContext = createContext()

export default BuyNowContext