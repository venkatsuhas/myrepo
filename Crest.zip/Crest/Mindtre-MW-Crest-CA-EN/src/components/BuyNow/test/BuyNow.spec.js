import React, { useState as useStateMock, useEffect as useEffectMock } from "react"
import { shallow } from "enzyme"
import BuyNow from "@components/BuyNow"

jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useEffect: jest.fn(),
}))

Object.defineProperty(global.window, 'PriceSpider', { value: { rebind: jest.fn().mockImplementation(()=>true) }, writable: true })

describe("BuyNow Component", () => {
    it("Should render BuyNow component", () => {
        const setState = jest.fn()
        const props = {
            buyNowState: {
                sku: "BuyNow",
                open: false,
            },
            closeBuyNow: jest.fn(),
            locale: "en-ca",
        }
        const mockState = {
            firstLoad: false,
        }
        useStateMock.mockImplementation(() => [mockState.firstLoad, setState])
        useEffectMock.mockImplementation((func) => func())
        const wrapper = shallow(<BuyNow {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it("Should render BuyNow component", () => {
        const setState = jest.fn()
        const props = {
            buyNowState: {
                sku: "BuyNow",
                open: true,
            },
            closeBuyNow: jest.fn(),
            locale: "en-ca",
        }
        const mockState = {
            firstLoad: false,
        }
        useStateMock.mockImplementation(() => [mockState.firstLoad, setState])
        useEffectMock.mockImplementation((func) => func())
        const wrapper = shallow(<BuyNow {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it("Should render BuyNow component", () => {
        const setState = jest.fn()
        const props = {
            buyNowState: {
                sku: "BuyNow",
                open: true,
            },
            closeBuyNow: jest.fn(),
            locale: "en-ca",
        }
        const mockState = {
            firstLoad: true,
        }
        useStateMock.mockImplementation(() => [mockState.firstLoad, setState])
        useEffectMock.mockImplementation((func) => func())
        const wrapper = shallow(<BuyNow {...props} />)
        expect(wrapper).toBeTruthy()
    })

    it("Should render BuyNow component", () => {
        const setState = jest.fn()
        const props = {
            buyNowState: {
                sku: "BuyNow",
                open: false,
            },
            closeBuyNow: jest.fn(),
            locale: "en-ca",
        }
        const mockState = {
            firstLoad: true,
        }
        window.PriceSpider = null
        useStateMock.mockImplementation(() => [mockState.firstLoad, setState])
        useEffectMock.mockImplementation((func) => func())
        const wrapper = shallow(<BuyNow {...props} />)
        expect(wrapper).toBeTruthy()
    })
})
