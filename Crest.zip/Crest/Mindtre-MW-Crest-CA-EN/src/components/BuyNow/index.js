import React, { useState, useEffect, useCallback, memo } from 'react'
import PropTypes from 'prop-types'
import dynamic from 'next/dynamic'
import { labels } from '@constants'

const Button = dynamic(()=>import('@components/Button'))
const Icon = dynamic(()=>import('@components/Icon'))

const BuyNow = ({ buyNowState, closeBuyNow, locale }) => {
    const findRetailers = labels[locale.toLowerCase()]?.findRetailer
    const [firstLoad,setFirstLoad] = useState(false)

    useEffect(()=>{
        if(typeof window !== 'undefined' && window.PriceSpider && window.PriceSpider.rebind){
            window.PriceSpider.rebind()
        }
    },[buyNowState.sku])

    useEffect(()=>{
        if(!firstLoad && buyNowState.open)
            setFirstLoad(true)
        if(buyNowState.open){
            document.body.classList.add("overflow-hidden")
        }else{
            document.body.classList.remove("overflow-hidden")
        }
    },[buyNowState.open])

    const getWrapperClassName = useCallback(()=>{
        if(firstLoad){
            if(buyNowState.open){
                return 'animate-fromRight'
            }else{
                return 'animate-toRight'
            }
        }else{
            return 'hidden'
        }
    },[firstLoad, buyNowState.open])

    return (
        <div className={`w-full fixed top-0 right-0 h-screen z-50 bg-black bg-opacity-80 ${getWrapperClassName()}`}>
            <div className='w-full mdl:w-5/12 fixed top-0 right-0 h-screen bg-white z-50'>
                <div className='w-full'>
                    <Button onClick={closeBuyNow} gaClass='event_button_click' className='w-full relative flex flex-row justify-center items-center py-25 border-b border-lightWhite'>
                        <Icon className='absolute left-40 fill-none stroke-current stroke-2 text-secondary w-20 h-20 transform rotate-90' name='ChevronArrow'/>
                        <p className='font-neutrafaceBold text-22 leading-24 text-gradientDarkBlue text-center'>{findRetailers}</p>
                    </Button>
                </div>
                {buyNowState.sku && <div className='min-h-450'>
                    <div className='ps-widget' ps-config={process.env.PS_WIDGET_ID} ps-sku={buyNowState.sku}></div>
                </div>}
            </div>
        </div>
    )
}

BuyNow.propTypes = {
    buyNowState: PropTypes.shape({
        sku: PropTypes.string,
        open: PropTypes.bool.isRequired,
    }).isRequired,
    closeBuyNow: PropTypes.func.isRequired,
    locale: PropTypes.string.isRequired,
}

export default memo(BuyNow)
