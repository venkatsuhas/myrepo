import React, { useState, useRef, useEffect, memo } from "react"
import PropTypes from "prop-types"
import dynamic from "next/dynamic"
import { siteCountries } from "@constants"

const Icon = dynamic(() => import("@components/Icon"))
const Button = dynamic(() => import("@components/Button"))

const CountrySelector = ({ locale, closeModal }) => {
    const [outsideClick, setOutsideClick] = useState(false)
    const popUpNode = useRef()

    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (popUpNode.current && (popUpNode.current === event.target || popUpNode.current.contains(event.target))) {
                setOutsideClick(false)
            } else {
                setOutsideClick(true)
            }
        }

        document.addEventListener("mousedown", handleOutsideClick)
        return () => {
            document.removeEventListener("mousedown", handleOutsideClick)
        }
    }, [])

    useEffect(() => {
        if (outsideClick) {
            closeModal()
            setOutsideClick(false)
        }
    }, [outsideClick])

    useEffect(() => {
        document.body.classList.add("overflow-hidden")
        return () => {
            document.body.classList.remove("overflow-hidden")
        }
    }, [])

    return (
        <div className='CountrySelector-container  fixed z-50 overflow-y-auto inset-0 bg-countryOverlaybg flex items-center'>
            <div
                className='CountrySelector-wrapper px-20 w-full mdl:w-50p mdl:left-50p top-auto mdl:top-50p bottom-0 mdl:bottom-auto bg-white fixed top-0 left-0 overflow-hidden py-25 mdl:py-20'
                ref={popUpNode}>
                <div className='closeDiv float-right'>
                    <Button gaClass='event_button_click' onClick={closeModal}>
                        <Icon className='closeIcon' name='Close' />
                    </Button>
                </div>
                <div className='bodyDiv pt-40 mdl:pt-0'>
                    <div className='titleDiv text-center text-22 text-primary leading-24 font-neutrafaceBold mb-40'>{siteCountries.title}</div>
                    <div className='countryDiv w-full mdl:flex mdl:flex-wrap mdl:px-40 mb-50 mdl:mb-20'>
                        {siteCountries.items.map((country, index) => {
                            return (
                                <div key={index} className='eachCountryDiv w-full mb-30 mdl:mb-0 mdl:w-33p'>
                                    <Button gaClass='event_button_click' onClick={closeModal} href={country.url}>
                                        <Icon
                                            className='countryIcon mt-5'
                                            name={locale.toLowerCase() === country.locale ? "LocationDark" : "LocationLight"}
                                        />
                                        <div className='countryNameDiv ml-8'>
                                            <div className='countryName text-20 leading-26 text-left text-primary font-neutrafaceDemi'>
                                                {country.name}
                                            </div>
                                            <div className='countryLang text-16 leading-22 text-left text-secondary font-neutrafaceBook'>
                                                {country.lang}
                                            </div>
                                        </div>
                                    </Button>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        </div>
    )
}

CountrySelector.propTypes = {
    locale: PropTypes.string,
    closeModal: PropTypes.func,
}

export default memo(CountrySelector)
