import React, { useState as useStateMock, useEffect as useEffectMock, useRef as useRefMock } from "react"
import { shallow } from "enzyme"
import CountrySelector from "../index"

jest.mock("react", () => ({
    ...jest.requireActual("react"),
    useState: jest.fn(),
    useEffect: jest.fn(),
    useRef: jest.fn(),
}))

Object.defineProperty(global.document, 'addEventListener', { value: jest.fn().mockImplementation((type,callback)=>{ 
    if(typeof callback === 'function'){
        callback({ target: "ref" })
    }
}) 
})

String.prototype.contains = String.prototype.includes

describe("Country Selector component", () => {
    const setOutsideClick = jest.fn()
    let wrapper

    it('should render Country Selector', () => {
        const mockState = {
            outsideClick: false,
        }

        let props = {
            locale:"en-ca",
            closeModal: jest.fn(),
        }
        
        useStateMock.mockImplementation(() => [mockState.outsideClick, setOutsideClick])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
        
        useRefMock.mockImplementation(()=>({ current: 'ref' }))
        wrapper = shallow(<CountrySelector {...props}  />)
        expect(wrapper).toBeTruthy()
    })
    
    it('should render Country Selector', () => {
        const mockState = {
            outsideClick: true,
        }

        let props = {
            locale:"en-ca",
            closeModal: jest.fn(),
        }
        
        useStateMock.mockImplementation(() => [mockState.outsideClick, setOutsideClick])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
        useRefMock.mockImplementation(()=>({ current: 'reference' }))
        wrapper = shallow(<CountrySelector {...props}  />)
        expect(wrapper).toBeTruthy()
    })
    
    it('should render Country Selector', () => {
        const mockState = {
            outsideClick: true,
        }

        let props = {
            locale:"en-ca",
            closeModal: jest.fn(),
        }
        
        useStateMock.mockImplementation(() => [mockState.outsideClick, setOutsideClick])
        useEffectMock.mockImplementation((func) => {
            const output = func()
            if(typeof output === 'function'){
                output()
            }
        })
        useRefMock.mockImplementation(()=>({ current: null }))
        wrapper = shallow(<CountrySelector {...props}  />)
        expect(wrapper).toBeTruthy()
    })
})
