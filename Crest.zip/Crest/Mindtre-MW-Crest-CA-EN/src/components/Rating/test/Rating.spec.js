import React from "react"
import { shallow } from "enzyme"
import Rating from '@components/Rating'

describe('Rating Component', ()=>{
    it('Should render Rating component with no props',()=>{
        const wrapper=shallow(<Rating/>)
        expect(wrapper).toBeTruthy()
    })
    it('Should render Rating component with rating value',()=>{
        const wrapper=shallow(<Rating ratingValue={3.5} />)
        expect(wrapper).toBeTruthy()
    })
})
