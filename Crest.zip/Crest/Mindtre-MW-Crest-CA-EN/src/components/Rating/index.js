import React, { useMemo, memo } from "react"
import PropTypes from "prop-types"
import { svgNameSpace } from "@constants"

const Rating = ({
    className,
    svgClassName,
    ratingColor,
    ratingBackgroundColor,
    ratingValue,
    productId,
    constant
}) => {
    const starArray = useMemo(()=>Array(5)
        .fill(1)
        .map((element, index) => {
            if (ratingValue >= index && ratingValue <= index + 1)
                return (ratingValue - index)*100
            else if (ratingValue < index) return 0
            else return 100
        }),[ratingValue])
    return (
        <div className={`${className} flex`}>
            {starArray.map((element,index) => (
                <svg key={`${index}-${constant}`} className={svgClassName} xmlns={svgNameSpace} viewBox='0 0 30.094 28.804'>
                    {element!==100?(<linearGradient id={`grad-${productId}-${index}-${constant}`}>
                        <stop offset='0%'  stopColor={ratingColor} />
                        <stop offset={`${element}%`}  stopColor={ratingColor} />
                        <stop offset='0%' stopColor={ratingBackgroundColor} />
                    </linearGradient>):null}
                    <path
                        d='M14.874,1,11.2,8.449l-8.218,1.2a1.8,1.8,0,0,0-1,3.071l5.946,5.794L6.526,26.7a1.8,1.8,0,0,0,2.61,1.9l7.352-3.864,7.352,3.864a1.8,1.8,0,0,0,2.61-1.9l-1.406-8.185,5.946-5.794a1.8,1.8,0,0,0-1-3.071l-8.218-1.2L18.1,1a1.8,1.8,0,0,0-3.229,0Z'
                        transform='translate(-1.441 0.001)'
                        fill={element!==100?`url(#grad-${productId}-${index}-${constant})`:ratingColor}
                    />
                </svg>))}
        </div>
    )
}

Rating.propTypes = {
    className: PropTypes.string,
    svgClassName: PropTypes.string,
    ratingColor: PropTypes.string,
    ratingBackgroundColor: PropTypes.string,
    ratingValue: PropTypes.number,
    productId: PropTypes.string,
    constant:PropTypes.string
}

Rating.defaultProps = {
    className: "",
    svgClassName: "",
    ratingColor: "#0c457c",
    ratingBackgroundColor: "#c8d8f4",
    ratingValue: 0,
    productId:'123456789',
    constant:'default'
}

export default memo(Rating)