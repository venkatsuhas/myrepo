import React from 'react'
import { shallow } from 'enzyme'
import Typography from '..'

const dummyContent = `
This is dummy data
![altText](//images.ctfassets.net/${process.env.CF_SPACE_ID}/testImage.jpg)
![](//images.ctfassets.net/${process.env.CF_SPACE_ID}/testImage.jpg)
![](testImage.jpg)
![No Source Image]()

[![altText](//images.ctfassets.net/${process.env.CF_SPACE_ID}/testImage.jpg) extra data](https://ca.crest.com)
[![](//images.ctfassets.net/${process.env.CF_SPACE_ID}/testImage.jpg) extra data](https://ca.crest.com)
[extra data](https://ca.crest.com)
[<br/>](https://ca.crest.com)
<br/>
`

describe('Typography component', () => {
    let wrapper
    
    it('should render the component that has been passed without content', () => {
        const props = {
            component: 'span',
        }
        wrapper = shallow(<Typography {...props} />)
        expect(wrapper).toBeTruthy()
    })
    
    it('should render the component that has been passed with content and br_allowed is false', () => {
        const props = {
            component: 'span',
            className: 'test',
            content: dummyContent, 
            br_allowed : false
        }
        wrapper = shallow(<Typography {...props} />)
        expect(wrapper).toBeTruthy()
    })
    
    it('should render the component that has been passed with content and br_allowed is true', () => {
        const props = {
            component: 'span',
            className: 'test',
            content: dummyContent, 
            br_allowed : true
        }
        wrapper = shallow(<Typography {...props} />)
        expect(wrapper).toBeTruthy()
    })
})
