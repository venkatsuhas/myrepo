# Release to operations - URLs

## URLs for Environments

| Environment  |                                            URL                                                        |
| -------------| ----------------------------------------------------------------------------------------------------- |
| Production   | [https://prod-ca.crest.com](https://prod-ca.crest.com)                                                |
| Canary       | [https://crest-ca-en-prod-canary.azurewebsites.net](https://crest-ca-en-prod-canary.azurewebsites.net)|
| Preview      | [https://preview-ca.crest.com](https://preview-ca.crest.com)                                          |
| Staging      | [https://stage-ca.crest.com](https://stage-ca.crest.com)                                              |
| Development  | [https://dev-ca.crest.com](https://dev-ca.crest.com)                                                  |
