# Release to operations - Stakeholder Contact Details

## Stakeholder Contacts

| Topics            | Vendor         | Point of Contact                                     |
| ----------------- | -------------- | ---------------------------------------------------- |
| Brand             | P&G            | Kerry James  <james.k@pg.com>                        |
| Creative Agency   | PGOne          | Claire Standridge <claire.standridge@saatchi.com>    |
| Technical Agency  | Mindtree       | Alex Xavier <alex.xavier@mindtree.com>               |
| SEO               | Mindtree       | Sabitha Chittibabu <Sabitha.Chittibabu@mindtree.com> |