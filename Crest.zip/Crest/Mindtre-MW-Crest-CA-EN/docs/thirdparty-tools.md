# Release to operations - Third Party Details

## Thirdparty tools used

| Thirdparty tool      | Production      | Dev                | Details |
| -------------------- | --------------- | ------------------ | ------- |
| Algolia              | ```{ PRODUCT_INDEX:"crest_ca_prod_product", ARTICLE_INDEX: "crest_ca_prod_article" }``` | ```{ PRODUCT_INDEX:"crest_ca_dev_product", ARTICLE_INDEX: "crest_ca_dev_article" }``` | ```{ WRITE_KEY: "06a0e9d37ed0b1f2a4429837a628c52d", READ_KEY: "c44429703888cb8bb2e5ca83d51e84dc", APP_ID:"CF2Y2BS7NE" }``` |
| BuyNow               ||| ```{ ClientId: "1766", WidgetId: "610acdfc56f66e001f1ebbb9" }``` |
| BazaarVoice          | ```{ EN_CA: "s8nyq8wqtrjzv5wksgfxzyjx", FR_CA: "fpun2xyg55kzhfv5kexepwcr" }``` |  ```{ EN_CA: "2grb6urjrum4szorsyyv5l9vn", FR_CA: "2bsks7lxy9t81h0cd53ksfqn5" }``` |||
| Contentful           ||| ```{ "Space ID": "kyl4ub5sv0it" }``` |
| Cloudinary           ||| ```{ "Folder" : "Crest_CA_MW" }```  |
