import React from 'react';
import './App.css';

import AppBar from "../src/components/NavBar";
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      {/* <Login/> */}
      {/* <Register/> */}
      <AppBar/>
    </div>
  );
}

export default App;
