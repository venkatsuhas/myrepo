import axios from "axios"
import* as Constants from "../reducers/constants"

class MovieService{
    getMmovies=async(dispatch:any)=>{
        let response =await axios.get('http://localhost:8080/api/movies');
        dispatch({type:Constants.GET_MOVIES,payload:response.data});
        return response;
    }
    getMovieById=async (dispatch:any,id:any)=>{
        let response =await axios.get('http://localhost:8080/api/movies/'+id);
        dispatch({type:Constants.GET_MOVIE_BY_ID,payload:response.data});
         return response;
    }
    searchMovies=async(dispatch:any,searchText:any)=>{
        let response =await axios.get('http://localhost:8080/api/movies/containing/'+searchText);
        dispatch({type:Constants.GET_SEARCHED_MOVIES,payload:response.data});
        return response;
    }
    addToFavourites=async(dispatch:any,favParams:any)=>{
        let response =await axios.patch('http://localhost:8080/api/movies/favourites',favParams);
        dispatch({type:Constants.ADD_TO_FAV,payload:response.data});
        return response; 
    }
    userFavourites=async(dispatch:any,id:any)=>{
        console.log("userid in service",id);
        
        let response =await axios.get('http://localhost:8080/api/movies/myfavourites/'+id);
        console.log("fav response from server--",response);
        
        dispatch({type:Constants.USER_FAV,payload:response.data});
        return response; 
    }
    searchUsersMovies=async(dispatch:any,name:any)=>{
        let response =await axios.get('http://localhost:8080/api/movies/userfavourites/'+name);
        dispatch({type:Constants.USERS_FAV,payload:response.data});
        return response;  
    }
}

export default MovieService;