import React from 'react'

function IF(props:any) {
    console.log("props",props.condition);
    
    // return (
    //     <div>
    //         {props.condition?<>{props.children}</>:null}
    //     </div>
    // )
    if(props.condition){
        return (props.children);
    }
}

export default IF
