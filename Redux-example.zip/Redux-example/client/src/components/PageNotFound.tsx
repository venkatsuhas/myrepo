import React from 'react'

function PageNotFound() {
    return (
        <div  className="page-not-found">
            <img src="https://media.istockphoto.com/vectors/error-page-not-found-website-banner-vector-id654971856?k=6&m=654971856&s=612x612&w=0&h=vhEqSbb2hVtxvackiu2z8k-Ac5NlYPfzWgQRYY_9FEg="></img>
        </div>
    )
}

export default PageNotFound
