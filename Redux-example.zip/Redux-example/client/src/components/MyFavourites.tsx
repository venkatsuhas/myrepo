import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, Route } from 'react-router-dom'
import serviceProvider from "../services/movie-services"
function MyFavourites() {
    const id=useSelector((state:any)=>state.user.user.id);
    console.log("id in my favs",typeof(id));
    
    const dispatch = useDispatch()
    const services=new serviceProvider();
    useEffect(() => {
        services.userFavourites(dispatch,id);
    }, [])
    const myFavs=useSelector((state:any)=>state.movies.favouriteMovies);
    return (
        <div>
            <div className="row row-cols-1 row-cols-md-6 g-4">
    {myFavs.map(function (movie: any) {
        return (
            <div className="col">
               <Link to={"/movie/"+movie.imdbID}>
               <div className="card">
                    <img src={movie.Poster} className="card-img-top" alt="..." />
                </div>
               </Link>
               <Route path={"/movie/"+movie.imdbID}></Route>
            </div>
        )
    })}
</div>
        </div>
    )
}

export default MyFavourites
