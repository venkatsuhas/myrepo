import * as Constants from "./constants";

export const promiseResolver = (store: any) => (next: any) => (action: any) => {
  if (action.payload instanceof Promise) {
    // it the payload is a promise

    store.dispatch({
      type: Constants.Status, // as specified in problem statement
      payload: {
        status: "pending", // as spec. in problem stat.
        action: action.type,
        message: "Resolving",
      },
    });

    action.payload // when the promise is resolved
      .then((res: any) => {
        store.dispatch({
          type: action.type, // type of action that was dispatched  //  "REG_USER" from the problem statement
          payload: res.data, // whatever the result from the response
        });
        store.dispatch({
          type: Constants.Status, //as sepc. in problem stat.
          payload: {
            status: "done", //as sepc. in problem stat.
            action: action.type, // type of action that was dispatched  //  "REG_USER" lem statement
            message: "Resolved",
          },
        });
      })
      .catch(
        (
          error: any // if the promise is rejected
        ) =>
          store.dispatch({
            type: Constants.Status, //as sepc. in problem stat.
            payload: {
              status: "error", //as sepc. in problem stat.
              action: action.type,
              message: error.response.data.message, // type of action that was dispatched  //  "Add_Movie" in problem statement
            },
          })
      );
  } else {
    next(action); //pass to next middleware if I don't want to handle it
  }
};
