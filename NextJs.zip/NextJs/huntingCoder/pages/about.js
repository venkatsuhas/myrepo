import React from 'react'
import styles from '../styles/about.module.css'


const About = () => {
  return (
    <div className={styles.container}>
      <h1>About Hunting Coders</h1>
      <h2>Introduction</h2>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit, architecto esse. Tempora, nam quasi aliquam soluta eum quis, quod ex excepturi rem, illo molestias libero dolor accusamus provident dolore sequi eveniet doloribus cupiditate cumque temporibus? Veniam voluptatum ullam, laudantium atque eveniet pariatur eaque accusantium? Nisi natus quis necessitatibus porro dignissimos maxime a autem earum illo odit laborum quisquam veniam veritatis reiciendis vitae, blanditiis ex hic voluptatum tempore iure nesciunt voluptatibus?</p>
      <h2>Services Offered</h2>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo, quod dolor est rem numquam neque perspiciatis modi esse, eos odio sunt voluptate velit. Earum reprehenderit, explicabo et quasi quis ad! Ipsa error adipisci, quae distinctio fugiat quis repellat minima at.</p>

      <p>We offered the following services</p>
      <ul>
        <li>service 1</li>
        <li>service 2</li>
        <li>service 3</li>
        <li>service 4</li>
        <li>service 5</li>

      </ul>

      <h2>Contact Us</h2>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, laborum aut excepturi aliquam enim, fugit earum mollitia nobis, accusantium doloremque vitae! Expedita enim itaque consectetur, et sit placeat voluptatem error?</p>
    </div>
  )
}

export default About