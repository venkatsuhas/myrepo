import React, { useEffect, useState } from 'react'
// import Index from './index.js'
import styles from '../styles/blog.module.css'
import Link from 'next/link'
import * as fs from "fs";
// import InfiniteScroll from 'react-infinite-scroll-component';



const Blogs = (props) => {
  const [blogs, setBlogs] = useState(props.allBlogs)
  
  return (
    <div className={styles.container}>
    <main className={styles.main}>
      {blogs.map((item)=>{
        return <div key={item.slug} className={styles.blogItem}>
        <Link href={`/blogpost/${item.slug}`}>
        <h3>{item.title}</h3></Link>
        <p>{item.metadesc.substr(0,200)}....</p>
        <Link href={`/blogpost/${item.slug}`}><button type="submit" className={styles.btn}>Read more</button></Link>
      </div>
      })}
    </main>
  </div>
  )
}

export async function getStaticProps(context) {
  let data =await fs.promises.readdir("blogdata")
    let myfile;
    let allBlogs=[]
    for (let index = 0; index < data.length; index++) {
        const ele = data[index];
        myfile = await fs.promises.readFile(("blogdata/"+ele),'utf-8')
        allBlogs.push(JSON.parse(myfile))
    }
  return {
    props: {allBlogs}, // will be passed to the page component as props
  }
}

// export async function getServerSideProps(context) {
//   let data = await fetch('http://localhost:3000/api/blog')
//   let allBlogs = await data.json();
//   return {
//     props: {allBlogs}, // will be passed to the page component as props
//   }
// }

export default Blogs