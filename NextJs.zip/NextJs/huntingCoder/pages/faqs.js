import React,{useState} from 'react'
import styles from '../styles/contact.module.css'


const ContactUs = () => {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [desc, setDesc] = useState("")


  const handleSubmit = (e)=>{
    e.preventDefault();
    let data = {name,email,phone,desc}
    fetch('http://localhost:3000/api/contact/',{
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
      },
      method: 'POST'
    })
  .then((response) => response.json())
  .then(() => {
    alert("Posted Successful")
    setDesc("")
    setEmail("")
    setName("")
    setPhone("")
  });
  }

  const handleChange = (e) =>{
    if(e.target.name=="name")
    setName(e.target.value)
    else if(e.target.name=="email")
    setEmail(e.target.value)
    else if(e.target.name=="phone")
    setPhone(e.target.value)
    else if(e.target.name=="desc")
    setDesc(e.target.value)
  }

  return (
    <form className={styles.container} onSubmit={handleSubmit} >
  <div className={styles.mb3}>
    <label htmlFor="name" className={styles.lable}>Name:</label>
    <input id="name" name="name" type="name" value={name} onChange={handleChange} className={styles.input}  aria-describedby="emailHelp"/>
  </div>
  <div className={styles.mb3}>
    <label htmlFor="email" className={styles.lable}>Email address:</label>
    <input id="email" name="email"  type="email" value={email} onChange={handleChange} className={styles.input} aria-describedby="emailHelp"/>
    <div id="emailHelp" className={styles.formtext}>We'll never share your email with anyone else.</div>
  </div>
  <div className={styles.mb3}>
    <label htmlFor="phone" className={styles.lable}>Phone no:</label>
    <input name="phone"  type="phone" value={phone} onChange={handleChange} className={styles.input} id="phone" required/>
  </div>
  <div className={styles.mb3}>
  <label htmlFor="desc" className={styles.lable}>Enter your Concerns:</label>
  <textarea name="desc" value={desc} onChange={handleChange} className={styles.input}  id="desc" required></textarea>
  </div>
  <button type="submit" className={styles.btn}>Submit</button>
</form>
  )
}

export default ContactUs