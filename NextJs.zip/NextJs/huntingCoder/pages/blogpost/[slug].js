import React ,{useEffect,useState}from 'react'
// import {useRouter} from 'next/router'
import styles from '../../styles/blogPost.module.css'
import * as fs from "fs";



const Slug = (props) => {
// const router = useRouter();
function createMarkup(d) {
  return {__html:d};
}
const [blog, setBlog] = useState(props.myBlogs)

  return (
    <div className={styles.container}>
      <main className={styles.main}>
      <h2>Documentation for {blog.title}</h2>
      {/* <hr /> */}
      {blog && <div className={styles.desc} dangerouslySetInnerHTML={createMarkup(blog.description)}></div>}
        {/* {blog && blog.description} */}
      
      </main>
    </div>
  )
}

export async function getStaticPaths() {
  let d = await fs.promises.readdir(`blogdata`)
  d=d.map((item)=>{
    return {params:{slug:item.split(".")[0]}}
  })

  return {
    paths: d,
    fallback: false, // can also be true or 'blocking'
  }
}

// `getStaticPaths` requires using `getStaticProps`
export async function getStaticProps(context) {
  let {slug} = context.params;
  let data = await fs.promises.readFile(`blogdata/${slug}.json`,'utf-8')
  // let myBlogs = await data.json()
  return {
    // Passed to the page component as props
    props: { myBlogs:JSON.parse(data) },
  }
}

// export async function getServerSideProps(context) {
//   let {slug} = context.query;
//   let data = await fetch(`http://localhost:3000/api/getblog?slug=${slug}`)
//   let myBlogs = await data.json();
//   return {
//     props: {myBlogs}, // will be passed to the page component as props
//   }
// }

export default Slug